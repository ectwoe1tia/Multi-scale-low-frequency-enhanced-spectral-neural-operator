package com.bydauto.yunfan.agent;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.audit.*;
import com.bydauto.yunfan.agent.chat.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.governance.*;
import com.bydauto.yunfan.agent.modelconfig.*;
import com.bydauto.yunfan.agent.runtime.*;
import com.bydauto.yunfan.agent.session.*;
import com.bydauto.yunfan.agent.skill.*;
import com.bydauto.yunfan.agent.tooling.*;
import com.bydauto.yunfan.agent.data.*;
import java.nio.file.Path;
import java.util.*;
public final class AppServices implements AutoCloseable {
    public final Config config;
    public final DocumentStore store;
    public final AuthService auth;
    public final AuditService audit;
    public final SessionStore sessions;
    public final ModelConfigService models;
    public final ModelClientFactory clients;
    public final SkillService skills;
    public final SkillRegistry skillRegistry;
    public final GovernanceService governance;
    public final McpRegistry mcp;
    public final com.bydauto.yunfan.agent.process.ProcessSupervisor processes;
    public final SkillExecutionService skillExecution;
    public final ToolExecutionService tools;
    public final DataWorkspace data;
    public final DataTools dataTools;
    public final ToolResultPolicy resultPolicy;
    public final AgentRunService runs;
    public final ApiRouter router;
    public AppServices(Config config) {
        this(config,new ModelClientFactory(config));
    }
    public AppServices(Config config,ModelClientFactory clients) {
        this.config=config;
        auth=new AuthService(config);
        String jdbc=config.get("yunfan.store.jdbc-url","");
        store=jdbc.isBlank()?new FileDocumentStore(Path.of(config.get("yunfan.store.directory","data"))):new JdbcDocumentStore(jdbc,config.get("yunfan.store.jdbc-user",""),config.secret(config.get("yunfan.store.jdbc-password-ref","")));
        audit=new AuditService(store);
        sessions=new SessionStore(store,auth);
        models=new ModelConfigService(store,auth,config);
        this.clients=clients;
        SkillEmbeddingService embeddings=new SkillEmbeddingService(config);
        skills=new SkillService(store,auth,embeddings);
        skillRegistry=new SkillRegistry(skills,embeddings,config);
        governance=new GovernanceService(store,auth);
        processes=new com.bydauto.yunfan.agent.process.ProcessSupervisor(config);
        skillExecution=new SkillExecutionService(store,auth,processes);
        mcp=new McpRegistry(store,auth,new McpConnection(auth,processes),models);
        data=new DataWorkspace(store,config);
        dataTools=new DataTools(data,config);
        resultPolicy=new ToolResultPolicy(data);
        tools=new ToolExecutionService(store,auth,mcp,new BuiltinTools(store,governance,config,dataTools),audit,skillExecution,resultPolicy);
        seed();
        runs=new AgentRunService(store,auth,sessions,models,clients,skillRegistry,tools,audit,config);
        router=new ApiRouter(this);
    }
    private void seed() {
        if(!Set.of("local","test").contains(config.get("yunfan.profile","local"))||!config.bool("yunfan.demo.enabled",true))return;
        AuthContext actor=new AuthContext("local","developer",Set.of("*"),"bootstrap");
        if(models.list(actor).isEmpty()) {
            String base=config.get("yunfan.model.base-url","");
            Map<String,Object> m=Json.map("name",base.isBlank()?"本地演示模型":"默认真实模型","provider",base.isBlank()?"mock":"openai","baseUrl",base,"modelName",config.get("yunfan.model.name","demo"),"credentialRef",config.get("yunfan.model.credential-ref",""),"capabilities",Json.map("streaming",true,"toolCalling",true,"reasoning",config.bool("yunfan.model.reasoning",false)),"options",Json.map("contextChars",32000));
            Map<String,Object> saved=models.save(actor,null,m);
            models.action(actor,saved.get("id").toString(),"default");
        }
        if(skills.list(actor).isEmpty())skills.save(actor,null,"---\nname: process-governance\ndescription: 流程治理、采购审批检查、整改待办创建与查询\nallowedTools: [governance__check, todo__create, todo__list]\ntriggerExamples: [检查采购流程并创建待办, 流程治理, 创建整改待办]\npriority: 10\n---\n先获取流程快照并检查，返回规则问题和证据；需要整改时生成待办草案，通过确认后执行。实际创建结果以工具返回为准。\n");
        if(governance.rules(actor).isEmpty())for(String handler:new TreeSet<>(GovernanceService.HANDLERS))governance.saveRule(actor,null,Json.map("name",handler,"handler",handler,"severity","WARNING","enabled",true));
    }
    @Override public void close() {
        runs.close();
        mcp.close();
        processes.close();
        store.close();
    }
}
