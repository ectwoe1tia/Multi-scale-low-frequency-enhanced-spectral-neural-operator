package com.bydauto.yunfan.agent.data;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.function.Consumer;

/** Large results live in bounded, private disk artifacts, never in chat memory or events. */
public final class DataWorkspace {
    public record Table(List<Map<String,Object>> rows,String completeness,Long reportedTotal) {}
    private final DocumentStore store;
    private final Path root;
    private final int maxRows,maxBytes,ttl;
    public DataWorkspace(DocumentStore store,Config config) {
        this.store=store;root=Path.of(config.get("yunfan.data.directory",config.get("yunfan.store.directory","data")+"/artifacts")).toAbsolutePath().normalize();
        maxRows=config.integer("yunfan.data.max-rows",100000);maxBytes=config.integer("yunfan.data.max-bytes",32*1024*1024);ttl=config.integer("yunfan.data.ttl-hours",24);
        if(maxRows<1||maxRows>1000000||maxBytes<1024||maxBytes>128*1024*1024||ttl<1||ttl>720)throw new IllegalArgumentException("Invalid data workspace limits");
        try{Files.createDirectories(root);if(Files.isSymbolicLink(root))throw new IOException("Linked artifact root");}catch(IOException e){throw new IllegalStateException(e);}
    }
    public int maxRows(){return maxRows;}
    public int maxBytes(){return maxBytes;}
    public Object legacy(AuthContext actor,String id){var old=store.get("tool-result",id);if(old==null||!actor.tenantId().equals(old.get("tenantId"))||!actor.userId().equals(old.get("userId")))return null;return old.get("result");}
    public static Table table(Object value) {return table(value,0);}
    private static Table table(Object value,int depth) {
        if(depth>6)return null;
        if(value instanceof String s){if(s.stripLeading().startsWith("{")||s.stripLeading().startsWith("["))try{return table(Json.parse(s),depth+1);}catch(ApiException ignored){}return null;}
        if(value instanceof List<?> list){
            if(list.isEmpty())return new Table(List.of(),"UNKNOWN",null);
            if(list.stream().allMatch(v->v instanceof Map<?,?>))return new Table(list.stream().map(Json::object).toList(),"UNKNOWN",null);
            if(list.stream().allMatch(v->v==null||v instanceof String||v instanceof Number||v instanceof Boolean))return new Table(list.stream().map(v->Json.map("value",v)).toList(),"UNKNOWN",null);
            return null;
        }
        if(!(value instanceof Map<?,?>))return null;
        var m=Json.object(value);
        if(Boolean.TRUE.equals(m.get("isError")))return null;
        if(m.containsKey("structuredContent")){Table found=table(m.get("structuredContent"),depth+1);if(found!=null)return found;}
        if(m.get("content") instanceof List<?> blocks){
            List<Table> found=new ArrayList<>();for(Object block:blocks)if(block instanceof Map<?,?> b&&"text".equals(b.get("type"))){Table t=table(b.get("text"),depth+1);if(t!=null)found.add(t);}
            if(found.size()==1)return found.get(0);if(!found.isEmpty())return null;
        }
        List<Table> found=new ArrayList<>();
        for(String key:List.of("rows","records","items","data","result","results"))if(m.containsKey(key)){
            Object child=m.get(key);
            if(child instanceof List<?> rows&&!rows.isEmpty()&&rows.get(0) instanceof List<?> &&m.get("columns") instanceof List<?> columns){
                List<String> names=columns.stream().map(c->c instanceof Map<?,?>?Json.required(Json.object(c),"name"):c.toString()).toList();
                if(new HashSet<>(names).size()!=names.size())throw ApiException.bad("Duplicate table columns");
                List<Map<String,Object>> mapped=new ArrayList<>();for(Object row:rows){var cells=Json.array(row);if(cells.size()!=names.size())throw ApiException.bad("Table column/row mismatch");Map<String,Object> object=Json.map();for(int i=0;i<names.size();i++)object.put(names.get(i),cells.get(i));mapped.add(object);}child=mapped;
            }
            Table candidate=table(child,depth+1);if(candidate!=null)found.add(candidate);
        }
        if(found.size()!=1)return null;
        Table candidate=found.get(0);Long total=null;for(String key:List.of("total","totalCount"))if(m.get(key) instanceof Number n){total=n.longValue();break;}
        String completeness=candidate.completeness();
        if(Boolean.FALSE.equals(m.get("complete"))||Boolean.TRUE.equals(m.get("hasMore"))||Boolean.TRUE.equals(m.get("truncated"))||m.get("nextCursor")!=null||total!=null&&total>candidate.rows().size())completeness="PARTIAL";
        else if(!"PARTIAL".equals(completeness)&&(Boolean.TRUE.equals(m.get("complete"))||total!=null&&total==candidate.rows().size()))completeness="COMPLETE";
        return new Table(candidate.rows(),completeness,total==null?candidate.reportedTotal():total);
    }
    public synchronized Map<String,Object> capture(AuthContext actor,String run,String source,Object value) {
        Table t=table(value);
        if(t!=null)return saveRows(actor,run,source,t.rows().iterator(),t.completeness(),t.reportedTotal());
        String id=Util.id();byte[] bytes=Json.write(value).getBytes(StandardCharsets.UTF_8);if(bytes.length>maxBytes)throw limit("Result exceeds artifact size limit");
        capacity(actor);write(id,bytes);
        Map<String,Object> metadata=metadata(actor,id,run,source,"blob");metadata.put("bytes",bytes.length);try{store.put("data-artifact",id,metadata);}catch(RuntimeException e){delete(file(id));throw e;}return reference(metadata);
    }
    public synchronized Map<String,Object> saveRows(AuthContext actor,String run,String source,Iterator<Map<String,Object>> rows,String completeness,Long total) {
        capacity(actor);String id=Util.id();Path tmp=file(id+".tmp");Map<String,Object> fields=new LinkedHashMap<>();int count=0;long bytes=0;
        boolean capped=false;
        try(OutputStream raw=Files.newOutputStream(tmp,StandardOpenOption.CREATE_NEW);BufferedOutputStream out=new BufferedOutputStream(raw)){
            while(rows.hasNext()){
                if(count>=maxRows){capped=true;break;}if(Thread.currentThread().isInterrupted())throw new IOException("Cancelled");
                Map<String,Object> row=rows.next();if(row.size()>256)throw limit("Too many columns");
                for(var e:row.entrySet()){
                    if(e.getKey().length()>128)throw limit("Column name too long");Object v=e.getValue();String type=v==null?"null":v instanceof Number?"number":v instanceof Boolean?"boolean":v instanceof String?"string":"json";
                    if(!fields.containsKey(e.getKey())||"null".equals(fields.get(e.getKey())))fields.put(e.getKey(),type);
                    else if(v!=null&&!fields.get(e.getKey()).equals(type))fields.put(e.getKey(),"mixed");
                }
                if(fields.size()>256)throw limit("Too many union columns");byte[] line=(Json.write(row)+"\n").getBytes(StandardCharsets.UTF_8);
                if(line.length>1024*1024||bytes+line.length>maxBytes)throw limit("Dataset size limit exceeded; narrow the query or aggregate at source");
                out.write(line);bytes+=line.length;count++;
            }
        }catch(IOException|RuntimeException e){delete(tmp);if(e instanceof RuntimeException r)throw r;throw new ApiException(503,"DATA_STORAGE_FAILED","Cannot save dataset");}
        try{Files.move(tmp,file(id),StandardCopyOption.ATOMIC_MOVE);}catch(IOException e){delete(tmp);throw new ApiException(503,"DATA_STORAGE_FAILED","Atomic dataset commit failed");}
        Map<String,Object> m=metadata(actor,id,run,source,"dataset");m.put("rowCount",count);m.put("fields",fields);m.put("bytes",bytes);m.put("completeness",capped?"PARTIAL":completeness);m.put("reportedTotal",total);m.put("rowLimitReached",capped);
        try{store.put("data-artifact",id,m);}catch(RuntimeException e){delete(file(id));throw e;}return reference(m);
    }
    private Map<String,Object> metadata(AuthContext actor,String id,String run,String source,String kind){return Json.map("id",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"runId",run,"source",source,"kind",kind,"createdAt",Util.now(),"expiresAt",Instant.now().plusSeconds(ttl*3600L).toString());}
    public Map<String,Object> owned(AuthContext actor,String id){
        Map<String,Object> m=store.get("data-artifact",id);if(m==null||!actor.tenantId().equals(m.get("tenantId"))||!actor.userId().equals(m.get("userId")))throw ApiException.missing("dataset");
        if(!Instant.parse(Json.required(m,"expiresAt")).isAfter(Instant.now()))throw new ApiException(410,"DATA_EXPIRED","Data reference expired; rerun an authorized read query");return m;
    }
    public Map<String,Object> reference(Map<String,Object> m){
        boolean table="dataset".equals(m.get("kind"));Map<String,Object> out=Json.map("kind",table?"dataset_ref":"artifact_ref","dataRef",m.get("id"),"stored",true,"expiresAt",m.get("expiresAt"));
        if(table){List<Object> fields=new ArrayList<>();Json.child(m,"fields").entrySet().stream().limit(12).forEach(e->fields.add(Json.map("name",e.getKey(),"type",e.getValue())));out.putAll(Json.map("rowCount",m.get("rowCount"),"completeness",m.get("completeness"),"reportedTotal",m.get("reportedTotal"),"columnCount",Json.child(m,"fields").size(),"fields",fields,"scope","Statistics cover captured rows only; UNKNOWN/PARTIAL is not a full-source result","nextTools",List.of("data__schema","data__aggregate","data__page","data__export")));}
        else out.putAll(Json.map("bytes",m.get("bytes"),"downloadUrl","/api/data/artifacts/"+m.get("id"),"note","Opaque result stored without a text preview. Configure a structured table result at source."));
        if(Json.write(out).length()>2400)out.remove("fields");return out;
    }
    public void scan(AuthContext actor,String id,Consumer<Map<String,Object>> action){
        Map<String,Object> m=owned(actor,id);if(!"dataset".equals(m.get("kind")))throw ApiException.bad("Reference is not a dataset");
        try(BufferedReader reader=Files.newBufferedReader(file(id),StandardCharsets.UTF_8)){String line;while((line=reader.readLine())!=null){if(Thread.currentThread().isInterrupted())throw new IOException("Cancelled");action.accept(Json.object(Json.parse(line)));}}
        catch(IOException e){throw new ApiException(503,"DATA_READ_FAILED","Cannot read dataset");}
    }
    public synchronized Map<String,Object> export(AuthContext actor,String run,String source,String suffix,WriterAction action){
        capacity(actor);String id=Util.id();Path tmp=file(id+".tmp");
        try(OutputStream raw=Files.newOutputStream(tmp,StandardOpenOption.CREATE_NEW);OutputStream bounded=new FilterOutputStream(raw){long size;public void write(int b)throws IOException{if(++size>maxBytes)throw new IOException("Export size limit");out.write(b);}public void write(byte[] b,int off,int len)throws IOException{if((size+=len)>maxBytes)throw new IOException("Export size limit");out.write(b,off,len);}}){action.write(bounded);}
        catch(Exception e){delete(tmp);if(e instanceof ApiException a)throw a;throw new ApiException(422,"EXPORT_FAILED","Export failed or exceeded size limit");}
        try{Files.move(tmp,file(id),StandardCopyOption.ATOMIC_MOVE);var m=metadata(actor,id,run,source,"export");m.put("bytes",Files.size(file(id)));m.put("filename","export-"+id+"."+suffix);store.put("data-artifact",id,m);return Json.map("artifactId",id,"filename",m.get("filename"),"bytes",m.get("bytes"),"downloadUrl","/api/data/artifacts/"+id,"expiresAt",m.get("expiresAt"));}
        catch(IOException|RuntimeException e){delete(tmp);delete(file(id));throw new ApiException(503,"DATA_STORAGE_FAILED","Cannot commit export");}
    }
    @FunctionalInterface public interface WriterAction {void write(OutputStream output)throws Exception;}
    public byte[] download(AuthContext actor,String id){owned(actor,id);try{return Files.readAllBytes(file(id));}catch(IOException e){throw ApiException.missing("artifact file");}}
    private Path file(String id){if(!id.matches("[a-zA-Z0-9-]{1,100}(\\.tmp)?"))throw ApiException.bad("Invalid data reference");Path p=root.resolve(id);if(Files.isSymbolicLink(p))throw ApiException.bad("Linked artifact forbidden");return p;}
    private void write(String id,byte[] bytes){try{Files.write(file(id+".tmp"),bytes,StandardOpenOption.CREATE_NEW);Files.move(file(id+".tmp"),file(id),StandardCopyOption.ATOMIC_MOVE);}catch(IOException e){delete(file(id+".tmp"));throw new ApiException(503,"DATA_STORAGE_FAILED","Cannot save artifact");}}
    private void capacity(AuthContext actor){long bytes=0;int count=0;for(var m:store.list("data-artifact"))if(actor.tenantId().equals(m.get("tenantId"))&&actor.userId().equals(m.get("userId"))){
        if(!Instant.parse(Json.required(m,"expiresAt")).isAfter(Instant.now())){delete(file(Json.required(m,"id")));store.transaction(tx->{tx.delete("data-artifact",Json.required(m,"id"));return null;});}
        else{count++;bytes+=((Number)m.getOrDefault("bytes",0)).longValue();}}
        if(count>=100||bytes+maxBytes>256L*1024*1024)throw limit("Per-user artifact quota reached; wait for expiry or narrow queries");}
    private static ApiException limit(String message){return new ApiException(413,"DATA_LIMIT",message);}
    private static void delete(Path p){try{Files.deleteIfExists(p);}catch(IOException ignored){}}
}
