package com.bydauto.yunfan.agent.modelconfig;
import com.bydauto.yunfan.agent.common.*;
import java.util.Map;
public final class ModelClientFactory {
    private final Config config;
    private final java.util.function.Function<Map<String,Object>,ModelClient> adapter;
    public ModelClientFactory(Config config) {
        this(config,null);
    }
    public ModelClientFactory(Config config,java.util.function.Function<Map<String,Object>,ModelClient> adapter) {
        this.config=config;
        this.adapter=adapter;
    }
    public ModelClient create(Map<String,Object> model) {
        return Json.str(model,"provider","openai").equals("mock")?new MockModelClient():adapter==null?new OpenAiModelClient(model,config):adapter.apply(model);
    }
}
