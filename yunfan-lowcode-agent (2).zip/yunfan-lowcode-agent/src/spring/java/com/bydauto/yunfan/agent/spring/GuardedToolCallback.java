package com.bydauto.yunfan.agent.spring;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.data.ToolResultPolicy;
import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.ai.tool.metadata.ToolMetadata;
import java.util.Map;
import java.util.function.Supplier;

/** Drop-in boundary for an existing Spring AI/MCP ToolCallback. READ tools only: writes use Agent confirmations. */
public final class GuardedToolCallback implements ToolCallback {
    public record Scope(AuthContext actor,String runId) {}
    private final ToolCallback delegate;private final ToolResultPolicy policy;private final Supplier<Scope> scope;private final AuthorizationPolicy authorization;
    public GuardedToolCallback(ToolCallback delegate,ToolResultPolicy policy,Supplier<Scope> scope,AuthorizationPolicy authorization,String deploymentRisk){
        if(!"READ".equals(deploymentRisk))throw new IllegalArgumentException("Use the guarded Agent runtime for WRITE/HIGH_RISK tools");
        this.delegate=delegate;this.policy=policy;this.scope=scope;this.authorization=authorization;
    }
    public ToolDefinition getToolDefinition(){return delegate.getToolDefinition();}
    public ToolMetadata getToolMetadata(){return delegate.getToolMetadata();}
    public String call(String input){return call(input,null);}
    public String call(String input,ToolContext context){Scope current=scope.get();if(current==null)throw new ApiException(401,"UNAUTHENTICATED","Server-bound invocation scope required");
        authorization.check(current.actor(),"tool:"+getToolDefinition().name(),Json.map("tenantId",current.actor().tenantId(),"userId",current.actor().userId()));
        Object result=delegate.call(input,context);try{result=Json.parse(result.toString());}catch(ApiException ignored){}
        return Json.write(policy.modelView(current.actor(),current.runId(),getToolDefinition().name(),result,false));
    }
}
