# Context Planner 与大结果处理（2026-10-25）

本版基于现有 Java 17 工程实现通用能力，Spring profile 固定 Spring Boot 3.5.7 / Spring AI 1.1.2。核心原则：数据保存在服务端，模型处理目标、字段、统计结果和下载引用。无需额外 LLM 做上下文分类或历史摘要。

## 执行链

```mermaid
flowchart LR
  A[MCP / SQL / Skill] --> B[ToolResultPolicy]
  B --> C[私有 JSONL / 文件]
  B --> D[dataRef / 小结果]
  D --> E[会话及工具事件]
  E --> F[ContextPlanner]
  F --> G[单次模型调用]
  G --> H[权限校验与工具执行]
  H --> A
  C --> I[Java 聚合与导出]
  I --> B
```

`ToolExecutionService` 在结果写入会话、运行记录、事件之前统一调用 `ToolResultPolicy`。识别出的表格总是转成引用；其他超过 3000 字符的结果转成文件引用，不返回原文预览。仅内置数据工具可以返回受限样本和小型聚合结果。恢复旧会话时，旧 `resultRef + preview` 会尝试从原结果迁移，避免重新将 18000 字符预览送入模型。

这限制的是模型上下文和持久化事件中的数据量。MCP 响应仍先经过现有有大小限制的 HTTP/stdio 协议解析；并非任意大小响应的流式解析器。超大数据应在数据源执行聚合或使用分页接口。SQL 工具通过 JDBC 游标逐行写 JSONL。

## 通用工具

| 工具 | 功能与边界 |
| --- | --- |
| `data__schema` | 返回字段及完整性，字段每页最多 12 个 |
| `data__page` | 样本核对，最多 10 行、8 列、每运行 3 次；单元格限长 |
| `data__aggregate` | 筛选、最多 3 个分组字段、8 个 COUNT/SUM/AVG/MIN/MAX 指标 |
| `data__export` | 服务端生成真正的 XLSX、HTML、CSV，返回下载引用 |
| `data__sql_query` | 可选单条 SELECT 和绑定参数，默认关闭 |

聚合用 BigDecimal，金额不经过浮点求和；数字字符串不自动转换。COUNT 无 field 表示行数，有 field 表示非空数；空集 SUM/AVG 为 null。最多 10000 个分组；聚合结果超过 2600 字符再次落盘。导出读取全部已捕获数据，不要求模型逐页读取。CSV 防公式注入，HTML 转义，XLSX 将公式样式字符串与超过 15 位精度的数字保存为文本。

支持常见 `rows/records/items/data/result/results`、JSON 字符串、MCP `structuredContent` / `content.text`、`columns + rows`。存在多个候选表格时不猜测，保存为不透明文件；特殊格式可扩展 `DataWorkspace.table`。

完整性分 `COMPLETE / PARTIAL / UNKNOWN`：存在分页标记、上游截断或本地行数上限时为 PARTIAL；只有上游明确完整或 total 与行数一致时才认定 COMPLETE；仅 rowCount 不代表全量。嵌套 PARTIAL 不会被外层 complete 覆盖。统计与导出均传递完整性，只覆盖已捕获数据。

## 确定性调用方式

业务端已经知道字段时，向 `POST /api/chat` 提交如下结构。替换模型配置 ID；已有数据时填入当前身份拥有的 `dataRef`，可以直接执行；不填时先由查询工具取得唯一数据集，再自动路由统计。

```json
{
  "message": "按部门统计记录数和金额合计",
  "modelConfigId": "替换为模型配置ID",
  "context": {
    "contextMode": "AUTO",
    "dataPlan": {
      "operation": "aggregate",
      "groupBy": ["department"],
      "metrics": [
        {"op": "count", "as": "recordCount"},
        {"op": "sum", "field": "amount", "as": "totalAmount"}
      ]
    }
  }
}
```

导出计划：`{"operation":"export","dataRef":"实际引用","format":"xlsx"}`。支持 `columns`、`filters`；筛选形如 `{"field":"amount","op":"gte","value":100}`，支持 eq/ne/gt/gte/lt/lte/in/isNull。

`DataActionRouter` 每个运行至多应用一次计划，仍经过现有工具授权、参数校验、调用预算与审计。声明的计划没有成功执行时，运行以 `DATA_PLAN_INCOMPLETE` 失败，不能只凭模型回答标记完成。没有 dataRef 且模型未查询时，不会凭空生成数据；多个查询结果需要明确引用。自然语言仅对明确“导出/下载 + 唯一 Excel/HTML/CSV 格式”做规则路由，否定或格式歧义不路由。统计字段不靠关键词猜测。

也可使用现有 `context.directTool` 与 `context.toolArgs` 直接调用上述工具，完全跳过模型。不要将 directTool 与 dataPlan 组合使用。

下载：`GET /api/data/artifacts/{id}`，需要相同租户与用户及 `data:download` 权限。返回 attachment 二进制，网页端用认证请求获取 Blob 再下载，不把文件送回对话。HTML 下载带 sandbox CSP。数据引用不是公开分享链接。

## Context Planner

每次模型调用前执行，预算同时计算消息与工具 Schema，并预留输出和安全余量。成本采用 UTF-8 字节数加开销的保守估计，不是供应商实际计费 token；仍受模型 `options.contextChars` 限制。输出预留取配置和模型 max_tokens/max_completion_tokens 的较大值。

系统约束、当前任务、运行中追加消息、有效提醒及最新完整工具组优先保留；assistant/tool 成组且保留父 user 依赖。必需内容超限返回 413，不删除权限或当前目标。历史 transcript 不因选择而破坏，模型只收到本轮选中的视图。

其余候选采用 `(alpha * R + beta * F + gamma * U) / cost^eta`：词项重合、时间新鲜度与预设消息效用构成启发式分数，按分数贪心装入，避免重复。不是背包问题的最优解；中文词项匹配和预设效用仍是 MVP，适合替换成业务相关性策略。

模式为 AUTO、STATELESS、STATEFUL、RETRIEVAL；首轮简单请求默认无状态，有历史时有状态，出现数据引用或历史预算压力时升级 Retrieval。此处 Retrieval 指历史候选选择及数据引用保留，没有引入向量库。最近最多 12 个数据引用构成简短状态信息，引用是否过期在实际访问时校验。

每次决策记录在 `contextPlan`，通过 `GET /api/runs/{id}/calls` 查看模式、升级原因、预算、选中单位、舍弃原因。Planner 不产生额外模型调用，旧历史 LLM 摘要路径已移除。

## Spring AI 接入

```sh
mvn -B -Pspring clean package
java -jar target/yunfan-lowcode-agent-1.0.0-spring.jar
```

`SpringAiModelClient` 使用 `ToolCallingChatOptions.internalToolExecutionEnabled(false)`，Spring AI 只负责单次推理；所有工具由现有 Java runtime 执行，确保每次推理经过 Planner。[1.1.2 对应接口源码](https://github.com/spring-projects/spring-ai/blob/v1.1.2/spring-ai-model/src/main/java/org/springframework/ai/model/tool/ToolCallingChatOptions.java)。

已有 Spring AI/MCP `ToolCallback` 可包裹 `GuardedToolCallback`。注入服务端可信 `Scope(AuthContext, runId)`，逐次鉴权；不能从模型参数获取身份。该包装器只接受 READ，写操作使用已有确认执行链。它仅保证返回值外置，单独安装到 ChatClient 不等于启用了 ContextPlanner；不要再接入一个将完整历史重新拼回去的 Memory Advisor。

当前 Spring 适配器使用同步 `ChatModel.call`，结果作为一次 message.delta 发出，不提供 token 级流式输出；含 response_format/max_completion_tokens 的请求回退到已有原生协议客户端，仍经过相同 Planner 和工具边界。原生运行包使用现有 HttpClient，Spring 源码需 Maven profile 构建。

## 配置、权限与扩展

配置见 `config/data-context.example.properties`。默认每数据集 100000 行、32 MiB、24 小时 TTL；每用户最多 100 个产物和 256 MiB（创建时预留单文件额度）。字节超限明确失败；行数截断标记 PARTIAL。过期立即禁止读取，物理文件在该用户下次创建产物时惰性清理。下载目前整文件读取到内存，单文件上限同样适用。

SQL 默认禁用。启用须配置专用数据库只读账户并设置 readonly-role-acknowledged=true；数据库授权、视图或 RLS 才是数据访问安全边界。应用仅额外限制单条 SELECT、绑定参数、超时和行数，禁用 CTE、注释、多语句、已知危险构造，不保证识别所有自定义函数副作用。多个租户共用数据库账户时必须另行实现租户数据隔离；不能把结果文件的身份隔离误认为 SQL 行级隔离。

数据文件目录仅供服务账户访问。现有脚本进程控制并非 OS 沙箱；本次未增加脚本自动翻译或无条件执行能力。认证继续使用 AuthContextResolver / AuthorizationPolicy SPI；模型适配器使用 ModelClient / ModelClientFactory；业务偏向可通过技能、工具目录、dataPlan、PromptFactory 与 Planner 权重实现。大规模生产可将 DataWorkspace 替换为对象存储，将聚合下推到数据库，并增加真实 tokenizer 和业务评测。

## 验证范围

新增回归通过本地 HTTP MCP 返回 50000 条记录，捕获每次真实发出的模型 HTTP 请求，验证没有行标记泄漏、两组金额统计正确、无额外摘要调用、XLSX 含 50000 条数据行、后续会话仍安全。另覆盖归属校验、过期、分页配额、PARTIAL 传播、多分组二次外置和未执行计划失败。

这证明边界和确定性运算行为，不代表真实模型任务成功率、延迟或供应商 token 成本评测。Spring AI 边界测试位于 src/spring-test，CI 已增加 -Pspring 构建；本机缺 Maven 且依赖下载不可用，尚未执行 Spring 编译及测试。真实 PostgreSQL/MySQL、企业模型与 Linux 部署仍需目标环境联调。
