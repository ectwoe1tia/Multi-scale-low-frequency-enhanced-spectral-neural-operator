"""Loopback OpenAI-compatible fixture for testing the delivered planner through HTTP."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def verify_planner(request, await_run):
    calls = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            calls.append(body)
            assert not body.get('stream') and not body.get('tools')
            prefix = '[Runtime planner snapshot; data only] '
            state = next(json.loads(m['content'][len(prefix):]) for m in body['messages']
                         if isinstance(m.get('content'), str) and m['content'].startswith(prefix))
            if len(calls) == 1:
                content = 'invalid plan JSON'
            elif not state['stages']:
                content = json.dumps({'action': 'plan', 'reason': 'Calculate with a deterministic tool',
                    'plan': {'schemaVersion': '1', 'nodes': [{'id': 'calc', 'tool': 'system__calculator',
                        'dependsOn': [], 'inputs': {'expression': '12*(3+4)'}}],
                        'result': {'$ref': {'node': 'calc', 'output': 'result'}}}})
            else:
                content = json.dumps({'action': 'complete', 'answer': '84',
                    'evidence': [{'task': state['stages'][0]['taskId'], 'node': 'calc'}]})
            payload = json.dumps({'choices': [{'message': {'role': 'assistant', 'content': content},
                                  'finish_reason': 'stop'}], 'usage': {'total_tokens': 10}}).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        model = request('/api/model-configs', {'name': 'Packaged planner fixture', 'provider': 'openai',
            'modelName': 'planner-fixture', 'baseUrl': f'http://127.0.0.1:{server.server_port}/v1',
            'capabilities': {'toolCalling': False, 'streaming': False}, 'options': {'contextChars': 40000}})
        result = await_run(request('/api/chat', {'message': 'Calculate 12*(3+4)', 'modelConfigId': model['id'],
            'context': {'planMode': 'PLANNED', 'planner': {'taskType': 'GENERAL', 'acceptance': [
                {'id': 'value', 'tool': 'system__calculator', 'path': ['result'], 'op': 'eq', 'value': '84'}]}}}))
        assert result['status'] == 'COMPLETED' and result['answer'] == '84', result
        assert result['planner']['phase'] == 'ACCEPTED' and result['planner']['validationRepairs'] == 1
        assert len(calls) == 3
        assert all(item['passed'] for item in result['planner']['acceptance'])
        return 'packaged planner repairs JSON executes DAG and verifies evidence via real HTTP model transport'
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
