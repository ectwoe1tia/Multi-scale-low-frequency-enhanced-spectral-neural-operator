param([string]$Since = '7 days ago')
$ErrorActionPreference = 'Stop'
$project = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$registration = Join-Path $project 'docs\release\发版登记.csv'
if (Test-Path -LiteralPath $registration) { Import-Csv -LiteralPath $registration -Encoding UTF8 }
if (Get-Command git -ErrorAction SilentlyContinue) {
    & git -C $project rev-parse --is-inside-work-tree 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { & git -C $project log "--since=$Since" '--format=%h %ad %s' '--date=short' '--' '.' }
}
