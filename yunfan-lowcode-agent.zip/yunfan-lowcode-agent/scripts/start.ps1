param([string]$ConfigFile = '', [string]$JavaHome = $env:JAVA_HOME)
$ErrorActionPreference = 'Stop'
$project = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$javaTool = if ($JavaHome) { Join-Path $JavaHome 'bin\java.exe' } else { (Get-Command java).Source }
$jar = Join-Path $project 'yunfan-lowcode-agent-1.0.0.jar'
if (-not (Test-Path -LiteralPath $jar)) { $jar = Join-Path $project 'target\yunfan-lowcode-agent-1.0.0.jar' }
$arguments = @()
if ($ConfigFile) { $arguments += "-Dyunfan.config=$([IO.Path]::GetFullPath($ConfigFile))" }
$arguments += @('-cp', "$jar;$(Join-Path $project 'lib\*')", 'com.bydauto.yunfan.agent.YunfanLowcodeAgentApplication')
& $javaTool @arguments
exit $LASTEXITCODE
