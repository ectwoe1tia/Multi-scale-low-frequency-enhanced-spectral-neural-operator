param([string]$JavaHome = $env:JAVA_HOME, [switch]$SkipTests)
$ErrorActionPreference = 'Stop'
$project = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if ($JavaHome -and (Test-Path -LiteralPath (Join-Path $JavaHome 'bin\javac.exe'))) {
    $compiler = Join-Path $JavaHome 'bin\javac.exe'
    $jarTool = Join-Path $JavaHome 'bin\jar.exe'
    $javaTool = Join-Path $JavaHome 'bin\java.exe'
} else {
    $compiler = (Get-Command javac).Source
    $jdkBin = Split-Path -Parent $compiler
    $jarTool = Join-Path $jdkBin 'jar.exe'
    $javaTool = Join-Path $jdkBin 'java.exe'
}
$classes = Join-Path $project 'target\classes'
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$sources = @(Get-ChildItem -LiteralPath (Join-Path $project 'src\main\java') -Recurse -Filter '*.java' | ForEach-Object { '"' + $_.FullName.Replace('\','/') + '"' })
$arguments = Join-Path $project 'target\sources.args'
[IO.File]::WriteAllLines($arguments, $sources, [Text.UTF8Encoding]::new($false))
& $compiler --release 17 -encoding UTF-8 -d $classes "@$arguments"
if ($LASTEXITCODE -ne 0) { throw 'Java compilation failed' }
Copy-Item -Path (Join-Path $project 'src\main\resources\*') -Destination $classes -Recurse -Force
if (-not $SkipTests) {
    $testClasses = Join-Path $project 'target\test-classes'
    New-Item -ItemType Directory -Force -Path $testClasses | Out-Null
    $tests = @(Get-ChildItem -LiteralPath (Join-Path $project 'src\test\java') -Recurse -Filter '*.java' | ForEach-Object { '"' + $_.FullName.Replace('\','/') + '"' })
    if ($tests.Count -gt 0) {
        $testArguments = Join-Path $project 'target\tests.args'
        [IO.File]::WriteAllLines($testArguments, $tests, [Text.UTF8Encoding]::new($false))
        & $compiler --release 17 -encoding UTF-8 -cp $classes -d $testClasses "@$testArguments"
        if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed' }
        & $javaTool -ea -cp "$classes;$testClasses" com.bydauto.yunfan.agent.AgentTestSuite
        if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
    }
}
$jarPath = Join-Path $project 'target\yunfan-lowcode-agent-1.0.0.jar'
& $jarTool --create --file $jarPath --main-class com.bydauto.yunfan.agent.YunfanLowcodeAgentApplication -C $classes .
if ($LASTEXITCODE -ne 0) { throw 'JAR packaging failed' }
Write-Output "Built Java 17 bytecode: $jarPath"
