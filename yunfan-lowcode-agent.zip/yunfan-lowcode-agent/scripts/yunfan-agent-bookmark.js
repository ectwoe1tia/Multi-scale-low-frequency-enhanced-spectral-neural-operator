// Browser bookmark helper: no credentials are placed in URLs or local storage.
(() => {
  const address = prompt('Agent 服务地址', 'http://127.0.0.1:8080');
  if (!address) return;
  const url = new URL(address);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('仅支持 HTTP/HTTPS');
  url.username = '';
  url.password = '';
  url.search = '';
  url.hash = '';
  window.open(url.href, '_blank', 'noopener,noreferrer');
})();
