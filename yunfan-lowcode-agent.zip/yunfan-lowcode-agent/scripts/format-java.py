"""Dependency-free layout pass for project Java sources; only changes whitespace outside literals/comments."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]

def format_source(source):
    output, line = [], []
    indent, index = 0, 0
    parens = []
    def emit():
        text = ''.join(line).strip()
        if text:
            output.append('    ' * indent + text)
        line.clear()
    while index < len(source):
        char = source[index]
        if source.startswith('//', index):
            end = source.find('\n', index)
            if end < 0:
                end = len(source)
            if line and not ''.join(line).endswith(' '):
                line.append(' ')
            line.append(source[index:end]); emit(); index = end
        elif source.startswith('/*', index):
            end = source.find('*/', index + 2)
            if end < 0:
                raise ValueError('Unterminated comment')
            emit()
            for part in source[index:end+2].splitlines():
                output.append('    ' * indent + part.strip())
            index = end + 2
        elif char in ('"', "'"):
            quote = char; end = index + 1
            while end < len(source):
                if source[end] == '\\':
                    end += 2
                elif source[end] == quote:
                    end += 1; break
                else:
                    end += 1
            line.append(source[index:end]); index = end
        elif char == '{':
            if line and not ''.join(line).endswith(' '):
                line.append(' ')
            line.append('{'); emit(); indent += 1; index += 1
        elif char == '}':
            emit(); indent = max(0, indent - 1); line.append('}'); index += 1
            following = source[index:].lstrip()
            if not following.startswith((')', ';', ',', 'else', 'catch', 'finally')):
                emit()
        elif char == ';':
            line.append(';')
            if any(parens):
                line.append(' ')
            else:
                emit()
            index += 1
        elif char == '(':
            previous = re.search(r'([A-Za-z_$][A-Za-z0-9_$]*)\s*$', source[:index])
            parens.append(bool(previous and previous.group(1) == 'for'))
            line.append(char); index += 1
        elif char == ')':
            if parens:
                parens.pop()
            line.append(char); index += 1
        elif char in '\r\n\t ':
            if line and not ''.join(line).endswith(' '):
                line.append(' ')
            index += 1
        else:
            line.append(char); index += 1
    emit()
    return '\n'.join(output) + '\n'

if __name__ == '__main__':
    for tree in ('src/main/java', 'src/test/java', 'src/spring/java'):
        for path in (root / tree).rglob('*.java'):
            path.write_text(format_source(path.read_text(encoding='utf-8')), encoding='utf-8')
