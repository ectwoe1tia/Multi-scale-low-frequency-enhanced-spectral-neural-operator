#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p target/classes target/test-classes
find src/main/java -name '*.java' > target/sources.args
javac --release 17 -encoding UTF-8 -d target/classes @target/sources.args
cp -R src/main/resources/. target/classes/
find src/test/java -name '*.java' > target/tests.args
javac --release 17 -encoding UTF-8 -cp target/classes -d target/test-classes @target/tests.args
java -ea -cp target/classes:target/test-classes com.bydauto.yunfan.agent.AgentTestSuite
jar --create --file target/yunfan-lowcode-agent-1.0.0.jar --main-class com.bydauto.yunfan.agent.YunfanLowcodeAgentApplication -C target/classes .
