"""Regenerate the static OpenAPI document. Python is only a development utility, not a server dependency."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
paths = {}
routes = [
    ('/api/me', 'get', '当前身份'),
    ('/api/chat', 'post', '非流式对话'),
    ('/api/chat/stream', 'post', 'POST SSE 对话'),
    ('/api/runs/{id}', 'get', '运行状态与最终结果'),
    ('/api/runs/{id}/events', 'get', '按序号回放与订阅 SSE'),
    ('/api/runs/{id}/cancel', 'post', '取消运行'),
    ('/api/runs/{id}/input', 'post', '提交澄清输入'),
    ('/api/confirmations/{id}/decision', 'post', '确认或拒绝绑定的操作'),
    ('/api/sessions', 'get post', '会话列表 / 新建'),
    ('/api/sessions/{id}', 'get patch delete', '会话详情 / 修改 / 删除'),
    ('/api/sessions/{id}/messages', 'get', '消息分页'),
    ('/api/skills', 'get post', '技能列表 / 创建'),
    ('/api/skills/{id}', 'get put delete', '技能详情 / 更新 / 删除'),
    ('/api/skills/import', 'post', '导入技能 ZIP'),
    ('/api/skills/{id}/enable', 'post', '启用技能'),
    ('/api/skills/{id}/disable', 'post', '停用技能'),
    ('/api/skills/{id}/reindex', 'post', '重新生成技能向量'),
    ('/api/model-configs', 'get post', '模型列表 / 创建'),
    ('/api/model-configs/{id}', 'get put delete', '模型详情 / 更新 / 删除'),
    ('/api/model-configs/{id}/test', 'post', '测试模型连接'),
    ('/api/model-configs/{id}/default', 'post', '设置默认模型'),
    ('/api/model-configs/{id}/enable', 'post', '启用模型'),
    ('/api/model-configs/{id}/disable', 'post', '停用模型'),
    ('/api/admin/mcp/servers', 'get post', 'MCP 服务列表 / 注册'),
    ('/api/admin/mcp/servers/{id}', 'put delete', '更新 / 删除 MCP 服务'),
    ('/api/admin/mcp/tools', 'get', '当前身份可见的 MCP 工具目录'),
    ('/api/admin/mcp/reload', 'post', '刷新 MCP 工具目录'),
    ('/api/governance/checks', 'post', '创建结构化治理运行'),
    ('/api/governance/rules', 'get post', '治理规则列表 / 创建'),
    ('/api/governance/rules/{id}', 'put delete', '更新 / 删除治理规则'),
    ('/api/governance/reports', 'get', '治理报告列表'),
    ('/api/governance/reports/{id}', 'get', '治理报告详情'),
    ('/api/todos', 'get post', '本服务待办列表 / 经确认创建'),
    ('/api/tool-executions', 'get', '工具执行记录'),
    ('/api/tool-executions/{id}/reconcile', 'post', '记录人工核对的外部执行结果'),
    ('/api/tool-results/{id}', 'get', '受控读取大工具结果'),
    ('/api/admin/audits', 'get', '审计查询'),
    ('/api/admin/metrics', 'get', '当前租户运行统计'),
]
string = {'type': 'string'}
obj = {'type': 'object', 'additionalProperties': True}
schemas = {
    'ChatRequest': {'type': 'object', 'required': ['message'], 'properties': {
        'requestId': string, 'sessionId': string, 'message': {'type':'string','minLength':1,'maxLength':60000},
        'modelConfigId': string, 'skillIds': {'type':'array','items':string}, 'context': obj,
        'responseFormat': {'type':'object','description':'可选 json_object / json_schema；模型需声明 structuredOutput 能力','properties':{'type':{'enum':['json_object','json_schema']},'json_schema':obj}},
    }},
    'Decision': {'type':'object','required':['decision','version'],'additionalProperties':False,'properties':{'decision':{'enum':['APPROVE','REJECT']},'version':{'type':'integer','minimum':1}}},
    'ModelInput': {'type':'object','required':['name','modelName'],'properties':{'name':string,'provider':{'enum':['openai','mock']},'modelName':string,'baseUrl':string,'credentialRef':{'type':'string','description':'仅环境变量名，不能传明文密钥'},'enabled':{'type':'boolean'},'capabilities':obj,'options':obj}},
    'SkillInput': {'type':'object','required':['markdown'],'properties':{'markdown':string}},
    'GovernanceCheck': {'type':'object','properties':{'requestId':string,'modelConfigId':string,'processId':string,'process':obj,'instances':{'type':'array','items':obj}}},
    'Reconciliation': {'type':'object','required':['resolution','evidence'],'properties':{'resolution':{'enum':['SUCCEEDED','NOT_EXECUTED','FAILED']},'evidence':string,'externalOperationId':string}},
    'Envelope': {'type':'object','required':['code','message','data','traceId'],'properties':{'code':string,'message':string,'data':{},'traceId':string}},
    'AgentEvent': {'type':'object','required':['runId','seq','type','payload'],'properties':{'runId':string,'seq':{'type':'integer'},'type':string,'timestamp':{'type':'string','format':'date-time'},'payload':{}}},
}
for path, methods, summary in routes:
    for method in methods.split():
        operation = {'summary':summary,'operationId':method+'_'+path.strip('/').replace('/','_').replace('{','').replace('}','').replace('-','_'), 'responses':{}}
        parameters = []
        if '{id}' in path:
            parameters.append({'name':'id','in':'path','required':True,'schema':string})
        if method=='get' and path.endswith('/events'):
            parameters.append({'name':'afterSeq','in':'query','schema':{'type':'integer','minimum':0,'default':0}})
        elif method=='get' and '{id}' not in path and path!='/api/me':
            parameters.extend([{'name':'offset','in':'query','schema':{'type':'integer','minimum':0,'default':0}}, {'name':'limit','in':'query','schema':{'type':'integer','minimum':1,'maximum':200,'default':50}}])
        if parameters:
            operation['parameters'] = parameters
        content = {'application/json':{'schema':{'$ref':'#/components/schemas/Envelope'}}}
        if path.endswith('/stream') or path.endswith('/events'):
            content = {'text/event-stream':{'schema':{'type':'string'},'example':'id: run:1\nevent: run.started\ndata: {"runId":"run","seq":1,"type":"run.started","payload":{}}\n\n'}}
        operation['responses']['200']={'description':'成功；运行结果可能为等待输入或确认','content':content}
        if method=='post':
            operation['responses']['202']={'description':'运行已创建或继续，使用 runId 查询状态','content':{'application/json':{'schema':{'$ref':'#/components/schemas/Envelope'}}}}
            operation['responses']['201']={'description':'资源已创建','content':{'application/json':{'schema':{'$ref':'#/components/schemas/Envelope'}}}}
        for status, desc in [('400','输入无效'),('401','身份缺失'),('403','无权限'),('404','资源不存在'),('409','并发、版本或运行状态冲突'),('410','事件已过期'),('422','工具参数或模型能力不匹配'),('429','并发或模型限流'),('500','内部异常'),('502','下游调用失败')]:
            operation['responses'][status]={'description':desc,'content':{'application/json':{'schema':{'$ref':'#/components/schemas/Envelope'}}}}
        if method in ('post','put','patch'):
            name='ChatRequest' if path.startswith('/api/chat') else 'Decision' if path.endswith('/decision') else 'ModelInput' if path.startswith('/api/model-configs') and (path=='/api/model-configs' or path=='/api/model-configs/{id}') else 'SkillInput' if path in ('/api/skills','/api/skills/{id}') else 'GovernanceCheck' if path.endswith('/governance/checks') else 'Reconciliation' if path.endswith('/reconcile') else None
            schema={'$ref':'#/components/schemas/'+name} if name else obj
            if path.endswith('/input'):
                schema={'type':'object','required':['message'],'properties':{'message':string}}
            operation['requestBody']={'required':bool(name or path.endswith('/input')),'content':{'application/json':{'schema':schema}}}
            if path=='/api/skills/import':
                operation['requestBody']={'required':True,'content':{'application/zip':{'schema':{'type':'string','format':'binary'}}}}
        paths.setdefault(path,{})[method]=operation
spec={'openapi':'3.0.3','info':{'title':'Yunfan Agent API','version':'1.0.0','description':'JDK 17 Agent 与流程治理后端。local/test 为开发身份；生产通过 Auth SPI。SSE done 结束一次输出段，WAITING_* 仍需继续当前运行。'},'servers':[{'url':'http://127.0.0.1:8080'}],'security':[{'bearerAuth':[]}],'paths':paths,'components':{'securitySchemes':{'bearerAuth':{'type':'http','scheme':'bearer'}},'schemas':schemas}}
(root/'src/main/resources/openapi.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Generated OpenAPI:', len(paths), 'paths')
