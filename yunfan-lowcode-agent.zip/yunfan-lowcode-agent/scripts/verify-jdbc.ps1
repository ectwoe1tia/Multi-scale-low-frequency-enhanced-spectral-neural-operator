param([string]$JavaHome = $env:JAVA_HOME)
$ErrorActionPreference = 'Stop'
$project = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$javaTool = if ($JavaHome) { Join-Path $JavaHome 'bin\java.exe' } else { (Get-Command java).Source }
if (-not $env:YUNFAN_TEST_JDBC_URL) { throw 'Set YUNFAN_TEST_JDBC_URL, YUNFAN_TEST_JDBC_USER and YUNFAN_TEST_JDBC_PASSWORD first; apply the migration and put the driver JAR in lib/.' }
& $javaTool -cp "$(Join-Path $project 'target\classes');$(Join-Path $project 'target\test-classes');$(Join-Path $project 'lib\*')" com.bydauto.yunfan.agent.JdbcStoreContractTest
if ($LASTEXITCODE -ne 0) { throw 'JDBC contract failed' }
