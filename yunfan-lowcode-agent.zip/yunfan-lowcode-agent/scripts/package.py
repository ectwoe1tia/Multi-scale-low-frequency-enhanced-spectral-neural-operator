"""Create source/runtime ZIPs without credentials or locally generated business state."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[1]
dist = root / 'dist'
dist.mkdir(exist_ok=True)
jar = root / 'target/yunfan-lowcode-agent-1.0.0.jar'
if not jar.exists():
    raise SystemExit('Build and test the JAR before packaging.')
report = root / 'target/verification-results.json'
if not report.exists() or json.loads(report.read_text(encoding='utf-8'))['failed'] != 0:
    raise SystemExit('A successful verification-results.json is required.')

source_dirs = ('src', 'scripts', 'docs', 'config', 'examples', 'sql', 'deploy')
top_files = ('README.md', 'pom.xml', 'Dockerfile', 'gitlab-ci.yml', '.gitlab-ci.yml', '.dockerignore', '.gitignore')
verification = [report]
smoke = root / 'target/package-smoke-results.json'
if smoke.exists():
    verification.append(smoke)

with zipfile.ZipFile(dist / 'yunfan-lowcode-agent-1.0.0-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for directory in source_dirs:
        for path in sorted((root / directory).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                archive.write(path, 'yunfan-lowcode-agent/' + path.relative_to(root).as_posix())
    for name in top_files:
        archive.write(root / name, 'yunfan-lowcode-agent/' + name)
    for path in verification:
        archive.write(path, 'yunfan-lowcode-agent/target/' + path.name)

with zipfile.ZipFile(dist / 'yunfan-lowcode-agent-1.0.0-runtime.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    prefix = 'yunfan-lowcode-agent-runtime/'
    archive.write(jar, prefix + jar.name)
    archive.write(root / 'README.md', prefix + 'README.md')
    for directory in ('docs', 'config', 'examples', 'sql', 'deploy'):
        for path in sorted((root / directory).rglob('*')):
            if path.is_file():
                archive.write(path, prefix + path.relative_to(root).as_posix())
    for name in ('start.ps1', 'start.sh'):
        archive.write(root / 'scripts' / name, prefix + 'scripts/' + name)
    archive.writestr(prefix + 'lib/README.txt', 'Place production Auth SPI adapter JARs and optional JDBC driver JARs here. Use scripts/start.* to load lib/*.jar.\n')
    archive.write(root / 'src/main/resources/openapi.json', prefix + 'openapi.json')
    for path in verification:
        archive.write(path, prefix + path.name)

checksums = []
for path in sorted(dist.glob('*.zip')):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise SystemExit('Corrupted archive: ' + path.name)
    checksums.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name)
(dist / 'SHA256SUMS.txt').write_text('\n'.join(checksums) + '\n', encoding='utf-8')
print('\n'.join(checksums))
