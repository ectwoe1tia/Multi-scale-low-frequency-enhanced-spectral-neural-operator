#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
JAR=yunfan-lowcode-agent-1.0.0.jar
[ -f "$JAR" ] || JAR=target/yunfan-lowcode-agent-1.0.0.jar
if [ "${YUNFAN_CONFIG:-}" ]; then
  exec java "-Dyunfan.config=$YUNFAN_CONFIG" -cp "$JAR:lib/*" com.bydauto.yunfan.agent.YunfanLowcodeAgentApplication
fi
exec java -cp "$JAR:lib/*" com.bydauto.yunfan.agent.YunfanLowcodeAgentApplication
