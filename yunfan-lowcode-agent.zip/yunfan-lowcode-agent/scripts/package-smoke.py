"""Launch the extracted runtime ZIP and exercise its public API. Uses only the Python standard library."""
from pathlib import Path
import json
import os
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import zipfile

root = Path(__file__).resolve().parents[1]
passed = []
java = os.environ.get('YUNFAN_VERIFY_JAVA', 'java')
with tempfile.TemporaryDirectory(prefix='package-smoke-', dir=root / 'target') as temporary:
    directory = Path(temporary)
    assert directory.resolve().is_relative_to((root / 'target').resolve())
    archive = root / 'dist/yunfan-lowcode-agent-1.0.0-runtime.zip'
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
        package.extractall(directory)
    runtime = directory / 'yunfan-lowcode-agent-runtime'
    jar = runtime / 'yunfan-lowcode-agent-1.0.0.jar'
    with zipfile.ZipFile(jar) as contents:
        classes = [name for name in contents.namelist() if name.endswith('.class')]
        assert classes and all(int.from_bytes(contents.read(name)[6:8], 'big') == 61 for name in classes)
    passed.append('all packaged classes target Java 17 (major 61)')
    with socket.socket() as port_socket:
        port_socket.bind(('127.0.0.1', 0))
        port = port_socket.getsockname()[1]
    base = f'http://127.0.0.1:{port}'
    # Ignore host proxy configuration for loopback-only verification requests.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    command = [java, '-Dyunfan.profile=test', '-Dyunfan.http.port=' + str(port), '-Dyunfan.store.directory=' + str(directory / 'state'), '-jar', str(jar)]
    process = None
    log = (directory / 'service.log').open('wb')

    def request(path, body=None, raw=False, method=None):
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode('utf-8')
        req = urllib.request.Request(base + path, data=data, headers={'Content-Type': 'application/json'}, method=method)
        with opener.open(req, timeout=20) as response:
            text = response.read().decode('utf-8')
        if raw:
            return text
        value = json.loads(text)
        return value['data'] if 'data' in value else value

    def start_service():
        proc = subprocess.Popen(command, cwd=runtime, stdout=log, stderr=log,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        end = time.monotonic() + 15
        while time.monotonic() < end:
            if proc.poll() is not None:
                raise AssertionError('Packaged service exited; inspect log')
            try:
                if request('/actuator/health')['status'] == 'UP':
                    return proc
            except (OSError, urllib.error.URLError):
                time.sleep(.1)
        proc.terminate()
        raise AssertionError('Service startup timed out')

    def await_run(run):
        end = time.monotonic() + 15
        while time.monotonic() < end:
            run = request('/api/runs/' + run['id'])
            if run['status'] not in ('CREATED', 'RUNNING'):
                return run
            time.sleep(.05)
        raise AssertionError('Run timed out')

    try:
        process = start_service()
        passed.append('extracted runtime JAR starts independently')
        assert '联调台' in request('/', raw=True)
        assert 'appendMessage' in request('/', raw=True) and 'testMcp' in request('/', raw=True)
        passed.append('bundled integration page loads')
        api = request('/openapi.json')
        assert len(api['paths']) >= 42 and '/api/runs/{id}/context' in api['paths']
        assert 'McpServerSettings' in api['components']['schemas']
        passed.append('bundled OpenAPI document loads')
        body = {'requestId': 'packaged-calculation', 'message': '计算 12*(3+4)'}
        run = request('/api/chat', body)
        assert run['status'] == 'COMPLETED' and '84' in run['answer']
        assert request('/api/chat', body)['id'] == run['id']
        passed.append('ordinary agent tool task and idempotent retry')
        assert request('/api/runs/' + run['id'] + '/calls')['total'] >= 2
        passed.append('packaged model invocation chain is queryable')
        plan = {'schemaVersion': '1', 'nodes': [{'id': 'calc', 'tool': 'system__calculator',
                'dependsOn': [], 'inputs': {'expression': '12*(3+4)'}}],
                'result': {'$ref': {'node': 'calc', 'output': 'result'}}}
        assert request('/api/plans/validate', {'plan': plan})['valid']
        planned = await_run(request('/api/chat', {'message': '执行固定计划',
                            'context': {'executionPlan': plan, 'planMode': 'DIRECT'}}))
        assert planned['status'] == 'COMPLETED' and '84' in planned['answer']
        assert request('/api/runs/' + planned['id'] + '/calls')['total'] == 0
        assert any(s['status'] == 'COMPLETED' for s in request('/api/runs/' + planned['id'] + '/state'))
        passed.append('packaged DAG validates and executes without a model call')
        program = request('/api/programs', {'definition': {'name': 'Packaged calculator', 'plan': plan}})
        program_id = program['programId']
        executed = await_run(request('/api/programs/' + program_id + '/run', {'parameters': {}, 'requestId': 'packaged-program'}))
        assert executed['status'] == 'COMPLETED' and '84' in executed['answer']
        detail = request('/api/programs/' + program_id)
        assert detail['observations'][0]['toolCalls'] == 1 and detail['graph']['nodes'][0]['id'] == 'calc'
        passed.append('packaged program API creates executes and inspects measured results')
        revised = request('/api/programs/' + program_id + '/revise', {'definition': {'name': 'Revised calculator', 'reason': 'Keep equivalent fixture for version check', 'plan': plan}})
        assert revised['revision'] == 2 and revised['parentProgramId'] == program_id
        assert request('/api/programs/' + program_id)['name'] == 'Packaged calculator'
        passed.append('packaged program revisions preserve the baseline')
        memory = request('/api/memories', {'fact': '退款口径按订单数', 'source': 'package smoke'})
        assert any(m['id'] == memory['id'] for m in request('/api/memories'))
        assert request('/api/memories/' + memory['id'], method='DELETE')['deleted']
        passed.append('packaged persistent memory has an independent lifecycle')
        stream = request('/api/chat/stream', {'requestId': 'packaged-sse', 'message': '计算 6*7'}, raw=True)
        assert 'event: tool.completed' in stream and 'event: done' in stream and '42' in stream
        passed.append('POST SSE tool progress and final event')
        snapshot = json.loads((runtime / 'examples/process.json').read_text(encoding='utf-8'))
        check = await_run(request('/api/governance/checks', {'requestId': 'packaged-check', 'process': snapshot}))
        assert check['status'] == 'COMPLETED' and request('/api/governance/reports')['total'] >= 1
        passed.append('structured process governance and persisted report')
        todo = await_run(request('/api/todos', {'title': 'packaged todo', 'requestId': 'packaged-todo'}))
        assert todo['status'] == 'WAITING_CONFIRMATION'
        cid = todo['waitingReason']['confirmationId']
        request('/api/confirmations/' + cid + '/decision', {'decision': 'APPROVE', 'version': 1})
        assert await_run(todo)['status'] == 'COMPLETED'
        request('/api/confirmations/' + cid + '/decision', {'decision': 'APPROVE', 'version': 1})
        assert sum(t['title'] == 'packaged todo' for t in request('/api/todos')['items']) == 1
        passed.append('confirmed write creates exactly one persisted todo')
        waiting = request('/api/chat', {'requestId': 'packaged-wait', 'message': '澄清补充测试'})
        assert waiting['status'] == 'WAITING_INPUT'
        context_path = '/api/runs/' + waiting['id'] + '/context'
        addition = {'requestId': 'packaged-append', 'message': '新增要求：简短回答'}
        entry = request(context_path, addition)
        assert request(context_path, addition)['id'] == entry['id']
        cancelled = request(context_path, {'requestId': 'packaged-cancel-reminder', 'kind': 'REMINDER', 'message': '待撤销提醒', 'repeat': 3})
        assert request(context_path + '/' + cancelled['id'], method='DELETE')['status'] == 'CANCELLED'
        passed.append('packaged inbox append idempotency and reminder cancellation')
        process.terminate(); process.wait(timeout=10); process = start_service()
        assert request('/api/sessions')['total'] >= 1 and request('/api/todos')['total'] == 1
        passed.append('packaged service restart restores state')
        assert request('/api/programs/' + program_id)['programId'] == program_id
        passed.append('packaged program versions persist across restart')
        assert request(context_path)[0]['status'] == 'QUEUED'
        request('/api/runs/' + waiting['id'] + '/input', {'message': '补充完成'})
        assert await_run(waiting)['status'] == 'COMPLETED'
        assert request(context_path)[0]['status'] == 'APPLIED'
        passed.append('packaged restart preserves and delivers queued conversation')
        assert request('/api/admin/metrics')['toolCalls'] >= 4
        passed.append('operational metrics query')
    finally:
        if process is not None and process.poll() is None:
            process.terminate(); process.wait(timeout=10)
        log.close()

report = {'passed': len(passed), 'failed': 0, 'tests': passed, 'javaExecutable': Path(java).name,
          'createdAt': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
(root / 'target/package-smoke-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
