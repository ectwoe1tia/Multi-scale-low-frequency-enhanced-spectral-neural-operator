param([string]$JavaHome = $env:JAVA_HOME)
$ErrorActionPreference = 'Stop'
$project = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
Push-Location $project
try {
    $compiler = if ($JavaHome) { Join-Path $JavaHome 'bin/javac.exe' } else { (Get-Command javac).Source }
    $runner = Join-Path (Split-Path -Parent $compiler) 'java.exe'
    New-Item -ItemType Directory -Force -Path 'target/test-classes' | Out-Null
    & $compiler --release 17 -encoding UTF-8 -cp target/classes -d target/test-classes src/test/java/com/bydauto/yunfan/agent/PlannerTests.java
    if ($LASTEXITCODE -ne 0) { throw 'Planner test compilation failed' }
    & $runner -ea -cp 'target/classes;target/test-classes' com.bydauto.yunfan.agent.PlannerTests
    if ($LASTEXITCODE -ne 0) { throw 'Planner verification failed' }
} finally { Pop-Location }
