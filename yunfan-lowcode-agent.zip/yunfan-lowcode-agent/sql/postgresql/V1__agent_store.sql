-- PostgreSQL 14+. Run once using a migration account before starting the service.
CREATE TABLE IF NOT EXISTS agent_store_lock (
    lock_name VARCHAR(32) PRIMARY KEY
);
INSERT INTO agent_store_lock(lock_name) VALUES ('global'), ('service')
ON CONFLICT (lock_name) DO NOTHING;

-- Versioned domain documents; same transaction can update sessions/runs/events/confirmations.
-- Payload is text to preserve identical JSON number and time semantics across supported dialects.
CREATE TABLE IF NOT EXISTS agent_document (
    kind VARCHAR(64) NOT NULL,
    document_id VARCHAR(160) NOT NULL,
    payload TEXT NOT NULL,
    PRIMARY KEY(kind, document_id)
);
