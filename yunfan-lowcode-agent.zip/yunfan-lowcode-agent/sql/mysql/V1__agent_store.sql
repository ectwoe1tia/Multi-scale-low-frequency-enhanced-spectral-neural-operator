-- MySQL 8.0+, InnoDB. FOR UPDATE NOWAIT is required by the single-active-service lease.
CREATE TABLE IF NOT EXISTS agent_store_lock (
    lock_name VARCHAR(32) NOT NULL PRIMARY KEY
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
INSERT INTO agent_store_lock(lock_name) VALUES ('global'), ('service')
ON DUPLICATE KEY UPDATE lock_name=VALUES(lock_name);

CREATE TABLE IF NOT EXISTS agent_document (
    kind VARCHAR(64) NOT NULL,
    document_id VARCHAR(160) NOT NULL,
    payload LONGTEXT NOT NULL,
    PRIMARY KEY(kind, document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
