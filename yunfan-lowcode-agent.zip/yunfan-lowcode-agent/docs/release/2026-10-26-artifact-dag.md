# 2026-10-26 Artifact、Adapter/Filter 与 DAG

沿用 1.0.0 归档文件名。本日期标识本次实现更新。

- 新增可信部署工具契约、逻辑/协议 Schema 分离及输入输出 Adapter。
- 支持 Artifact HANDLE、旧 MCP 受限内部数组绑定、数据指纹与派生血缘、完整性传播。
- 新增运行过滤链与最终模型请求过滤，保护工具参数、历史、任务状态和公开事件。
- 新增 $ref 顺序 DAG、节点检查点、原有写入确认恢复、失败依赖阻断及阶段预算。
- 分离任务状态、临时模型上下文与显式持久事实；增加任务分类、元数据/删除接口与租约 GC。
- Spring 接入源码迁移至 2.1.0-M1 / Boot 4.2.0-M2，Maven 构建尚未验证。

运行包为已测试的原生 Java JAR，Spring 接入需在具备依赖访问的环境构建。验证以附带报告为准；编译使用 JDK 18 的 --release 17，尚无 Linux/JDK 17 实机或真实企业模型/数据库验收。

使用方式与限制见 [Artifact 与 DAG 接入说明](../implementation/Artifact与DAG接入说明.md)。
