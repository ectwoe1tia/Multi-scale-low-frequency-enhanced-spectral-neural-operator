# 2026-10-25 大结果处理与 Context Planner

沿用 1.0.0 文件名，本日期标识增强版本。

- 统一工具结果边界：表格落盘并返回 dataRef，取消大段预览；历史结果在模型调用前再次清理。
- 新增字段查询、受限样本、确定性聚合、XLSX/HTML/CSV 导出和可选只读 SQL。
- 新增规则优先 ContextPlanner，固定保留任务和约束，按预算选择完整消息组，移除额外历史摘要模型调用。
- 新增结构化 dataPlan 路由、明确格式导出路由和声明计划未执行成功检查。
- Spring profile 引入 Spring AI 1.1.2，禁用内部工具循环，提供现有 ToolCallback 的结果外置包装器。

195 项核心测试通过，包含 50000 行真实本地 HTTP MCP 往返；在 JDK 18.0.2.1 上以 --release 17 编译。Spring Maven 构建、真实数据库及企业模型验收尚未执行。运行包包含经过验证的原生 JAR，Spring 适配器在源码包中。

详见 [设计及使用说明](../design/ContextPlanner与数据工具.md)。
