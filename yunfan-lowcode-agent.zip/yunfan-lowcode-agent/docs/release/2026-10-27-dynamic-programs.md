# 2026-10-27 动态 Plan 程序交付

增加不可变程序版本、标量参数模板、LLM 生成与优化 API、依赖图和执行指标，以及 Agent 的 runtime__program 工具。开启 context.programming 后，模型可生成、执行、观察、修订并执行新版本。

所有业务节点经过已有 DAG、权限、确认、Artifact Adapter/Filter。新版本不覆盖旧版本，优化不能改变写节点或超出原能力快照。源码编译、AST 和动态 SQL 改写不在本次实现范围。

使用方式和完整限制见 [动态 Plan 程序说明](../implementation/动态Plan程序与运行时优化.md)。本次按用户要求使用程序专项验证与运行包冒烟检查，实际数量以包内 verification-results.json 和 package-smoke-results.json 为准，未重新执行全套回归。
