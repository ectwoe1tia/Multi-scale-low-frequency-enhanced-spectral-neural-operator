# 动态 Plan 程序与运行时优化

2026-10-27 交付。采用现有 Plan 与依赖图，无 AST 执行器。程序是经过校验、可保存和参数化的工具组合，具有不可变版本；主服务不编译或加载模型生成的 Java 类。算法源码仍可通过已有受控 Skill/子进程能力接入。

## 已实现

- 创建并保存程序；每个版本独立 programId、内容哈希、工具与契约快照。
- 参数模板：仅在节点 inputs 中使用 `{"$param":"字段"}`，参数限定标量；数据通过 Artifact ID 传递。
- 返回节点依赖图、父版本、节点/边数量比较和最近三次执行指标。
- LLM 单次生成或优化 API；生成结果必须是完整、受限 JSON，随后执行同一 PlanCompiler 校验，不自动执行生成物。
- 动态 Agent Loop 中通过 runtime__program 执行 create → execute → inspect → revise → execute；可在同一运行中根据真实指标调整下一版本。
- 复用 DagExecutor、Artifact Adapter/Filter、工具权限、全局调用预算、确认与恢复。写节点保持原有确认流程。
- 原程序不被修改；已运行版本不会因优化建议被热替换。新版本继续受父版本能力范围和版本约束，不能添加、删除或修改写节点。

新版本只表示结构和 Schema 校验通过，不表示业务等价或性能更好。节点/边减少是静态比较；toolCalls 和 toolDurationMillis 是实际执行观测，不是相同数据快照下的严格性能实验。模型无权自行宣告验证成功。

## 快速使用

启动运行包后，先保存示例（本地演示身份可用）：

```powershell
$base = 'http://127.0.0.1:8080'
$definition = Get-Content -Raw -Encoding UTF8 examples/program-calculator.json
$created = Invoke-RestMethod -Method Post -Uri "$base/api/programs" -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($definition))
$programId = $created.data.programId
$body = @{ parameters = @{ expression = '6*7' }; requestId = [guid]::NewGuid().ToString() } | ConvertTo-Json
$started = Invoke-RestMethod -Method Post -Uri "$base/api/programs/$programId/run" -ContentType 'application/json' -Body $body
$runId = $started.data.id
Invoke-RestMethod -Uri "$base/api/runs/$runId"
Invoke-RestMethod -Uri "$base/api/programs/$programId"
```

执行接口返回 202，使用 runId 查询状态；等待确认时沿用 `/api/confirmations/{id}/decision`。运行结果含 programId 与原 DAG 的输出引用。默认程序执行不调用模型，因而手工模板示例可以使用本地 mock 模型配置。

## 模型生成与优化

配置真实模型后，向 `POST /api/programs/generate` 提交：

```json
{
  "objective": "生成一个可接收 expression 参数的计算程序",
  "modelConfigId": "实际模型配置ID"
}
```

优化同一程序时追加 `baseProgramId`，objective 指定目标，例如“根据最近执行结果删除不参与最终计算的读取节点，保留最终计算含义”。返回新的 programId；可先 GET 检查，再调用 run。模型会获得可见工具、数据绑定字段、原程序和受限观测；不会加载 Artifact 明细。非法 JSON、越权工具、循环依赖、体积超限等直接拒绝，不用代码解释器兜底。

希望模型在一次任务里自行完成闭环时，提交 [program-agent-request.json](../../examples/program-agent-request.json) 到 `/api/chat` 或 `/api/chat/stream`，并指定真实 modelConfigId。`context.programming=true` 才向普通对话目录加入程序工具。现有网页联调台可在“业务上下文 JSON”填入这个开关，然后发送示例任务。

该模式提供一个固定入口 runtime__program，action 为 create、inspect、revise、execute。没有临时向模型工具目录注入未经校验的函数；新程序只组合当前运行已授权且冻结的工具。未开启 programming 的普通对话保持原有工具目录。

本地 mock 模型不会生成这些程序；自动闭环测试使用可控的模型替身验证协议与调度，并不代表真实模型对任意任务均能优化成功。

## API 与权限

| 路径 | 用途 | 专用权限 |
| --- | --- | --- |
| GET /api/programs | 分页查看本人版本 | program:read |
| POST /api/programs | body.definition 保存模板，可带 skillIds | program:write |
| GET /api/programs/{id} | 定义、关系图、比较、执行观测 | program:read |
| POST /api/programs/{id}/revise | body.definition 提交完整新版本，必须含 reason | program:write + program:read |
| POST /api/programs/generate | 模型生成；baseProgramId 可选 | program:generate + program:write；有基线另需 program:read |
| POST /api/programs/{id}/run | parameters、requestId、modelConfigId、skillIds | program:execute、chat、相关模型和工具权限 |

程序执行还要求 `tool:runtime__program`、`tool:runtime__execute_plan` 和各节点工具权限。create/revise 是注册程序，不是业务写工具的执行许可。程序按 tenant/user 隔离，管理员通配权限也不会获得他人的程序引用访问权。调用模型仍使用已有模型配置权限。

若能力来自非基础 Skill，创建、生成和执行时提供一致的 skillIds。工具/契约变化返回 PROGRAM_CAPABILITY_CHANGED，需要显式创建重新校验的程序，不能绕过旧快照继续执行。

## 限制与状态

每版本最多 12 节点，定义最大 9000 字符，最多 16 个标量参数、实例参数最大 4096 字符；每个所有者最多 100 个版本，修订链最多 16 层。生成 API 最多同时处理两个模型请求，每请求一次模型调用；模型传输使用不超过 60 秒的配置超时。暂不提供程序版本删除/共享发布功能。

继承当前每个 run 的工具次数、模型轮次和 DAG 阶段预算，子程序不能重置预算。程序内不能调用 runtime__execute_plan、runtime__program 或交互节点。当前没有条件分支、循环或嵌套程序；动态变化通过模型在阶段边界选择下一次程序调用实现。

记录：program-version 保存定义与依赖；program-execution 保存运行关联和指标；program-event 保存版本变更；program-generation 只记录生成关联与目标哈希。程序观察只包括状态、计数、时长、错误码和参数哈希，不持久化绑定的数据行。program-projection 保存服务端生成投影的哈希凭证，使受限程序定义可以进入后续模型上下文；外部工具伪造 program_ref 仍会被外置。

程序检查返回的 observations.status 是本次程序调用的记录状态，runStatus 是其所在运行的最新状态；崩溃/取消时应同时查看 runStatus 与任务节点。旧运行仍按既有策略失败或核对，不增加盲目重放。

## 本次验证与交付

按本次交付要求采用专项验证：ProgramTests 覆盖生成、参数绑定、实际运行、指标反馈、新版本优化、完整 Agent 闭环、权限隔离、非法程序、写确认和重启恢复；运行包另做基本冒烟检查。`target/verification-results.json` 的 scope 明确为专项验证，本次没有重新执行完整回归套件。

复现命令：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/build.ps1 -JavaHome D:/JDK -SkipTests
powershell -ExecutionPolicy Bypass -File scripts/verify-programs.ps1 -JavaHome D:/JDK
```

本机环境为 Windows/JDK 18，以 `--release 17` 编译。Spring profile 仍未在本机编译验证；运行包是原生 Java JAR。源码继续保持 JDK 17 / 可选 Spring AI 接入结构。
