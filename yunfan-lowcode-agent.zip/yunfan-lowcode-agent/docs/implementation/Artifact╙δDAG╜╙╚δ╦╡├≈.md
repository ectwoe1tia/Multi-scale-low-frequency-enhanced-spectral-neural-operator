# Artifact、Adapter、Filter 与 DAG 接入说明

逐项实现状态与后续优先级见 [架构回顾与改进清单](架构回顾与改进清单.md)。DIRECT 计划不接收追加消息；需要后续模型决策或追加提醒时使用 HYBRID。工具快照新增 wireSchema，旧版本暂停计划的升级注意事项见上述清单。

2026-10-26。实现位于现有 Java 17 工程；总体设计见 [控制面与数据面分离总体方案](../design/控制面与数据面分离总体方案.md)。

## 已实现的调用路径

`AgentRunService → ToolExecutionService → RuntimeFilterChain → ArtifactInputAdapter → 工具 → ToolOutputAdapter → 安全投影`。

DAG 和动态 Agent Loop 使用同一工具执行服务。DAG 按拓扑顺序执行，节点之间不调用模型；需要语义判断时把执行摘要交给模型，模型可再次调用 runtime__execute_plan。执行计划是受限 JSON，不能执行表达式、代码、任意 JSONPath 或嵌套计划。

输出表格自动转成私有 JSONL 数据集；公开结果仅包含 dataRef 等元数据。现有 dataRef 是本版 Artifact ID 的兼容表示，计划中也支持 artifact_id。内部数据参数只存在于 BoundInvocation 生命周期内，不写入执行记录、历史或任务状态。ArtifactStore SPI 提供句柄、公开描述、扫描、指纹和读租约，当前实现为 DataWorkspace 本地文件存储。

## 部署工具契约

复制 `config/tool-contracts.example.json`，替换为实际 MCP 工具别名与逻辑 Schema，然后配置：

```properties
yunfan.contracts.file=config/tool-contracts.json
yunfan.plan.max-nodes=32
yunfan.plan.max-stages=3
```

工具还需要出现在该运行的授权目录中。契约来自服务端配置或 Java `ToolContractRegistry.register`，模型和 MCP 返回值不能注册契约。修改配置后重启服务；Java SPI 注册应在接收请求前完成。

契约包括 logicalSchema、bindings、exposure、outputPath、summaryFields、maxSummaryBytes、outputKind。输入先校验逻辑 Schema，绑定之后再校验远端原始 wire Schema。契约版本和内容哈希参与计划固定及确认参数指纹；暂停期间契约改变会拒绝继续。

- `AUTO`：兼容旧工具，表格或大结果外置。
- `REFERENCE_ONLY`：所选输出强制存为 Artifact；table 类型会校验是否为表格。
- `BOUNDED_SUMMARY`：只投影允许字段；超过字节上限时外置，不截取正文。

`outputPath` 是固定对象键路径，例如 structuredContent；MCP 的 JSON 文本表格也由现有识别器处理。当前适配器不执行自定义解析脚本。

输入绑定已实现 HANDLE 和 BOUNDED_INLINE。内置 data__ 工具默认使用 HANDLE，在 Java 中扫描 JSONL，不将行数组回传模型。旧 MCP 若只接受 rows 数组，配置 BOUNDED_INLINE，运行时在调用范围内生成数组；超出契约大小明确失败。远端 MCP 必须本来就支持对应 wire 参数，不能把本地 ID 当作任意远端服务都能理解的句柄。

## 提交计划

对 `POST /api/chat` 发送 [完整示例](../../examples/artifact-dag-request.json)。示例 orders__query 是待接入的业务工具，需先注册真实 MCP 服务并部署匹配契约。

```json
{
  "message": "查询并导出",
  "context": {
    "planMode": "DIRECT",
    "executionPlan": {
      "schemaVersion": "1",
      "nodes": [
        {"id":"query","tool":"orders__query","dependsOn":[],"inputs":{"month":"2026-09"}},
        {"id":"export","tool":"data__export","dependsOn":["query"],"inputs":{"dataRef":{"$ref":{"node":"query","output":"dataset"}},"format":"xlsx"}}
      ],
      "result":{"$ref":{"node":"export","output":"file"}}
    }
  }
}
```

DIRECT 默认不调用模型，直接返回 execution_summary 和最终下载引用。HYBRID 在节点执行完成后进入模型循环，模型看到安全摘要并可决定下一阶段。没有显式计划时，模型也可通过 runtime__execute_plan 工具生成同样的计划。

节点必须声明 dependsOn，引用只能指向祖先节点的命名端口。dataset/file 返回 Artifact ID；summary/result 返回已经过滤的公开结果，不提供任意子字段访问。已有数据可以使用 `{"$ref":{"artifact_id":"实际ID"}}`，读取时重新核验归属。Artifact 端口必须绑定到契约声明的数据输入，不能拿 dataset 引用替换普通控制参数。

工具权限、参数校验、调用预算、写入确认和结果不明处理继续生效。内置 READ 与导出无需修改业务数据；WRITE 节点进入现有 WAITING_CONFIRMATION，批准后跳过已完成节点继续。输入 Artifact 内容哈希参与参数指纹，绑定后的明细不会出现在确认记录中。失败节点阻断下游，最新计划未完成时不能仅凭模型回答将运行标记成功。

## 状态、上下文、记忆

分别使用 task-state、ModelContext 临时值、persistent-memory 存储。任务状态保存节点进度、下一节点、输出引用和计划哈希；会话消息仍是独立记录。每轮上下文只注入受限状态投影，不复制完整检查点。

`context.taskType` 支持 CLASSIFICATION、EXTRACTION、DATA_ACCESS、CONVERSATION、CROSS_FILE、LONG_RUNNING。前三者按短历史策略处理；未明确分类时，有 dataPlan/executionPlan 的请求使用 DATA_ACCESS，其余默认 CONVERSATION。分类不调用额外模型；现有 ContextPlanner 继续执行固定约束保留和预算选择。当前没有向量检索或真实 tokenizer，仍是规则/词项检索和保守字节估算。

持久记忆仅支持服务端显式事实写入和删除，不自动保存工具输出。每条 fact 最多 1000 字符，必须带 source，可指定 expiresAt；按身份隔离、按相关词项最多取 3 条。临时 Artifact 引用不能作为永久事实。该功能不等于自动学习记忆系统。

## API

| API | 用途 |
| --- | --- |
| POST /api/plans/validate | 无副作用预检，返回计划哈希与执行顺序；不承诺执行时仍有权限 |
| GET /api/runs/{id}/state | 独立任务状态 |
| GET /api/runs/{id}/nodes | DAG 节点状态、错误码 |
| GET /api/runs/{id}/plan | 计划哈希和节点视图 |
| GET /api/admin/tool-contracts | 已部署契约描述，需要 admin |
| GET/POST /api/memories | 查询/写入本人事实，需要 memory:read/write |
| DELETE /api/memories/{id} | 删除事实，需要 memory:write |
| GET /api/data/artifacts/{id}/metadata | 公开元数据，需要 data:read |
| GET/DELETE /api/data/artifacts/{id} | 下载/删除，需要 data:download/delete |

下载仍使用身份校验和 attachment；公开结果不暴露物理路径或 storage_uri。正在读取的产物不能删除，GC 每 60 秒清理无读租约的过期产物。过期逻辑校验立即生效；有活动租约的文件保留至读取结束，不代表过期 ID 可被新请求读取。

## 防回灌与定制

RuntimeFilterChain 对逻辑参数与公开结果执行结构校验，可通过 ServiceLoader 注册 RuntimeFilter 扩展策略；扩展前后均执行强制校验。过滤器不会接收到 BoundInvocation 的数据数组。

ModelClientFactory 对原生、mock、注入的 Spring 客户端统一包装 ModelContextFilter，在同步和流式入口检查最终消息与工具描述。assistant.tool_calls.arguments、JSON 格式文本、记忆/检索内容同样检查；超预算、批量结构化数据或内部存储字段明确拒绝，不截坏 JSON。该过滤器不是任意自然语言敏感信息识别器，授权文档文本仍可按上下文预算使用。

原始外部结果不能通过伪造 kind=aggregate_result 获得内部小结果信任。只有内部数据工具的受限样本与统计可直接投影。派生产物保存父引用，并传播 PARTIAL/UNKNOWN；要求完整数据的输入可配置 requireComplete=true。

定制点包括 ToolContractRegistry、ArtifactStore、RuntimeFilter SPI、现有 Auth SPI 和 ModelClientFactory。新工具通过契约与适配器接入，不能关掉最终模型边界。

## Spring AI 与当前限制

Spring profile 默认固定 Spring AI 2.1.0-M1 / Boot 4.2.0-M2，Java release 17。此组合来自所检查的 Spring AI 标签基线；若公司使用其他 2.1 里程碑，需按实际坐标重新核对。2.1 接入使用 OpenAiChatModel/OpenAiChatOptions，直接单轮调用 ChatModel，不安装自动工具执行 Advisor；声明用 ToolCallback 不允许直接执行。

```sh
mvn -B -Pspring clean package
java -jar target/yunfan-lowcode-agent-1.0.0-spring.jar
```

本机无 Maven，依赖下载连接被拒绝，Spring profile 尚未编译或执行。源码提供 Spring 边界测试和 JDK 17 CI。已验证运行包是原生 Java JAR，不是 Spring fat JAR。当前 Spring 模型调用仍为同步，结果以单个 delta 返回；特定供应商选项沿用原生客户端。

本版实现顺序 DAG，不提供并行 DAG、跨实例调度、远端 Artifact 上传、OS 沙箱或向量记忆。中断活跃任务继续采用现有“失败或核对、不自动重放”策略；暂停确认可以恢复。未将依赖图提升为分布式工作流引擎。

## 验证

新增回归覆盖：真实 HTTP MCP 查询 50000 行直接 XLSX 导出零模型调用、旧 MCP 数组参数内部绑定、HYBRID 执行后单次模型调用、模型生成 DAG 后连续执行、状态/历史/事件无明细、非法依赖与循环、跨租户引用、绑定超限、写入确认及恢复、下游阻断、模型出口过滤、派生血缘与完整性、独立记忆及租约 GC。

完整结果以 target/verification-results.json 和运行包所附报告为准。测试在 Windows 的 JDK 18 上以 --release 17 编译运行；真实 Linux/JDK 17、企业模型、真实数据库及 Spring 构建仍需目标环境验证。
