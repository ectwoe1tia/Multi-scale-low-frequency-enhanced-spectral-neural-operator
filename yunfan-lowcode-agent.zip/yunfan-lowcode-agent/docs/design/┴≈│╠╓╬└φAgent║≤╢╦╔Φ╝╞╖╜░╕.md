流程治理 Agent 后端设计方案
===========================

版本：设计稿 v1.0；日期：2026-10-18。依据：用户提供的目录及 `E:/AI/agent.txt`。这是实施前设计稿。后续用户指定 JDK 17；实际实施结果、技术调整和验证边界以 `docs/implementation/实施与设计差异.md` 及 README.md 为准。

**1. 建设目标与范围**

建设一个 Java 流程治理 Agent 后端，提供“理解需求 → 读取流程资料 → 调用工具 → 检查问题 → 给出有依据的建议 → 按策略执行操作 → 保存结果与审计”的完整闭环。

保留参考目录的 chat、tooling、skill、session、modelconfig、auth、common，补充 runtime、governance、audit。采用单体模块化部署、单 Agent 多工具编排；先形成可维护的完整服务，再根据实际负载拆分服务。

业务默认假设：现有流程平台负责流程定义、实例、审批和发布；本服务经 MCP 接入。数据库、模型服务和实际 MCP 地址尚未提供，因此设计包含可替换适配器与本地联调桩。接入真实系统后的功能范围由其工具能力决定。

本期完整功能包括会话、模型调用、工具循环、技能、流程检查、报告、操作确认、审计与部署配置。流程引擎、流程设计器、SSO/JWT 验签、定时巡检、跨会话长期知识库和多 Agent 协作不纳入本期。知识文档检索本期通过 MCP 工具接入，技能语义检索不等同于知识库 RAG。

**2. 技术方案**

| 项目 | 设计选择 | 说明 |
|---|---|---|
| 语言与构建 | Java 21、Maven | 统一编译与运行版本 |
| Web | Spring Boot、Spring MVC | REST + SseEmitter；模型流与阻塞数据库调用隔离 |
| AI 适配 | Spring AI + ModelClientFactory | 统一模型接口，运行时选择模型与参数 |
| 工具接入 | MCP Java SDK 的适配层 | 优先使用 SDK，按实际支持的协议版本验收 |
| 持久化 | MyBatis、PostgreSQL / MySQL | 单次部署选择一种数据库，分别维护方言与迁移脚本 |
| 技能向量 | Embedding 接口、关系库保存向量、应用内余弦匹配 | 适合初期小规模技能库；保留 VectorIndex 扩展点 |
| 缓存 | 有容量限制的进程内缓存 | 数据库为事实来源，Redis 不作为首期必需依赖 |
| 运维 | Actuator、Micrometer、容器、K8s | 监控、追踪、健康检查、优雅停机 |
| 测试 | JUnit、ArchUnit、Testcontainers、HTTP/MCP 桩 | 验证两种数据库及异常工具链路 |

参考版本 Spring Boot 4.2.0-M2 与 Spring AI 2.1.0-M1 在官方文档中均为预览版本。设计可以沿用，但不能仅凭版本号认定组合已经兼容；正式实现先执行依赖解析、启动、模型流、工具调用与序列化验证。生产候选基线为 Java 21 + Spring Boot 4.1.x + Spring AI 2.0.x，具体补丁版本在实现时固定。Spring AI 官方说明 2.0.x 支持 Boot 4.0.x/4.1.x。[Boot 版本说明](https://docs.spring.io/spring-boot/4.2/system-requirements.html)、[Spring AI 版本说明](https://docs.spring.io/spring-ai/reference/2.1/getting-started.html)

序列化沿用 Boot 所管理的 Jackson 主版本，不因参考类名为 Jackson2ObjectMapperConfig 就强行引入旧版本；实际命名采用 JacksonObjectMapperConfig。MyBatis、迁移工具与 MCP SDK 同样纳入依赖兼容验证。

**3. 支持功能列表**

| 模块 | 本期拟实现功能 | 关键约束 |
|---|---|---|
| 对话 | 多轮对话、流式/非流式、结构化结果、缺参澄清 | 两种输出共用同一执行循环 |
| 执行 | 多轮工具调用、参数校验、取消、超时、预算控制、状态查询 | 最大轮次、工具次数、Token 和总耗时均有限制 |
| 流式事件 | 回答增量、执行进度、工具开始/结束、确认请求、错误、结束事件 | 单运行序号递增；同一输出段只关闭一次 |
| 可见推理输出 | 提供商允许输出的 reasoning 增量或摘要，按能力开关 | 不假造 thinking；无支持时仅返回可核实执行进度 |
| 历史 | 归一化、基于 ID 去重、Token 预算压缩、摘要更新 | 原始消息独立保存，工具调用与结果成组保留 |
| 会话 | 新建、分页列表、详情、重命名、删除、消息分页 | 预留租户与用户归属隔离 |
| 动态模型 | CRUD、默认模型、启停、连接测试、参数配置、缓存失效 | 对话模型与向量模型区分，密钥不回显 |
| MCP | 多服务配置、工具发现、分页目录、命名隔离、热刷新、健康状态 | 每个运行绑定目录版本；认证错误与会话失效分别处理 |
| 技能 | CRUD、启停、SKILL.md 解析、ZIP 上传、版本管理 | ZIP 路径和解压配额校验；首期不执行上传脚本 |
| 技能激活 | 显式 skillIds、语义匹配、优先级、工具白名单、提示词合并 | 语义匹配失败退化为显式技能；技能不能扩权 |
| 流程治理 | 定义检查、实例分析、规则判定、证据报告、优化建议 | 区分规则命中、模型建议、数据缺失与未执行检查 |
| 流程操作 | 创建整改待办；为发布、停用、审批等操作提供接入机制 | 实际业务操作依赖 MCP，并按配置进入确认流程 |
| 审计 | 请求链路、技能/规则/模型版本、工具输入输出摘要、确认记录 | 凭据不记录，敏感业务字段按配置脱敏 |
| Auth 预留 | 身份解析、权限策略、下游凭据提供接口、开发身份 | 本期不实现登录、令牌签发和真实 JWT 验签 |
| 工程交付 | 联调页、OpenAPI、双数据库脚本、环境配置、Docker/CI/K8s | 示例使用占位符，真实配置经环境变量/Secret 注入 |

**4. 总体架构与目录映射**

```mermaid
flowchart TD
    UI[业务前端 / 联调页] --> API[Controller REST / SSE]
    API --> CHAT[ChatService 请求编排]
    CHAT --> RUN[AgentRunService 执行循环]
    RUN --> MODEL[ModelClientFactory 模型适配]
    RUN --> SKILL[SkillRegistry 技能选择]
    RUN --> GOV[GovernanceService 规则与报告]
    RUN --> TOOL[ToolExecutionService 工具执行]
    TOOL --> POLICY[ToolPolicy / 确认 / 幂等]
    POLICY --> MCP[McpRegistry / McpConnection]
    MCP --> PLATFORM[现有流程平台与知识服务]
    RUN --> STORE[会话 / 消息 / 运行 / 事件]
    TOOL --> AUDIT[AuditService 审计]
    GOV --> STORE
    API --> AUTH[AuthContextResolver 预留接口]
```

| 包 | 保留/补充的关键类 | 职责 |
|---|---|---|
| chat | 原有 Controller、Service、HistoryLogic、Parser、PromptFactory；补充 SseOutbound | 协议适配、输入归一化、上下文构建；不直接操作数据库 Mapper |
| runtime（新增） | AgentRunService、AgentRunStore、AgentRun、AgentEvent、ExecutionBudget、RunRecoveryService | 唯一 Agent 执行循环、状态推进、执行检查点、取消与恢复 |
| tooling | 原有 MCP 类；补充 ToolExecutionService、ToolPolicy、ToolCatalogSnapshot | 统一工具入口、目录快照、重试与幂等 |
| skill | 原有 Registry/Service/Mapper/Parser；补充 SkillVersion、VectorIndex | 技能生命周期、版本、匹配、权限范围内的工具筛选 |
| session | 原有 SessionStore/Mapper/Controller；补充 ChatMessageMapper | 会话元数据与追加式消息持久化 |
| modelconfig | 原有 CRUD；补充 ModelClientFactory、ModelCapability、SecretProvider | 按版本创建模型客户端、能力校验、凭据引用 |
| governance（新增） | GovernanceController/Service、RuleEngine、RuleRepository、ProcessSnapshot、GovernanceReport、ActionConfirmationService | 流程标准化、确定性规则、问题证据、操作确认 |
| audit（新增） | AuditService、AuditMapper、AuditController | 审计写入、受控查询 |
| auth | AuthContextResolver、AuthorizationPolicy、DownstreamCredentialProvider、AuthContext | 外部认证接入契约；开发桩仅限 local/test |
| common | StreamOutbound、JsonResult、ErrorCode、异常处理、WebConfig | 公共 DTO、错误映射和基础配置 |

依赖方向为 Controller → 应用服务 → 领域逻辑/端口 → 适配器。领域逻辑不依赖 Servlet、SseEmitter 或 MCP SDK。避免为每个 DTO 单独建设 DDD 层级；只在模型、工具、存储、认证等变化边界抽象接口。

TodoController 作为兼容入口仍调用 ToolExecutionService。它可以跳过模型选择步骤，但不能绕开工具策略、确认、幂等与审计。

**5. 对话与 Agent 执行链路**

1. Controller 解析并校验请求，取得不可变 AuthContext，校验会话归属及模型/技能可用性。
2. 以 `(tenantId, userId, requestId)` 建立唯一运行；重复请求返回现有 runId。相同 requestId 携带不同请求内容返回冲突。
3. 对同一会话获得数据库执行租约，默认一个活跃写入运行；并发新运行返回 409。等待澄清或确认期间保留逻辑占用，仅允许继续当前运行。
4. 加载服务端历史，合并可选的历史导入，生成模型上下文。默认不信任前端提交的 system/tool 历史。
5. 合并显式技能与语义候选，绑定技能版本、规则版本、模型配置版本和工具目录快照。
6. PromptFactory 组装基础角色、输出规范、技能说明、压缩摘要、最近消息与业务资料。业务资料和工具返回值作为数据，不得改变执行策略。
7. 调用模型；只有完整接收并校验工具调用名称、参数 JSON 和调用 ID 后才执行工具，绝不执行流式的半截参数。
8. 工具执行经过权限与白名单、Schema 校验、风险策略、确认/幂等控制，结果作为对应 tool 消息回填。
9. 继续调用模型，直到产生最终回复、需要用户输入/确认、预算耗尽、取消或失败。
10. 保存回复、结构化报告与运行状态，发送本次输出段的结束事件，释放可释放资源。

AgentRunService 自己控制工具循环，避免同时开启框架内部自动循环产生重复工具调用。Spring AI 用于模型和 ToolCallback 适配。

建议默认值：最大模型轮次 12、最大工具调用 20、单工具超时 30 秒、单运行活跃执行预算 180 秒；全部可配置。等待人工输入不占活跃执行时长，另设确认/输入过期时间。重复工具参数与相同错误连续出现时提前停止，返回明确原因。

运行状态：`CREATED → RUNNING → COMPLETED / FAILED / CANCELLED / EXPIRED / RECONCILIATION_REQUIRED`；RUNNING 可以进入 `WAITING_INPUT` 或 `WAITING_CONFIRMATION`，经合法继续请求回到 RUNNING。`RECONCILIATION_REQUIRED` 表示外部写入结果不明，不能当作普通失败自动重跑。

执行节点续租与检查点使用数据库乐观版本和 fencing token 防止旧节点继续提交本地状态；外部副作用仍必须依靠下游幂等键或操作状态查询保障。重启后只自动恢复可确认未执行的安全步骤，外部结果不明的写操作先核对。

**6. SSE 与非流式协议**

主端点 `POST /api/chat/stream`，前端采用 fetch ReadableStream 读取 POST SSE。`POST /api/chat` 返回同一运行引擎的聚合结果。若预计耗时超过 HTTP 等待预算，返回 202 + runId，前端查询状态或订阅事件。

```json
{
  "requestId": "req-001",
  "sessionId": "s-001",
  "message": "检查采购审批流程的配置问题",
  "modelConfigId": "model-default",
  "skillIds": ["process-audit"],
  "context": {"processDefinitionId": "purchase", "version": "3"}
}
```

租户、用户、权限与下游令牌均不接受此请求体指定。processDefinitionId 等业务资源仍由工具执行前校验访问范围。

```text
id: run-001:8
event: tool.completed
data: {"runId":"run-001","seq":8,"timestamp":"2026-10-18T08:00:00Z","payload":{"toolCallId":"call-1","tool":"workflow__get_definition","status":"SUCCESS"}}
```

事件类型：`run.started`、`message.delta`、`reasoning.delta`（可选）、`step.started`、`tool.started`、`tool.completed`、`tool.failed`、`input.required`、`confirmation.required`、`report.created`、`error`、`done`。心跳为 SSE comment。

`done` 表示本次输出段关闭，携带当前 runStatus；WAITING_INPUT/WAITING_CONFIRMATION 并不表示业务运行完成。恢复执行使用新的事件订阅继续读取同一 runId。

验证失败在 SSE 建连前返回标准 HTTP 错误；流已经建立后用 error 事件表达异常，再发送 done。SseOutbound 以原子终止标记保证结束/异常/超时竞争时仅终止一次。

事件以 `(runId, seq)` 持久化。文本增量可按短窗口合并后先存储再发送，关键事件立即落库。`GET /api/runs/{id}/events?afterSeq=8` 用于回放与订阅，避免把重连解释成新请求。事件有保留期，超过期限返回明确的过期响应，最终消息与报告仍可查询。

网络断开默认不取消业务运行；显式 cancel 接口停止后续模型与工具调度，并尽力取消在途请求。取消不能撤销已经发生的外部写入。慢消费者使用有限队列，溢出后断开并允许按序号恢复，不能无限堆积内存。

**7. 历史与记忆设计**

ChatHistoryLogic 仅承担归一化、选择压缩区间、Token 预算计算和消息编组等纯逻辑。真实模型摘要调用放入独立 HistorySummaryService，避免“纯逻辑”类包含网络请求。

服务端消息为事实来源；按 messageId、clientMessageId 或 requestId 去重，不能按文本去重，否则用户重复提问会被误删。原始消息不因压缩删除。

模型上下文由“基础提示词 + 技能 + 摘要 + 最近完整消息组 + 本轮输入 + 工具定义”组成。预算预留输出 Token；超过预算时压缩旧的完整对话组。tool call 和 tool result 不拆散，未完成调用不参与摘要。摘要记录覆盖消息边界、生成模型、版本及内容摘要。

摘要失败时保留最近的完整消息组并说明上下文裁剪；当前必要输入仍超长则返回 CONTEXT_LIMIT_EXCEEDED，不悄悄丢弃当前需求。保存逻辑消息数与摘要覆盖数，界面消息数不因模型上下文压缩而变化。

**8. MCP 工具编排**

McpServerProperties 包含 serverId、URL、transport、protocolVersion、enabled、credentialRef、连接/调用超时、工具白名单。工具名映射采用 `serverId__toolName`，同时保存真实名称并处理模型工具名长度和字符约束。

McpRegistry 启动执行工具发现并处理分页；权限相关的工具目录按身份/权限域缓存，不能把管理员看到的目录直接暴露给所有用户。热刷新构建新快照，成功后原子替换；失败保留旧快照。在途运行持有旧快照，强制停用与权限撤销仍在每次调用前实时检查。

协议版本必须显式区分。参考目录的 MCP Session 缓存适合有状态协议适配；2025-11-25 版本在服务端分配 Session ID 时需复用，Session 失效返回 404 时重新初始化。401 代表认证失败，应由凭据提供器刷新/重新获取有效凭据，最多进行一次受控恢复，不能仅靠创建 Session 解决。[MCP 2025-11-25 传输规范](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)

2026-07-28 协议已调整为无状态核心，取消 initialize 和 MCP-Session-Id，因此不能把 JWT 级 Session 缓存作为所有版本的必备实现。本期优先落地与实际 Java SDK、存量 MCP 服务一致的协议适配；较新协议只在适配实现及契约测试通过后声明支持。[MCP 2026-07-28 发布说明](https://blog.modelcontextprotocol.io/posts/2026-07-28/)

有状态连接缓存使用 serverId + tenantId + principalId + 权限/凭据版本指纹作为键，按凭据有效期清理并限制容量；不记录明文 JWT。认证与请求上下文显式传递，不能在共享客户端上修改一个全局 Authorization 请求头。

工具风险分 READ、WRITE、HIGH_RISK，由服务端策略配置；MCP 的 readOnly 等提示仅作参考。只读调用可按预算有限重试；有下游幂等保障的写入使用稳定幂等键；无保障的写入遇到超时进入结果核对，禁止盲重试。对 401 恢复后的写请求也应用同样原则。

工具输出设体积上限；大结果保存为受控附件引用，返回模型的是摘要和分页信息。工具返回中的自然语言指令不得覆盖工具策略。

**9. Skill 技能增强**

SkillMdParser 解析 YAML front matter 与 Markdown 正文，建议字段为 name、description、version、tags、allowedTools、triggerExamples、priority、requiresConfirmation。数据库增加发布状态、所属租户、内容摘要、embeddingModelId、embeddingVersion、向量维度与向量状态。

显式激活：校验 skillIds 的存在、启用状态与访问范围，去重并保持稳定顺序。隐式激活：对当前意图向量化，按租户过滤后计算余弦相似度，以阈值 + topK 选取候选；首期 topK 建议为 3，阈值用实际样本校准。

有效工具集合 = 用户允许工具 ∩ 系统启用工具 ∩（基础只读工具 ∪ 已激活技能允许工具）。无技能时只开放基础工具；无白名单的技能不会自动获得全部工具。显式技能优先，冲突时按明确优先级与稳定排序处理，并将选择原因写入审计。

技能更新生成新版本，运行绑定不可变版本。向量异步更新时以内容摘要和版本做 compare-and-set，避免旧任务覆盖新向量；检索不能混用不同模型、不同维度的向量。向量服务不可用时保留显式技能路径，不默认激活全部技能。

ZIP 上传校验压缩大小、解压总量、文件数、路径穿越、绝对路径和符号链接；解析通过后原子发布。资源文件可按受控引用读取，首期不执行 Python/Shell 等上传脚本。

**10. 流程治理领域能力**

governance 模块包含本地规则检查与基于 MCP 的业务取数两部分。统一 ProcessSnapshot 表达 definitionId、version、节点、连线、开始/结束标记、条件、审批人配置和 SLA；适配器将流程平台格式转换为该模型。

| 场景 | 实现方式 | 输出与限制 |
|---|---|---|
| 流程定义查询 | MCP 获取指定版本定义并保存快照摘要 | 展示来源、版本和读取时间 |
| 结构检查 | 本地规则检查缺失引用、不可达节点、无法到达结束节点、孤立节点 | 环路单独标记需分析，不把所有环路视为错误 |
| 配置检查 | 校验必需审批人配置、默认分支及 SLA 格式 | 不支持的表达式语法标为未检查；不宣称证明所有条件互斥/完备 |
| 运行分析 | MCP 拉取实例及节点时间，计算超期、积压、耗时统计 | 规则注明工作日历、时区、样本范围和 SLA 版本 |
| 责任人有效性 | MCP 查询组织/人员目录 | 无目录工具时标记缺失数据，不能当作人员有效 |
| 治理建议 | 模型基于规则结果、业务资料生成建议 | 标记为模型建议，保留证据引用 |
| 整改落地 | 经统一工具执行入口创建待办或更新流程配置 | 需要对应 MCP 写工具和操作授权 |

首期规则采用类型化 Java 规则处理器 + 可配置参数，支持规则启停、适用范围和版本。不开放任意脚本执行；复杂流程平台表达式由其校验工具或专门适配器处理。

治理报告包含 reportId、runId、processDefinitionId、processVersion、snapshotHash、ruleSetVersion、执行时间、检查覆盖情况、问题列表、严重级别、证据、建议及未完成项。规则检查结果为 PASS / FAIL / UNKNOWN / NOT_APPLICABLE；UNKNOWN 不能统计为通过。

待确认操作必须先保存规范化参数、参数摘要、目标流程版本、toolId、toolCallId、申请人、权限范围、过期时间与幂等键。确认接口只接收 decision 和确认记录版本，不接收替换后的工具参数。执行前重新验证权限和目标版本；参数或版本变化需重新生成确认。重复确认通过数据库 CAS 保证只推进一次。

示例闭环：“检查采购流程并生成整改待办” → 获取定义 → 本地规则检查 → 返回问题与证据 → 生成待办草案 → 按策略确认 → MCP 创建待办 → 保存外部待办 ID → 返回治理报告。缺少写工具时返回可执行草案，明确未创建实际待办。

**11. 数据模型**

| 表 | 核心字段 |
|---|---|
| agent_session | id、tenant_id、user_id、title、message_count、summary、summary_through_seq、version、timestamps、deleted |
| agent_message | id、session_id、run_id、seq、role、content、tool_call_id、status、token_usage |
| agent_run | id、session_id、request_id、request_hash、status、model_config_version、skill_versions、catalog_version、budget、checkpoint、lease_owner、lease_until、fencing_token、version |
| agent_run_event | run_id、seq、type、payload、created_at、expires_at |
| agent_tool_execution | id、run_id、tool_call_id、server_id、tool_name、args_hash、idempotency_key、status、external_operation_id、result_ref |
| agent_skill | id、tenant_id、name、enabled、current_version、timestamps |
| agent_skill_version | skill_id、version、front_matter、body、content_hash、resource_ref、embedding、embedding_model_version、embedding_status |
| agent_model_config | id、tenant_id、name、provider、base_url、model_name、capabilities、options、credential_ref、enabled、version |
| agent_governance_rule | id、tenant_id、rule_code、handler_type、parameters、scope、severity、enabled、version |
| agent_governance_report | id、tenant_id、run_id、process_id、process_version、snapshot_ref、snapshot_hash、rule_versions、findings、coverage |
| agent_action_confirmation | id、run_id、tool_execution_id、args_hash、target_version、status、requested_by、decided_by、expires_at、version |
| agent_audit_log | id、tenant_id、actor_id、trace_id、run_id、action、target、redacted_payload、created_at |

消息追加和 session.message_count 更新放在同一短事务内；消息计数仅在插入成功时增加。关键唯一约束包括 `(tenant_id,user_id,request_id)`、`(session_id,seq)`、`(run_id,seq)`、`(run_id,tool_call_id)`、`(skill_id,version)`。模型网络调用与 MCP 调用不放在数据库事务里。

PostgreSQL 的 ON CONFLICT 与 MySQL 的 ON DUPLICATE KEY 分别实现并测试；元数据分页不加载完整消息 JSON。时间统一存 UTC，展示时转换。规则版本和执行快照确保事后可解释。

数据库脚本覆盖全部表，按 pg/mysql 拆分；生产使用版本化迁移，SessionTableInitializer 只用于 local/test。会话删除需先结束活跃运行，业务消息与审计按各自保留策略处理。

**12. API 清单**

所有资源操作由 AuthContext + AuthorizationPolicy 检查归属；带 admin 的端点另需管理权限。接口中 `{id}` 均为服务端分配标识。

| 方法与路径 | 功能 |
|---|---|
| POST /api/chat | 非流式对话；等待中返回状态或 202 |
| POST /api/chat/stream | POST SSE 对话 |
| GET /api/runs/{id} | 查询运行、阶段与最终结果 |
| GET /api/runs/{id}/events | 按 afterSeq 回放和订阅事件 |
| POST /api/runs/{id}/cancel | 显式取消 |
| POST /api/runs/{id}/input | 提交澄清输入并继续当前运行 |
| POST /api/confirmations/{id}/decision | 确认或拒绝具体工具操作 |
| POST、GET /api/sessions | 新建、分页查询会话 |
| GET、PATCH、DELETE /api/sessions/{id} | 详情、重命名、删除 |
| GET /api/sessions/{id}/messages | 消息分页 |
| POST、GET /api/skills | 创建、分页查询技能 |
| GET、PUT、DELETE /api/skills/{id} | 技能详情、更新、删除 |
| POST /api/skills/import | ZIP 导入 |
| POST /api/skills/{id}/enable、/disable | 技能启停 |
| POST /api/skills/{id}/reindex | 重新生成当前版本向量 |
| POST、GET /api/model-configs | 创建、查询模型配置 |
| GET、PUT、DELETE /api/model-configs/{id} | 模型详情、更新、删除 |
| POST /api/model-configs/{id}/test、/default、/enable、/disable | 测试、设置默认、启停 |
| GET /api/admin/mcp/servers、/tools | MCP 状态与工具目录 |
| POST /api/admin/mcp/reload | 指定服务或全部服务刷新 |
| POST /api/governance/checks | 创建一次结构化治理检查，返回 runId |
| GET /api/governance/reports、/{id} | 报告列表和详情 |
| GET、POST /api/governance/rules | 查询、创建规则配置 |
| PUT、DELETE /api/governance/rules/{id} | 更新、删除规则配置 |
| POST /api/todos | 通过统一工具执行入口创建待办，可能返回待确认状态 |
| GET /api/admin/audits | 分页查询审计 |

REST 使用 `{code,message,data,traceId}`，HTTP 状态码保留语义。主要错误码：INVALID_ARGUMENT、NOT_FOUND、FORBIDDEN、SESSION_BUSY、MODEL_UNAVAILABLE、MODEL_CAPABILITY_MISMATCH、MCP_UNAVAILABLE、TOOL_TIMEOUT、TOOL_RESULT_UNKNOWN、SKILL_INVALID、CONTEXT_LIMIT_EXCEEDED、RUN_BUDGET_EXCEEDED、CONFIRMATION_EXPIRED、RESOURCE_VERSION_CONFLICT。

**13. Auth 预留接口**

```java
public interface AuthContextResolver {
    AuthContext resolve(HttpServletRequest request);
}

public interface AuthorizationPolicy {
    void check(AuthContext context, String action, ResourceRef resource);
}

public interface DownstreamCredentialProvider {
    DownstreamCredential resolve(AuthContext context, String serverId);
}

public record AuthContext(
    String tenantId,
    String userId,
    Set<String> roles,
    Set<String> permissions,
    String credentialRef,
    String traceId
) {}
```

local/test 提供固定开发身份与受控策略；pro 在缺少真实身份解析与权限策略适配时启动失败。预留不等于在生产匿名放行管理和写操作。

参考目录只描述了“三级 JWT 通道”，没有给出各通道语义、信任边界和优先级。本期以 TokenSource 策略接口承接，后续按网关/SSO 合同实现，不猜测或混用请求体、Cookie、请求头来源。下游凭据按目标 MCP audience 获取，避免把任意上游 JWT 直接转发。

AuthContext 在进入异步模型流和工具任务前显式传递；ThreadLocal 如因兼容保留，应在 finally 清理且不能作为跨线程身份来源。JwtUtil 验签和令牌刷新由后续认证集成负责，本期不提供“只解析不验签”的正式身份实现。

**14. 动态模型、配置与部署**

模型选择优先级为请求显式指定 → 会话默认 → 租户默认 → 系统默认，选择后均检查可见性、启用状态与所需能力。模型配置记录 chat/embedding、streaming、toolCalling、structuredOutput、reasoning 等能力；能力不足返回明确错误或采用已配置兼容路径。

ModelClientFactory 以配置 ID + 版本 + 凭据版本创建不可变客户端，避免跨用户修改同一个模型实例。运行开始固定模型配置版本；模型停用和凭据撤销执行实时策略。连接测试仅返回脱敏诊断。

密钥仅保存 Secret 引用或由外部主密钥保护的密文，不进入日志、Prompt、SSE 或配置查询响应。baseUrl/MCP URL 仅允许管理员在部署允许的地址范围内配置。

application.properties 只设置默认 profile；local/test/pro 各自提供完整非敏感配置模板，数据库密码和模型密钥通过环境变量注入。关键配置分组：yunfan.agent、yunfan.mcp.servers、yunfan.skill、yunfan.session、yunfan.auth、yunfan.governance、yunfan.stream。

Docker 使用多阶段构建与非 root 运行；CI 执行编译、单元测试、数据库/MCP 契约测试和镜像构建。K8s 配置探针、资源限制、终止宽限期与 Secrets 引用。Ingress 关闭 SSE 响应缓冲并调整空闲超时，启用精确 CORS 白名单。

联调页包含模型/技能选择、会话列表、事件时间线、确认/拒绝、取消和报告查看；bookmark 脚本只携带后端地址，不固化凭据。release-summary.ps1 只读 Git 与发版登记表。

指标至少包含活跃运行数、SSE 连接数、首字延迟、总耗时、模型 Token、工具成功率/超时率、技能命中、摘要失败和待核对写操作数。日志使用 traceId/runId/toolCallId 关联，不把高基数用户标识作为指标标签。

**15. 实现顺序与验收标准**

| 顺序 | 实现内容 | 验收结果 |
|---|---|---|
| 1 | 工程骨架、数据库迁移、Auth 接口、模型配置 | local 启动、双数据库初始化、模型测试可用 |
| 2 | 会话、历史、AgentRunService、非流式与 SSE | 同一执行链完成问答；断连、取消与状态查询一致 |
| 3 | MCP 注册、ToolExecutionService、技能显式激活 | 至少两轮模型-工具循环，工具名不冲突，越界工具被拦截 |
| 4 | 技能 ZIP/向量触发、压缩、动态模型版本 | 更新期间无旧向量覆盖、无跨用户配置污染 |
| 5 | 治理规则、报告、确认、写入幂等与审计 | 完成“检查 → 报告 → 确认 → 创建整改待办”的样例闭环 |
| 6 | 恢复、异常契约测试、联调页与部署资料 | 重启和下游异常不导致盲重放写入，交付可复现环境 |

关键测试覆盖：

- ChatServiceStreamTest / SseOutboundTest：增量次序、结束事件唯一、连接中断、慢消费者、错误后终止、按序号续读。
- ChatServiceThinkingTest：有/无 reasoning 能力、文本增量与元数据区分，不为缺失能力伪造输出。
- ChatHistoryLogicTest / ChatRequestParserTest：按 ID 去重、同文重复提问、工具消息配对、超长上下文、非法角色注入、字段冲突。
- AgentRunServiceTest：轮次预算、同会话并发、同 requestId 重试、取消竞态、等待后继续、崩溃恢复。
- McpConnectionTest：服务失效、401 凭据恢复、旧协议 Session 404 重建、权限目录隔离、工具热刷新、写调用结果不明。
- SkillRegistryTest / SkillServiceImplTest / SkillMdParserTest / SkillEmbeddingServiceImplTest：白名单、冲突技能、ZIP 穿越、容量限制、向量维度与版本隔离。
- GovernanceServiceTest：标准流程通过、断链和缺审批人失败、合法环路不误判、缺数据 UNKNOWN、报告关联实际流程版本。
- ConfirmationTest：重复确认、参数篡改、超时、目标版本变化、权限撤销与拒绝后不执行。
- SessionStoreIntegrationTest：PostgreSQL/MySQL 的 upsert、唯一约束、乐观锁、计数和分页一致性。
- AuthContextResolverTest：开发身份仅在允许的 profile 启用、生产缺适配器失败、异步身份不串用。
- ArchitectureTest：Controller 不访问 Mapper，领域纯逻辑不依赖 Web/SDK，工具入口统一。

整体完成标准：使用一套可复现的模型与 MCP 联调配置，用户可创建会话、选择模型/技能、发起流程治理、查看工具进度与证据报告、完成一次受控整改操作，并查询完整执行记录。真实业务上线仍需接入真实 Auth 适配器及流程平台工具，并完成对应联调验收。
