# 可选 AST、能力程序与显式控制流架构

日期：2026-10-27。状态：设计提案，未接入运行时。本次新增文档和设计样例，不改变当前 DAG 的执行行为、POM 或已发布的 API。

关联：[现有总体方案](控制面与数据面分离总体方案.md)、[实现回顾](../implementation/架构回顾与改进清单.md)、[动态数据库规则方案](动态模板与数据库规则架构.md)。

## 1. 结论和适用边界

建议在现有工具网关上增加 **ProgramSource → CompiledProgram → ExecutionDriver** 抽象，AST 是一种可选输入形式。现有 DAG 包装为 LegacyDagProgram，继续使用原 DagExecutor；新的结构化程序将来编译为 Control IR，由显式状态机驱动。这样可以先获得统一的程序描述和状态检查能力，再决定是否启用 AST 执行。

用户提及的 cpp 在此理解为 C++ 模板、元编程式的组合与实例化。可以借鉴类型参数、约束、模板展开和特化思想；C++ 模板本身是编译期机制，不能直接提供 Java 运行时控制流。建议主要生成受限程序结构，必要时才生成源码。

组合通用能力能提高复用和任务表达能力，但不能凭空获得底层没有的操作权限、设备接口或外部服务。新算法可以通过受控编译获得；新外部能力仍需要注册执行器、配置身份和验证协议。

以下场景值得引入上层程序抽象：多分支、有限重试、等待事件、调用子程序、复用业务模板，以及运行时生成能力组合。单次查询、固定查询到导出链继续使用当前 DAG 即可。

## 2. AST、控制流和状态分开

| 对象 | 回答的问题 | 是否随执行改变 |
| --- | --- | --- |
| Program AST | 程序由哪些结构组成，如顺序、条件、调用 | 发布版本不可变 |
| Control IR / CFG | 每个控制点允许跳转到哪里，输入来自何处 | 编译结果不可变 |
| ExecutionSnapshot | 当前激活哪个控制点、等待什么、局部值是什么 | 在事务中更新 |
| ExecutionEvent | 哪个输入/决策/工具结果使状态发生变化 | 追加记录 |
| ControlStateView | 当前进度、候选跳转、阻塞原因和剩余预算 | 从以上对象生成投影 |

AST 不会自动提取正在运行的任意 Java 调用栈。解析 Java 源码只能描述潜在结构，不能可靠恢复反射、线程、外部调用或 JVM 局部变量。这里管理的是 Agent 自身的显式执行帧；现有 Java 方法内部仍作为一个能力调用处理。

TaskState 仍是任务级状态，新增执行快照作为它的组成部分或关联记录；ModelContext 仍是每次模型调用的受限投影；PersistentMemory 仍保存跨任务事实。程序定义和 Artifact 是另外两类对象，不能再次混进会话记忆。

## 3. 总体结构

```mermaid
flowchart TD
    A[现有 executionPlan] --> B[LegacyDagFrontend]
    C[LLM 结构化程序 / 模板实例] --> D[可选 AST Frontend]
    B --> E[ProgramCompiler 类型 能力 预算 校验]
    D --> E
    E --> F[CompiledProgram 不可变版本]
    F --> G{ExecutionFacade 选择驱动}
    G --> H[现有 DagExecutor]
    G --> I[ControlRuntime 显式控制状态]
    H --> J[统一能力调用网关]
    I --> J
    J --> K[授权 Adapter Filter 确认 审计]
    K --> L[MCP Java SQL Skill Computer Worker]
    L --> M[Artifact 与受限结果]
    M --> H
    M --> I
    I <--> S[ExecutionSnapshot 与事件]
    H --> V[Legacy 状态投影]
    S --> N[ControlStateInspector]
    V --> N
    N --> O[ContextPlanner / 可视化 / 调试]
```

不要把 `FlowAst`、`ExpressionAst`、`QueryAst` 设计成一个包罗万象的树：流程树负责顺序和分支；表达式树负责纯计算；查询树负责关系操作和 SQL。三者通过类型化端口连接，各自具有独立的验证器。

## 4. 兼容层与 Java 接口

建议包结构：

```text
program/api          ProgramSource、ProgramRef、CompiledProgram、ControlStateView
program/frontend     LegacyDagFrontend、TemplateFrontend、可选 StructuredAstFrontend
program/compile      类型/权限需求/副作用/预算检查、SourceMap
program/ir           Block、Instruction、Terminator、ValueRef
program/runtime      ExecutionDriver、ControlRuntime、ExecutionFrame、Transition
program/catalog      ProgramRegistry、CapabilityCatalog、模板版本
program/inspect      LegacyDagInspector、ControlStateInspector
rules/api            RuleSet、RuleSnapshot、Decision
query/api            QueryPlan、Predicate、BoundQuery、QueryPolicy
integration/mybatis  PolicySqlSource、LanguageDriver、必要的拦截器
integration/jdbc     PolicyQueryExecutor
worker/api           ProgramBundle、WorkerInvocation、WorkerResult
```

接口草案，名称仅用于评审，尚不是可调用 SDK：

```java
interface ProgramFrontend {
    boolean supports(String format);
    ProgramSource parse(ProgramDocument document, ParseLimits limits);
}
interface ProgramCompiler {
    CompiledProgram compile(ProgramSource source, CompileScope scope);
}
interface ExecutionDriver {
    boolean supports(String backend, String engineVersion);
    Transition advance(ExecutionSnapshot current, RuntimeEvent event);
}
interface ControlStateInspector {
    ControlStateView inspect(CompiledProgram program, ExecutionSnapshot state);
}
interface CapabilityInvoker {
    InvocationResult invoke(AuthorizedInvocation invocation);
}
```

`CompiledProgram` 是带 backend 标签的封闭类型，例如 `LegacyDagProgram` 与 `ControlGraphProgram`。不要求现有 DagExecutor 理解循环，也不将新循环偷偷展开成当前 DAG。第二阶段才为可证明等价的直线程序提供编译到 DAG 的优化。

`CompileScope` 来自服务端，包含可用能力快照、输入 Schema、配额上限和编译选项；模型只能声明需求。`AuthorizedInvocation` 不能从 JSON 直接反序列化获取权限，必须由网关在每次调用前签发或构造。

推荐配置为 `program.frontend=legacy`，可逐步开放 `structured-json`；解析器与执行后端分开开关。不支持的结构明确拒绝，不降级成 shell、eval 或再次询问模型如何绕过限制。

现有计划的原始 JSON、planHash、callId 和确认记录不改变。不能在包装时重新编号旧节点，否则会破坏幂等与暂停恢复。新状态接口根据保存的 engineVersion 选择检查器，不把旧检查点强行迁移为执行帧。

## 5. 第一版语言与通用元能力

| 类别 | 第一版建议 | 约束 |
| --- | --- | --- |
| 调用 | InvokeCapability | 指定已登记能力版本和类型化端口 |
| 组合 | Sequence、CallProgram、Return | 子程序有固定版本和效果声明，第一版拒绝递归环 |
| 分支 | If、Match | 条件是纯表达式；缺失/错误不能默认为成功 |
| 等待 | AwaitEvent、AwaitDecision | 事件有身份、关联 ID、期限和去重标识 |
| 模型判断 | Decide | 仅提供受限摘要；返回枚举分支或子程序提案，重新校验 |
| 循环 | BoundedForEach、Retry | 集合和次数有上限，重试受能力幂等性约束 |
| 失败 | Fail、有限错误处理 | 取消、权限拒绝、预算耗尽不能被业务 catch 吞掉后继续 |

暂不开放任意 goto、无限 while、动态反射、Java 方法名拼接和任意函数调用。CFG 可以有经过验证的有界回边，有循环的图已经不是 DAG。IR 内部可以包含 Jump/Branch，但跳转目标由编译器生成并验证，用户没有任意改 pc 的接口。

通用能力目录可以包括 `query.execute`、`data.aggregate`、`document.parse`、`artifact.export`、`model.decide`、`computer.observe`、`computer.act`、`program.instantiate` 和 `worker.execute`。这是概念命名，现有 `data__aggregate` 等工具由适配器映射；不是新增即已可用的工具。

能力描述至少包括 input/output Schema、版本/哈希、READ/WRITE 等副作用、可重试性、幂等保证、数据用途和目标、运行环境及预算。组合能力的效果是子能力效果的保守并集，权限是所需授权的并集；发布为新能力不能把 WRITE 伪装成 READ，不能继承发布者权限替调用者执行。

`BoundedForEach` 只处理少量控制项或 Artifact 分片 ID。几万行数据仍由 SQL、流式聚合或 Worker 在数据面处理，不形成几万个 AST 节点或模型调用。金额继续采用 Decimal/BigDecimal，不因为引入表达式引擎而退化为 double。

## 6. 状态提取与跳转约束

执行快照建议保存以下字段，均有大小和层级限制：

```text
taskId、revision、programId/hash、compilerVersion、engineVersion
activeCursors = [{frameId, blockId, instructionOffset}]
frames = [{frameId, parentFrameId, returnTo, boundedLocals, artifactRefs}]
activationPath、loopCounters、pendingInvocationIds、waitDescriptor
lastAppliedEventSeq、remainingBudgets、policyEpoch
```

先保持一个活跃 cursor，预留多个 cursor 表达未来并行。输入/output 类型先做确定赋值与作用域检查：分支结束后仅能使用所有到达路径都已定义的值，或明确的 Option/Union。循环的同名节点每次具有不同 activationId；不能仅用 AST nodeId 作为写操作幂等键。

示意语义：`advance(program, snapshot, event) -> proposedTransition + commands`。Runtime 在同一事务中校验 revision、事件是否已消费、允许的边、状态变化和预算扣减，再记录外部调用意图。执行器随后派发命令，结果作为事件回到该调用位置；不能在状态归约器里直接调用数据库、模型或网络。

外部调用使用稳定的 logicalOperationId，包含任务、程序版本、调用帧/循环激活路径和节点。一次逻辑操作的允许重试保持相同 ID，尝试次数另记。数据库已提交但结果未持久化的窗口仍然存在：无目标端幂等或核对能力时进入 UNKNOWN，不能宣称检查点实现 exactly-once。未知写结果不能走 success 分支。

分支结果、非确定性时间/模型决策要持久记录。恢复使用已经记录的结果；再次问模型可能得到不同分支，不是同一次执行的重放。审批绑定最终逻辑参数、数据哈希、程序/规则版本和有效授权，批准后仍检查当前撤销规则。

`ControlStateView` 返回 currentLocations、completedSteps、blockedReasons、possibleTransitions、dataRefs、budgets。对旧 DAG，仅依据依赖完成状态计算候选节点；状态检查不能触发工具、模型或数据库读取。`possibleTransitions` 是解释用视图，不是客户端可直接提交的跳转凭证。

用户追加要求先进入现有 inbox，在模型/Decide/Await 的安全边界消费。改变目标产生新程序提案，不能修改已执行前缀。旧任务可继续旧版本，新任务使用新版本；正在运行的程序迁移要显式校验帧映射、局部值 Schema、在途写操作和审批指纹，不做通用“热改指令”。

## 7. 运行时生成、模板实例化与注册

建议模板分三个层级：

| 层级 | 生成物 | 适合的需求 |
| --- | --- | --- |
| 参数实例 | 已验证模板＋类型化值 | 月报、不同字段的统计、不同阈值的规则 |
| 程序实例 | 受限 AST/IR＋能力依赖 | 新增分支、组合已有工具形成专用能力 |
| 源码实例 | 固定 ABI 的 Worker Bundle | 原有数据算子不能表达的新算法 |

模板定义约束 TypeParameter、CapabilityParameter、FieldParameter 和 ValueParameter。FieldParameter 绑定到服务端目录中的字段符号；ValueParameter 只成为值。模板展开采用结构替换和内部标识重命名，不能简单字符串替换造成变量捕获、SQL 注入或权限扩展。限制展开深度、总节点数和编译时间。

运行时流程：创建任务范围草稿 → Schema/类型/效果/预算检查 → 固定工具和规则版本 → 用 fixture 或仿真执行 → 保存不可变版本 → 按部署策略启用 → 可选发布为组合能力。样例用于验证预期行为和辅助生成，不是安全证明。仿真必须使用无副作用执行器；不能为了验证计划执行一次真实写入，再正式执行第二次。

任务内只读组合可以在既有授权范围内自动实例化，无需每次人工确认。跨任务共享、扩大能力范围或新增写副作用使用独立发布权限/现有确认策略。Registry 的发布权限与执行权限分开，模型不能自行给生成程序签发更多权限。

注册结果为带 tenant、scope、hash、输入输出 Schema、依赖、effect、有效期的 ProgramRef。`latest` 只用于新任务解析，运行任务始终固定版本。复用程序仍经过网关，并共用父任务剩余预算，不允许子程序重置配额。

当前 run 会冻结工具目录，新程序不能靠热改全局 catalog 就在该轮变成可调用工具。建议启用该功能时预先登记固定的 `program.instantiate` / `program.invoke` 能力：前者返回已校验的 ProgramRef，后者只允许调用本任务可见、依赖完全落在原授权能力集合内的版本。共享发布可以为后续任务生成新的工具描述；当前任务若需要新的底层能力，应进入新的授权/计划边界。不能用新程序包装一个原本无权调用的工具。

若确需生成 Java，使用完整 JDK 17 的 JavaCompiler 在独立构建/执行 Worker 中编译；JDK 的 ToolProvider 在缺少编译器模块时可以返回 null，部署需要实际验证。[JDK 17 ToolProvider](https://docs.oracle.com/en/java/javase/17/docs/api/java.compiler/javax/tools/ToolProvider.html)

构建固定 `--release 17`、受控 classpath、关闭自动注解处理，禁止模型临时下载任意依赖。Bundle 保存来源、编译器、依赖和 ABI 哈希。不能把 ClassLoader 当安全沙箱；主服务不加载模型生成类。现有 ProcessSupervisor 可承担进程生命周期管理，但并不提供 OS 隔离；生产代码 Worker 另配系统级隔离、资源和网络策略。

## 8. Computer Use 如何接入

把观察和动作分别登记为能力：Observe 产生屏幕/页面 Artifact 与有期限的观察 ID；Act 接受该观察 ID、允许的动作和目标。敏感句柄保留在 Runtime，模型只接收获准的图像或受限描述。

动作前校验环境、观察新鲜度和授权，动作后验证目标状态。页面变化后重新观察；不能仅因脚本没有异常就认定业务成功。提交、发送、支付等有外部副作用的操作按相应能力策略处理；超时且无法确认结果时不自动重复点击。

屏幕、网页或外部文档不能注册能力或修改规则。运行时生成的程序可组合 Observe → Decide → Act，但每个节点均经过相同网关。这能复用 Computer Use，同时保留可解释的控制轨迹。

## 9. 可用方案与取舍

| 方案 | 适用位置 | 本项目建议 |
| --- | --- | --- |
| 小型自有 JSON DSL＋类型化 IR | Agent 的能力组合与控制流 | 推荐主线，复用当前 DAG、Artifact 和确认网关；不承诺实现通用编程语言 |
| CEL Java | 分支条件、纯规则判断 | 优先验证；支持解析/类型检查/求值，限制输入集合和扩展函数。不能替代流程调度器。[官方项目](https://github.com/cel-expr/cel-java) |
| Commons JEXL | 更接近脚本的表达式 | 备选；能力更广，需显式配置 Permissions/Features，不能暴露任意服务对象。[官方说明](https://commons.apache.org/proper/commons-jexl/) |
| SCXML / 状态图 | 事件驱动、状态嵌套和转移语义 | 借鉴标准；若状态机建模成为主需求，再评估引擎，仍需自己提供数据面和权限。[W3C SCXML](https://www.w3.org/TR/scxml/) |
| Drools / DMN | 大量业务规则和决策表 | 规则子系统的候选；决策返回结构化结果，不让规则后果直接绕过网关执行工具。[规则引擎说明](https://docs.drools.org/latest/drools-docs/drools/rule-engine/index.html) |
| Temporal Java | 多实例、长时间等待、持久执行 | 规模需要时作为生命周期后端；模型和外部调用放 Activity，工作流消费记录的结果，不把原始数据放事件历史。[事件历史机制](https://docs.temporal.io/encyclopedia/event-history) |
| JavaCompiler / Janino | 必须编译源码的算法扩展 | 优先 JDK 编译器＋独立 Worker。Janino 官方说明作者已于 2025 年停止开发并归档仓库，新依赖需评估维护来源。[Janino 官方](https://janino-compiler.github.io/janino/) |
| MyBatis Dynamic SQL / JSqlParser / Calcite | 生成查询、分析已有 SQL、关系规划 | 三者职责不同，详见数据库规则方案；不把 SQL 解析成功当作授权通过 |

以上为选型候选，不是依赖兼容性声明。JDK 17、公司 Spring/MyBatis 版本及候选库的准确发布坐标需在 PoC 中固定；本次不修改依赖或声称已跑通这些引擎。可先使用有限的比较/布尔表达式节点，验证成本合适后再接 CEL，保留 ExpressionEvaluator SPI。

## 10. 分阶段落地

1. **只加抽象和检查视图。** ProgramSource、ProgramRef、ExecutionFacade、LegacyDagInspector；默认仍走旧执行器。提供只读状态解释，不引入新的恢复语义。
2. **增加模板和编译预检。** 模板生成现有 DAG 子集，检查字段、能力、效果和预算；只比较编译结果与现有执行轨迹，不重复调用工具。
3. **按需启用 ControlRuntime。** 从 Sequence/Invoke/If/Return/Await 开始，再加有界循环和子程序；执行帧、事件、预算和审批同时验收。
4. **接入数据库规则。** 查询模板和固定 Mapper 入口优先，按场景增加旧 SQL 改写；先支持只读 SELECT 的受控子集。
5. **独立代码 Worker 与共享能力发布。** 仅在前述组合不能满足算法需求时增加源码编译；并行控制流和多实例后置。

第一阶段即可保留未来 AST 的接入口；是否执行 AST 的决定可以延后，不必先引入 ANTLR、动态类加载或重量级规则引擎。

## 11. 验收条件

- 功能关闭时，旧 DAG 的 planHash、确认恢复、幂等键和大结果外置行为保持不变。
- 分支缺失变量、非法跳转、无界循环、模板递归和权限扩大在执行前拒绝。
- 同一静态节点的不同循环实例有不同 operationId，允许重试保持同一逻辑 ID。
- 任何崩溃点恢复均不能自动重放结果未知的写入；多次消费相同事件不重复推进。
- 相同快照和已记录事件得到相同转移；不为重放再次询问模型。
- 5 万行仍只存在数据面，AST、帧、决策上下文和追踪仅含引用与受限摘要。
- 用户追加请求在规定边界生效；不能修改已提交操作、伪造审批或吞掉取消。
- 规则更新、代码发布、缓存切换和撤销具有版本及审计记录。
- Windows/Linux 上使用相同程序协议与能力契约测试；平台 Worker 独立验证，协议一致不等于系统行为完全一致。

设计样例：[流程模板实例](../../examples/design/program-template-proposal.json)。该样例不是当前 `/api/chat` 的执行计划格式。
