云帆通用任务与流程治理 Agent（Java 17）
=====================================

本项目提供可直接运行的 Java 后端：普通对话与工具任务、MCP 多服务接入、技能管理、会话记忆、模型配置、流程规则检查、治理报告、写操作确认和执行审计。认证按需求保留 SPI 接口。

**启动与构建**

运行包解压后，在包根目录执行：

```powershell
java -jar yunfan-lowcode-agent-1.0.0.jar
```

打开 `http://127.0.0.1:8080/` 使用联调页面；健康检查为 `/actuator/health`，OpenAPI 为 `/openapi.json`。

默认 `local` 配置使用固定开发身份、磁盘持久化和明确标注的离线演示模型。可以验证“计算 12*(3+4)”“现在时间”“检查采购流程并创建待办”。待办会在确认后真实写入本服务数据库文件。真实模型与真实流程平台的接入方式见下文。

源码包需要完整 JDK 17 或更新版本；编译始终使用 `--release 17`，不需要 Python、Maven 或外部 JAR：

```powershell
# Windows；JAVA_HOME 应指向完整 JDK，而不是 JRE。
powershell -ExecutionPolicy Bypass -File scripts/build.ps1
java -jar target/yunfan-lowcode-agent-1.0.0.jar
```

```sh
# Linux/macOS
sh scripts/build.sh
java -jar target/yunfan-lowcode-agent-1.0.0.jar
```

编译脚本会执行完整 Java 自动化检查，再生成 JAR；测试结果保存在 `target/verification-results.json`。

使用外部配置：

```powershell
java -Dyunfan.config=config/application-local.properties -jar yunfan-lowcode-agent-1.0.0.jar
```

配置优先级：Java `-D` 属性 → 同名环境变量 → 外部 properties → 内置默认值。环境变量将键名转为大写并将 `.`、`-` 替换为 `_`，例如 `YUNFAN_HTTP_PORT=8090`。配置路径也可通过 `YUNFAN_CONFIG` 指定。

**真实模型接入**

支持 OpenAI-compatible Chat Completions 协议，包含真实 SSE 增量、模型提供的可见 reasoning 增量、工具调用、用量统计和可选 JSON 结构化输出。可以接入提供该兼容协议的企业模型网关；其他模型协议需实现 `ModelClient` 适配器。

先在服务进程的环境中配置密钥，再启动：

```powershell
$env:YUNFAN_MODEL_API_KEY = '替换为实际密钥'
java -jar yunfan-lowcode-agent-1.0.0.jar
```

在联调页面创建模型，或调用 `POST /api/model-configs`：

```json
{
  "name": "企业通用模型",
  "provider": "openai",
  "baseUrl": "https://model-gateway.example.com/v1",
  "modelName": "your-model",
  "credentialRef": "YUNFAN_MODEL_API_KEY",
  "capabilities": {
    "streaming": true,
    "toolCalling": true,
    "structuredOutput": true,
    "reasoning": false
  },
  "options": {"contextChars": 32000, "timeoutSeconds": 60, "max_tokens": 4096}
}
```

`credentialRef` 只保存环境变量名，不接受明文 API Key。执行 `/api/model-configs/{id}/test` 验证连接，再通过 `/default` 设为默认，或在请求中指定 `modelConfigId`。已有 local 数据目录不会因改变环境变量自动覆盖原模型配置。

普通 Agent 请求：

```json
{
  "requestId": "request-001",
  "message": "比较这两种审批方式，并计算每月节省的工时……",
  "modelConfigId": "实际模型配置ID",
  "skillIds": [],
  "context": {}
}
```

发送至 `POST /api/chat` 或 `POST /api/chat/stream`。响应包含 `runId`、`sessionId`、状态和最终 answer；多轮对话携带 sessionId。服务支持问答、分析、文本整理和已注册工具任务；实际可操作的外部业务取决于接入工具。

结构化输出通过 `responseFormat: {"type":"json_object"}` 或标准 OpenAI `json_schema` 对象启用。模型需要声明 structuredOutput 能力；最终结果额外返回 `structuredResult`，并按指定 Schema 验证。

**MCP 接入与业务工具**

支持 Streamable HTTP 的 2025-03-26、2025-06-18、2025-11-25 协议族：初始化、Session 传播、JSON/SSE 响应、分页工具发现、工具调用和目录热刷新。本版不声明支持旧 HTTP+SSE、stdio 或 2026 无状态协议。

1. 在服务环境中配置对应下游凭据变量。
2. 使用 `examples/mcp-server.json` 注册到 `POST /api/admin/mcp/servers`。
3. 调用 `POST /api/admin/mcp/reload`，检查 tools 和 failures。
4. 只读基础工具放入 baseTools；业务写工具加入相应技能 allowedTools。
5. 工具名暴露为 `serverId__toolName`，调用时映射回原始工具名。

工具风险必须在 toolPolicies 中明确配置：READ、WRITE、HIGH_RISK 或 DISABLED；未配置的外部工具默认 HIGH_RISK。所有写操作经确认后执行。基础目录、权限、Schema、当前服务启停与工具策略都会在执行前检查。

有状态连接以服务、租户、用户、权限和凭据指纹隔离。404 Session 失效时，只读请求重新初始化一次；401 时，只读请求通过 DownstreamCredentialProvider 获取新凭据并恢复一次。写请求遇到连接/认证等不确定结果不自动重试。

工具调用附带 `_meta["yunfan/idempotencyKey"]`，值为持久化执行 ID。下游需要识别该扩展键才能提供业务幂等保障；本服务不会因此假设所有第三方写接口具有幂等性。

对于流程发布等版本敏感操作，可配置 `versionChecks`，在执行前调用指定 READ 工具，比较 actual version 与已确认参数中的 expectedVersion。业务平台仍需在写入时原子校验 expectedVersion，避免读取与写入之间发生并发更新。

**技能管理与语义触发**

技能 Markdown 示例位于 `examples/skills/`。通过 `POST /api/skills` 提交 `{"markdown":"..."}`，或将包含一个 SKILL.md 的 ZIP 以 `application/zip` 原始请求体上传到 `/api/skills/import`。不要将 ZIP 包装成 multipart。

front matter 支持字符串、布尔值、整数、简单行内列表和块列表；不支持完整 YAML 的标签、锚点或多行标量。ZIP 校验路径、文件数、文件大小和解压总量，文件作为资源数据保存，不执行上传的脚本。

显式技能优先，再按 topK 和阈值补充检索候选。技能保存新版本，运行绑定版本；技能停用在后续调用前生效。没有激活技能时只提供基础工具。技能可以缩小工具使用范围，不能绕过身份权限。

没有配置 Embedding 时使用标记为 `local-lexical-ngram-v1` 的本地词法检索；这不等同于语义向量模型。配置下列参数后使用真实 Embedding 接口进行余弦相似度匹配：

```properties
yunfan.embedding.base-url=https://model-gateway.example.com/v1
yunfan.embedding.model=your-embedding-model
yunfan.embedding.credential-ref=YUNFAN_EMBEDDING_API_KEY
```

更换模型后对技能执行 `/api/skills/{id}/reindex`。检索不会混用不同模型或不同维度的向量。Embedding 不可用时仍能显式激活技能。

**流程治理与操作闭环**

结构化检查调用 `POST /api/governance/checks`，请求示例：

```json
{
  "requestId": "check-001",
  "process": {
    "id": "purchase", "version": "3",
    "nodes": [
      {"id":"start","type":"start"},
      {"id":"approve","type":"approval","approvers":[],"slaMinutes":60},
      {"id":"end","type":"end"}
    ],
    "edges": [{"source":"start","target":"approve"},{"source":"approve","target":"end"}]
  },
  "instances": []
}
```

该入口仍使用运行引擎和统一工具入口，直接执行确定性规则；不依赖模型自行决定是否检查。查询 `/api/runs/{runId}` 和 `/api/governance/reports` 查看结果。当前租户需要配置模型和治理规则；local/test 自动建立演示配置，pro 通过管理 API 建立。

规则处理器包括 NODE_REFERENCE、REACHABILITY、APPROVER、BRANCH、SLA、INSTANCE_SLA；支持启停、流程范围、严重度和版本。检查断链、重复节点、不可达节点、无结束路径、缺审批人、默认分支数量、SLA 格式和实例超期。合法循环不直接判错。

审批人有效性、复杂分支表达式和工作日历需要专用业务工具；缺少能力或资料时报告为 UNKNOWN。PASS、FAIL、UNKNOWN、NOT_APPLICABLE 独立统计。模型可以基于真实报告补充自然语言建议，不能改变规则判定。

报告保存流程 ID/版本、快照哈希、规则版本、问题严重度、证据、检查覆盖情况和建议来源。内置模板建议标记 DETERMINISTIC_TEMPLATE，不冒充模型分析。

待办接口 `/api/todos` 操作的是本服务待办；外部流程平台待办使用对应 MCP 工具。通过 `POST /api/todos` 创建也会进入确认流程。

**运行状态、确认与 SSE**

状态包括 CREATED、RUNNING、WAITING_INPUT、WAITING_CONFIRMATION、COMPLETED、FAILED、CANCELLED、EXPIRED、RECONCILIATION_REQUIRED。

- 相同身份下 requestId + 相同内容返回原运行；相同 ID 改变内容返回 409。
- 同一会话保留一个活跃或等待中的运行；其他新请求返回 SESSION_BUSY。
- 等待澄清时调用 `POST /api/runs/{id}/input`，请求为 `{"message":"补充信息"}`。
- 等待确认时，事件中给出 confirmationId、参数与版本。调用 `POST /api/confirmations/{id}/decision`，请求为 `{"decision":"APPROVE","version":1}` 或 REJECT。
- 确认绑定固定参数哈希；不能通过确认接口替换参数。并发或重复确认不会重复创建同一项待办。
- `POST /api/runs/{id}/cancel` 停止后续调度；已发生的外部写入不会被撤销。
- 重启时保留等待状态。被中断的活跃运行明确失败；正在执行的外部写入进入结果核对，不自动重放。

SSE 采用 POST + fetch ReadableStream。事件包含 runId、seq、type、timestamp、payload；类型包括 run.started、message.delta、reasoning.delta、step.started、tool.started、tool.completed、tool.failed、input.required、confirmation.required、report.created、error、done。

done 表示本次输出段结束，WAITING_* 还需要继续当前运行。恢复执行后订阅 `/api/runs/{id}/events?afterSeq=上次序号`。断开 SSE 不取消运行。完成运行的事件默认保留七天，过期游标返回 410，原始消息和最终报告仍保留。

外部写入结果不明时，查询 `/api/tool-executions`，由有权限的操作者先核对下游记录，再调用 `/api/tool-executions/{id}/reconcile`：

```json
{"resolution":"SUCCEEDED","evidence":"已核对下游操作日志编号……","externalOperationId":"operation-123"}
```

该接口只记录核对结果，不重新执行工具。原运行保留其历史状态，并增加 reconciliationStatus=RESOLVED。

**认证扩展**

生产实现以下 Java SPI，并将适配器 JAR 放入 lib/：

- AuthContextResolver：验证身份并返回租户、用户、权限和 traceId。
- AuthorizationPolicy：校验操作与资源访问范围。
- DownstreamCredentialProvider（按需）：按目标 MCP 交换和刷新下游凭据。

在适配器 JAR 中分别创建 `META-INF/services/接口全限定名`，文件内容为实现类全限定名。接口位置均在 `com.bydauto.yunfan.agent.auth`。生产必须提供前两个适配器；缺失时启动失败。三级 JWT 来源及优先级由真实 SSO 协议定义，本项目未猜测实现。

使用外部适配器或 JDBC 驱动时，通过 `scripts/start.ps1` / `scripts/start.sh` 启动，它们将 `lib/*` 加入 classpath。`java -jar` 不会自动加载 lib/ 中的扩展。

**存储与部署**

默认 FileDocumentStore：单实例独占目录锁、事务回滚、消息/运行/事件/确认记录一起原子落盘。适合开发、演示与小规模单实例。文件 JSON 快照不是分布式数据库。

JdbcDocumentStore：使用 JDBC，提供 PostgreSQL 14+ / MySQL 8.0+ 建表脚本，需先执行 `sql/相应数据库/V1__agent_store.sql` 并安装对应 JDBC 驱动。配置 jdbc-url、jdbc-user、jdbc-password-ref。本版将领域实体保存为具有 kind/id 的版本化 JSON 文档，跨文档更新使用数据库事务；没有使用设计草案中的 12 张独立领域表或 MyBatis。

两种存储模式都限定单个活跃服务实例；JDBC 通过独占服务锁防止多实例同时处理恢复任务。K8s 示例使用 replicas=1 与 Recreate。分布式执行租约和多活集群不在本版运行保证范围内。

Dockerfile 使用 JDK 17 编译与 JRE 17 运行；部署模板位于 deploy/。生产需替换镜像、域名、Secret 和 PVC，并放入认证适配器。Ingress 已设置 SSE 不缓冲和 300 秒超时。

原生模式提供健康检查和 `/api/admin/metrics` 运行统计；Spring 模式还可使用 Actuator。审计记录凭据脱敏字段及参数哈希，不保存访问令牌；业务原始工具结果仍按身份范围存储和读取。

**Spring Boot 接入与版本说明**

已提供 `src/spring/java` 的 Spring Boot 3.5.7 / Spring MVC 桥接层，使用同一个 ApiRouter 与业务服务，具有 SseEmitter、CORS、受限流式线程池和 Actuator。具备 Maven 及依赖访问能力的环境中执行：

```sh
mvn -Pspring clean package
java -jar target/yunfan-lowcode-agent-1.0.0-spring.jar
```

为兼容 JDK 17 和支持离线验证，本版核心采用 JDK HttpClient 与显式模型/MCP 协议适配器，未引入 Spring AI 或 MCP SDK。所有工具循环由 AgentRunService 显式控制。Spring 依赖解析与打包在本交付环境中未执行，不将其列为已验证的运行产物。

**交付与验证**

源码包包括 Java 源码、测试、配置、SQL、OpenAPI、联调页、Docker/K8s/CI、技能示例和设计/实施文档。运行包包括可执行 JAR、启动脚本、配置、示例和文档；不包含测试产生的数据、凭据或本机 JDK。

详细验证结果及未验证项见 `docs/implementation/验证说明.md`。生产接入前还需用真实 Auth、模型网关与流程平台完成联调。
