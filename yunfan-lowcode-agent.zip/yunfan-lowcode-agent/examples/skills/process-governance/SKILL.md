---
name: process-governance
description: 流程治理、流程定义检查、超期实例分析及整改待办
version: 1.0.0
allowedTools: [workflow__get_definition, workflow__list_instances, governance__check, todo__create, workflow__create_todo, workflow__publish_definition]
triggerExamples: [检查采购审批流程, 分析流程积压, 生成整改待办]
priority: 10
requiresConfirmation: false
---
先查询用户指定版本的流程，转换成标准 process 快照，再调用 governance__check。

明确报告的检查覆盖情况和证据，不能将 UNKNOWN 描述为已通过。
分析运行超期时需取得真实实例时间及 SLA；工作日历未接入时说明无法判定。

需要整改时先说明具体修改或待办内容；使用统一工具确认机制后执行。
区分本服务的 todo__create 与外部平台的 workflow__create_todo，按用户目标选择。
发布流程必须传递 expectedVersion，并要求平台自身原子检查该版本。
