import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;

/** Run using a deployment-approved JDK source launcher; input is the JSON object on stdin. */
public class JsonDigest {
    public static void main(String[] args) throws Exception {
        byte[] input=System.in.readNBytes(1024*1024+1);
        if(input.length>1024*1024)throw new IllegalArgumentException("Input exceeds 1 MiB");
        String hash=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(input));
        System.out.write(("{\"inputBytes\":"+input.length+",\"sha256\":\""+hash+"\"}\n").getBytes(StandardCharsets.UTF_8));
    }
}
