---
name: java-json-digest
description: 使用 Java 计算输入 JSON 的字节数和 SHA-256 摘要
type: script
runtime: java
entrypoint: scripts/JsonDigest.java
timeoutSeconds: 30
tags: [java, digest]
---

仅在用户需要计算输入 JSON 的摘要时调用本技能的 run 工具，参数就是待计算的 JSON 对象。
说明脚本将在服务账户权限下运行，经平台确认后执行。
摘要针对平台序列化后带换行的 UTF-8 输入，不宣称它等同于文件内容或规范化 JSON 的摘要。
读取返回的 stdout，说明字节数、SHA-256 和计算范围。失败时说明真实错误，不猜测摘要。
