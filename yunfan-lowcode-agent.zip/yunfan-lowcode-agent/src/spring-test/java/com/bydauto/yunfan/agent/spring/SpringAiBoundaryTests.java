package com.bydauto.yunfan.agent.spring;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.data.*;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.*;
import org.springframework.ai.model.tool.ToolCallingChatOptions;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Compiled/run only by -Pspring against the actual pinned Spring AI artifacts, not local stubs. */
public final class SpringAiBoundaryTests {
    public static void main(String[] args)throws Exception{
        Path root=Files.createTempDirectory("spring-ai-data-boundary-");Path cfg=root.resolve("test.properties");Files.writeString(cfg,"yunfan.data.directory="+root.resolve("artifacts").toString().replace('\\','/')+"\n");Config config=new Config(cfg);
        try(var store=new FileDocumentStore(root.resolve("store"))){
            var data=new DataWorkspace(store,config);var policy=new ToolResultPolicy(data);var actor=new AuthContext("test","owner",Set.of("tool:query"),"test");
            List<Object> rows=new ArrayList<>();for(int i=0;i<50000;i++)rows.add(Json.map("value",i,"secret","ROW_SECRET_"+i));
            ToolCallback original=new ToolCallback(){public ToolDefinition getToolDefinition(){return ToolDefinition.builder().name("query").description("query").inputSchema("{\"type\":\"object\"}").build();}public String call(String input){return Json.write(Json.map("rows",rows,"total",50000));}};
            var guarded=new GuardedToolCallback(original,policy,()->new GuardedToolCallback.Scope(actor,"run"),AuthorizationPolicy.defaultPolicy(),"READ");String result=guarded.call("{}");
            if(result.length()>3000||result.contains("ROW_SECRET_")||!result.contains("dataRef"))throw new AssertionError("Spring callback leaked rows");
            AtomicBoolean called=new AtomicBoolean();ChatModel fake=prompt->{
                if(!(prompt.getOptions() instanceof ToolCallingChatOptions options))throw new AssertionError("Tool declarations missing");
                try{options.getToolCallbacks().get(0).call("{}");throw new AssertionError("Declaration-only callback was executable");}catch(IllegalStateException expected){}
                if(prompt.getInstructions().stream().anyMatch(m->m.toString().contains("ROW_SECRET_")))throw new AssertionError("Spring prompt leaked rows");called.set(true);
                return new ChatResponse(List.of(new Generation(new AssistantMessage("ok"))));
            };
            var client=new SpringAiModelClient(fake,Json.map("modelName","fixture","options",Json.map()),config);
            var messages=List.of(Json.map("role","system","content","policy"),Json.map("role","user","content","query"),Json.map("role","assistant","content","","tool_calls",List.of(Json.map("id","c1","function",Json.map("name","query","arguments","{}")))),Json.map("role","tool","tool_call_id","c1","content",result));
            var spec=Json.map("type","function","function",Json.map("name","query","description","query","parameters",Json.map("type","object")));
            var response=client.complete(messages,List.of(spec),false,(type,text)->{});if(!called.get()||!response.content().equals("ok"))throw new AssertionError("Spring AI bridge failed");
            boolean rejected=false;try{new GuardedToolCallback(original,policy,()->null,AuthorizationPolicy.defaultPolicy(),"WRITE");}catch(IllegalArgumentException expected){rejected=true;}if(!rejected)throw new AssertionError("Writes bypassed confirmation");
            System.out.println("SPRING AI BOUNDARY TESTS PASSED: callback offloading, message conversion, declaration-only callbacks, write bypass rejected");
        }
    }
}
