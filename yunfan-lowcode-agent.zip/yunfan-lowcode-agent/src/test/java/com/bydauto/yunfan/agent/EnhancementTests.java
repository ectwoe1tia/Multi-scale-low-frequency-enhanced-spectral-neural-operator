package com.bydauto.yunfan.agent;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.chat.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.process.*;
import com.bydauto.yunfan.agent.runtime.*;
import com.bydauto.yunfan.agent.skill.*;
import com.bydauto.yunfan.agent.tooling.*;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BiConsumer;
import java.util.regex.Pattern;
import java.util.zip.*;

public final class EnhancementTests {
    private static final AuthContext ACTOR=new AuthContext("local","developer",Set.of("*"),"enhancement-test");
    private static BiConsumer<String,Boolean> check;
    private static void reject(String name,String code,Runnable action) {
        try {action.run();throw new AssertionError(name+" did not reject");}
        catch(ApiException e){check.accept(name,code==null||e.code.equals(code));}
    }
    public static void run(BiConsumer<String,Boolean> assertion)throws Exception {
        check=assertion;
        parserAndWindow();
        Path root=Files.createTempDirectory("yunfan-enhancement-");
        String java=Path.of(System.getProperty("java.home"),"bin",System.getProperty("os.name").startsWith("Windows")?"java.exe":"java").toString().replace('\\','/');
        String classpath=String.join(File.pathSeparator,Arrays.stream(System.getProperty("java.class.path").split(Pattern.quote(File.pathSeparator))).map(p->Path.of(p).toAbsolutePath().toString().replace('\\','/')).toList());
        StringBuilder config=new StringBuilder("yunfan.profile=test\nyunfan.store.directory="+root.resolve("data").toString().replace('\\','/')+"\nyunfan.process.directory="+root.resolve("processes").toString().replace('\\','/')+"\nyunfan.process.enabled=true\nyunfan.process.max-children=4\n");
        config.append("yunfan.process.command.java=").append(Json.write(List.of(java,"-Xmx64m"))).append('\n');
        for(String mode:List.of("stdio","slow","flood","fail","echo","page-fail"))config.append("yunfan.process.command.").append(mode).append('=').append(Json.write(List.of(java,"-Xmx64m","-cp",classpath,ProcessFixture.class.getName(),mode))).append('\n');
        Path file=root.resolve("test.properties");Files.writeString(file,config.toString());
        Config settings=new Config(file);
        String waiting;
        try(AppServices app=new AppServices(settings)) {
            processTests(app);
            stdioTests(app);
            scriptTests(app);
            contextTests(app);
            finalResponseRace(app);
            Map<String,Object> run=app.runs.start(ACTOR,Json.map("message","澄清重启补充测试"));
            run=app.runs.await(ACTOR,run.get("id").toString(),10000);
            waiting=run.get("id").toString();
            check.accept("inbox restart fixture waits for input",run.get("status").equals("WAITING_INPUT"));
            app.runs.context.enqueue(ACTOR,waiting,Json.map("requestId","after-restart","message","重启后需要保留的补充"));
        }
        try(AppServices app=new AppServices(settings)) {
            check.accept("queued input survives service restart",app.runs.context.list(ACTOR,waiting).size()==1);
            app.runs.input(ACTOR,waiting,"补充已完成");
            var done=app.runs.await(ACTOR,waiting,10000);
            check.accept("restored input applies on resumed model call",done.get("status").equals("COMPLETED")&&Json.object(app.runs.context.list(ACTOR,waiting).get(0)).get("status").equals("APPLIED"));
        }
    }
    private static void parserAndWindow() {
        var parsed=new SkillMdParser().parse("\uFEFF---\r\nname: text\r\ndescription: >\r\n  first line\r\n  second line\r\nallowed-tools: [\"a,b\", x]\r\n---\r\n```java\r\nSystem.exit(0);\r\n```\r\n");
        check.accept("skill BOM folded scalar and quoted comma",Json.child(parsed,"metadata").get("description").equals("first line second line")&&Json.strings(Json.child(parsed,"metadata").get("allowedTools")).contains("a,b"));
        check.accept("fenced code stays text by default",Json.child(parsed,"metadata").get("type").equals("text"));
        reject("skill rejects Windows reserved path",null,()->SkillMdParser.validatePath("scripts/CON.java"));
        reject("skill rejects traversal entrypoint",null,()->new SkillMdParser().parse("---\nname: bad\ndescription: bad\ntype: script\nruntime: java\nentrypoint: ../Bad.java\n---\nx"));
        List<Map<String,Object>> source=new ArrayList<>(List.of(Json.map("role","system","content","policy"),Json.map("role","user","content","original objective")));
        for(int i=0;i<4;i++) {
            source.add(Json.map("role","assistant","content","","tool_calls",List.of(Json.map("id","call"+i,"type","function","function",Json.map("name","echo","arguments","{}")))));
            source.add(Json.map("role","tool","tool_call_id","call"+i,"content","x".repeat(1000)));
        }
        var window=new ContextWindow().fit(source,1900,"run1");
        check.accept("context compacts whole tool groups and retains latest result",window.removedGroups()==3&&window.messages().stream().filter(m->"tool".equals(m.get("role"))).count()==1&&Json.write(window.messages()).contains("call3")&&Json.write(window.messages()).contains("original objective"));
        check.accept("context compaction preserves original transcript",source.size()==10);
        reject("context refuses to truncate pinned instructions", "CONTEXT_LIMIT_EXCEEDED",()->new ContextWindow().fit(List.of(Json.map("role","system","content","x".repeat(2000))),1000,"run1"));
    }
    private static void processTests(AppServices app) {
        try(ProcessSupervisor disabled=new ProcessSupervisor(new Config(null))) {
            reject("local process execution is disabled by default","PROCESS_DISABLED",()->disabled.command("java"));
        }
        reject("process command must be deployment configured","PROCESS_COMMAND_DENIED",()->app.processes.command("untrusted"));
        var a=app.processes.workspace();var b=app.processes.workspace();
        check.accept("process workspaces are unique",!a.equals(b));
        var echo=app.processes.execute("echo",List.of(),a,"literal $(do-not-execute); & text",3,1024);
        check.accept("process input is passed literally on stdin",echo.get("stdout").equals("literal $(do-not-execute); & text"));
        reject("process enforces output bound","PROCESS_OUTPUT_LIMIT",()->app.processes.execute("flood",List.of(),b,"",3,1024));
        reject("process timeout terminates child","PROCESS_TIMEOUT",()->app.processes.execute("slow",List.of(),b,"",1,1024));
        reject("process nonzero exit is explicit","SCRIPT_EXIT_NONZERO",()->app.processes.execute("fail",List.of(),b,"",3,1024));
        List<ProcessSupervisor.Child> held=new ArrayList<>();
        try {
            for(int i=0;i<4;i++)held.add(app.processes.start("slow",List.of(),Map.of(),app.processes.workspace()));
            reject("process child concurrency is bounded","PROCESS_CAPACITY",()->app.processes.start("slow",List.of(),Map.of(),b));
        } finally {held.forEach(ProcessSupervisor.Child::close);}
        check.accept("closed child processes terminate",held.stream().allMatch(c->{try{return c.process.waitFor(3,TimeUnit.SECONDS);}catch(InterruptedException e){return false;}}));
    }
    private static void stdioTests(AppServices app) {
        reject("MCP API rejects arbitrary launch commands",null,()->app.mcp.save(ACTOR,null,Json.map("command","arbitrary")));
        var server=app.mcp.save(ACTOR,null,Json.map("serverId","stdio","transport","stdio","commandProfile","stdio","timeoutSeconds",2,"baseTools",List.of("echo"),"toolPolicies",Json.map("echo","READ")));
        check.accept("stdio MCP initialize notification and discovery",app.mcp.test(ACTOR,"stdio").get("status").equals("UP"));
        ToolDefinition tool=app.mcp.catalog(ACTOR,true).tools().stream().filter(t->t.name().equals("stdio__echo")).findFirst().orElseThrow();
        var first=Json.child(app.mcp.invoke(ACTOR,tool,Json.map("text","中文")),"structuredContent");
        var second=Json.child(app.mcp.invoke(ACTOR,tool,Json.map()),"structuredContent");
        check.accept("stdio MCP reuses identity process",first.get("pid").equals(second.get("pid")));
        var other=Json.child(app.mcp.invoke(new AuthContext("local","other",Set.of("*"),"other"),tool,Json.map()),"structuredContent");
        check.accept("stdio MCP isolates user processes",!other.get("pid").equals(first.get("pid")));
        check.accept("stdio environment does not inherit PATH or model secrets",!Json.strings(first.get("env")).contains("PATH")&&!Json.strings(first.get("env")).contains("YUNFAN_MODEL_API_KEY"));
        reject("stdio MCP read timeout is bounded","MCP_TIMEOUT",()->app.mcp.invoke(ACTOR,tool,Json.map("sleep",true)));
        check.accept("stdio MCP reconnects after failed read",Json.child(app.mcp.invoke(ACTOR,tool,Json.map()),"structuredContent").containsKey("pid"));
        app.mcp.save(ACTOR,"stdio",Json.map("toolPolicies",Json.map("echo","HIGH_RISK")));
        reject("MCP configuration change invalidates bound tool","MCP_CONFIG_CHANGED",()->app.mcp.invoke(ACTOR,tool,Json.map()));
        ToolDefinition write=app.mcp.catalog(ACTOR,true).tools().stream().filter(t->t.name().equals("stdio__echo")).findFirst().orElseThrow();
        reject("stdio uncertain write is never retried","TOOL_RESULT_UNKNOWN",()->app.mcp.invoke(ACTOR,write,Json.map("crash",true)));
        app.mcp.delete(ACTOR,"stdio");
        app.mcp.save(ACTOR,null,Json.map("serverId","partial","transport","stdio","commandProfile","page-fail"));
        var failed=app.mcp.catalog(ACTOR,true);
        check.accept("failed MCP pagination does not leak partial catalog",failed.tools().isEmpty()&&failed.failures().size()==1);
        app.mcp.delete(ACTOR,"partial");
    }
    private static byte[] zip(Map<String,String> files)throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(ZipOutputStream zip=new ZipOutputStream(bytes)) {
            for(var e:files.entrySet()){zip.putNextEntry(new ZipEntry(e.getKey()));zip.write(e.getValue().getBytes(StandardCharsets.UTF_8));zip.closeEntry();}
        }
        return bytes.toByteArray();
    }
    private static void scriptTests(AppServices app)throws Exception {
        String markdown="---\nname: java-json-script\ndescription: explicit script package fixture\ntype: script\nruntime: java\nentrypoint: scripts/Main.java\ntimeoutSeconds: 10\n---\nRead JSON from stdin and print it.\n";
        String script="public class Main {public static void main(String[] args)throws Exception {String input=new String(System.in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8); if(input.contains(\"failNow\"))System.exit(2);System.out.print(input);}}";
        int before=app.skills.list(ACTOR).size();
        byte[] missing=zip(Map.of("SKILL.md",markdown));
        reject("script import requires existing entrypoint",null,()->app.skills.importZip(ACTOR,missing));
        check.accept("invalid script package leaves no skill record",app.skills.list(ACTOR).size()==before);
        var skill=app.skills.importZip(ACTOR,zip(Map.of("package/SKILL.md",markdown,"package/scripts/Main.java",script,"package/references/note.txt","resource note")));
        String id=skill.get("id").toString();
        var catalog=app.tools.catalog(ACTOR,List.of(skill));
        var read=catalog.stream().filter(t->t.originalName().equals("read_resource")).findFirst().orElseThrow();
        var execute=catalog.stream().filter(t->t.originalName().equals("run")).findFirst().orElseThrow();
        check.accept("skill resource names are relative to SKILL.md",Json.strings(skill.get("resourcePaths")).contains("scripts/Main.java"));
        check.accept("skill references are loaded on demand",Json.object(app.skillExecution.invoke(ACTOR,read,Json.map("path","references/note.txt"))).get("content").equals("resource note"));
        reject("skill resource cannot escape package",null,()->app.skillExecution.invoke(ACTOR,read,Json.map("path","../outside")));
        var request=Json.map("requestId",Util.id(),"message","run the explicit fixture","skillIds",List.of(id),"context",Json.map("directTool",execute.name(),"toolArgs",Json.map("text","literal; $()")));
        var run=app.runs.start(ACTOR,request);String runId=run.get("id").toString();
        run=app.runs.await(ACTOR,runId,10000);
        check.accept("script execution waits for confirmation",run.get("status").equals("WAITING_CONFIRMATION"));
        String cid=Json.required(Json.child(run,"waitingReason"),"confirmationId");
        var confirmation=app.store.get("confirmation",cid);
        check.accept("script confirmation exposes risk and isolation boundary",confirmation.get("risk").equals("HIGH_RISK")&&confirmation.get("warning").toString().contains("沙箱"));
        app.skills.save(ACTOR,id,markdown.replace("Read JSON","Version two: read JSON"));
        app.runs.resumeConfirmation(ACTOR,cid,"APPROVE",1);
        run=app.runs.await(ACTOR,runId,15000);
        check.accept("confirmed Java script executes pinned package version",run.get("status").equals("COMPLETED")&&run.get("answer").toString().contains("literal; $()"));
        var rejected=app.runs.start(ACTOR,Json.map("message","reject fixture","skillIds",List.of(id),"context",Json.map("directTool",execute.name(),"toolArgs",Json.map())));
        rejected=app.runs.await(ACTOR,rejected.get("id").toString(),10000);
        String rejectId=Json.required(Json.child(rejected,"waitingReason"),"confirmationId");
        app.runs.resumeConfirmation(ACTOR,rejectId,"REJECT",1);
        var no=app.runs.await(ACTOR,rejected.get("id").toString(),10000);
        check.accept("rejected script does not execute",app.store.list("tool-execution").stream().anyMatch(e->no.get("id").equals(e.get("runId"))&&"REJECTED".equals(e.get("status"))));
        var failing=app.runs.start(ACTOR,Json.map("message","failing fixture","skillIds",List.of(id),"context",Json.map("directTool",execute.name(),"toolArgs",Json.map("failNow",true))));
        failing=app.runs.await(ACTOR,failing.get("id").toString(),10000);
        app.runs.resumeConfirmation(ACTOR,Json.required(Json.child(failing,"waitingReason"),"confirmationId"),"APPROVE",1);
        failing=app.runs.await(ACTOR,failing.get("id").toString(),15000);
        check.accept("failed script requires reconciliation without replay",failing.get("status").equals("RECONCILIATION_REQUIRED"));
        app.skills.action(ACTOR,id,"disable");
        reject("disabled skill blocks previously bound script","SKILL_DISABLED",()->app.skillExecution.invoke(ACTOR,execute,Json.map()));
    }
    private static void contextTests(AppServices app) {
        String sid=app.sessions.create(ACTOR,"context fixture").get("id").toString(),id=Util.id();
        var calls=List.of(Json.map("id","c1"),Json.map("id","c2"));
        app.store.put("run",id,Json.map("id",id,"tenantId","local","userId","developer","status","RUNNING","sessionId",sid,"request",Json.map(),"pendingCalls",calls,"pendingIndex",0,"tools",List.of(),"model",Json.map("options",Json.map("contextChars",10000)),"modelMessages",List.of(Json.map("role","system","content","policy"),Json.map("role","user","content","original"),Json.map("role","assistant","content","","tool_calls",calls),Json.map("role","tool","tool_call_id","c1","content","one"),Json.map("role","tool","tool_call_id","c2","content","two"))));
        var body=Json.map("requestId","same","message","supplement");
        var entry=app.runs.context.enqueue(ACTOR,id,body);
        check.accept("inbox append is idempotent",app.runs.context.enqueue(ACTOR,id,body).get("id").equals(entry.get("id")));
        reject("inbox detects request ID reuse","REQUEST_ID_CONFLICT",()->app.runs.context.enqueue(ACTOR,id,Json.map("requestId","same","message","changed")));
        reject("inbox enforces identity ownership","FORBIDDEN",()->app.runs.context.enqueue(new AuthContext("other","x",Set.of("*"),"x"),id,body));
        app.runs.context.enqueue(ACTOR,id,Json.map("requestId","reminder","kind","REMINDER","message","remember this","repeat",2));
        app.runs.context.enqueue(ACTOR,id,Json.map("requestId","expired","kind","REMINDER","message","expired","expiresAt","2020-01-01T00:00:00Z"));
        var cancel=app.runs.context.enqueue(ACTOR,id,Json.map("requestId","cancel","message","cancelled"));
        app.runs.context.cancel(ACTOR,id,cancel.get("id").toString());
        reject("inbox never splits pending tool result group","TOOLS_PENDING",()->app.runs.context.prepare(id));
        app.store.transaction(tx->{var run=tx.get("run",id);run.put("pendingIndex",2);tx.put("run",id,run);return null;});
        var one=app.runs.context.prepare(id);
        check.accept("appended conversation follows complete tool group",one.messages().get(5).get("content").equals("supplement")&&one.messages().get(4).get("tool_call_id").equals("c2"));
        check.accept("expired and cancelled input is not injected",!Json.write(one.messages()).contains("expired")&&!Json.write(one.messages()).contains("cancelled"));
        var two=app.runs.context.prepare(id);var three=app.runs.context.prepare(id);
        check.accept("reminder repeat count is exact without persistent copies",Json.write(one.messages()).contains("remember this")&&Json.write(two.messages()).contains("remember this")&&!Json.write(three.messages()).contains("remember this"));
        check.accept("model call chain links parent invocation",two.parentInvocationId().equals(one.invocationId())&&three.parentInvocationId().equals(two.invocationId()));
        check.accept("inbox history is persisted only once",app.sessions.messages(sid).size()==2);
        check.accept("run reminders do not leak into future session context",!Json.write(new ChatHistoryLogic().normalize(app.sessions.messages(sid))).contains("remember this"));
        app.store.transaction(tx->{var r=tx.get("run",id);r.put("status","COMPLETED");tx.put("run",id,r);return null;});
        reject("completed run rejects new appended messages","RUN_FINISHED",()->app.runs.context.enqueue(ACTOR,id,Json.map("requestId","late","message","late")));
    }
    private static void finalResponseRace(AppServices app)throws Exception {
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),4);
        ExecutorService pool=Executors.newCachedThreadPool();server.setExecutor(pool);
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
        List<Map<String,Object>> received=new CopyOnWriteArrayList<>();
        server.createContext("/v1/chat/completions",exchange->{
            try {
                var request=Json.object(Json.parse(new String(exchange.getRequestBody().readAllBytes(),StandardCharsets.UTF_8)));received.add(request);
                if(received.size()==1){entered.countDown();if(!release.await(10,TimeUnit.SECONDS))throw new IOException("test latch timed out");}
                byte[] bytes=Json.write(Json.map("choices",List.of(Json.map("message",Json.map("role","assistant","content","answer "+received.size()))),"usage",Json.map("total_tokens",3))).getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);exchange.getResponseBody().write(bytes);
            } catch(InterruptedException e){Thread.currentThread().interrupt();}finally{exchange.close();}
        });
        server.start();
        try {
            var model=app.models.save(ACTOR,null,Json.map("name","race fixture","provider","openai","modelName","test","baseUrl","http://127.0.0.1:"+server.getAddress().getPort()+"/v1","options",Json.map("contextChars",32000)));
            var run=app.runs.start(ACTOR,Json.map("message","first question","modelConfigId",model.get("id")));String id=run.get("id").toString();
            check.accept("model request has started before concurrent append",entered.await(10,TimeUnit.SECONDS));
            var append=Json.map("requestId","during-response","message","new constraint arrived while streaming");
            List<Future<Map<String,Object>>> attempts=new ArrayList<>();
            for(int i=0;i<4;i++)attempts.add(pool.submit(()->app.runs.context.enqueue(ACTOR,id,append)));
            Set<String> ids=new HashSet<>();for(var future:attempts)ids.add(future.get().get("id").toString());
            check.accept("concurrent appended request is stored exactly once",ids.size()==1);
            release.countDown();run=app.runs.await(ACTOR,id,10000);
            check.accept("late appended input schedules another model request before completion",run.get("status").equals("COMPLETED")&&received.size()==2&&run.get("answer").equals("answer 2"));
            check.accept("next model request contains appended input exactly once",Json.list(received.get(1),"messages").stream().map(Json::object).filter(m->"new constraint arrived while streaming".equals(m.get("content"))).count()==1);
            check.accept("model call traces record context and usage",app.store.list("model-call").stream().filter(c->id.equals(c.get("runId"))&&"COMPLETED".equals(c.get("status"))).count()==2);
            ApiRouter.Response response=app.router.handle(new ApiRouter.Request("GET","/api/runs/"+id+"/calls",Map.of(),Map.of(),new byte[0]));
            check.accept("model call inspection endpoint works",response.status()==200);
        } finally {release.countDown();server.stop(0);pool.shutdownNow();}
    }
}
