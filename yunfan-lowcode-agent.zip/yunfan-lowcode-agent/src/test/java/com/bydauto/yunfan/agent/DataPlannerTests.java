package com.bydauto.yunfan.agent;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.chat.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.data.*;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.math.BigDecimal;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BiConsumer;
import java.util.zip.*;

/** Regression: 50,000 MCP rows -> server-side aggregation/export -> bounded model context. */
public final class DataPlannerTests {
    private static final AuthContext ACTOR=new AuthContext("local","developer",Set.of("*"),"data-regression");
    private static BiConsumer<String,Boolean> check;
    private static void reject(String name,Runnable work){try{work.run();throw new AssertionError(name);}catch(ApiException e){check.accept(name,true);}}
    public static void run(BiConsumer<String,Boolean> assertion)throws Exception{
        check=assertion;Path root=Files.createTempDirectory("yunfan-data-tests-");Path config=root.resolve("test.properties");
        Files.writeString(config,"yunfan.profile=test\nyunfan.store.directory="+root.resolve("state").toString().replace('\\','/')+"\nyunfan.data.directory="+root.resolve("data").toString().replace('\\','/')+"\nyunfan.http.port=0\n");
        List<Map<String,Object>> rows=new ArrayList<>();for(int i=0;i<50000;i++)rows.add(Json.map("department",i%2==0?"A":"B","amount",new BigDecimal("0.10"),"recordMarker","PRIVATE_ROW_"+i));
        try(AppServices app=new AppServices(new Config(config));Remote remote=new Remote(rows)){
            Map<String,Object> ref=Json.object(app.resultPolicy.modelView(ACTOR,"capture","mcp-query",Json.map("structuredContent",Json.map("rows",rows,"total",50000)),false));
            String id=Json.required(ref,"dataRef");
            check.accept("50000-row MCP result is a compact reference without raw preview",Json.write(ref).length()<2400&&!Json.write(ref).contains("PRIVATE_ROW_")&&Json.integer(ref,"rowCount",0)==50000);
            check.accept("bulk rows are absent from document store metadata",!Json.write(app.store.list("data-artifact")).contains("PRIVATE_ROW_"));
            var sums=Json.object(app.dataTools.invoke(ACTOR,"stats","data__aggregate",Json.map("dataRef",id,"groupBy",List.of("department"),"metrics",List.of(Json.map("op","count","as","count"),Json.map("op","sum","field","amount","as","sum"),Json.map("op","avg","field","amount","as","avg")))));
            var first=Json.object(Json.list(sums,"rows").get(0));
            check.accept("grouped count uses all 50000 rows",Json.list(sums,"rows").size()==2&&Json.integer(first,"count",0)==25000);
            check.accept("decimal SUM/AVG avoid binary floating point drift",new BigDecimal(first.get("sum").toString()).compareTo(new BigDecimal("2500"))==0&&new BigDecimal(first.get("avg").toString()).compareTo(new BigDecimal("0.1"))==0);
            var filtered=Json.object(app.dataTools.invoke(ACTOR,"filter","data__aggregate",Json.map("dataRef",id,"filters",List.of(Json.map("field","amount","op","eq","value",new BigDecimal("0.1"))),"metrics",List.of(Json.map("op","count","as","n")))));
            check.accept("numeric filter equality ignores decimal scale",Json.integer(Json.object(Json.list(filtered,"rows").get(0)),"n",0)==50000);
            var page=app.dataTools.invoke(ACTOR,"page","data__page",Json.map("dataRef",id,"offset",100,"limit",10));
            check.accept("explicit sample page has bounded rows and payload",Json.list(Json.object(page),"rows").size()<=10&&Json.write(page).length()<3000&&Json.write(page).contains("PRIVATE_ROW_100"));
            reject("sample page rejects bulk limit",()->app.dataTools.invoke(ACTOR,"page","data__page",Json.map("dataRef",id,"limit",50000)));
            reject("dataset handles enforce ownership even with wildcard permissions",()->app.data.owned(new AuthContext("local","another",Set.of("*"),"x"),id));
            reject("dataset handles reject traversal",()->app.data.download(ACTOR,"../state"));
            reject("aggregation rejects unknown fields",()->app.dataTools.invoke(ACTOR,"bad","data__aggregate",Json.map("dataRef",id,"metrics",List.of(Json.map("op","sum","field","missing","as","s")))));
            var partial=app.data.capture(ACTOR,"partial","remote",Json.map("data",rows.subList(0,2),"total",50000,"hasMore",true));
            check.accept("upstream pagination is labelled PARTIAL",partial.get("completeness").equals("PARTIAL"));
            var nested=DataWorkspace.table(Json.map("data",Json.map("rows",rows.subList(0,2),"hasMore",true),"complete",true));
            check.accept("outer complete flag cannot hide nested pagination",nested.completeness().equals("PARTIAL"));
            var unknown=app.data.capture(ACTOR,"unknown","remote",Json.map("rows",rows.subList(0,2),"rowCount",2));
            check.accept("page rowCount does not falsely certify whole-source completeness",unknown.get("completeness").equals("UNKNOWN"));
            var ps=Json.object(app.dataTools.invoke(ACTOR,"partial-stat","data__aggregate",Json.map("dataRef",partial.get("dataRef"),"metrics",List.of(Json.map("op","count","as","n")))));
            check.accept("statistics propagate partial coverage",ps.get("completeness").equals("PARTIAL")&&Json.integer(Json.object(Json.list(ps,"rows").get(0)),"n",0)==2);
            var many=Json.object(app.dataTools.invoke(ACTOR,"many","data__aggregate",Json.map("dataRef",id,"groupBy",List.of("amount"),"metrics",List.of(Json.map("op","count","as","n")))));
            check.accept("grouping does not return source row arrays",Json.write(many).length()<1000);
            var groupedInput=app.data.capture(ACTOR,"many-groups","test",Json.map("rows",rows.subList(0,200),"complete",true));
            var groupedOutput=Json.object(app.dataTools.invoke(ACTOR,"many-groups","data__aggregate",Json.map("dataRef",groupedInput.get("dataRef"),"groupBy",List.of("recordMarker"),"metrics",List.of(Json.map("op","count","as","n")))));
            check.accept("large aggregation output becomes another dataset reference",groupedOutput.get("kind").equals("dataset_ref")&&Json.integer(groupedOutput,"rowCount",0)==200&&!Json.write(groupedOutput).contains("PRIVATE_ROW_"));
            var empty=Json.object(app.dataTools.invoke(ACTOR,"empty","data__aggregate",Json.map("dataRef",id,"filters",List.of(Json.map("field","department","op","eq","value","absent")),"metrics",List.of(Json.map("op","count","as","n"),Json.map("op","sum","field","amount","as","sum")))));
            var emptyRow=Json.object(Json.list(empty,"rows").get(0));check.accept("empty aggregate returns count zero and sum null",Json.integer(emptyRow,"n",-1)==0&&emptyRow.get("sum")==null);
            var object=Json.object(app.resultPolicy.modelView(ACTOR,"blob","opaque",Map.of("text","private-data".repeat(2000)),false));
            check.accept("opaque large outputs never use text previews",object.get("kind").equals("artifact_ref")&&!Json.write(object).contains("private-data"));
            exports(app,id);
            planner(new Config(config));
            sqlGuard();
            remote(app,remote);
            pageBudget(app,id);
            // Full legacy results, not their old 18k preview, are migrated before model exposure.
            app.store.put("tool-result","legacy",Json.map("tenantId",ACTOR.tenantId(),"userId",ACTOR.userId(),"result",rows));
            var migrated=app.resultPolicy.sanitizeHistory(ACTOR,"legacy-run",List.of(Json.map("role","tool","tool_call_id","old","content",Json.write(Json.map("truncated",true,"resultRef","legacy","preview","PRIVATE_ROW_0")))));
            check.accept("legacy preview migrates to a full dataset reference",!Json.write(migrated).contains("PRIVATE_ROW_")&&Json.integer(Json.object(Json.parse(Json.required(migrated.get(0),"content"))),"rowCount",0)==50000);
            var expire=app.data.capture(ACTOR,"expire","test",List.of(Json.map("n",1)));String expireId=Json.required(expire,"dataRef");var meta=app.data.owned(ACTOR,expireId);meta.put("expiresAt",Instant.now().minusSeconds(1).toString());app.store.put("data-artifact",expireId,meta);reject("expired references fail explicitly",()->app.data.owned(ACTOR,expireId));
        }
    }
    private static void exports(AppServices app,String id)throws Exception{
        var xlsx=Json.object(app.dataTools.invoke(ACTOR,"xlsx","data__export",Json.map("dataRef",id,"format","xlsx")));byte[] bytes=app.data.download(ACTOR,Json.required(xlsx,"artifactId"));String sheet=zipText(bytes,"xl/worksheets/sheet1.xml");
        check.accept("real XLSX export includes every row without context paging",sheet.split("<row>",-1).length-1==50001&&Json.integer(xlsx,"exportedRows",0)==50000&&Json.write(xlsx).length()<1000);
        var dangerous=app.data.capture(ACTOR,"danger","test",List.of(Json.map("text","=HYPERLINK(\"https://example.invalid\")","html","<script>alert(1)</script>","largeId",new BigDecimal("1234567890123456789"))));String ref=Json.required(dangerous,"dataRef");
        var html=Json.object(app.dataTools.invoke(ACTOR,"html","data__export",Json.map("dataRef",ref,"format","html")));String content=new String(app.data.download(ACTOR,Json.required(html,"artifactId")),StandardCharsets.UTF_8);
        check.accept("HTML export escapes active markup",!content.contains("<script>")&&content.contains("&lt;script&gt;"));
        var csv=Json.object(app.dataTools.invoke(ACTOR,"csv","data__export",Json.map("dataRef",ref,"format","csv")));content=new String(app.data.download(ACTOR,Json.required(csv,"artifactId")),StandardCharsets.UTF_8);
        check.accept("CSV export neutralizes spreadsheet formulas",content.contains("'=HYPERLINK"));
        var excel=Json.object(app.dataTools.invoke(ACTOR,"excel","data__export",Json.map("dataRef",ref,"format","xlsx")));sheet=zipText(app.data.download(ACTOR,Json.required(excel,"artifactId")),"xl/worksheets/sheet1.xml");
        check.accept("XLSX stores formulas as literal strings and preserves long IDs",!sheet.contains("<f>")&&sheet.contains("1234567890123456789")&&sheet.contains("inlineStr"));
        var response=app.router.handle(new ApiRouter.Request("GET","/api/data/artifacts/"+xlsx.get("artifactId"),Map.of(),Map.of(),new byte[0]));
        check.accept("artifact API downloads binary outside model context",response.status()==200&&response.contentType().equals("application/octet-stream")&&response.body().length==bytes.length);
        check.accept("artifact download forces attachment and sandbox headers",response.headers().get("Content-Disposition").contains("attachment")&&response.headers().get("Content-Disposition").contains(".xlsx")&&response.headers().get("Content-Security-Policy").contains("sandbox"));
    }
    private static String zipText(byte[] bytes,String path)throws Exception{try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry entry;while((entry=zip.getNextEntry())!=null)if(entry.getName().equals(path))return new String(zip.readAllBytes(),StandardCharsets.UTF_8);}throw new AssertionError("Missing XLSX entry");}
    private static void planner(Config config){
        List<Map<String,Object>> source=new ArrayList<>();source.add(Json.map("role","system","content","POLICY_MUST_REMAIN"));for(int i=0;i<12;i++){source.add(Json.map("role","user","content","old-topic-"+i));source.add(Json.map("role","assistant","content","filler ".repeat(250)));}
        source.add(Json.map("role","user","content","CURRENT_TASK"));source.add(Json.map("role","assistant","content","","tool_calls",List.of(Json.map("id","last","function",Json.map("name","test","arguments","{}")))));source.add(Json.map("role","tool","tool_call_id","last","content",Json.write(Json.map("kind","dataset_ref","dataRef","ref-test","rowCount",50000))));
        var run=Json.map("request",Json.map("message","CURRENT_TASK","context",Json.map("contextMode","STATELESS")));var planner=new ContextPlanner(config);
        var plan=planner.plan(source,List.of(Json.map("role","user","content","REMINDER_PIN")),List.of(),run,4000);String text=Json.write(plan.messages());
        check.accept("planner pins policy, task, reminders and latest complete tool group",text.contains("POLICY_MUST_REMAIN")&&text.contains("CURRENT_TASK")&&text.contains("REMINDER_PIN")&&text.contains("tool_call_id"));
        check.accept("planner upgrades to retrieval on data references",plan.diagnostics().get("mode").equals("RETRIEVAL")&&plan.removedGroups()>0);
        check.accept("planner budgets tokens and chars with explainable decisions",text.length()<4000&&Json.integer(plan.diagnostics(),"estimatedInputTokens",0)<=Json.integer(plan.diagnostics(),"inputBudget",0)&&!Json.list(plan.diagnostics(),"candidateDecisions").isEmpty());
        check.accept("planning does not destructively alter transcript",source.size()==28);
        reject("planner refuses to drop mandatory constraints",()->planner.plan(List.of(Json.map("role","system","content","x".repeat(5000))),List.of(),List.of(),run,1000));
        reject("planner validates orphan tool messages even under budget",()->planner.plan(List.of(Json.map("role","tool","tool_call_id","orphan","content","x")),List.of(),List.of(),run,10000));
        var stateless=planner.plan(List.of(Json.map("role","system","content","policy"),Json.map("role","user","content","hello")),List.of(),List.of(),Json.map("request",Json.map("message","hello")),10000);
        check.accept("simple tasks use Stateless without auxiliary model calls",stateless.diagnostics().get("mode").equals("STATELESS"));
        var router=new DataActionRouter();check.accept("negative export instruction is not auto-routed",router.choose(Json.map("message","不要导出Excel"),Json.map("dataRef","id"))==null);
        check.accept("ambiguous format request is not guessed",router.choose(Json.map("message","导出Excel或者HTML"),Json.map("dataRef","id"))==null);
    }
    private static void sqlGuard(){
        ReadOnlySql.validate("SELECT department, SUM(amount) FROM orders WHERE note = ? GROUP BY department");ReadOnlySql.validate("SELECT 'delete; -- harmless literal' AS note");check.accept("SQL permits parameterized SELECT and literal text",true);
        for(String sql:List.of("DELETE FROM t","SELECT * FROM t; DROP TABLE t","WITH x AS (DELETE FROM t RETURNING *) SELECT * FROM x","SELECT * INTO OUTFILE '/tmp/x' FROM t","SELECT 1 -- comment","SELECT * FROM t FOR UPDATE","SELECT pg_sleep(20)"))reject("SQL rejects: "+sql,()->ReadOnlySql.validate(sql));
    }
    private static void remote(AppServices app,Remote remote){
        app.mcp.save(ACTOR,null,Json.map("serverId","bulk","name","Bulk test MCP","url",remote.base()+"/mcp","allowedTools",List.of("query"),"baseTools",List.of("query"),"toolPolicies",Json.map("query","READ")));
        var model=app.models.save(ACTOR,null,Json.map("name","Bulk regression model","modelName","fixture","provider","openai","baseUrl",remote.base()+"/v1","capabilities",Json.map("streaming",false,"toolCalling",true),"options",Json.map("contextChars",40000)));
        var request=Json.map("message","统计按部门汇总金额","modelConfigId",model.get("id"),"context",Json.map("dataPlan",Json.map("operation","aggregate","groupBy",List.of("department"),"metrics",List.of(Json.map("op","count","as","n"),Json.map("op","sum","field","amount","as","total")))));
        var run=app.runs.start(ACTOR,request);run=app.runs.await(ACTOR,Json.required(run,"id"),20000);
        check.accept("50000-row MCP query auto-routes typed aggregate without LLM tool choice",run.get("status").equals("COMPLETED")&&app.runs.events(ACTOR,Json.required(run,"id"),0).stream().anyMatch(e->"data.action.routed".equals(e.get("type"))));
        check.accept("no raw row values enter any actual model HTTP request",remote.inputs.stream().noneMatch(s->s.contains("PRIVATE_ROW_")));
        check.accept("model receives computed aggregates, not manual-count material",remote.inputs.stream().anyMatch(s->s.contains("aggregate_result")&&s.contains("25000")));
        check.accept("planner and old history summary add zero model calls",remote.inputs.size()==2);
        check.accept("run events and execution snapshots contain no bulk rows",!Json.write(app.runs.events(ACTOR,Json.required(run,"id"),0)).contains("PRIVATE_ROW_")&&!Json.write(app.store.list("tool-execution")).contains("PRIVATE_ROW_"));
        String runId=Json.required(run,"id");check.accept("context decision is persisted per model invocation",app.store.list("model-call").stream().filter(c->runId.equals(c.get("runId"))).allMatch(c->c.containsKey("contextPlan")));
        int before=remote.inputs.size();var exported=app.runs.start(ACTOR,Json.map("message","查询数据并导出Excel","modelConfigId",model.get("id")));exported=app.runs.await(ACTOR,Json.required(exported,"id"),20000);
        check.accept("explicit Excel request routes export without asking model to select export tool",exported.get("status").equals("COMPLETED")&&remote.inputs.size()==before+2&&remote.inputs.get(remote.inputs.size()-1).contains("downloadUrl"));
        // Repeat within a session: safe history, no summarizer reinjection.
        var continued=app.runs.start(ACTOR,Json.map("message","继续说明结果","modelConfigId",model.get("id"),"sessionId",run.get("sessionId")));continued=app.runs.await(ACTOR,Json.required(continued,"id"),20000);
        check.accept("subsequent session turn cannot reload bulk data from history",continued.get("status").equals("COMPLETED")&&remote.inputs.stream().noneMatch(s->s.contains("PRIVATE_ROW_")));
        remote.skipQuery=true;var skipped=app.runs.start(ACTOR,request);skipped=app.runs.await(ACTOR,Json.required(skipped,"id"),20000);
        check.accept("model cannot mark an unexecuted declared data plan complete",skipped.get("status").equals("FAILED")&&Json.write(skipped).contains("DATA_PLAN_INCOMPLETE"));
    }
    private static void pageBudget(AppServices app,String ref){
        var run=Json.map("id","sample-budget","tenantId",ACTOR.tenantId(),"userId",ACTOR.userId(),"status","RUNNING");app.store.put("run","sample-budget",run);
        var tool=app.dataTools.definitions().stream().filter(t->t.name().equals("data__page")).findFirst().orElseThrow();String last="";
        for(int i=0;i<4;i++){var result=app.tools.execute(ACTOR,"sample-budget","page-"+i,tool,Json.map("dataRef",ref,"offset",i,"limit",1),Json.map(),false,(a,b)->{});last=result.status();}
        check.accept("sample paging cannot be abused to load an entire dataset in one run",last.equals("FAILED"));app.store.transaction(tx->{tx.delete("run","sample-budget");return null;});
    }
    private static final class Remote implements AutoCloseable {
        final HttpServer server;final ExecutorService executor=Executors.newFixedThreadPool(3);final List<String> inputs=Collections.synchronizedList(new ArrayList<>());final List<Map<String,Object>> rows;volatile boolean skipQuery;
        Remote(List<Map<String,Object>> rows)throws IOException{this.rows=rows;server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);server.setExecutor(executor);server.createContext("/",exchange->{try{
            String body=new String(exchange.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);var request=Json.object(Json.parse(body));Object result;
            if(exchange.getRequestURI().getPath().equals("/mcp")){
                String method=Json.required(request,"method");if(!request.containsKey("id")){exchange.sendResponseHeaders(202,-1);return;}
                Object value=switch(method){case "initialize"->Json.map("protocolVersion","2025-11-25","capabilities",Json.map("tools",Json.map()),"serverInfo",Json.map("name","bulk","version","1"));case "tools/list"->Json.map("tools",List.of(Json.map("name","query","description","Return records","inputSchema",Json.map("type","object"))));case "tools/call"->Json.map("content",List.of(Json.map("type","text","text",Json.write(Json.map("rows",rows,"total",rows.size())))));default->Json.map();};result=Json.map("jsonrpc","2.0","id",request.get("id"),"result",value);
            }else{
                inputs.add(body);var messages=Json.list(request,"messages");boolean hasResult=skipQuery||messages.stream().map(Json::object).anyMatch(m->"tool".equals(m.get("role")));Map<String,Object> message=hasResult?Json.map("role","assistant","content","服务器已完成数据操作，请使用返回的统计或下载引用。"):Json.map("role","assistant","content","","tool_calls",List.of(Json.map("id",Util.id(),"type","function","function",Json.map("name","bulk__query","arguments","{}"))));result=Json.map("choices",List.of(Json.map("message",message)),"usage",Json.map("total_tokens",40));
            }
            byte[] bytes=Json.write(result).getBytes(StandardCharsets.UTF_8);exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);exchange.getResponseBody().write(bytes);
        }catch(Exception e){try{exchange.sendResponseHeaders(500,-1);}catch(IOException ignored){}}finally{exchange.close();}});server.start();}
        String base(){return "http://127.0.0.1:"+server.getAddress().getPort();}
        public void close(){server.stop(0);executor.shutdownNow();}
    }
}
