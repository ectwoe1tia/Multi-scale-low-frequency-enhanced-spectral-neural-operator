package com.bydauto.yunfan.agent;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
/** Run separately against a migrated real PostgreSQL/MySQL database; never silently substitutes a fake DB. */
public final class JdbcStoreContractTest {
    public static void main(String[] args) {
        String url=Objects.requireNonNull(System.getenv("YUNFAN_TEST_JDBC_URL"),"Set YUNFAN_TEST_JDBC_URL");
        String user=System.getenv().getOrDefault("YUNFAN_TEST_JDBC_USER","");
        String password=System.getenv().getOrDefault("YUNFAN_TEST_JDBC_PASSWORD","");
        String id="contract-"+Util.id();
        try(JdbcDocumentStore store=new JdbcDocumentStore(url,user,password)) {
            store.put("contract",id,Json.map("id",id,"value",1,"text","中文"));
            if(Json.integer(store.get("contract",id),"value",0)!=1)throw new AssertionError("insert/read");
            try {
                store.transaction(tx-> {
                    tx.put("contract",id,Json.map("id",id,"value",2));
                    throw ApiException.bad("rollback");
                } );
                throw new AssertionError("rollback missing");
            } catch(ApiException expected) {
            }
            if(Json.integer(store.get("contract",id),"value",0)!=1)throw new AssertionError("rollback");
            store.put("contract",id,Json.map("id",id,"value",3));
            if(Json.integer(store.get("contract",id),"value",0)!=3)throw new AssertionError("update");
            boolean denied=false;
            try(var duplicate=new JdbcDocumentStore(url,user,password)) {
                throw new AssertionError("second service lease accepted");
            } catch(IllegalStateException expected) {
                denied=true;
            }
            if(!denied)throw new AssertionError("lease");
            store.transaction(tx-> {
                tx.delete("contract",id);
                return null;
            } );
            if(store.get("contract",id)!=null)throw new AssertionError("delete");
            System.out.println("JDBC CONTRACT PASSED: "+(url.startsWith("jdbc:postgresql:")?"PostgreSQL":"MySQL"));
        }
    }
}
