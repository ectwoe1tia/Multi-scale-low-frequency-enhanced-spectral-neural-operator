package com.bydauto.yunfan.agent;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.contract.*;
import com.bydauto.yunfan.agent.filter.*;
import com.bydauto.yunfan.agent.modelconfig.*;
import com.bydauto.yunfan.agent.tooling.*;
import com.sun.net.httpserver.HttpServer;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;

/** Public API and actual MCP wire tests for data/control plane separation. */
public final class ContractDagTests {
    private static final AuthContext OWNER=new AuthContext("local","developer",Set.of("*"),"dag-test");
    private static BiConsumer<String,Boolean> check;
    private static void reject(String name,Runnable task){try{task.run();throw new AssertionError(name);}catch(ApiException e){check.accept(name,true);}}
    private static Map<String,Object> ref(String node,String output){return Json.map("$ref",Json.map("node",node,"output",output));}
    private static Map<String,Object> node(String id,String tool,List<String> deps,Map<String,Object> args){return Json.map("id",id,"tool",tool,"dependsOn",deps,"inputs",args);}
    private static Map<String,Object> plan(List<Object> nodes,String last,String output){return Json.map("schemaVersion","1","nodes",nodes,"result",ref(last,output));}
    public static void run(BiConsumer<String,Boolean> assertion)throws Exception{
        check=assertion;Path root=Files.createTempDirectory("dag-contract-");Path file=root.resolve("config.properties");Files.writeString(file,"yunfan.profile=test\nyunfan.store.directory="+root.resolve("state").toString().replace('\\','/')+"\nyunfan.data.directory="+root.resolve("artifacts").toString().replace('\\','/')+"\n");Config config=new Config(file);
        AtomicInteger modelCalls=new AtomicInteger();List<String> modelInputs=new ArrayList<>();
        AtomicReference<Map<String,Object>> generatedPlan=new AtomicReference<>();
        ModelClientFactory clients=new ModelClientFactory(config,model->(messages,tools,stream,delta)->{modelCalls.incrementAndGet();modelInputs.add(Json.write(messages));var generated=generatedPlan.getAndSet(null);if(generated!=null)return new ModelClient.Result("",List.of(Json.map("id",Util.id(),"type","function","function",Json.map("name","runtime__execute_plan","arguments",Json.write(Json.map("plan",generated))))),Json.map());return new ModelClient.Result("依据执行摘要完成",List.of(),Json.map());});
        try(AppServices app=new AppServices(config,clients);Remote remote=new Remote()){
            app.mcp.save(OWNER,null,Json.map("serverId","bulk2","name","Artifact contract fixture","url",remote.url(),"allowedTools",List.of("query","consume","fail","spoof","scalar"),"baseTools",List.of("query","consume","fail","spoof","scalar"),"toolPolicies",Json.map("query","READ","consume","READ","fail","READ","spoof","READ","scalar","READ")));
            var model=app.models.save(OWNER,null,Json.map("name","Spy model","modelName","fixture","provider","openai","baseUrl","http://127.0.0.1:1/v1","capabilities",Json.map("toolCalling",true),"options",Json.map("contextChars",40000)));
            app.contracts.register(new ToolContract("bulk2__query","1",Json.map("type","object"),List.of(),ToolContract.Exposure.REFERENCE_ONLY,List.of(),Set.of(),2048,"table"));
            var consumeSchema=Json.map("type","object","properties",Json.map("dataset",Json.map("type","string")),"required",List.of("dataset"),"additionalProperties",false);
            app.contracts.register(new ToolContract("bulk2__consume","1",consumeSchema,List.of(new ToolContract.Binding("dataset","rows",ToolContract.Mode.BOUNDED_INLINE,8*1024*1024,true)),ToolContract.Exposure.BOUNDED_SUMMARY,List.of("structuredContent"),Set.of("count"),2048,"value"));
            var exportPlan=plan(List.of(node("query","bulk2__query",List.of(),Json.map()),node("export","data__export",List.of("query"),Json.map("dataRef",ref("query","dataset"),"format","xlsx"))),"export","file");
            var run=start(app,model,exportPlan,"DIRECT");String runId=Json.required(run,"id");
            check.accept("DAG queries and exports 50000 rows with zero model invocations",run.get("status").equals("COMPLETED")&&modelCalls.get()==0);
            var outcome=Json.object(Json.parse(Json.required(run,"answer")));String artifact=Json.required(Json.child(outcome,"result"),"dataRef");
            check.accept("DAG exports the full dataset to a committed XLSX",app.data.download(OWNER,artifact).length>100000&&app.store.list("tool-execution").stream().anyMatch(e->e.get("result") instanceof Map<?,?> result&&result.get("exportedRows") instanceof Number count&&count.longValue()==50000));
            check.accept("TaskState is separate and records both completed nodes",app.taskStates.forRun(OWNER,runId).stream().anyMatch(s->Json.list(s,"nodes").size()==2&&"COMPLETED".equals(s.get("status"))));
            String publicStores=Json.write(List.of(app.store.list("task-state"),app.store.list("message"),app.store.list("event"),app.store.list("tool-execution")));
            check.accept("DAG state, history, events and logical args contain no row payload",!publicStores.contains("BOUND_ROW_")&&!publicStores.contains("storage_uri"));
            var consumePlan=plan(List.of(node("query","bulk2__query",List.of(),Json.map()),node("consume","bulk2__consume",List.of("query"),Json.map("dataset",ref("query","dataset")))),"consume","summary");
            var consumed=start(app,model,consumePlan,"HYBRID");
            check.accept("legacy MCP array input is materialized only inside adapter",consumed.get("status").equals("COMPLETED")&&remote.consumed.get()==50000);
            check.accept("hybrid DAG invokes model once after all data work",modelCalls.get()==1&&modelInputs.stream().noneMatch(s->s.contains("BOUND_ROW_")));
            check.accept("bound rows never enter persisted MCP execution arguments",app.store.list("tool-execution").stream().filter(e->"bulk2__consume".equals(Json.child(e,"tool").get("name"))).allMatch(e->Json.child(e,"args").containsKey("dataset")&&!Json.child(e,"args").containsKey("rows")&&Json.write(e).contains("sha256")));
            generatedPlan.set(exportPlan);int beforeGenerated=modelCalls.get();var generated=app.runs.start(OWNER,Json.map("message","Generate and execute a data plan","modelConfigId",model.get("id")));generated=app.runs.await(OWNER,Json.required(generated,"id"),20000);
            check.accept("LLM-generated DAG executes all nodes between two model turns",generated.get("status").equals("COMPLETED")&&modelCalls.get()==beforeGenerated+2&&modelInputs.stream().noneMatch(s->s.contains("BOUND_ROW_")));
            var catalog=app.tools.catalog(OWNER,List.of());var compiler=app.tools.planCompiler;
            reject("DAG rejects cyclic dependencies before any tool execution",()->compiler.compile(OWNER,plan(List.of(node("a","system__time",List.of("b"),Json.map()),node("b","system__time",List.of("a"),Json.map())),"b","result"),catalog));
            reject("DAG rejects references without declared ancestry",()->compiler.compile(OWNER,plan(List.of(node("a","bulk2__query",List.of(),Json.map()),node("b","data__export",List.of(),Json.map("dataRef",ref("a","dataset"),"format","xlsx"))),"b","file"),catalog));
            reject("DAG rejects recursive plan tools",()->compiler.compile(OWNER,plan(List.of(node("a","runtime__execute_plan",List.of(),Json.map("plan",exportPlan))),"a","result"),catalog));
            reject("DAG rejects artifact binding to undeclared control parameters",()->compiler.compile(OWNER,plan(List.of(node("a","bulk2__query",List.of(),Json.map()),node("b","system__calculator",List.of("a"),Json.map("expression",ref("a","dataset")))),"b","result"),catalog));
            var dataset=app.data.capture(OWNER,"fixture","test",Json.map("rows",List.of(Json.map("n",1)),"complete",true));String datasetId=Json.required(dataset,"dataRef");
            var other=new AuthContext("other","developer",Set.of("*"),"test");
            reject("artifact adapter rechecks tenant ownership",()->new com.bydauto.yunfan.agent.adapter.ArtifactInputAdapter(app.data).bind(other,app.contracts.get(catalog.stream().filter(t->t.name().equals("data__export")).findFirst().orElseThrow()),Json.map("dataRef",datasetId,"format","csv")));
            app.contracts.register(new ToolContract("bulk2__consume","2",consumeSchema,List.of(new ToolContract.Binding("dataset","rows",ToolContract.Mode.BOUNDED_INLINE,8,true)),ToolContract.Exposure.AUTO,List.of(),Set.of(),2048,"value"));
            var limited=start(app,model,consumePlan,"DIRECT");check.accept("legacy binding over limit fails instead of asking model to move rows",limited.get("status").equals("FAILED")&&remote.consumed.get()==50000);
            var partial=app.data.capture(OWNER,"partial","test",Json.map("rows",List.of(Json.map("n",1)),"total",100,"hasMore",true));
            var partialPlan=plan(List.of(node("export","data__export",List.of(),Json.map("dataRef",Json.map("$ref",Json.map("artifact_id",partial.get("dataRef"))),"format","csv"))),"export","file");
            var partialRun=start(app,model,partialPlan,"DIRECT");var partialResult=Json.child(Json.object(Json.parse(Json.required(partialRun,"answer"))),"result");var derived=app.data.owned(OWNER,Json.required(partialResult,"dataRef"));
            check.accept("derived artifact retains partial completeness and parent lineage",partialRun.get("status").equals("COMPLETED")&&"PARTIAL".equals(derived.get("completeness"))&&Json.list(derived,"parents").contains(partial.get("dataRef")));
            // Writes use the same child confirmation and resume the original checkpoint.
            var writePlan=plan(List.of(node("write","todo__create",List.of(),Json.map("title","DAG confirmation regression"))),"write","result");
            var pending=start(app,model,writePlan,"DIRECT");check.accept("DAG write pauses for existing confirmation",pending.get("status").equals("WAITING_CONFIRMATION"));
            reject("DIRECT DAG refuses inbox messages without a future model boundary",()->app.runs.context.enqueue(OWNER,Json.required(pending,"id"),Json.map("requestId","late-direct","message","additional input")));
            String cid=Json.required(Json.child(pending,"waitingReason"),"confirmationId");app.runs.resumeConfirmation(OWNER,cid,"APPROVE",1);var resumed=app.runs.await(OWNER,Json.required(pending,"id"),10000);
            check.accept("approved DAG resumes without replaying completed nodes",resumed.get("status").equals("COMPLETED")&&app.store.list("todo").stream().filter(t->"DAG confirmation regression".equals(t.get("title"))).count()==1);
            var failedPlan=plan(List.of(node("fail","bulk2__fail",List.of(),Json.map()),node("never","system__time",List.of("fail"),Json.map())),"never","result");
            var failed=start(app,model,failedPlan,"DIRECT");check.accept("failed DAG skips dependent nodes",failed.get("status").equals("FAILED")&&app.taskStates.forRun(OWNER,Json.required(failed,"id")).stream().anyMatch(s->Json.list(s,"nodes").stream().map(Json::object).anyMatch(n->"SKIPPED".equals(n.get("status")))));
            var failedHybrid=start(app,model,failedPlan,"HYBRID");check.accept("model answer cannot mark an incomplete hybrid plan successful",failedHybrid.get("status").equals("FAILED")&&Json.write(failedHybrid).contains("PLAN_INCOMPLETE"));
            filterTests(config);
            var classified=new com.bydauto.yunfan.agent.chat.ContextPlanner(config).plan(List.of(Json.map("role","system","content","policy"),Json.map("role","user","content","OLD_PRIVATE_HISTORY"),Json.map("role","assistant","content","OLD_PRIVATE_ANSWER"),Json.map("role","user","content","classify current input")),List.of(),List.of(),Json.map("request",Json.map("message","classify current input","context",Json.map("taskType","CLASSIFICATION"))),10000);
            check.accept("classification context excludes unrelated previous turns",!Json.write(classified.messages()).contains("OLD_PRIVATE_")&&Json.write(classified.messages()).contains("classify current input"));
            var memory=app.memories.put(OWNER,Json.map("fact","refund metrics use order count","source","operator"));
            check.accept("persistent memory uses its own store and scoped retrieval",app.memories.retrieve(OWNER,"refund").size()==1&&app.memories.list(other).isEmpty()&&app.store.list("persistent-memory").size()==1);
            reject("memory rejects temporary artifact references",()->app.memories.put(OWNER,Json.map("fact","dataRef = temp","source","operator")));
            app.memories.delete(OWNER,Json.required(memory,"id"));check.accept("persistent facts can be deleted independently of tasks",app.memories.list(OWNER).isEmpty()&&!app.taskStates.forRun(OWNER,runId).isEmpty());
            var meta=app.data.owned(OWNER,datasetId);try(var lease=app.data.lease(OWNER,datasetId)){
                reject("active artifact lease prevents deletion",()->app.data.remove(OWNER,datasetId));meta.put("expiresAt",Instant.now().minusSeconds(1).toString());app.store.put("data-artifact",datasetId,meta);app.data.collectExpired();check.accept("GC retains artifacts with active readers",app.store.get("data-artifact",datasetId)!=null);
            }app.data.collectExpired();check.accept("GC removes expired artifacts after reader closes",app.store.get("data-artifact",datasetId)==null);
            var response=app.router.handle(new ApiRouter.Request("GET","/api/runs/"+runId+"/state",Map.of(),Map.of(),new byte[0]));check.accept("task state API exposes checkpoints without bulk payload",response.status()==200&&!new String(response.body(),StandardCharsets.UTF_8).contains("BOUND_ROW_"));
            ReviewBoundaryTests.run(app,config,model,check);
        }
        restartConfirmationTest();
    }
    private static void restartConfirmationTest()throws Exception{
        Path root=Files.createTempDirectory("dag-restart-");Path contracts=root.resolve("contracts.json"),settings=root.resolve("config.properties");
        Files.writeString(contracts,Json.write(List.of(Json.map("tool","restart__consume","version","1","logicalSchema",Json.map("type","object","properties",Json.map("dataset",Json.map("type","string")),"required",List.of("dataset"),"additionalProperties",false),"bindings",List.of(Json.map("field","dataset","wireField","rows","mode","BOUNDED_INLINE","requireComplete",true)),"exposure","BOUNDED_SUMMARY","outputPath",List.of("structuredContent"),"summaryFields",List.of("count")))));
        Files.writeString(settings,"yunfan.profile=test\nyunfan.store.directory="+root.resolve("state").toString().replace('\\','/')+"\nyunfan.contracts.file="+contracts.toString().replace('\\','/')+"\n");Config config=new Config(settings);
        try(Remote remote=new Remote()){
            String confirmation,runId;
            try(AppServices first=new AppServices(config)){
                first.mcp.save(OWNER,null,Json.map("serverId","restart","name","restart fixture","url",remote.url(),"allowedTools",List.of("consume"),"baseTools",List.of("consume"),"toolPolicies",Json.map("consume","WRITE")));
                var dataset=first.data.capture(OWNER,"restart","fixture",Json.map("rows",List.of(Json.map("n",7)),"complete",true));
                var graph=plan(List.of(node("consume","restart__consume",List.of(),Json.map("dataset",Json.map("$ref",Json.map("artifact_id",dataset.get("dataRef")))))),"consume","summary");
                var pending=first.runs.start(OWNER,Json.map("message","resume binding after restart","context",Json.map("executionPlan",graph)));runId=Json.required(pending,"id");pending=first.runs.await(OWNER,runId,10000);
                check.accept("bound MCP write pauses without invoking remote consumer","WAITING_CONFIRMATION".equals(pending.get("status"))&&remote.consumed.get()==0);confirmation=Json.required(Json.child(pending,"waitingReason"),"confirmationId");
            }
            try(AppServices restarted=new AppServices(config)){
                restarted.runs.resumeConfirmation(OWNER,confirmation,"APPROVE",1);var completed=restarted.runs.await(OWNER,runId,10000);
                check.accept("confirmed MCP binding resumes after service restart with no catalog warmup","COMPLETED".equals(completed.get("status"))&&remote.consumed.get()==1);
            }
        }
    }
    private static Map<String,Object> start(AppServices app,Map<String,Object> model,Map<String,Object> plan,String mode){var run=app.runs.start(OWNER,Json.map("message","execute declared DAG","modelConfigId",model.get("id"),"skillIds",app.skills.list(OWNER).stream().map(s->s.get("id")).toList(),"context",Json.map("executionPlan",plan,"planMode",mode)));return app.runs.await(OWNER,Json.required(run,"id"),20000);}
    private static void filterTests(Config config){
        var filter=new ModelContextFilter(config);var model=Json.map("options",Json.map("contextChars",40000));List<Object> rows=new ArrayList<>();for(int i=0;i<100;i++)rows.add(Json.map("private",i));
        reject("final model filter rejects bulk rows in assistant tool arguments",()->filter.validate(List.of(Json.map("role","assistant","content","","tool_calls",List.of(Json.map("function",Json.map("arguments",Json.write(Json.map("rows",rows))))))),List.of(),model));
        reject("final model filter rejects storage locators in retrieved memory",()->filter.validate(List.of(Json.map("role","user","content",Json.write(Json.map("storage_uri","file:///private")))),List.of(),model));
        var wrapped=filter.wrap((messages,tools,stream,delta)->{throw new AssertionError("Transport must not run");},model);
        reject("streaming model path cannot bypass final filter",()->wrapped.complete(List.of(Json.map("role","tool","content",Json.write(Json.map("rows",rows)))),List.of(),true,(type,text)->{}));
        filter.validate(List.of(Json.map("role","user","content","合法的受控文档片段")),List.of(),model);check.accept("final filter still permits normal document text",true);
    }
    private static final class Remote implements AutoCloseable {
        final HttpServer server;final ExecutorService executor=Executors.newFixedThreadPool(2);final AtomicInteger consumed=new AtomicInteger();
        Remote()throws Exception{server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);server.setExecutor(executor);server.createContext("/mcp",exchange->{try{
            var req=Json.object(Json.parse(new String(exchange.getRequestBody().readAllBytes(),StandardCharsets.UTF_8)));if(!req.containsKey("id")){exchange.sendResponseHeaders(202,-1);return;}
            Object value;String method=Json.required(req,"method");
            if(method.equals("initialize"))value=Json.map("protocolVersion","2025-11-25","capabilities",Json.map("tools",Json.map()),"serverInfo",Json.map("name","data-contract","version","1"));
            else if(method.equals("tools/list"))value=Json.map("tools",List.of("query","consume","fail","spoof","scalar").stream().map(name->Json.map("name",name,"description",name,"inputSchema",name.equals("consume")?Json.map("type","object","properties",Json.map("rows",Json.map("type","array")),"required",List.of("rows"),"additionalProperties",false):Json.map("type","object"))).toList());
            else if(method.equals("tools/call")){
                var params=Json.child(req,"params");String name=Json.required(params,"name");
                if(name.equals("consume")){int count=Json.list(Json.child(params,"arguments"),"rows").size();consumed.set(count);value=Json.map("structuredContent",Json.map("count",count));}
                else if(name.equals("fail")){exchange.sendResponseHeaders(500,-1);return;}
                else if(name.equals("scalar"))value=Json.map("structuredContent",Json.map("value","ordinary scalar result"));
                else{List<Object> rows=new ArrayList<>();for(int i=0;i<50000;i++)rows.add(Json.map("value",i,"marker","BOUND_ROW_"+i));value=Json.map("structuredContent",Json.map("rows",rows,"total",50000));}
            }else value=Json.map();byte[] bytes=Json.write(Json.map("jsonrpc","2.0","id",req.get("id"),"result",value)).getBytes(StandardCharsets.UTF_8);exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);exchange.getResponseBody().write(bytes);
        }catch(Exception e){try{exchange.sendResponseHeaders(500,-1);}catch(Exception ignored){}}finally{exchange.close();}});server.start();}
        String url(){return "http://127.0.0.1:"+server.getAddress().getPort()+"/mcp";}
        public void close(){server.stop(0);executor.shutdownNow();}
    }
}
