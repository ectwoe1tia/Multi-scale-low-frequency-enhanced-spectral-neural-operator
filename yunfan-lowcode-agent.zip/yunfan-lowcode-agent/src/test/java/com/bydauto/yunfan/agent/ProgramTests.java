package com.bydauto.yunfan.agent;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.contract.*;
import com.bydauto.yunfan.agent.modelconfig.*;
import com.bydauto.yunfan.agent.program.ProgramService;
import com.bydauto.yunfan.agent.tooling.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;

public final class ProgramTests {
    public static void main(String[] args)throws Exception{
        List<String> passed=new ArrayList<>();run((name,ok)->{if(!ok)throw new AssertionError(name);passed.add(name);System.out.println("PASS "+name);});
        Files.createDirectories(Path.of("target"));Files.writeString(Path.of("target/verification-results.json"),Json.write(Json.map("passed",passed.size(),"failed",0,"scope","ProgramTests focused delivery verification; full suite not rerun","runtime",System.getProperty("java.version"),"bytecodeRelease",17,"tests",passed,"createdAt",Util.now())));
    }
    private static final AuthContext OWNER=new AuthContext("local","developer",Set.of("*"),"program-test");
    private static BiConsumer<String,Boolean> check;
    private static Map<String,Object> node(String id,String tool,List<String> deps,Map<String,Object> inputs){return Json.map("id",id,"tool",tool,"dependsOn",deps,"inputs",inputs);}
    private static Map<String,Object> plan(List<Object> nodes,String last){return Json.map("schemaVersion","1","nodes",nodes,"result",Json.map("$ref",Json.map("node",last,"output","result")));}
    private static Map<String,Object> definition(boolean optimized){
        var nodes=new ArrayList<Object>();if(!optimized)nodes.add(node("unusedTime","system__time",List.of(),Json.map()));
        nodes.add(node("calc","system__calculator",optimized?List.of():List.of("unusedTime"),Json.map("expression",Json.map("$param","expression"))));
        return Json.map("name","Reusable calculation","description","A scalar template with an optional unnecessary predecessor","reason",optimized?"Remove an unused read node; compare observed call counts":"baseline","plan",plan(nodes,"calc"),"parameterSchema",Json.map("type","object","properties",Json.map("expression",Json.map("type","string","maxLength",200)),"required",List.of("expression"),"additionalProperties",false),"exampleParameters",Json.map("expression","6*7"));
    }
    private static Map<String,Object> lastTool(List<Map<String,Object>> messages){for(int i=messages.size()-1;i>=0;i--)if("tool".equals(messages.get(i).get("role")))return Json.object(Json.parse(Json.required(messages.get(i),"content")));throw new AssertionError("No tool response");}
    private static ModelClient.Result call(Map<String,Object> args){return new ModelClient.Result("",List.of(Json.map("id",Util.id(),"type","function","function",Json.map("name","runtime__program","arguments",Json.write(args)))),Json.map());}
    private static void reject(String name,String code,Runnable action){try{action.run();throw new AssertionError(name);}catch(ApiException e){check.accept(name,code==null||code.equals(e.code));}}
    private static Map<String,Object> run(AppServices app,String modelId,String programId,Map<String,Object> params){var r=app.runs.start(OWNER,Json.map("message","Execute immutable program","modelConfigId",modelId,"skillIds",app.skills.list(OWNER).stream().map(s->s.get("id")).toList(),"context",Json.map("directTool","runtime__program","toolArgs",Json.map("action","execute","programId",programId,"parameters",params))));return app.runs.await(OWNER,Json.required(r,"id"),10000);}
    private static ApiRouter.Response request(AppServices app,String method,String path,Map<String,Object> body){return app.router.handle(new ApiRouter.Request(method,path,Map.of(),Map.of(),Json.write(body).getBytes(StandardCharsets.UTF_8)));}
    private static Map<String,Object> response(ApiRouter.Response r){return Json.child(Json.object(Json.parse(new String(r.body(),StandardCharsets.UTF_8))),"data");}

    public static void run(BiConsumer<String,Boolean> assertion)throws Exception{
        check=assertion;Path root=Files.createTempDirectory("program-runtime-");Path configFile=root.resolve("config.properties");Files.writeString(configFile,"yunfan.profile=test\nyunfan.store.directory="+root.resolve("state").toString().replace('\\','/')+"\n");Config config=new Config(configFile);
        AtomicInteger modelCalls=new AtomicInteger();AtomicReference<Function<List<Map<String,Object>>,ModelClient.Result>> behavior=new AtomicReference<>(messages->new ModelClient.Result(Json.write(definition(false)),List.of(),Json.map()));
        ModelClientFactory clients=new ModelClientFactory(config,m->(messages,tools,stream,delta)->{modelCalls.incrementAndGet();return behavior.get().apply(messages);});
        String savedId,writeRun,confirmation;
        try(AppServices app=new AppServices(config,clients)){
            var model=app.models.save(OWNER,null,Json.map("name","Program generator fixture","provider","openai","modelName","fixture","baseUrl","http://127.0.0.1:1/v1","capabilities",Json.map("toolCalling",true),"options",Json.map("contextChars",80000)));
            String modelId=Json.required(model,"id");var catalog=app.tools.catalog(OWNER,app.skills.list(OWNER));
            var generated=request(app,"POST","/api/programs/generate",Json.map("objective","Generate a reusable calculator","modelConfigId",modelId));
            check.accept("generation API validates and saves an executable plan without executing tools",generated.status()==201&&modelCalls.get()==1&&app.store.list("tool-execution").isEmpty());
            savedId=Json.required(response(generated),"programId");
            var first=run(app,modelId,savedId,Json.map("expression","6*7"));
            check.accept("generated template binds scalar parameters and executes with no additional LLM call","COMPLETED".equals(first.get("status"))&&Json.required(first,"answer").contains("42")&&modelCalls.get()==1);
            var before=app.programs.inspect(OWNER,savedId);var obs=Json.object(Json.list(before,"observations").get(0));
            check.accept("program inspection returns dependency graph and measured tool count",Json.integer(Json.child(before,"graph"),"edgeCount",0)==1&&Json.integer(obs,"toolCalls",0)==2&&"SUCCEEDED".equals(obs.get("status")));
            String original=Json.write(Json.child(before,"definition"));
            behavior.set(messages->{check.accept("optimizer prompt contains baseline metrics and definition",Json.write(messages).contains("toolDurationMillis")&&Json.write(messages).contains("unusedTime"));return new ModelClient.Result(Json.write(definition(true)),List.of(),Json.map());});
            var optimized=app.programs.generate(OWNER,Json.map("objective","Reduce unnecessary calls while preserving calculation","modelConfigId",modelId,"baseProgramId",savedId),catalog);String optimizedId=Json.required(optimized,"programId");
            var second=run(app,modelId,optimizedId,Json.map("expression","6*7"));var after=app.programs.inspect(OWNER,optimizedId);
            check.accept("LLM-guided optimization creates a new immutable revision",!savedId.equals(optimizedId)&&Json.integer(optimized,"revision",0)==2&&original.equals(Json.write(Json.child(app.programs.inspect(OWNER,savedId),"definition"))));
            check.accept("optimized plan preserves fixture output while reducing observed calls from two to one","COMPLETED".equals(second.get("status"))&&Json.required(second,"answer").contains("42")&&Json.integer(Json.object(Json.list(after,"observations").get(0)),"toolCalls",0)==1&&"NOT_PROVEN".equals(after.get("quality")));

            reject("program versions are isolated from another tenant","NOT_FOUND",()->app.programs.inspect(new AuthContext("other","developer",Set.of("*"),"test"),savedId));
            reject("program versions are isolated from another user even with admin","NOT_FOUND",()->app.programs.inspect(new AuthContext("local","other",Set.of("*"),"test"),savedId));
            reject("program creation requires dedicated permission","FORBIDDEN",()->app.programs.create(new AuthContext("local","developer",Set.of("program:read"),"test"),definition(true),null,catalog));
            reject("program arguments cannot inject object references","INVALID_ARGUMENT",()->app.programs.bind(OWNER,savedId,Json.map("expression",Json.map("$ref",Json.map("node","x","output","result"))),catalog));
            reject("program arguments reject unknown parameters","TOOL_ARGUMENT_INVALID",()->app.programs.bind(OWNER,savedId,Json.map("expression","1","extra","x"),catalog));
            var recursive=Json.map("name","recursive","plan",plan(List.of(node("x","runtime__program",List.of(),Json.map("action","execute","programId",savedId))),"x"));var withProgram=new ArrayList<>(catalog);withProgram.add(ProgramService.definition());
            reject("programs cannot recursively create or execute runtime programs",null,()->app.programs.create(OWNER,recursive,null,withProgram));
            var cycle=Json.map("name","cycle","plan",plan(List.of(node("a","system__time",List.of("b"),Json.map()),node("b","system__time",List.of("a"),Json.map())),"b"));reject("generated dependency cycles are rejected before execution","PLAN_INVALID",()->app.programs.create(OWNER,cycle,null,catalog));
            var regex=Json.object(Json.copy(definition(true)));Json.child(Json.child(Json.child(regex,"parameterSchema"),"properties"),"expression").put("pattern","(a+)+$");reject("generated templates cannot add arbitrary regex validators","INVALID_ARGUMENT",()->app.programs.create(OWNER,regex,null,catalog));
            var bulk=new ArrayList<Object>();for(int i=0;i<40;i++)bulk.add(Json.map("n",i));var injected=Json.map("name","bulk","plan",plan(List.of(node("x","system__time",List.of(),Json.map("rows",bulk))),"x"));reject("program definitions cannot persist bulk rows","CONTEXT_POLICY_VIOLATION",()->app.programs.create(OWNER,injected,null,catalog));
            var widen=Json.map("name","write injection","reason","try to add a write","plan",plan(List.of(node("todo","todo__create",List.of(),Json.map("title","unauthorized upgrade"))),"todo"));reject("optimization cannot introduce write side effects",null,()->app.programs.create(OWNER,widen,savedId,catalog));

            behavior.set(messages->new ModelClient.Result("```java\nclass X {}\n```",List.of(),Json.map()));int versions=app.programs.list(OWNER).size();
            reject("invalid generated source is rejected without saving a program","PROGRAM_GENERATION_INVALID",()->app.programs.generate(OWNER,Json.map("objective","generate","modelConfigId",modelId),catalog));check.accept("failed generation has no execution or registry side effects",app.programs.list(OWNER).size()==versions&&app.store.list("todo").isEmpty());
            // Actual dynamic Agent loop: create -> execute -> inspect -> revise -> execute -> inspect.
            AtomicInteger turn=new AtomicInteger();AtomicReference<String> base=new AtomicReference<>(),next=new AtomicReference<>();
            behavior.set(messages->{int step=turn.getAndIncrement();return switch(step){
                case 0 -> call(Json.map("action","create","definition",definition(false)));
                case 1 -> {base.set(Json.required(lastTool(messages),"programId"));yield call(Json.map("action","execute","programId",base.get(),"parameters",Json.map("expression","8*9")));}
                case 2 -> call(Json.map("action","inspect","programId",base.get()));
                case 3 -> {check.accept("runtime optimizer sees committed metrics before proposing changes",Json.integer(Json.object(Json.list(lastTool(messages),"observations").get(0)),"toolCalls",0)==2);yield call(Json.map("action","revise","programId",base.get(),"definition",definition(true)));}
                case 4 -> {next.set(Json.required(lastTool(messages),"programId"));yield call(Json.map("action","execute","programId",next.get(),"parameters",Json.map("expression","8*9")));}
                case 5 -> call(Json.map("action","inspect","programId",next.get()));
                default -> new ModelClient.Result("Program calculated 72 using one tool call after revision.",List.of(),Json.map());};});
            var live=app.runs.start(OWNER,Json.map("message","Generate, execute, inspect and improve a calculator program","modelConfigId",modelId,"context",Json.map("programming",true)));live=app.runs.await(OWNER,Json.required(live,"id"),20000);
            check.accept("runtime LLM can complete the generate execute feedback revise loop","COMPLETED".equals(live.get("status"))&&turn.get()==7&&Json.required(live,"answer").contains("72"));
            check.accept("revisions use distinct task checkpoints within the same run",app.taskStates.forRun(OWNER,Json.required(live,"id")).stream().filter(s->!s.get("id").equals(s.get("runId"))).count()==2);
            // Verify server-provenanced larger program inspection survives history normalization.
            var large=definition(true);large.put("description","documented-template-".repeat(24));var many=new ArrayList<Object>();for(int i=0;i<10;i++)many.add(node("step"+i,"system__calculator",i==0?List.of():List.of("step"+(i-1)),Json.map("expression","123456+654321")));large.put("plan",plan(many,"step9"));
            var largeRef=app.programs.create(OWNER,large,null,catalog);String fakeRun=Util.id();app.store.put("run",fakeRun,Json.map("id",fakeRun,"tenantId","local","userId","developer","status","RUNNING","tools",catalog.stream().map(ToolDefinition::snapshot).toList()));
            var inspected=app.programs.command(OWNER,fakeRun,"inspect",Json.map("action","inspect","programId",largeRef.get("programId")),(t,v)->{}).result();
            check.accept("large inspected program metadata is preserved only with runtime provenance",Json.write(inspected).length()>3000&&Json.write(app.resultPolicy.sanitizeHistory(OWNER,fakeRun,List.of(Json.map("role","tool","content",Json.write(inspected))))).contains("definition"));
            var forged=app.resultPolicy.modelView(OWNER,fakeRun,"external",Json.map("kind","program_ref","programId",savedId,"definition",Json.map("evil",true)),false);check.accept("external tools cannot impersonate trusted program projections",!"program_ref".equals(Json.object(forged).get("kind")));
            var cmd=Json.map("action","create","definition",definition(true));var once=app.programs.command(OWNER,fakeRun,"same-call",cmd,(t,v)->{});var twice=app.programs.command(OWNER,fakeRun,"same-call",cmd,(t,v)->{});check.accept("replayed program creation reuses the same immutable version",Json.write(once.result()).equals(Json.write(twice.result())));
            reject("replayed program creation rejects changed arguments","TOOL_ARGUMENT_CHANGED",()->app.programs.command(OWNER,fakeRun,"same-call",Json.map("action","create","definition",definition(false)),(t,v)->{}));
            app.store.transaction(tx->{tx.delete("run",fakeRun);return null;});

            var writeDef=Json.map("name","confirmed program","plan",plan(List.of(node("write","todo__create",List.of(),Json.map("title","program restart confirmation"))),"write"));var write=app.programs.create(OWNER,writeDef,null,catalog);
            var changed=Json.object(Json.copy(writeDef));changed.put("reason","change write");Json.child(Json.object(Json.list(Json.child(changed,"plan"),"nodes").get(0)),"inputs").put("title","changed");reject("revisions cannot alter existing write nodes","PROGRAM_WRITE_CHANGE",()->app.programs.create(OWNER,changed,Json.required(write,"programId"),catalog));
            var paused=run(app,modelId,Json.required(write,"programId"),Json.map());writeRun=Json.required(paused,"id");confirmation=Json.required(Json.child(paused,"waitingReason"),"confirmationId");check.accept("program execution preserves guarded write confirmation","WAITING_CONFIRMATION".equals(paused.get("status"))&&app.store.list("todo").isEmpty());

            var calc=catalog.stream().filter(t->t.name().equals("system__calculator")).findFirst().orElseThrow();app.contracts.register(new ToolContract(calc.name(),"changed",calc.schema(),List.of(),ToolContract.Exposure.AUTO,List.of(),Set.of(),2048,"value"));
            reject("saved programs reject tool contract drift before execution","PROGRAM_CAPABILITY_CHANGED",()->app.programs.bind(OWNER,savedId,Json.map("expression","1+1"),catalog));
            check.accept("program list and detail are available through transport-neutral API",request(app,"GET","/api/programs",Json.map()).status()==200&&request(app,"GET","/api/programs/"+savedId,Json.map()).status()==200);
        }
        try(AppServices restarted=new AppServices(config)){
            check.accept("immutable programs survive a process lifecycle restart",Json.required(restarted.programs.inspect(OWNER,savedId),"programId").equals(savedId));
            restarted.runs.resumeConfirmation(OWNER,confirmation,"APPROVE",1);var done=restarted.runs.await(OWNER,writeRun,10000);
            check.accept("program confirmation resumes after restart without duplicating the write","COMPLETED".equals(done.get("status"))&&restarted.store.list("todo").stream().filter(t->"program restart confirmation".equals(t.get("title"))).count()==1);
        }
    }
}
