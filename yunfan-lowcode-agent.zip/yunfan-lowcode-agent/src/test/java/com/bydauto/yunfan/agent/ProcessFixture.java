package com.bydauto.yunfan.agent;
import com.bydauto.yunfan.agent.common.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Real subprocess fixture; no external runtime, model, or credential is required. */
public final class ProcessFixture {
    public static void main(String[] args)throws Exception {
        if(args[0].equals("slow")){Thread.sleep(30000);return;}
        if(args[0].equals("flood")){System.out.print("x".repeat(300000));return;}
        if(args[0].equals("fail")){System.exit(2);return;}
        if(args[0].equals("echo")){System.out.print(new String(System.in.readAllBytes(),StandardCharsets.UTF_8));return;}
        boolean initialized=false;
        try(BufferedReader input=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8))) {
            for(String line;(line=input.readLine())!=null;) {
                Map<String,Object> request=Json.object(Json.parse(line));
                String method=Json.str(request,"method","");
                if(method.equals("notifications/initialized")){initialized=true;continue;}
                Object result;
                if(method.equals("initialize"))result=Json.map("protocolVersion",Json.child(request,"params").get("protocolVersion"),"capabilities",Json.map("tools",Json.map()),"serverInfo",Json.map("name","java-fixture","version","1"));
                else if(!initialized)throw new IllegalStateException("Missing initialized notification");
                else if(method.equals("tools/list")) {
                    if(args[0].equals("page-fail")&&Json.child(request,"params").containsKey("cursor")){System.out.println("{invalid");return;}
                    result=Json.map("tools",List.of(Json.map("name","echo","description","fixture echo","inputSchema",Json.map("type","object"))));
                    if(args[0].equals("page-fail"))Json.object(result).put("nextCursor","page2");
                } else {
                    Map<String,Object> data=Json.child(Json.child(request,"params"),"arguments");
                    if(data.containsKey("sleep")){Thread.sleep(30000);return;}
                    if(data.containsKey("crash")){System.exit(3);return;}
                    result=Json.map("structuredContent",Json.map("pid",ProcessHandle.current().pid(),"args",data,"env",new TreeSet<>(System.getenv().keySet())),"content",List.of(Json.map("type","text","text","echo")));
                }
                System.err.println("fixture diagnostic");
                System.out.println(Json.write(Json.map("jsonrpc","2.0","id",request.get("id"),"result",result)));
            }
        }
    }
}
