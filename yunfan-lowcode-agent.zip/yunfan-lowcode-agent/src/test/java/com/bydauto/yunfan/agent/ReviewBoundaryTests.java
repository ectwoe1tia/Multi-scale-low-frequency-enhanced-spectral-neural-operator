package com.bydauto.yunfan.agent;

import com.bydauto.yunfan.agent.adapter.*;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.contract.*;
import com.bydauto.yunfan.agent.data.*;
import com.bydauto.yunfan.agent.tooling.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.BiConsumer;

/** Regression checks identified by the architecture review, including cold snapshots and forged references. */
final class ReviewBoundaryTests {
    private static final AuthContext OWNER=new AuthContext("local","developer",Set.of("*"),"review-test");
    private static Map<String,Object> ref(String node,String port){return Json.map("$ref",Json.map("node",node,"output",port));}
    private static Map<String,Object> artifact(String id){return Json.map("$ref",Json.map("artifact_id",id));}
    private static Map<String,Object> node(String id,String tool,List<String> deps,Map<String,Object> args){return Json.map("id",id,"tool",tool,"dependsOn",deps,"inputs",args);}
    private static Map<String,Object> plan(List<Object> nodes,String last,String port){return Json.map("schemaVersion","1","nodes",nodes,"result",ref(last,port));}
    private static void rejects(BiConsumer<String,Boolean> check,String name,String code,Runnable action){try{action.run();throw new AssertionError(name);}catch(ApiException e){check.accept(name,code.equals(e.code));}}
    private static Map<String,Object> start(AppServices app,Map<String,Object> model,Map<String,Object> plan){var r=app.runs.start(OWNER,Json.map("message","review boundary execution","modelConfigId",model.get("id"),"context",Json.map("executionPlan",plan)));return app.runs.await(OWNER,Json.required(r,"id"),10000);}
    static void run(AppServices app,Config config,Map<String,Object> model,BiConsumer<String,Boolean> check)throws Exception {
        var catalog=app.tools.catalog(OWNER,List.of());var compiler=app.tools.planCompiler;
        rejects(check,"explicit artifact IDs cannot bypass declared input bindings","PLAN_INVALID",()->compiler.compile(OWNER,plan(List.of(node("a","system__calculator",List.of(),Json.map("expression",artifact("opaque")))),"a","result"),catalog));
        rejects(check,"nested artifact references cannot bypass binding checks","PLAN_INVALID",()->compiler.compile(OWNER,plan(List.of(node("a","bulk2__query",List.of(),Json.map()),node("b","bulk2__fail",List.of("a"),Json.map("options",List.of(ref("a","dataset"))))),"b","result"),catalog));
        var invalid=plan(List.of(node("a","data__export",List.of(),Json.map("dataRef",artifact("missing-artifact"),"format","csv")),node("b","system__time",List.of("a"),Json.map())),"b","result");
        var failed=start(app,model,invalid);var checkpoints=app.taskStates.forRun(OWNER,Json.required(failed,"id")).stream().filter(s->Json.list(s,"nodes").size()==2).findFirst().orElseThrow();
        check.accept("reference resolution failure records failed node and skips successors","FAILED".equals(failed.get("status"))&&"FAILED".equals(Json.object(Json.list(checkpoints,"nodes").get(0)).get("status"))&&"SKIPPED".equals(Json.object(Json.list(checkpoints,"nodes").get(1)).get("status"))&&Json.object(Json.list(checkpoints,"nodes").get(0)).containsKey("errorCode"));

        var logical=Json.map("type","object","properties",Json.map("dataset",Json.map("type","string")),"required",List.of("dataset"),"additionalProperties",false);
        var wire=Json.map("type","object","properties",Json.map("rows",Json.map("type","array")),"required",List.of("rows"),"additionalProperties",false);
        var inline=new ToolContract("example","1",logical,List.of(new ToolContract.Binding("dataset","rows",ToolContract.Mode.BOUNDED_INLINE,10000,true)),ToolContract.Exposure.AUTO,List.of(),Set.of(),2048,"value");
        var first=new ToolContractRegistry(config);first.register(inline);
        var snapshot=first.logical(new ToolDefinition("example","example","server","",wire,"READ",true,"1")).snapshot();
        var restored=ToolDefinition.from(Json.object(Json.parse(Json.write(snapshot))));var cold=new ToolContractRegistry(config);cold.register(inline);
        new JsonSchemaValidator().validate(Json.map("rows",List.of(Json.map("n",1))),cold.wire(restored).schema());
        check.accept("cold restored snapshot retains original wire schema without catalog cache",restored.schema().equals(logical)&&cold.wire(restored).schema().equals(wire)&&!restored.modelSpec().toString().contains("wireSchema"));
        rejects(check,"contracts reject duplicate wire destinations","INVALID_ARGUMENT",()->new ToolContract("bad","1",logical,List.of(new ToolContract.Binding("a","rows",ToolContract.Mode.HANDLE,100,false),new ToolContract.Binding("b","rows",ToolContract.Mode.HANDLE,100,false)),ToolContract.Exposure.AUTO,List.of(),Set.of(),2048,"value"));
        var complete=app.data.capture(OWNER,"review","source",Json.map("rows",List.of(Json.map("n",1)),"complete",true));String id=Json.required(complete,"dataRef");
        var adapter=new ArtifactInputAdapter(app.data);
        var tiny=new ToolContract("limited","1",logical,List.of(new ToolContract.Binding("dataset","dataset",ToolContract.Mode.HANDLE,1,false)),ToolContract.Exposure.AUTO,List.of(),Set.of(),2048,"value");
        rejects(check,"HANDLE mode enforces artifact byte budget","DATA_BINDING_UNSUPPORTED",()->{try(var bound=adapter.bind(OWNER,tiny,Json.map("dataset",id))) {throw new AssertionError("size bound ignored");}});
        rejects(check,"binding cannot silently overwrite caller wire argument","INVALID_ARGUMENT",()->{try(var bound=adapter.bind(OWNER,inline,Json.map("dataset",id,"rows",List.of()))) {throw new AssertionError("collision ignored");}});
        app.data.remove(OWNER,id);check.accept("failed artifact binding releases read leases",app.store.get("data-artifact",id)==null);

        var partial=app.data.capture(OWNER,"review","source",Json.map("rows",List.of(Json.map("n",1)),"hasMore",true));String partialId=Json.required(partial,"dataRef");
        var output=new ToolOutputAdapter(app.data,new ToolResultPolicy(app.data));
        var auto=ToolContract.fallback(new ToolDefinition("trusted","","","",Json.map(),"READ",true,"1"));
        var fingerprints=Json.map("artifacts",Json.map("source",Json.map("artifact_id","parent","completeness","UNKNOWN")));
        var projected=Json.object(output.normalize(OWNER,"review",auto,partial,true,fingerprints));
        check.accept("UNKNOWN inputs never weaken an existing PARTIAL result","PARTIAL".equals(projected.get("completeness"))&&"PARTIAL".equals(app.data.owned(OWNER,partialId).get("completeness")));
        var before=Json.write(app.data.owned(OWNER,partialId));
        var forged=Json.object(output.normalize(OWNER,"review",auto,Json.map("dataRef",partialId,"completeness","COMPLETE"),false,fingerprints));
        check.accept("untrusted dataRef field is externalized instead of accepted as a runtime handle",!partialId.equals(forged.get("dataRef"))&&before.equals(Json.write(app.data.owned(OWNER,partialId))));
        var summary=new ToolContract("summary","1",Json.map(),List.of(),ToolContract.Exposure.BOUNDED_SUMMARY,List.of(),Set.of("dataRef"),2048,"value");
        var forgedSummary=Json.object(output.normalize(OWNER,"review",summary,Json.map("dataRef",partialId),false));
        check.accept("summary projection cannot manufacture an artifact handle",!partialId.equals(forgedSummary.get("dataRef")));

        var prior=app.store.list("tool-execution").stream().filter(e->"SUCCEEDED".equals(e.get("status"))&&"bulk2__query".equals(Json.child(e,"tool").get("name"))).findFirst().orElseThrow();
        long count=app.store.list("data-artifact").size();
        var replay=app.tools.execute(OWNER,Json.required(prior,"runId"),Json.required(prior,"toolCallId"),ToolDefinition.from(Json.child(prior,"tool")),Json.child(prior,"args"),Json.map(),false,(type,data)->{});
        check.accept("cached normalized results preserve dataset identity without recapturing references",Json.write(prior.get("result")).equals(Json.write(replay.result()))&&app.store.list("data-artifact").size()==count);

        Path dir=Files.createTempDirectory("review-contract-");Path contracts=dir.resolve("contracts.json"),settings=dir.resolve("application.properties");
        Files.writeString(contracts,Json.write(List.of(Json.map("tool","repeated","version","1","outputPath",List.of("data","data"),"exposure","BOUNDED_SUMMARY","summaryFields",List.of("count")))));
        Files.writeString(settings,"yunfan.contracts.file="+contracts.toString().replace('\\','/')+"\n");
        var loaded=new ToolContractRegistry(new Config(settings)).get(new ToolDefinition("repeated","","","",Json.map(),"READ",true,"1"));
        check.accept("configured selector preserves repeated path segments",loaded.outputPath().equals(List.of("data","data"))&&Json.object(output.normalize(OWNER,"review",loaded,Json.map("data",Json.map("data",Json.map("count",3))),false)).get("count").equals(3));

        app.contracts.register(new ToolContract("bulk2__scalar","1",Json.map("type","object"),List.of(),ToolContract.Exposure.AUTO,List.of("structuredContent","value"),Set.of(),2048,"value"));
        var scalar=start(app,model,plan(List.of(node("s","bulk2__scalar",List.of(),Json.map())),"s","result"));
        check.accept("DAG result port preserves a scalar string instead of interpreting it as an artifact","COMPLETED".equals(scalar.get("status"))&&Json.required(scalar,"answer").contains("ordinary scalar result"));
        var writer=new AuthContext("local","memory-writer",Set.of("memory:write"),"review");var fact=app.memories.put(writer,Json.map("fact","Approved glossary fact","source","operator"));
        rejects(check,"write-only memory role still cannot list facts","FORBIDDEN",()->app.memories.list(writer));app.memories.delete(writer,Json.required(fact,"id"));
        check.accept("memory write permission works independently from memory read",app.store.get("persistent-memory",Json.required(fact,"id"))==null);
    }
}
