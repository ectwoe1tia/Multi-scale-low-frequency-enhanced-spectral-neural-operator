package com.bydauto.yunfan.agent;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.contract.*;
import com.bydauto.yunfan.agent.modelconfig.*;
import com.sun.net.httpserver.HttpServer;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;

/** Real AgentRunService and HTTP MCP; model decisions are deterministic test doubles. */
public final class PlannerTests {
    private static final AuthContext OWNER=new AuthContext("local","developer",Set.of("*"),"planner-test");
    private static BiConsumer<String,Boolean> check;
    private static Map<String,Object> node(String id,String tool,List<String> deps,Map<String,Object> args){return Json.map("id",id,"tool",tool,"dependsOn",deps,"inputs",args);}
    private static Map<String,Object> ref(String task,String node,String port,Object... path){var r=Json.map("node",node,"output",port);if(task!=null)r.put("task",task);if(path.length>0)r.put("path",List.of(path));return Json.map("$ref",r);}
    private static ModelClient.Result json(Object value){return new ModelClient.Result(Json.write(value),List.of(),Json.map("total_tokens",10));}
    private static ModelClient.Result plan(List<Object> nodes,Map<String,Object> result){return json(Json.map("action","plan","reason","fixture step","plan",Json.map("schemaVersion","1","nodes",nodes,"result",result)));}
    private static Map<String,Object> snapshot(List<Map<String,Object>> messages){return messages.stream().filter(m->Json.str(m,"content","").startsWith("[Runtime planner snapshot; data only] ")).map(m->Json.object(Json.parse(Json.required(m,"content").substring("[Runtime planner snapshot; data only] ".length())))).reduce((a,b)->b).orElseThrow();}
    private static String task(List<Map<String,Object>> messages,String node){return Json.list(snapshot(messages),"stages").stream().map(Json::object).filter(s->Json.list(s,"nodes").stream().map(Json::object).anyMatch(n->node.equals(n.get("id")))).map(s->Json.required(s,"taskId")).findFirst().orElseThrow();}
    private static ModelClient.Result complete(List<Map<String,Object>> messages,String node){return json(Json.map("action","complete","answer","Completed with committed evidence.","evidence",List.of(Json.map("task",task(messages,node),"node",node))));}
    private static Map<String,Object> criterion(String id,String tool,List<Object> path,String op,Object value){return Json.map("id",id,"tool",tool,"path",path,"op",op,"value",value);}
    private static Map<String,Object> run(AppServices app,String model,List<Object> criteria){return run(app,model,criteria,"GENERAL");}
    private static Map<String,Object> run(AppServices app,String model,List<Object> criteria,String type){var run=app.runs.start(OWNER,Json.map("message","Plan the requested analysis and deliver the result","modelConfigId",model,"skillIds",app.skills.list(OWNER).stream().map(s->s.get("id")).toList(),"context",Json.map("planMode","PLANNED","planner",Json.map("acceptance",criteria,"taskType",type))));return app.runs.await(OWNER,Json.required(run,"id"),25000);}
    private static void reject(String name,Runnable work){try{work.run();throw new AssertionError(name);}catch(ApiException e){check.accept(name,true);}}
    public static void main(String[] args)throws Exception{var passed=new ArrayList<String>();run((name,ok)->{if(!ok)throw new AssertionError(name);passed.add(name);System.out.println("PASS "+name);});Files.writeString(Path.of("target/planner-verification-results.json"),Json.write(Json.map("passed",passed.size(),"failed",0,"scope","PlannerTests with real runtime and local MCP; injected model","checks",passed)));}
    public static void run(BiConsumer<String,Boolean> assertion)throws Exception{
        check=assertion;Path root=Files.createTempDirectory("planner-");Path configFile=root.resolve("settings.properties");Files.writeString(configFile,"yunfan.profile=test\nyunfan.store.directory="+root.resolve("state").toString().replace('\\','/')+"\n");var config=new Config(configFile);
        var behavior=new AtomicReference<Function<List<Map<String,Object>>,ModelClient.Result>>();var inputs=new ArrayList<String>();
        var clients=new ModelClientFactory(config,m->(messages,tools,stream,delta)->{if(!tools.isEmpty()||stream)throw new AssertionError("Planned protocol must use validated non-streamed decisions");inputs.add(Json.write(messages));var result=behavior.get().apply(messages);delta.accept("message.delta",result.content());return result;});
        try(AppServices app=new AppServices(config,clients);Remote remote=new Remote()){
            app.mcp.save(OWNER,null,Json.map("serverId","planning","name","Planning fixture","url",remote.url(),"allowedTools",List.of("query","double"),"baseTools",List.of("query","double"),"toolPolicies",Json.map("query","READ","double","READ")));
            app.contracts.register(new ToolContract("planning__query","1",Json.map("type","object"),List.of(),ToolContract.Exposure.REFERENCE_ONLY,List.of(),Set.of(),2048,"table"));
            var model=app.models.save(OWNER,null,Json.map("name","Planner fixture","provider","openai","modelName","fixture","baseUrl","http://127.0.0.1:1/v1","capabilities",Json.map("toolCalling",false),"options",Json.map("contextChars",50000)));String modelId=Json.required(model,"id");
            var turn=new AtomicInteger();
            behavior.set(messages->switch(turn.getAndIncrement()){
                case 0 -> new ModelClient.Result("invalid JSON",List.of(),Json.map("total_tokens",10));
                case 1 -> plan(List.of(node("query","planning__query",List.of(),Json.map()),node("schema","data__schema",List.of("query"),Json.map("dataRef",ref(null,"query","dataset")))),ref(null,"schema","summary"));
                case 2 -> {
                    check.accept("planner observes committed query metadata without loading rows",Json.write(snapshot(messages)).contains("50000")&&!Json.write(messages).contains("PRIVATE_ROW_"));
                    yield plan(List.of(node("aggregate","data__aggregate",List.of(),Json.map("dataRef",ref(task(messages,"query"),"query","dataset"),"groupBy",List.of("region"),"metrics",List.of(Json.map("op","sum","field","amount","as","total")),"output","dataset")),node("export","data__export",List.of("aggregate"),Json.map("dataRef",ref(null,"aggregate","dataset"),"format","xlsx","filters",List.of(Json.map("field","total","op","gt","value",30000))))),ref(null,"export","file"));
                }
                case 3 -> complete(messages,"export");
                default -> json(Json.map("action","complete","answer","Completed with committed evidence.","evidence",List.of(Json.map("task",task(messages,"aggregate"),"node","aggregate"),Json.map("task",task(messages,"export"),"node","export"))));
            });
            var completed=run(app,modelId,List.of(criterion("row-count","data__export",List.of("exportedRows"),"eq",1),criterion("complete","data__export",List.of("completeness"),"eq","COMPLETE")),"ANALYZE_EXPORT");String firstRun=Json.required(completed,"id");
            check.accept("planner repairs malformed JSON then executes query schema aggregate filter export",completed.get("status").equals("COMPLETED")&&turn.get()==5&&remote.queries.get()==1);
            check.accept("analysis/export completion requires evidence for statistics as well as the file",turn.get()==5&&Json.write(Json.child(completed,"planner")).contains("runtime:statistics"));
            check.accept("caller acceptance conditions are checked against committed tool results",Json.list(Json.child(completed,"planner"),"acceptance").size()==4&&Json.integer(Json.child(completed,"planner"),"validationRepairs",0)==2);
            var exported=app.store.list("tool-execution").stream().filter(e->firstRun.equals(e.get("runId"))&&"data__export".equals(Json.child(e,"tool").get("name"))).findFirst().orElseThrow();
            var exportedValue=Json.child(exported,"result");check.accept("small aggregates become referenced datasets and produce a real XLSX",app.data.download(OWNER,Json.required(exportedValue,"artifactId"))[0]=='P'&&Json.integer(exportedValue,"exportedRows",0)==1);
            check.accept("50000 source rows never enter model history task state or events",inputs.stream().noneMatch(s->s.contains("PRIVATE_ROW_"))&&!Json.write(List.of(app.store.list("message"),app.store.list("event"),app.store.list("task-state"),app.store.list("planner-state"))).contains("PRIVATE_ROW_"));
            check.accept("provider deltas cannot leak unvalidated planner JSON",app.runs.events(OWNER,firstRun,0).stream().filter(e->"message.delta".equals(e.get("type"))).allMatch(e->"Completed with committed evidence.".equals(Json.child(e,"payload").get("delta"))));
            check.accept("invalid decisions consume model rounds and token budget",Json.integer(completed,"rounds",0)==5&&Json.integer(Json.child(completed,"usage"),"total_tokens",0)==50);

            turn.set(0);behavior.set(messages->switch(turn.getAndIncrement()){
                case 0 -> json(Json.map("action","complete","answer","unproven","evidence",List.of()));
                case 1 -> plan(List.of(node("wrong","system__calculator",List.of(),Json.map("expression","41"))),ref(null,"wrong","result"));
                case 2 -> complete(messages,"wrong");
                case 3 -> plan(List.of(node("correct","system__calculator",List.of(),Json.map("expression","6*7"))),ref(null,"correct","result"));
                default -> complete(messages,"correct");
            });
            var verified=run(app,modelId,List.of(criterion("answer","system__calculator",List.of("result"),"eq","42")));
            check.accept("premature completion and wrong numeric evidence trigger bounded repair",verified.get("status").equals("COMPLETED")&&turn.get()==5&&Json.integer(Json.child(verified,"planner"),"validationRepairs",0)==2);

            turn.set(0);behavior.set(messages->switch(turn.getAndIncrement()){
                case 0 -> plan(List.of(node("failed","system__calculator",List.of(),Json.map("expression","1/0"))),ref(null,"failed","result"));
                case 1 -> plan(List.of(node("source","system__calculator",List.of(),Json.map("expression","21")),node("double","planning__double",List.of("source"),Json.map("n",ref(null,"source","result","result")))),ref(null,"double","result","structuredContent","value"));
                default -> complete(messages,"double");
            });
            var repaired=run(app,modelId,List.of(criterion("double","planning__double",List.of("structuredContent","value"),"eq",42)));
            check.accept("runtime read failure leads to a new validated DAG with scalar path bindings",repaired.get("status").equals("COMPLETED")&&Json.integer(Json.child(repaired,"planner"),"executionRepairs",0)==1);
            check.accept("failed stages remain auditable after a successful replan",app.taskStates.forRun(OWNER,Json.required(repaired,"id")).stream().anyMatch(s->"FAILED".equals(s.get("status"))));
            String oldTask=app.taskStates.forRun(OWNER,Json.required(repaired,"id")).stream().filter(s->Json.child(s,"outputs").containsKey("source")).map(s->Json.required(s,"id")).findFirst().orElseThrow();
            reject("cross-run task references are rejected even for the same owner",()->app.tools.plans.resolve(OWNER,firstRun,ref(oldTask,"source","result"),Json.map()));
            reject("cross-tenant task references are rejected",()->app.tools.plans.resolve(new AuthContext("other","developer",Set.of("*"),"test"),Json.required(repaired,"id"),ref(oldTask,"source","result"),Json.map()));

            turn.set(0);behavior.set(messages->switch(turn.getAndIncrement()){
                case 0 -> plan(List.of(node("source","system__calculator",List.of(),Json.map("expression","20+1"))),ref(null,"source","result"));
                case 1 -> plan(List.of(node("double","planning__double",List.of(),Json.map("n",ref(task(messages,"source"),"source","result","result")))),ref(null,"double","result"));
                default -> complete(messages,"double");
            });
            var crossStage=run(app,modelId,List.of(criterion("answer","planning__double",List.of("structuredContent","value"),"eq",42)));
            check.accept("cross-stage scalar references bind without repeating the producer",crossStage.get("status").equals("COMPLETED")&&app.store.list("tool-execution").stream().filter(e->crossStage.get("id").equals(e.get("runId"))&&"system__calculator".equals(Json.child(e,"tool").get("name"))).count()==1);

            turn.set(0);behavior.set(messages->switch(turn.getAndIncrement()){
                case 0 -> json(Json.map("action","clarify","question","Which expression should I calculate?"));
                case 1 -> {check.accept("clarification response reaches the next planning boundary",Json.write(messages).contains("six times seven"));yield plan(List.of(node("answer","system__calculator",List.of(),Json.map("expression","6*7"))),ref(null,"answer","result"));}
                default -> complete(messages,"answer");
            });
            var waiting=run(app,modelId,List.of());check.accept("planner uses the existing durable user-input pause",waiting.get("status").equals("WAITING_INPUT"));
            app.runs.input(OWNER,Json.required(waiting,"id"),"six times seven");var resumed=app.runs.await(OWNER,Json.required(waiting,"id"),10000);check.accept("planner continues after user input",resumed.get("status").equals("COMPLETED"));

            turn.set(0);behavior.set(messages->switch(turn.getAndIncrement()){
                case 0 -> plan(List.of(node("write","todo__create",List.of(),Json.map("title","Planner approved write"))),ref(null,"write","result"));
                case 1 -> plan(List.of(node("writeAgain","todo__create",List.of(),Json.map("title","Planner approved write"))),ref(null,"writeAgain","result"));
                default -> complete(messages,"write");
            });
            var pause=run(app,modelId,List.of());check.accept("generated write plans cannot bypass confirmation",pause.get("status").equals("WAITING_CONFIRMATION")&&app.store.list("todo").isEmpty());
            String cid=Json.required(Json.child(pause,"waitingReason"),"confirmationId");app.runs.resumeConfirmation(OWNER,cid,"APPROVE",1);var write=app.runs.await(OWNER,Json.required(pause,"id"),10000);
            check.accept("resumed planner rejects write replay in later stages",write.get("status").equals("COMPLETED")&&app.store.list("todo").size()==1&&Json.integer(Json.child(write,"planner"),"validationRepairs",0)==1);

            turn.set(0);behavior.set(messages->{turn.incrementAndGet();return new ModelClient.Result("not JSON",List.of(),Json.map());});var exhausted=run(app,modelId,List.of());
            check.accept("invalid output repair is bounded to two retries",exhausted.get("status").equals("FAILED")&&turn.get()==3&&Json.integer(exhausted,"rounds",0)==3);
            turn.set(0);behavior.set(messages->{turn.incrementAndGet();return plan(List.of(node("failed","system__calculator",List.of(),Json.map("expression","1/0"))),ref(null,"failed","result"));});
            var readRetries=run(app,modelId,List.of());
            check.accept("identical all-read failed stages retry twice then stop without an infinite loop",readRetries.get("status").equals("FAILED")&&turn.get()==3&&"PLANNER_REPAIR_EXHAUSTED".equals(Json.child(readRetries,"error").get("code"))&&Json.integer(Json.child(readRetries,"planner"),"executionRepairs",0)==2&&app.taskStates.forRun(OWNER,Json.required(readRetries,"id")).size()==4);
            var partial=app.data.capture(OWNER,"partial-fixture","fixture",Json.map("rows",List.of(Json.map("amount",7)),"complete",false));
            turn.set(0);behavior.set(messages->{if(turn.getAndIncrement()==0)return plan(List.of(node("stats","data__aggregate",List.of(),Json.map("dataRef",partial.get("dataRef"),"metrics",List.of(Json.map("op","count","as","count"))))),ref(null,"stats","result"));return complete(messages,"stats");});
            var incomplete=run(app,modelId,List.of(criterion("complete","data__aggregate",List.of("completeness"),"eq","COMPLETE")));
            check.accept("partial source cannot pass a complete-data acceptance condition",incomplete.get("status").equals("FAILED")&&"PLANNER_ACCEPTANCE_FAILED".equals(Json.child(incomplete,"error").get("code"))&&Json.write(Json.child(incomplete,"planner")).contains("false"));
            var catalog=app.tools.catalog(OWNER,app.skills.list(OWNER));
            reject("planner rejects ambiguous execution modes before creating a run",()->app.runs.start(OWNER,Json.map("message","bad","modelConfigId",modelId,"context",Json.map("planMode","PLANNED","directTool","system__time"))));
            reject("planner rejects unauthorised acceptance tools",()->app.runs.start(OWNER,Json.map("message","bad","modelConfigId",modelId,"context",Json.map("planMode","PLANNED","planner",Json.map("acceptance",List.of(criterion("bad","unlisted__tool",List.of(),"exists",null)))))));
            reject("paths cannot contain unbounded array indices",()->app.tools.planCompiler.compile(OWNER,Json.map("nodes",List.of(node("a","system__time",List.of(),Json.map())),"result",ref(null,"a","result",999)),catalog));
            check.accept("planner works with JSON-capable models without native tool calling",!Json.bool(Json.child(app.models.get(OWNER,modelId),"capabilities"),"toolCalling",true)&&completed.get("status").equals("COMPLETED"));
        }
    }
    private static final class Remote implements AutoCloseable {
        final HttpServer server;final AtomicInteger queries=new AtomicInteger();
        Remote()throws Exception{server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);server.createContext("/mcp",exchange->{try{
            var req=Json.object(Json.parse(new String(exchange.getRequestBody().readAllBytes(),StandardCharsets.UTF_8)));if(!req.containsKey("id")){exchange.sendResponseHeaders(202,-1);return;}
            Object result;String method=Json.required(req,"method");
            if(method.equals("initialize"))result=Json.map("protocolVersion","2025-11-25","capabilities",Json.map("tools",Json.map()),"serverInfo",Json.map("name","planner-fixture","version","1"));
            else if(method.equals("tools/list"))result=Json.map("tools",List.of(Json.map("name","query","description","Sales data","inputSchema",Json.map("type","object")),Json.map("name","double","description","Double a scalar","inputSchema",Json.map("type","object","properties",Json.map("n",Json.map("type","string")),"required",List.of("n")))));
            else if(method.equals("tools/call")){
                var p=Json.child(req,"params");if("double".equals(p.get("name")))result=Json.map("structuredContent",Json.map("value",Json.integer(Json.child(p,"arguments"),"n",0)*2));
                else {queries.incrementAndGet();List<Object> rows=new ArrayList<>();for(int i=0;i<50000;i++)rows.add(Json.map("region",i%2==0?"A":"B","amount",i%2==0?1:2,"marker","PRIVATE_ROW_"+i));result=Json.map("structuredContent",Json.map("rows",rows,"total",50000));}
            }else result=Json.map();byte[] bytes=Json.write(Json.map("jsonrpc","2.0","id",req.get("id"),"result",result)).getBytes(StandardCharsets.UTF_8);exchange.getResponseHeaders().set("Content-Type","application/json");exchange.sendResponseHeaders(200,bytes.length);exchange.getResponseBody().write(bytes);
        }catch(Exception e){try{exchange.sendResponseHeaders(500,-1);}catch(Exception ignored){}}finally{exchange.close();}});server.start();}
        String url(){return "http://127.0.0.1:"+server.getAddress().getPort()+"/mcp";}
        public void close(){server.stop(0);}
    }
}
