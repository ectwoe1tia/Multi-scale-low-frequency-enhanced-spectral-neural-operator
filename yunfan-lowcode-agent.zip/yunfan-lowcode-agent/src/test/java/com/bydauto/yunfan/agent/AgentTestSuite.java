package com.bydauto.yunfan.agent;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.chat.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.governance.*;
import com.bydauto.yunfan.agent.skill.*;
import com.bydauto.yunfan.agent.tooling.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.*;
/** Runnable without Maven/JUnit. Tests actual persistence, model HTTP, MCP HTTP and public REST/SSE. */
public final class AgentTestSuite {
    private static int passed;
    private static String waitingAcrossRestart,interruptedWrite;
    private static int todosBeforeRestart;
    private static final List<String> names=new ArrayList<>();
    private static final AuthContext ACTOR=new AuthContext("local","developer",Set.of("*"),"test-trace");
    private static void check(String name,boolean condition) {
        if(!condition)throw new AssertionError(name);
        passed++;
        names.add(name);
        System.out.println("PASS "+name);
    }
    private static void expect(String name,Runnable action) {
        try {
            action.run();
            throw new AssertionError(name+" did not reject");
        } catch(ApiException|IllegalStateException expected) {
            check(name,true);
        }
    }
    public static void main(String[] args)throws Exception {
        jsonAndLogic();
        persistence();
        Path directory=Files.createTempDirectory("yunfan-agent-test-");
        Path cfg=directory.resolve("test.properties");
        Files.writeString(cfg,"yunfan.profile=test\nyunfan.store.directory="+directory.resolve("data").toString().replace('\\','/')+"\nyunfan.http.port=0\n");
        Config config=new Config(cfg);
        try(AppServices app=new AppServices(config);
        FakeRemote fake=new FakeRemote()) {
            governance(app);
            skillTests(app);
            agentTests(app);
            remoteTests(app,fake);
            httpTests(app);
            hardeningTests(app);
            check("cross-tenant session isolation",forbidden(()->app.sessions.get(new AuthContext("other","developer",Set.of("*"),"x"),app.sessions.list(ACTOR).get(0).get("id").toString())));
            check("cross-user model administration denied",forbidden(()->app.models.save(new AuthContext("local","reader",Set.of("chat"),"x"),null,Json.map())));
            waitingAcrossRestart=done(app,start(app,"澄清重启测试")).get("id").toString();
            var interrupted=done(app,start(app,"检查采购流程并创建待办"));
            interruptedWrite=interrupted.get("id").toString();
            app.store.transaction(tx-> {
                var run=tx.get("run",interruptedWrite);
                run.put("status","RUNNING");
                tx.put("run",interruptedWrite,run);
                for(var e:tx.list("tool-execution"))if(interruptedWrite.equals(e.get("runId"))&&"WAITING_CONFIRMATION".equals(e.get("status"))) {
                    e.put("status","EXECUTING");
                    tx.put("tool-execution",e.get("id").toString(),e);
                }
                return null;
            });
            todosBeforeRestart=app.store.list("todo").size();
        }
        try(AppServices restarted=new AppServices(config)) {
            check("restart restores sessions and reports",!restarted.sessions.list(ACTOR).isEmpty()&&!restarted.store.list("report").isEmpty());
            check("restart preserves waiting input",restarted.runs.get(ACTOR,waitingAcrossRestart).get("status").equals("WAITING_INPUT"));
            restarted.runs.input(ACTOR,waitingAcrossRestart,"补充完成");
            check("waiting input resumes after restart",done(restarted,restarted.runs.get(ACTOR,waitingAcrossRestart)).get("status").equals("COMPLETED"));
            check("interrupted write recovers as unknown",restarted.runs.get(ACTOR,interruptedWrite).get("status").equals("RECONCILIATION_REQUIRED"));
            check("restart recovery never replays a write",restarted.store.list("todo").size()==todosBeforeRestart);
        }
        String old=System.getProperty("yunfan.profile");
        System.setProperty("yunfan.profile","pro");
        try {
            expect("production requires auth adapters",()->new AuthService(config));
        } finally {
            if(old==null)System.clearProperty("yunfan.profile");
            else System.setProperty("yunfan.profile",old);
        }
        EnhancementTests.run(AgentTestSuite::check);
        Map<String,Object> report=Json.map("passed",passed,"failed",0,"runtime",System.getProperty("java.version"),"bytecodeRelease",17,"tests",names,"createdAt",Util.now());
        Path target=Path.of("target");
        Files.createDirectories(target);
        Files.writeString(target.resolve("verification-results.json"),Json.write(report));
        System.out.println("ALL TESTS PASSED: "+passed);
    }
    private static boolean forbidden(Runnable work) {
        try {
            work.run();
            return false;
        } catch(ApiException e) {
            return e.status==403;
        }
    }
    private static void jsonAndLogic() {
        String value="{\"text\":\"中文\\n😀\",\"items\":[1,true,null,-1.2e3]}";
        check("JSON unicode and numeric roundtrip",Json.write(Json.parse(Json.write(Json.parse(value)))).equals(Json.write(Json.parse(value))));
        expect("JSON duplicate keys rejected",()->Json.parse("{\"x\":1,\"x\":2}"));
        expect("JSON trailing content rejected",()->Json.parse("{}x"));
        expect("JSON leading zero rejected",()->Json.parse("01"));
        expect("JSON control chars rejected",()->Json.parse("\"a\nb\""));
        check("calculator precedence and unary",Calculator.evaluate("12 * (3 + 4) - -2").equals("86"));
        expect("calculator rejects executable text",()->Calculator.evaluate("Runtime.exec('x')"));
        expect("calculator division by zero",()->Calculator.evaluate("1/0"));
        JsonSchemaValidator schema=new JsonSchemaValidator();
        var spec=Json.map("type","object","properties",Json.map("n",Json.map("type","integer","minimum",1)),"required",List.of("n"),"additionalProperties",false);
        schema.validate(Json.map("n",2),spec);
        check("tool schema valid input",true);
        expect("tool schema rejects invalid integer",()->schema.validate(Json.map("n",1.5),spec));
        expect("tool schema rejects extra properties",()->schema.validate(Json.map("n",2,"bad",true),spec));
        List<Map<String,Object>> history=List.of(Json.map("id","1","role","user","content","same"),Json.map("id","2","role","assistant","content","ok"),Json.map("id","3","role","user","content","same"));
        check("history retains identical user questions",new ChatHistoryLogic().select(history,10000).messages().size()==3);
        List<Map<String,Object>> incomplete=List.of(Json.map("id","u","role","user","content","old"),Json.map("id","a","role","assistant","content","","tool_calls",List.of(Json.map("id","unfinished","type","function","function",Json.map("name","x","arguments","{}")))),Json.map("id","u2","role","user","content","new"));
        var normalized=new ChatHistoryLogic().normalize(incomplete);
        check("cancelled history removes dangling tool-call protocol",!normalized.get(1).containsKey("tool_calls")&&normalized.get(1).get("content").toString().contains("未完整结束"));
        expect("history rejects oversized current group",()->new ChatHistoryLogic().select(history,1));
        expect("request parser rejects system history",()->new ChatRequestParser().parse(Json.map("message","x","history",List.of())));
        var parsed=new SkillMdParser().parse("---\nname: example\ndescription: 示例\nallowedTools:\n  - system__time\n---\n说明");
        check("skill front matter block list",Json.strings(Json.child(parsed,"metadata").get("allowedTools")).contains("system__time"));
        expect("skill parser rejects YAML tags",()->new SkillMdParser().parse("---\nname: !unsafe\ndescription: x\n---\nx"));
        check("embedding cosine",Math.abs(SkillEmbeddingService.cosine(List.of(1,0),List.of(1,0))-1)<1e-9);
    }
    private static void persistence()throws Exception {
        Path p=Files.createTempDirectory("yunfan-store-test-");
        try(FileDocumentStore store=new FileDocumentStore(p)) {
            store.put("x","one",Json.map("value",1));
            expect("file store transaction rollback",()->store.transaction(tx-> {
                tx.put("x","one",Json.map("value",2));
                throw ApiException.bad("rollback");
            } ));
            check("rollback preserves old data",Json.integer(store.get("x","one"),"value",0)==1);
            var detached=store.get("x","one");
            detached.put("value",3);
            check("store returns detached snapshots",Json.integer(store.get("x","one"),"value",0)==1);
            expect("file store rejects concurrent process owner",()->new FileDocumentStore(p));
        }
        try(FileDocumentStore store=new FileDocumentStore(p)) {
            check("file snapshot survives reopen",Json.integer(store.get("x","one"),"value",0)==1);
        }
    }
    private static void governance(AppServices app) {
        var report=app.governance.check(ACTOR,"test",GovernanceService.demoProcess(),List.of());
        List<Object> f=Json.list(report,"findings");
        check("governance missing approver failure",f.stream().map(Json::object).anyMatch(x->"APPROVER".equals(x.get("handler"))&&"FAIL".equals(x.get("status"))));
        check("governance missing instances is unknown",f.stream().map(Json::object).anyMatch(x->"INSTANCE_SLA".equals(x.get("handler"))&&"UNKNOWN".equals(x.get("status"))));
        Map<String,Object> cycle=Json.map("id","cycle","version","1","nodes",List.of(Json.map("id","s","type","start"),Json.map("id","a","type","task"),Json.map("id","e","type","end")),"edges",List.of(Json.map("source","s","target","a"),Json.map("source","a","target","a"),Json.map("source","a","target","e")));
        var c=app.governance.check(ACTOR,"test",cycle,List.of());
        check("valid workflow cycle is not automatically an error",Json.list(c,"findings").stream().map(Json::object).noneMatch(x->"REACHABILITY".equals(x.get("handler"))&&"FAIL".equals(x.get("status"))));
        var invalid=Json.object(Json.copy(cycle));
        Json.list(invalid,"edges").add(Json.map("source","s","target","missing"));
        var bad=app.governance.check(ACTOR,"test",invalid,List.of());
        check("dangling edge detected",Json.list(bad,"findings").stream().map(Json::object).anyMatch(x->"NODE_REFERENCE".equals(x.get("handler"))&&"FAIL".equals(x.get("status"))));
    }
    private static void skillTests(AppServices app)throws Exception {
        expect("disabled explicit skill rejected",()-> {
            var skill=app.skills.save(ACTOR,null,"---\nname: disabled\ndescription: disabled\n---\n说明");
            app.skills.action(ACTOR,skill.get("id").toString(),"disable");
            app.skillRegistry.select(ACTOR,Set.of(skill.get("id").toString()),"x");
        } );
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(ZipOutputStream zip=new ZipOutputStream(bytes)) {
            zip.putNextEntry(new ZipEntry("../SKILL.md"));
            zip.write("x".getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        expect("ZIP traversal rejected",()->app.skills.importZip(ACTOR,bytes.toByteArray()));
        var selected=app.skillRegistry.select(ACTOR,Set.of(),"检查采购流程并创建待办");
        check("skill automatic retrieval",!selected.skills().isEmpty());
        check("offline retrieval is labelled lexical",selected.retrievalMode().startsWith("local-lexical"));
    }
    private static Map<String,Object> done(AppServices app,Map<String,Object> run) {
        return app.runs.await(ACTOR,run.get("id").toString(),15000);
    }
    private static Map<String,Object> start(AppServices app,String message) {
        return app.runs.start(ACTOR,Json.map("message",message,"requestId",Util.id()));
    }
    private static void agentTests(AppServices app)throws Exception {
        var input=Json.map("message","计算 12*(3+4)","requestId","dedup-test");
        var run=done(app,app.runs.start(ACTOR,input));
        check("agent calculator tool loop",run.get("status").equals("COMPLETED")&&run.get("answer").toString().contains("84"));
        check("request idempotency",app.runs.start(ACTOR,input).get("id").equals(run.get("id")));
        expect("request id content conflict",()->app.runs.start(ACTOR,Json.map("message","different","requestId","dedup-test")));
        var events=app.runs.events(ACTOR,run.get("id").toString(),0);
        check("SSE event sequence monotonic",java.util.stream.IntStream.range(0,events.size()).allMatch(i->Json.integer(events.get(i),"seq",0)==i+1));
        check("one done event per segment",events.stream().filter(e->"done".equals(e.get("type"))).count()==1);
        check("tool progress events",events.stream().anyMatch(e->"tool.completed".equals(e.get("type"))));
        var second=done(app,app.runs.start(ACTOR,Json.map("message","计算 12*(3+4)","sessionId",run.get("sessionId"),"requestId",Util.id())));
        check("multi-turn same text retained",app.sessions.messages(ACTOR,run.get("sessionId").toString()).stream().filter(m->"user".equals(m.get("role"))).count()==2&&"COMPLETED".equals(second.get("status")));
        var waiting=done(app,start(app,"检查采购流程并创建待办"));
        check("governance workflow pauses for write confirmation",waiting.get("status").equals("WAITING_CONFIRMATION"));
        String sid=waiting.get("sessionId").toString();
        expect("active session concurrency protection",()->app.runs.start(ACTOR,Json.map("message","x","sessionId",sid)));
        String cid=Json.required(Json.child(waiting,"waitingReason"),"confirmationId");
        app.runs.resumeConfirmation(ACTOR,cid,"APPROVE",1);
        var finished=done(app,waiting);
        check("confirmed write resumes and completes",finished.get("status").equals("COMPLETED"));
        int todoCount=app.store.list("todo").size();
        check("confirmed write persists actual todo",todoCount==1);
        app.runs.resumeConfirmation(ACTOR,cid,"APPROVE",1);
        check("duplicate confirmation does not duplicate write",app.store.list("todo").size()==todoCount);
        var clarify=done(app,start(app,"澄清流程"));
        check("agent waits for missing input",clarify.get("status").equals("WAITING_INPUT"));
        app.runs.input(ACTOR,clarify.get("id").toString(),"采购审批流程");
        check("clarification resumes same run",done(app,clarify).get("status").equals("COMPLETED"));
        var cancel=done(app,start(app,"检查采购流程并创建待办"));
        String cancelCid=Json.required(Json.child(cancel,"waitingReason"),"confirmationId");
        app.runs.cancel(ACTOR,cancel.get("id").toString());
        expect("cancelled run cannot execute pending approval",()->app.runs.resumeConfirmation(ACTOR,cancelCid,"APPROVE",1));
        check("cancellation state persisted",app.runs.get(ACTOR,cancel.get("id").toString()).get("status").equals("CANCELLED"));
        var denied=done(app,start(app,"检查采购流程并创建待办"));
        app.runs.resumeConfirmation(ACTOR,Json.required(Json.child(denied,"waitingReason"),"confirmationId"),"REJECT",1);
        check("rejected operation never writes",done(app,denied).get("status").equals("COMPLETED")&&app.store.list("todo").size()==todoCount);
    }
    private static void remoteTests(AppServices app,FakeRemote fake) {
        app.mcp.save(ACTOR,null,Json.map("serverId","remote","name","Test MCP","url",fake.base()+"/mcp","baseTools",List.of("echo","write"),"toolPolicies",Json.map("echo","READ","write","WRITE")));
        var catalog=app.mcp.catalog(ACTOR,true);
        check("MCP initialize and discovery",catalog.failures().isEmpty()&&catalog.tools().size()==2);
        check("MCP session header propagated",fake.sessionSeen.get()>0);
        var real=app.models.save(ACTOR,null,Json.map("name","Protocol test model","modelName","test","provider","openai","baseUrl",fake.base()+"/v1","capabilities",Json.map("streaming",true,"toolCalling",true)));
        String mid=real.get("id").toString();
        var run=done(app,app.runs.start(ACTOR,Json.map("message","remote-echo","modelConfigId",mid)));
        check("real model SSE fragmented tool arguments",run.get("status").equals("COMPLETED")&&run.get("answer").toString().contains("echo-result"));
        check("real MCP tool invoked",fake.echoCalls.get()==1);
        check("model usage persisted",Json.integer(Json.child(run,"usage"),"total_tokens",0)>0);
        fake.expireNext=true;
        ToolDefinition echo=catalog.tools().stream().filter(t->t.originalName().equals("echo")).findFirst().orElseThrow();
        var result=app.mcp.invoke(ACTOR,echo,Json.map("text","recover"));
        check("MCP session 404 reinitialization",Json.write(result).contains("recover")&&fake.initializes.get()>=2);
        var write=done(app,app.runs.start(ACTOR,Json.map("message","remote-write","modelConfigId",mid)));
        check("remote write requires confirmation",write.get("status").equals("WAITING_CONFIRMATION"));
        app.runs.resumeConfirmation(ACTOR,Json.required(Json.child(write,"waitingReason"),"confirmationId"),"APPROVE",1);
        var unknown=done(app,write);
        check("remote uncertain write enters reconciliation",unknown.get("status").equals("RECONCILIATION_REQUIRED"));
        check("uncertain write never automatically retries",fake.writeCalls.get()==1);
        String executionId=Json.required(Json.child(unknown,"error"),"executionId");
        var reconciled=app.tools.reconcile(ACTOR,executionId,Json.map("resolution","SUCCEEDED","externalOperationId","external-123","evidence","Operator checked the downstream operation log"));
        check("operator reconciliation records evidence without replay",reconciled.get("status").equals("RECONCILED")&&fake.writeCalls.get()==1&&"RESOLVED".equals(app.runs.get(ACTOR,write.get("id").toString()).get("reconciliationStatus")));
        expect("duplicate reconciliation rejected",()->app.tools.reconcile(ACTOR,executionId,Json.map("resolution","SUCCEEDED","evidence","again")));
        app.mcp.save(ACTOR,"remote",Json.map("versionChecks",Json.map("write",Json.map("tool","echo","resourceArgument","text","expectedArgument","expectedVersion","versionField","version"))));
        ToolDefinition writer=catalog.tools().stream().filter(t->t.originalName().equals("write")).findFirst().orElseThrow();
        expect("write version preflight requires expected version",()->app.mcp.verifyPreconditions(ACTOR,writer,Json.map("text","resource")));
        expect("changed target version rejected before write",()->app.mcp.verifyPreconditions(ACTOR,writer,Json.map("text","resource","expectedVersion","1")));
        check("failed preflight never submits another write",fake.writeCalls.get()==1);
        app.models.action(ACTOR,mid,"disable");
        expect("disabled model rejected",()->app.runs.start(ACTOR,Json.map("message","x","modelConfigId",mid)));
        app.mcp.delete(ACTOR,"remote");
    }
    private static void httpTests(AppServices app)throws Exception {
        try(JdkHttpServer server=new JdkHttpServer(app)) {
            String root="http://127.0.0.1:"+server.port();
            HttpClient client=HttpClient.newHttpClient();
            var health=client.send(HttpRequest.newBuilder(URI.create(root+"/actuator/health")).build(),HttpResponse.BodyHandlers.ofString());
            check("HTTP health endpoint",health.statusCode()==200&&health.body().contains("UP"));
            String request=Json.write(Json.map("message","计算 2+3","requestId",Util.id()));
            var stream=client.send(HttpRequest.newBuilder(URI.create(root+"/api/chat/stream")).timeout(Duration.ofSeconds(20)).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(request)).build(),HttpResponse.BodyHandlers.ofString());
            check("HTTP POST SSE complete stream",stream.statusCode()==200&&stream.body().contains("event: tool.completed")&&stream.body().contains("event: done"));
            var invalid=client.send(HttpRequest.newBuilder(URI.create(root+"/api/chat")).POST(HttpRequest.BodyPublishers.ofString("{}x")).build(),HttpResponse.BodyHandlers.ofString());
            check("HTTP malformed input returns 400",invalid.statusCode()==400&&invalid.body().contains("INVALID_ARGUMENT"));
            var cors=client.send(HttpRequest.newBuilder(URI.create(root+"/api/sessions")).header("Origin","https://not-allowed.invalid").build(),HttpResponse.BodyHandlers.ofString());
            check("CORS deny unknown origin",cors.statusCode()==403);
            var api=app.router.handle(new ApiRouter.Request("POST","/api/governance/checks",Map.of(),Map.of(),Json.write(Json.map("process",GovernanceService.demoProcess())).getBytes(StandardCharsets.UTF_8)));
            var r=Json.child(Json.object(Json.parse(new String(api.body(),StandardCharsets.UTF_8))),"data");
            check("structured governance API uses run engine",api.status()==202&&done(app,r).get("status").equals("COMPLETED"));
        }
    }
    private static void hardeningTests(AppServices app)throws Exception {
        String before=System.getProperty("yunfan.agent.max-rounds");
        System.setProperty("yunfan.agent.max-rounds","1");
        try {
            var limited=done(app,start(app,"计算 5+6"));
            check("agent round budget stops tool loop",limited.get("status").equals("FAILED")&&"RUN_BUDGET_EXCEEDED".equals(Json.child(limited,"error").get("code")));
        }finally {
            if(before==null)System.clearProperty("yunfan.agent.max-rounds");
            else System.setProperty("yunfan.agent.max-rounds",before);
        }
        var waiting=done(app,start(app,"检查采购流程并创建待办"));
        String cid=Json.required(Json.child(waiting,"waitingReason"),"confirmationId");
        int count=app.store.list("todo").size();
        ExecutorService callers=Executors.newFixedThreadPool(2);
        try {
            var a=callers.submit(()->app.runs.resumeConfirmation(ACTOR,cid,"APPROVE",1));
            var b=callers.submit(()->app.runs.resumeConfirmation(ACTOR,cid,"APPROVE",1));
            a.get(5,TimeUnit.SECONDS);
            b.get(5,TimeUnit.SECONDS);
        }finally {
            callers.shutdownNow();
        }
        check("concurrent approvals execute at most once",done(app,waiting).get("status").equals("COMPLETED")&&app.store.list("todo").size()==count+1);
        var stale=done(app,start(app,"检查采购流程并创建待办"));
        String scid=Json.required(Json.child(stale,"waitingReason"),"confirmationId");
        expect("stale confirmation version rejected",()->app.runs.resumeConfirmation(ACTOR,scid,"APPROVE",9));
        app.store.transaction(tx-> {
            var c=tx.get("confirmation",scid);
            c.put("expiresAt","2000-01-01T00:00:00Z");
            tx.put("confirmation",scid,c);
            return null;
        });
        expect("expired confirmation rejected",()->app.runs.resumeConfirmation(ACTOR,scid,"APPROVE",1));
        app.runs.cancel(ACTOR,stale.get("id").toString());
        check("skill whitelist withholds write tools without active skill",app.tools.catalog(ACTOR,List.of()).stream().noneMatch(t->t.name().equals("todo__create")));
        var direct=app.router.handle(new ApiRouter.Request("POST","/api/todos",Map.of(),Map.of(),Json.write(Json.map("title","API todo")).getBytes(StandardCharsets.UTF_8)));
        var dr=Json.child(Json.object(Json.parse(new String(direct.body(),StandardCharsets.UTF_8))),"data");
        var dw=done(app,dr);
        check("todo compatibility endpoint preserves confirmation",direct.status()==202&&dw.get("status").equals("WAITING_CONFIRMATION"));
        app.runs.resumeConfirmation(ACTOR,Json.required(Json.child(dw,"waitingReason"),"confirmationId"),"REJECT",1);
        done(app,dw);
        var retained=done(app,start(app,"计算 3+4"));
        String rid=retained.get("id").toString();
        app.store.transaction(tx-> {
            for(var event:tx.list("event"))if(rid.equals(event.get("runId"))) {
                event.put("timestamp","2000-01-01T00:00:00Z");
                tx.put("event",rid+":"+String.format("%08d",Json.integer(event,"seq",0)),event);
            }
            return null;
        });
        app.runs.cleanupEvents();
        expect("expired event cursor returns explicit error",()->app.runs.events(ACTOR,rid,0));
        check("event retention preserves final messages",app.runs.get(ACTOR,rid).get("answer").toString().contains("7")&&!app.sessions.messages(ACTOR,retained.get("sessionId").toString()).isEmpty());
        check("admin metrics endpoint",app.router.handle(new ApiRouter.Request("GET","/api/admin/metrics",Map.of(),Map.of(),new byte[0])).status()==200);
    }
    private static final class FakeRemote implements AutoCloseable {
        final HttpServer server;
        final ExecutorService executor=Executors.newCachedThreadPool();
        final AtomicInteger initializes=new AtomicInteger(),sessionSeen=new AtomicInteger(),echoCalls=new AtomicInteger(),writeCalls=new AtomicInteger();
        volatile boolean expireNext;
        FakeRemote()throws IOException {
            server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),16);
            server.setExecutor(executor);
            server.createContext("/mcp",this::mcp);
            server.createContext("/v1/chat/completions",this::model);
            server.start();
        }
        String base() {
            return "http://127.0.0.1:"+server.getAddress().getPort();
        }
        void mcp(HttpExchange x)throws IOException {
            try {
                var request=Json.object(Json.parse(new String(x.getRequestBody().readAllBytes(),StandardCharsets.UTF_8)));
                String method=Json.required(request,"method");
                if(x.getRequestHeaders().getFirst("Mcp-Session-Id")!=null)sessionSeen.incrementAndGet();
                if(method.equals("notifications/initialized")) {
                    x.sendResponseHeaders(202,-1);
                    return;
                }
                if(method.equals("initialize")) {
                    initializes.incrementAndGet();
                    x.getResponseHeaders().set("Mcp-Session-Id","session-"+initializes.get());
                    reply(x,200,Json.map("jsonrpc","2.0","id",request.get("id"),"result",Json.map("protocolVersion","2025-11-25","capabilities",Json.map("tools",Json.map()),"serverInfo",Json.map("name","test","version","1"))));
                    return;
                }
                if(expireNext) {
                    expireNext=false;
                    reply(x,404,Json.map("error","expired"));
                    return;
                }
                Object result;
                if(method.equals("tools/list")) {
                    var input=Json.map("type","object","properties",Json.map("text",Json.map("type","string")),"required",List.of("text"),"additionalProperties",false);
                    result=Json.map("tools",List.of(Json.map("name","echo","description","echo","inputSchema",input),Json.map("name","write","description","write","inputSchema",input)));
                } else {
                    var params=Json.child(request,"params");
                    if(params.get("name").equals("write")) {
                        writeCalls.incrementAndGet();
                        reply(x,500,Json.map("error","Result unknown after write"));
                        return;
                    }
                    echoCalls.incrementAndGet();
                    result=Json.map("content",List.of(Json.map("type","text","text","echo-result:"+Json.child(params,"arguments").get("text"))),"structuredContent",Json.map("version","2"));
                }
                reply(x,200,Json.map("jsonrpc","2.0","id",request.get("id"),"result",result));
            } finally {
                x.close();
            }
        }
        void model(HttpExchange x)throws IOException {
            try {
                var request=Json.object(Json.parse(new String(x.getRequestBody().readAllBytes(),StandardCharsets.UTF_8)));
                List<Object> messages=Json.list(request,"messages");
                Map<String,Object> last=Json.object(messages.get(messages.size()-1));
                boolean tool="tool".equals(last.get("role"));
                String user=messages.stream().map(Json::object).filter(m->"user".equals(m.get("role"))).reduce((a,b)->b).map(m->Json.str(m,"content","")).orElse("");
                StringBuilder output=new StringBuilder();
                if(tool)output.append(chunk(Json.map("content","echo-result complete")));
                else {
                    String name=user.contains("write")?"remote__write":"remote__echo";
                    output.append(chunk(Json.map("tool_calls",List.of(Json.map("index",0,"id","call-"+UUID.randomUUID(),"type","function","function",Json.map("name",name,"arguments","{\"text\":"))))));
                    output.append(chunk(Json.map("tool_calls",List.of(Json.map("index",0,"function",Json.map("arguments","\"hello\"}"))))));
                }
                output.append("data: ").append(Json.write(Json.map("choices",List.of(),"usage",Json.map("total_tokens",10)))).append("\n\ndata: [DONE]\n\n");
                byte[] bytes=output.toString().getBytes(StandardCharsets.UTF_8);
                x.getResponseHeaders().set("Content-Type","text/event-stream");
                x.sendResponseHeaders(200,bytes.length);
                x.getResponseBody().write(bytes);
            } finally {
                x.close();
            }
        }
        String chunk(Object delta) {
            return "data: "+Json.write(Json.map("choices",List.of(Json.map("index",0,"delta",delta))))+"\n\n";
        }
        void reply(HttpExchange x,int status,Object object)throws IOException {
            byte[] b=Json.write(object).getBytes(StandardCharsets.UTF_8);
            x.getResponseHeaders().set("Content-Type","application/json");
            x.sendResponseHeaders(status,b.length);
            x.getResponseBody().write(b);
        }
        @Override public void close() {
            server.stop(0);
            executor.shutdownNow();
        }
    }
}
