package com.bydauto.yunfan.agent.spring;
import com.bydauto.yunfan.agent.AppServices;
import com.bydauto.yunfan.agent.common.*;
import jakarta.servlet.http.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.springframework.http.ResponseEntity;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
/** Optional Spring Boot 3.5 / Servlet adapter. Business logic remains shared with the tested JDK runtime. */
@SpringBootApplication public class SpringAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringAgentApplication.class,args);
    }
    @Bean(destroyMethod="close") AppServices services() {
        String file=System.getProperty("yunfan.config",System.getenv("YUNFAN_CONFIG"));
        Config config=new Config(file==null?null:Path.of(file));
        return new AppServices(config,new com.bydauto.yunfan.agent.modelconfig.ModelClientFactory(config,model->new SpringAiModelClient(model,config)));
    }
    @Bean AsyncTaskExecutor streamExecutor() {
        ThreadPoolTaskExecutor executor=new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(16);
        executor.setQueueCapacity(0);
        executor.setThreadNamePrefix("spring-sse-");
        executor.initialize();
        return executor;
    }
    @Bean WebMvcConfigurer webConfig(AppServices app) {
        return new WebMvcConfigurer() {
            @Override public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins(app.config.get("yunfan.http.cors-origins","http://localhost:8080,http://127.0.0.1:8080").split(",")).allowedMethods("GET","POST","PUT","PATCH","DELETE","OPTIONS").allowedHeaders("Content-Type","Authorization","Last-Event-ID");
            }
        } ;
    }
    @RestController static class Bridge {
        private final AppServices app;
        private final AsyncTaskExecutor executor;
        Bridge(AppServices app,AsyncTaskExecutor executor) {
            this.app=app;
            this.executor=executor;
        }
        @RequestMapping( {
            "/","/api/**","/openapi.json"
        } ) Object handle(HttpServletRequest request,HttpServletResponse response)throws Exception {
            byte[] body=request.getInputStream().readNBytes(4*1024*1024+1);
            if(body.length>4*1024*1024)return ResponseEntity.status(413).build();
            Map<String,List<String>> headers=new LinkedHashMap<>();
            Collections.list(request.getHeaderNames()).forEach(k->headers.put(k,Collections.list(request.getHeaders(k))));
            Map<String,String> query=new LinkedHashMap<>();
            request.getParameterMap().forEach((k,v)-> {
                if(v.length>0)query.put(k,v[0]);
            } );
            ApiRouter.Response result=app.router.handle(new ApiRouter.Request(request.getMethod(),request.getRequestURI(),headers,query,body));
            response.setStatus(result.status());
            result.headers().forEach(response::setHeader);
            response.setHeader("Cache-Control","no-store");
            response.setHeader("X-Content-Type-Options","nosniff");
            if(result.stream()==null)return ResponseEntity.status(result.status()).header("Content-Type",result.contentType()).body(result.body());
            response.setHeader("Content-Type",result.contentType());
            response.setHeader("X-Accel-Buffering","no");
            SseEmitter emitter=new SseEmitter(0L);
            AtomicBoolean closed=new AtomicBoolean();
            emitter.onCompletion(()->closed.set(true));
            emitter.onTimeout(()->closed.set(true));
            emitter.onError(e->closed.set(true));
            try {
                executor.execute(()->result.stream().accept(new StreamOutbound() {
                    public void send(Map<String,Object> event)throws Exception {
                        if(closed.get())throw new java.io.IOException("SSE closed");
                        emitter.send(SseEmitter.event().id(event.get("runId")+":"+event.get("seq")).name(event.get("type").toString()).data(Json.write(event)));
                    }
                    public void heartbeat()throws Exception {
                        if(closed.get())throw new java.io.IOException("SSE closed");
                        emitter.send(SseEmitter.event().comment("heartbeat"));
                    }
                    public void close() {
                        if(closed.compareAndSet(false,true))emitter.complete();
                    }
                } ));
            } catch(org.springframework.core.task.TaskRejectedException e) {
                emitter.complete();
                response.setStatus(429);
            }
            return emitter;
        }
    }
}
