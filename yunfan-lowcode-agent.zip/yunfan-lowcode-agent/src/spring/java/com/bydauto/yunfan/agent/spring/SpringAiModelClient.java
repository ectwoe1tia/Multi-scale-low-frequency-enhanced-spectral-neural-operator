package com.bydauto.yunfan.agent.spring;

import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.modelconfig.ModelClient;
import org.springframework.ai.chat.messages.*;
import org.springframework.ai.chat.model.*;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import java.net.URI;
import java.util.*;
import java.util.function.BiConsumer;

/** Spring AI 2.1 single model turn. No ToolCallingAdvisor is installed: Runtime owns tools. */
public final class SpringAiModelClient implements ModelClient {
    private final ChatModel client;private final Map<String,Object> model;private final Config config;
    public SpringAiModelClient(Map<String,Object> model,Config config){this(create(model,config),model,config);}
    public SpringAiModelClient(ChatModel client,Map<String,Object> model,Config config){this.client=client;this.model=Json.object(Json.copy(model));this.config=config;}
    private static ChatModel create(Map<String,Object> model,Config config){
        URI uri=URI.create(Json.required(model,"baseUrl").replaceAll("/+$",""));
        if(uri.getRawQuery()!=null||uri.getFragment()!=null||uri.getUserInfo()!=null)throw ApiException.bad("Model base URL must not contain query, fragment or user info");
        var options=OpenAiChatOptions.builder().baseUrl(uri.toString()).apiKey(config.secret(Json.str(model,"credentialRef",""))).model(Json.required(model,"modelName"))
            .timeout(java.time.Duration.ofSeconds(Json.integer(Json.child(model,"options"),"timeoutSeconds",60))).maxRetries(0).build();
        return OpenAiChatModel.builder().options(options).build();
    }
    @Override public Result complete(List<Map<String,Object>> input,List<Map<String,Object>> tools,boolean stream,BiConsumer<String,String> delta){
        new com.bydauto.yunfan.agent.filter.ModelContextFilter(config).validate(input,tools,model);
        var providerOptions=Json.child(model,"options");
        // Preserve existing provider-specific structured/reasoning option behavior on the same guarded runtime.
        if(providerOptions.containsKey("response_format")||providerOptions.containsKey("max_completion_tokens"))return new com.bydauto.yunfan.agent.modelconfig.OpenAiModelClient(model,config).complete(input,tools,stream,delta);
        List<Message> messages=new ArrayList<>();Map<String,String> names=new HashMap<>();
        for(var item:input){String text=Json.str(item,"content","");switch(Json.required(item,"role")){
            case "system"->messages.add(new SystemMessage(text));case "user"->messages.add(new UserMessage(text));
            case "assistant"->{List<AssistantMessage.ToolCall> calls=new ArrayList<>();for(Object raw:Json.list(item,"tool_calls")){var call=Json.object(raw);var f=Json.child(call,"function");String id=Json.required(call,"id"),name=Json.required(f,"name");names.put(id,name);calls.add(new AssistantMessage.ToolCall(id,"function",name,Json.required(f,"arguments")));}messages.add(AssistantMessage.builder().content(text).toolCalls(calls).build());}
            case "tool"->{String id=Json.required(item,"tool_call_id");if(!names.containsKey(id))throw ApiException.bad("Orphan tool response");messages.add(ToolResponseMessage.builder().responses(List.of(new ToolResponseMessage.ToolResponse(id,names.get(id),text))).build());}
            default->throw ApiException.bad("Unsupported model message role");
        }}
        List<ToolCallback> callbacks=tools.stream().map(spec->{var f=Json.child(spec,"function");return (ToolCallback)new ToolCallback(){
            public ToolDefinition getToolDefinition(){return ToolDefinition.builder().name(Json.required(f,"name")).description(Json.str(f,"description","")).inputSchema(Json.write(Json.child(f,"parameters"))).build();}
            public String call(String input){throw new IllegalStateException("Tools must execute through the guarded Agent runtime");}
        };}).toList();
        var opts=Json.child(model,"options");
        var options=OpenAiChatOptions.builder().model(Json.required(model,"modelName")).toolCallbacks(callbacks)
            .maxTokens(Json.integer(opts,"max_completion_tokens",Json.integer(opts,"max_tokens",config.integer("yunfan.context.output-reserve",2048))));
        if(opts.containsKey("temperature"))options.temperature(((Number)opts.get("temperature")).doubleValue());
        if(opts.containsKey("top_p"))options.topP(((Number)opts.get("top_p")).doubleValue());
        ChatResponse response=client.call(new Prompt(messages,options.build()));
        if(response==null||response.getResult()==null)throw new ApiException(502,"MODEL_INVALID_RESPONSE","Empty Spring AI response");
        AssistantMessage message=response.getResult().getOutput();String content=message.getText()==null?"":message.getText();
        List<Map<String,Object>> calls=message.getToolCalls().stream().map(t->Json.map("id",t.id(),"type","function","function",Json.map("name",t.name(),"arguments",t.arguments()))).toList();
        if(!content.isEmpty())delta.accept("message.delta",content);
        var usage=response.getMetadata().getUsage();
        return new Result(content,calls,usage==null?Json.map():Json.map("prompt_tokens",usage.getPromptTokens(),"completion_tokens",usage.getCompletionTokens(),"total_tokens",usage.getTotalTokens()));
    }
}
