package com.bydauto.yunfan.agent.data;

import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
import java.sql.*;
import java.util.*;

/** SQL syntax guard is defense in depth. Database grants/RLS are the security boundary. */
public final class ReadOnlySql {
    private final DataWorkspace data;private final Config config;
    public ReadOnlySql(DataWorkspace data,Config config){this.data=data;this.config=config;if(enabled()&&!config.bool("yunfan.sql.readonly-role-acknowledged",false))throw new IllegalStateException("SQL tool requires a database-enforced read-only role; acknowledge deployment configuration");}
    public boolean enabled(){return config.bool("yunfan.sql.enabled",false);}
    public static void validate(String sql){
        if(sql.length()>16000)throw ApiException.bad("SQL length limit");StringBuilder tokens=new StringBuilder();char quote=0;
        for(int i=0;i<sql.length();i++){char c=sql.charAt(i);if(quote!=0){if(c==quote){if(i+1<sql.length()&&sql.charAt(i+1)==quote){i++;continue;}quote=0;}else if(c=='\\')throw ApiException.bad("Backslash SQL escaping is not supported");tokens.append(' ');continue;}
            if(c=='\''||c=='"'||c=='`'){quote=c;tokens.append(' ');continue;}
            if(c==';'||c=='#'||c=='$'||c=='['||c==']'||c=='-'&&i+1<sql.length()&&sql.charAt(i+1)=='-'||c=='/'&&i+1<sql.length()&&sql.charAt(i+1)=='*')throw ApiException.bad("Only one SELECT without comments or vendor quoting is allowed");tokens.append(Character.toUpperCase(c));}
        if(quote!=0)throw ApiException.bad("Unclosed SQL literal");String clean=tokens.toString().strip();if(!clean.matches("(?s)^SELECT\\b.*"))throw ApiException.bad("Only SELECT is supported; WITH/CTEs and procedures are disabled");
        Set<String> denied=Set.of("INSERT","UPDATE","DELETE","MERGE","INTO","CREATE","DROP","ALTER","TRUNCATE","GRANT","REVOKE","COPY","CALL","EXEC","EXECUTE","ATTACH","DETACH","PRAGMA","FOR","LOCK","OUTFILE","DUMPFILE","LOAD_FILE","PG_SLEEP","SLEEP","BENCHMARK","DBLINK");
        for(String word:clean.split("[^A-Z0-9_]+"))if(denied.contains(word))throw ApiException.bad("SQL construct is not allowed: "+word);
    }
    public Object query(AuthContext actor,String run,Map<String,Object> args){
        if(!enabled())throw new ApiException(403,"SQL_DISABLED","SQL tool is disabled");String sql=Json.required(args,"sql");validate(sql);
        String url=config.get("yunfan.sql.jdbc-url","");if(url.isBlank())throw ApiException.bad("SQL datasource is not configured");
        try(Connection connection=DriverManager.getConnection(url,config.get("yunfan.sql.jdbc-user",""),config.secret(config.get("yunfan.sql.jdbc-password-ref","")))){
            connection.setReadOnly(true);connection.setAutoCommit(false);
            try(PreparedStatement statement=connection.prepareStatement(sql,ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY)){
                statement.setQueryTimeout(Math.min(120,Math.max(1,config.integer("yunfan.sql.timeout-seconds",30))));statement.setFetchSize(512);statement.setMaxRows(data.maxRows()+1);
                List<Object> params=Json.list(args,"parameters");if(params.size()>100)throw ApiException.bad("SQL parameter limit");for(int i=0;i<params.size();i++){Object v=params.get(i);if(v!=null&&!(v instanceof String||v instanceof Number||v instanceof Boolean))throw ApiException.bad("SQL parameters must be scalar");statement.setObject(i+1,v);}
                try(ResultSet result=statement.executeQuery()){
                    ResultSetMetaData meta=result.getMetaData();List<String> names=new ArrayList<>();for(int i=1;i<=meta.getColumnCount();i++){String name=meta.getColumnLabel(i);if(names.contains(name))throw ApiException.bad("SQL requires unique column aliases");names.add(name);}
                    Iterator<Map<String,Object>> rows=new Iterator<>(){Boolean next;public boolean hasNext(){try{if(next==null)next=result.next();return next;}catch(SQLException e){throw new ApiException(502,"SQL_READ_FAILED","Reading SQL rows failed");}}public Map<String,Object> next(){if(!hasNext())throw new NoSuchElementException();next=null;Map<String,Object> row=Json.map();try{for(int i=1;i<=names.size();i++){Object v=result.getObject(i);if(v instanceof Blob||v instanceof Clob||v instanceof byte[])throw ApiException.bad("Binary/LOB columns are not supported; select explicit scalar columns");row.put(names.get(i-1),v==null||v instanceof String||v instanceof Number||v instanceof Boolean?v:v.toString());}return row;}catch(SQLException e){throw new ApiException(502,"SQL_READ_FAILED","Reading SQL columns failed");}}};
                    return data.saveRows(actor,run,"sql:"+Util.hash(sql),rows,"COMPLETE",null);
                }
            }finally{connection.rollback();}
        }catch(SQLException e){throw new ApiException(502,"SQL_QUERY_FAILED","Read-only SQL query failed; check query, grants and timeout (database detail not sent to model)");}
    }
}
