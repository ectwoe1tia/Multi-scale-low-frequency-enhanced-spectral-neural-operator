package com.bydauto.yunfan.agent.auth;
import com.bydauto.yunfan.agent.common.*;
import java.util.Map;
public interface AuthorizationPolicy {
    void check(AuthContext auth,String action,Map<String,Object> resource);
    static AuthorizationPolicy defaultPolicy() {
        return (auth,action,resource)-> {
            if(!auth.allows(action))throw new ApiException(403,"FORBIDDEN","Permission required: "+action);
            if(resource!=null&&(!auth.tenantId().equals(resource.get("tenantId"))||resource.containsKey("userId")&&!auth.userId().equals(resource.get("userId"))&&!auth.allows("admin")))throw new ApiException(403,"FORBIDDEN","Resource is outside the current identity scope");
        } ;
    }
}
