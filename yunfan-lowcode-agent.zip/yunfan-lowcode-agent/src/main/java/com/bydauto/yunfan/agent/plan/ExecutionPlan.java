package com.bydauto.yunfan.agent.plan;

import com.bydauto.yunfan.agent.tooling.ToolDefinition;
import java.util.*;

public record ExecutionPlan(List<Node> nodes,Map<String,Object> result,String hash) {
    public record Node(String id,ToolDefinition tool,Set<String> dependencies,Map<String,Object> inputs,String contractHash) {}
}
