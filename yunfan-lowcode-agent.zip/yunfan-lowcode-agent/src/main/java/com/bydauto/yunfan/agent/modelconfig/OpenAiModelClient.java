package com.bydauto.yunfan.agent.modelconfig;
import com.bydauto.yunfan.agent.common.*;
import java.net.URI;
import java.net.http.HttpRequest;
import java.time.Duration;
import java.util.*;
import java.util.function.BiConsumer;
/** OpenAI-compatible Chat Completions adapter; no provider SDK or hidden automatic tool loop. */
public final class OpenAiModelClient implements ModelClient {
    private final Map<String,Object> model;
    private final Config config;
    public OpenAiModelClient(Map<String,Object> model,Config config) {
        this.model=Json.object(Json.copy(model));
        this.config=config;
    }
    public Result complete(List<Map<String,Object>> messages,List<Map<String,Object>> tools,boolean stream,BiConsumer<String,String> delta) {
        Map<String,Object> caps=Json.child(model,"capabilities"),options=Json.child(model,"options");
        boolean streaming=stream&&Json.bool(caps,"streaming",true);
        Map<String,Object> body=Json.map("model",model.get("modelName"),"messages",messages,"stream",streaming);
        for(String k:List.of("temperature","top_p","max_tokens","max_completion_tokens"))if(options.containsKey(k))body.put(k,options.get(k));
        if(!body.containsKey("max_tokens")&&!body.containsKey("max_completion_tokens"))body.put("max_tokens",config.integer("yunfan.context.output-reserve",2048));
        if(options.get("response_format") instanceof Map<?,?>)body.put("response_format",options.get("response_format"));
        if(!tools.isEmpty()) {
            if(!Json.bool(caps,"toolCalling",false))throw new ApiException(422,"MODEL_CAPABILITY_MISMATCH","Selected model does not support tools");
            body.put("tools",tools);
            body.put("tool_choice","auto");
        }
        if(streaming)body.put("stream_options",Json.map("include_usage",true));
        int seconds=Json.integer(options,"timeoutSeconds",60);
        String base=Json.required(model,"baseUrl").replaceAll("/+$","");
        HttpRequest.Builder builder=HttpRequest.newBuilder(URI.create(base+"/chat/completions")).timeout(Duration.ofSeconds(seconds)).header("Content-Type","application/json");
        String key=config.secret(Json.str(model,"credentialRef",""));
        if(!key.isEmpty())builder.header("Authorization","Bearer "+key);
        StringBuilder text=new StringBuilder();
        Map<Integer,Map<String,Object>> calls=new TreeMap<>();
        Map<String,Object> usage=Json.map();
        RemoteHttp.Reply reply=RemoteHttp.send(builder.POST(HttpRequest.BodyPublishers.ofString(Json.write(body))).build(),seconds,data-> {
            if(data.equals("[DONE]"))throw new RemoteHttp.StreamComplete();
            Map<String,Object> event=Json.object(Json.parse(data));
            if(event.containsKey("error"))throw new ApiException(502,"MODEL_ERROR","Provider returned a streaming error");
            if(event.get("usage") instanceof Map<?,?>)usage.putAll(Json.object(event.get("usage")));
            for(Object choice:Json.list(event,"choices")) {
                Map<String,Object> d=Json.child(Json.object(choice),"delta");
                Object content=d.get("content");
                if(content instanceof String s) {
                    text.append(s);
                    delta.accept("message.delta",s);
                }
                if(Json.bool(caps,"reasoning",false)&&d.get("reasoning_content") instanceof String s)delta.accept("reasoning.delta",s);
                for(Object item:Json.list(d,"tool_calls")) {
                    Map<String,Object> fragment=Json.object(item);
                    int index=Json.integer(fragment,"index",0);
                    Map<String,Object> target=calls.computeIfAbsent(index,n->Json.map("id","","type","function","function",Json.map("name","","arguments","")));
                    if(fragment.get("id")!=null)target.put("id",fragment.get("id"));
                    Map<String,Object> f=Json.child(fragment,"function"),tf=Json.child(target,"function");
                    for(String keyPart:List.of("name","arguments"))if(f.get(keyPart)!=null)tf.put(keyPart,tf.get(keyPart).toString()+f.get(keyPart));
                }
            }
        } );
        if(reply.status()<200||reply.status()>=300)throw new ApiException(reply.status()==429?429:502,"MODEL_UNAVAILABLE","Model HTTP "+reply.status()+"; check endpoint, model and credentials");
        if(!reply.text().isBlank()) {
            Map<String,Object> data=Json.object(Json.parse(reply.text()));
            List<Object> choices=Json.list(data,"choices");
            if(choices.isEmpty())throw new ApiException(502,"MODEL_INVALID_RESPONSE","Model response has no choices");
            Map<String,Object> message=Json.child(Json.object(choices.get(0)),"message");
            String content=Json.str(message,"content","");
            text.append(content);
            if(!content.isEmpty())delta.accept("message.delta",content);
            for(Object c:Json.list(message,"tool_calls"))calls.put(calls.size(),Json.object(c));
            usage.putAll(Json.child(data,"usage"));
        }
        for(var call:calls.values()) {
            Json.required(call,"id");
            Map<String,Object> f=Json.child(call,"function");
            Json.required(f,"name");
            Json.object(Json.parse(Json.str(f,"arguments","{}")));
        }
        if(text.isEmpty()&&calls.isEmpty())throw new ApiException(502,"MODEL_INVALID_RESPONSE","Empty or incomplete model response");
        return new Result(text.toString(),new ArrayList<>(calls.values()),usage);
    }
}
