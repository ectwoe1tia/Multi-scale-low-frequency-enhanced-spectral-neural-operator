package com.bydauto.yunfan.agent.chat;

import com.bydauto.yunfan.agent.common.*;
import java.util.*;

/** Rule-based dependency classification; never makes a second model call. */
public final class TaskContextPolicy {
    public enum Type { CLASSIFICATION, EXTRACTION, DATA_ACCESS, CONVERSATION, CROSS_FILE, LONG_RUNNING }
    public record Policy(Type type,boolean shortHistory) {}
    public Policy classify(Map<String,Object> request){
        var context=Json.child(request,"context");String declared=Json.str(context,"taskType","");Type type;
        if(!declared.isBlank())try{type=Type.valueOf(declared.toUpperCase(Locale.ROOT));}catch(IllegalArgumentException e){throw ApiException.bad("Unknown taskType");}
        else if(context.containsKey("executionPlan")||context.containsKey("dataPlan"))type=Type.DATA_ACCESS;
        else type=Type.CONVERSATION;
        return new Policy(type,Set.of(Type.CLASSIFICATION,Type.EXTRACTION,Type.DATA_ACCESS).contains(type));
    }
}
