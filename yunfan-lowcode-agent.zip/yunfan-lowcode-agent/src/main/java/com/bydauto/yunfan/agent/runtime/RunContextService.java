package com.bydauto.yunfan.agent.runtime;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.chat.ContextWindow;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.session.SessionStore;
import com.bydauto.yunfan.agent.tooling.ToolDefinition;
import java.time.Instant;
import java.util.*;

/** Durable inbox and atomic model-request boundary. No user text is promoted to a system instruction. */
public final class RunContextService {
    public record Prepared(String invocationId,String parentInvocationId,List<Map<String,Object>> messages,int removedGroups,List<String> appliedIds,int chars) {}
    private final DocumentStore store;
    private final AuthService auth;
    private final SessionStore sessions;
    public RunContextService(DocumentStore store,AuthService auth,SessionStore sessions) {this.store=store;this.auth=auth;this.sessions=sessions;}
    public Map<String,Object> enqueue(AuthContext actor,String runId,Map<String,Object> body) {
        for(String field:List.of("requestId","message","kind","expiresAt"))if(body.containsKey(field)&&!(body.get(field) instanceof String))throw ApiException.bad(field+" must be a string");
        String requestId=Json.required(body,"requestId"),text=Json.required(body,"message"),kind=Json.str(body,"kind","MESSAGE");
        int repeat=Json.integer(body,"repeat",1);
        if(requestId.length()>128||text.length()>8000||!Set.of("MESSAGE","REMINDER").contains(kind)||repeat<1||repeat>100||kind.equals("MESSAGE")&&repeat!=1)throw ApiException.bad("Invalid inbox request: message <=8000 chars, repeat 1..100 for reminders only");
        String expires=Json.str(body,"expiresAt","");
        if(!expires.isBlank())try {Instant.parse(expires);}catch(RuntimeException e){throw ApiException.bad("expiresAt must be an ISO instant");}
        String hash=Util.hash(Util.canonical(Json.map("message",text,"kind",kind,"repeat",repeat,"expiresAt",expires)));
        return store.transaction(tx->{
            Map<String,Object> run=tx.get("run",runId);
            if(run==null)throw ApiException.missing("run");
            auth.policy.check(actor,"chat",run);
            List<Object> inbox=Json.list(run,"inbox");
            for(Object item:inbox) {
                var prior=Json.object(item);
                if(requestId.equals(prior.get("requestId"))) {
                    if(!hash.equals(prior.get("hash")))throw ApiException.conflict("REQUEST_ID_CONFLICT","Inbox requestId was reused with different content");
                    return prior;
                }
            }
            if(AgentRunService.TERMINAL.contains(run.get("status")))throw ApiException.conflict("RUN_FINISHED","Run already ended; send a new chat request with the sessionId");
            if(!Json.str(Json.child(Json.child(run,"request"),"context"),"directTool","").isBlank())throw ApiException.conflict("DIRECT_RUN","Direct tool runs have no model boundary for appended messages");
            if(inbox.size()>=100)throw new ApiException(429,"INBOX_LIMIT","Run inbox limit reached");
            Map<String,Object> entry=Json.map("id",Util.id(),"requestId",requestId,"hash",hash,"kind",kind,"message",text,"repeat",repeat,"remaining",repeat,"status","QUEUED","expiresAt",expires,"createdAt",Util.now());
            inbox.add(entry);run.put("inbox",inbox);tx.put("run",runId,run);
            return entry;
        });
    }
    public List<Object> list(AuthContext actor,String runId) {return Json.list(auth.owned(store,"run",runId,actor,"chat"),"inbox");}
    public Map<String,Object> cancel(AuthContext actor,String runId,String entryId) {
        return store.transaction(tx->{
            var run=tx.get("run",runId);
            if(run==null)throw ApiException.missing("run");
            auth.policy.check(actor,"chat",run);
            for(Object item:Json.list(run,"inbox")) {
                var entry=Json.object(item);
                if(entryId.equals(entry.get("id"))) {
                    if(Set.of("QUEUED","ACTIVE").contains(entry.get("status"))) {entry.put("status","CANCELLED");entry.put("remaining",0);}
                    tx.put("run",runId,run);return entry;
                }
            }
            throw ApiException.missing("inbox entry");
        });
    }
    public static boolean hasQueued(Map<String,Object> run) {return Json.list(run,"inbox").stream().map(Json::object).anyMatch(e->"QUEUED".equals(e.get("status")));}
    public Prepared prepare(String id) {
        return store.transaction(tx->{
            var run=tx.get("run",id);
            if(!"RUNNING".equals(run.get("status")))throw ApiException.conflict("RUN_STOPPED","Run stopped before context preparation");
            if(Json.integer(run,"pendingIndex",0)<Json.list(run,"pendingCalls").size())throw ApiException.conflict("TOOLS_PENDING","Cannot insert context into an incomplete tool group");
            List<Map<String,Object>> persistent=new ArrayList<>(Json.list(run,"modelMessages").stream().map(Json::object).toList());
            List<Map<String,Object>> reminders=new ArrayList<>();
            List<String> ids=new ArrayList<>();
            String invocation=Util.id(),parent=Json.str(run,"lastInvocationId","");
            for(Object item:Json.list(run,"inbox")) {
                var entry=Json.object(item);
                if(!Set.of("QUEUED","ACTIVE").contains(entry.get("status")))continue;
                String expires=Json.str(entry,"expiresAt","");
                if(!expires.isBlank()&&!Instant.parse(expires).isAfter(Instant.now())){entry.put("status","EXPIRED");entry.put("remaining",0);continue;}
                String text=Json.required(entry,"message");
                boolean reminder="REMINDER".equals(entry.get("kind"));
                String content=reminder?"[用户追加提醒] "+text:text;
                if(reminder)reminders.add(Json.map("role","user","content",content));
                else persistent.add(Json.map("role","user","content",content));
                if("QUEUED".equals(entry.get("status"))) {
                    var saved=sessions.append(tx,Json.required(run,"sessionId"),id,"inbox:"+entry.get("id"),"user",reminder?content+" [仅限本运行，投递次数="+entry.get("repeat")+"]":content,null,null);
                    saved.put("contextKind",entry.get("kind"));
                    tx.put("message",saved.get("id").toString(),saved);
                }
                int left=Json.integer(entry,"remaining",1)-1;
                entry.put("remaining",left);entry.put("status",left==0?"APPLIED":"ACTIVE");entry.put("lastInvocationId",invocation);entry.put("appliedAt",Util.now());
                ids.add(entry.get("id").toString());
            }
            int cap=Json.integer(Json.child(Json.child(run,"model"),"options"),"contextChars",24000);
            int specs=Json.write(Json.list(run,"tools").stream().map(Json::object).map(ToolDefinition::from).map(ToolDefinition::modelSpec).toList()).length();
            ContextWindow.Result fitted=new ContextWindow().fit(persistent,cap-specs-Json.write(reminders).length()-2,id);
            run.put("modelMessages",fitted.messages());run.put("lastInvocationId",invocation);
            List<Map<String,Object>> messages=new ArrayList<>(fitted.messages());messages.addAll(reminders);
            int chars=Json.write(messages).length()+specs;
            if(chars>cap)throw new ApiException(413,"CONTEXT_LIMIT_EXCEEDED","Context including reminders exceeds the model character budget");
            tx.put("run",id,run);
            tx.put("model-call",invocation,Json.map("id",invocation,"runId",id,"tenantId",run.get("tenantId"),"userId",run.get("userId"),"parentInvocationId",parent,"round",Json.integer(run,"rounds",0)+1,"status","PREPARED","messageCount",messages.size(),"contextChars",chars,"contextHash",Util.hash(Json.write(messages)),"inboxIds",ids,"removedGroups",fitted.removedGroups(),"createdAt",Util.now()));
            return new Prepared(invocation,parent,messages,fitted.removedGroups(),ids,chars);
        });
    }
    public void completed(String invocation,Object usage) {
        store.transaction(tx->{var call=tx.get("model-call",invocation);call.put("status","COMPLETED");call.put("usage",usage);call.put("finishedAt",Util.now());tx.put("model-call",invocation,call);return null;});
    }
    public void failed(String invocation,String code) {
        store.transaction(tx->{var call=tx.get("model-call",invocation);if(call!=null&&"PREPARED".equals(call.get("status"))){call.put("status","FAILED");call.put("errorCode",code);call.put("finishedAt",Util.now());tx.put("model-call",invocation,call);}return null;});
    }
}
