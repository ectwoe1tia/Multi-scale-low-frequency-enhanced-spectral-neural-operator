package com.bydauto.yunfan.agent.skill;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.process.ProcessSupervisor;
import com.bydauto.yunfan.agent.tooling.ToolDefinition;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class SkillExecutionService {
    private final DocumentStore store;
    private final AuthService auth;
    private final ProcessSupervisor processes;
    public SkillExecutionService(DocumentStore store,AuthService auth,ProcessSupervisor processes) {this.store=store;this.auth=auth;this.processes=processes;}
    public static boolean handles(ToolDefinition tool) {return tool.serverId().startsWith("skill:");}
    public static String prefix(String id) {return "skill_"+Util.hash(id).substring(0,16)+"__";}
    public List<ToolDefinition> catalog(List<Map<String,Object>> skills) {
        List<ToolDefinition> out=new ArrayList<>();
        for(var skill:skills) {
            String id=Json.required(skill,"id"),version=skill.get("version").toString(),prefix=prefix(id);
            if(!Json.list(skill,"resourcePaths").isEmpty())out.add(new ToolDefinition(prefix+"read_resource","read_resource","skill:"+id,"Read a packaged resource for "+skill.get("name"),Json.map("type","object","properties",Json.map("path",Json.map("type","string"),"offset",Json.map("type","integer","minimum",0)),"required",List.of("path"),"additionalProperties",false),"READ",false,version));
            if("script".equals(Json.child(skill,"metadata").get("type")))out.add(new ToolDefinition(prefix+"run","run","skill:"+id,"Run the confirmed script for "+skill.get("name")+"; JSON arguments are provided on stdin. Subprocess is not an OS sandbox.",Json.map("type","object"),"HIGH_RISK",false,version));
        }
        return out;
    }
    private Map<String,Object> version(AuthContext actor,ToolDefinition tool) {
        String id=tool.serverId().substring("skill:".length());
        Map<String,Object> live=auth.owned(store,"skill",id,actor,"tool:"+tool.name());
        if(!Json.bool(live,"enabled",false))throw new ApiException(403,"SKILL_DISABLED","Skill disabled");
        Map<String,Object> snapshot=store.get("skill-version",id+":"+tool.version());
        if(snapshot==null)throw ApiException.missing("skill version");
        return snapshot;
    }
    public String risk(AuthContext actor,ToolDefinition tool) {
        Map<String,Object> skill=version(actor,tool);
        if(tool.originalName().equals("read_resource"))return "READ";
        if(!tool.originalName().equals("run")||!"script".equals(Json.child(skill,"metadata").get("type")))throw ApiException.bad("Invalid skill operation");
        processes.command(Json.required(Json.child(skill,"metadata"),"runtime"));
        return "HIGH_RISK";
    }
    public Object invoke(AuthContext actor,ToolDefinition tool,Map<String,Object> args) {
        risk(actor,tool);
        Map<String,Object> skill=version(actor,tool);
        String key=skill.get("id")+":"+tool.version();
        Map<String,Object> stored=store.get("skill-resources",key);
        if(stored==null)throw ApiException.missing("skill resources");
        Map<String,Object> resources=Json.child(stored,"resources");
        if(!Objects.equals(skill.get("resourceHash"),Util.hash(Util.canonical(resources))))throw new ApiException(409,"SKILL_PACKAGE_CHANGED","Skill package hash mismatch");
        if(tool.originalName().equals("read_resource")) {
            String path=Json.required(args,"path");SkillMdParser.validatePath(path);
            if(!resources.containsKey(path))throw ApiException.missing("skill resource");
            String content=new String(Base64.getDecoder().decode(resources.get(path).toString()),StandardCharsets.UTF_8);
            int offset=Json.integer(args,"offset",0);
            if(offset<0||offset>content.length())throw ApiException.bad("Invalid resource offset");
            int end=Math.min(content.length(),offset+12000);
            return Json.map("path",path,"skillVersion",tool.version(),"content",content.substring(offset,end),"nextOffset",end<content.length()?end:null,"totalChars",content.length());
        }
        Map<String,Object> meta=Json.child(skill,"metadata");
        Path directory=processes.workspace();
        try {
            for(var resource:resources.entrySet()) {
                SkillMdParser.validatePath(resource.getKey());
                Path file=directory.resolve(resource.getKey()).normalize();
                if(!file.startsWith(directory))throw ApiException.bad("Unsafe skill resource path");
                Files.createDirectories(file.getParent());
                Files.write(file,Base64.getDecoder().decode(resource.getValue().toString()),StandardOpenOption.CREATE_NEW);
            }
            Path entrypoint=directory.resolve(Json.required(meta,"entrypoint")).normalize();
            return processes.execute(Json.required(meta,"runtime"),List.of(entrypoint.toString()),directory,Json.write(args)+"\n",Json.integer(meta,"timeoutSeconds",30),262144);
        } catch(IOException e) {throw new ApiException(500,"SKILL_MATERIALIZE_FAILED","Could not materialize skill package");}
    }
}
