package com.bydauto.yunfan.agent.filter;

import java.util.*;

/** Extensions may add restrictions; the mandatory structural filter always runs. */
public final class RuntimeFilterChain {
    private final List<RuntimeFilter> extensions=ServiceLoader.load(RuntimeFilter.class).stream().map(ServiceLoader.Provider::get).toList();
    private final PersistenceProjectionFilter structural=new PersistenceProjectionFilter();
    public void before(RuntimeFilter.Invocation invocation){structural.validate(invocation.logicalArguments());for(var filter:extensions)filter.beforeInvocation(invocation);structural.validate(invocation.logicalArguments());}
    public void after(RuntimeFilter.Invocation invocation,Object result){structural.validate(result);for(var filter:extensions)filter.afterProjection(invocation,result);structural.validate(result);}
}
