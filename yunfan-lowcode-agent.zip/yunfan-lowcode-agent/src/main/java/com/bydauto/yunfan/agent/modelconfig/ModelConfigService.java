package com.bydauto.yunfan.agent.modelconfig;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import java.net.URI;
import java.util.*;
public final class ModelConfigService {
    private final DocumentStore store;
    private final AuthService auth;
    private final Config config;
    public ModelConfigService(DocumentStore store,AuthService auth,Config config) {
        this.store=store;
        this.auth=auth;
        this.config=config;
    }
    public Map<String,Object> save(AuthContext actor,String id,Map<String,Object> body) {
        auth.policy.check(actor,"admin",null);
        boolean create=id==null;
        return store.transaction(tx-> {
            Map<String,Object> prior=create?null:tx.get("model",id);
            if(!create&&prior==null)throw ApiException.missing("model");
            if(prior!=null)auth.policy.check(actor,"admin",prior);
            Map<String,Object> m=prior==null?Json.map():new LinkedHashMap<>(prior);
            String key=create?Util.id():id;
            for(String field:List.of("name","provider","baseUrl","modelName","credentialRef","enabled","capabilities","options","embeddingModelId"))if(body.containsKey(field))m.put(field,body.get(field));
            m.put("id",key);
            m.put("tenantId",actor.tenantId());
            m.put("version",prior==null?1:Json.integer(prior,"version",0)+1);
            m.putIfAbsent("enabled",true);
            m.putIfAbsent("provider","openai");
            m.putIfAbsent("capabilities",Json.map("streaming",true,"toolCalling",true));
            m.putIfAbsent("options",Json.map());
            Json.required(m,"name");
            Json.required(m,"modelName");
            String provider=Json.required(m,"provider");
            if(!Set.of("openai","mock").contains(provider))throw ApiException.bad("provider must be openai or mock");
            if(provider.equals("mock")&&!Set.of("local","test").contains(config.get("yunfan.profile","local")))throw ApiException.bad("mock models are limited to local/test");
            if(provider.equals("openai"))validateUrl(Json.required(m,"baseUrl"));
            String ref=Json.str(m,"credentialRef","");
            if(!ref.isBlank()&&!ref.matches("[A-Z][A-Z0-9_]{1,127}"))throw ApiException.bad("Invalid credentialRef");
            validateOptions(Json.child(m,"options"));
            tx.put("model",key,m);
            return m;
        } );
    }
    private void validateOptions(Map<String,Object> options) {
        for(String k:options.keySet())if(!Set.of("temperature","top_p","max_tokens","max_completion_tokens","contextChars","timeoutSeconds").contains(k))throw ApiException.bad("Unsupported model option: "+k);
        int chars=Json.integer(options,"contextChars",24000);
        if(chars<2000||chars>1000000)throw ApiException.bad("contextChars out of range");
        int timeout=Json.integer(options,"timeoutSeconds",60);
        if(timeout<1||timeout>300)throw ApiException.bad("timeoutSeconds out of range");
    }
    public void validateUrl(String text) {
        try {
            URI uri=URI.create(text);
            if(!Set.of("https","http").contains(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null||uri.getFragment()!=null||uri.getQuery()!=null)throw ApiException.bad("Invalid service URL");
            String allow=config.get("yunfan.remote.allowed-hosts","");
            if(!Set.of("local","test").contains(config.get("yunfan.profile","local"))&&(!uri.getScheme().equals("https")||Arrays.stream(allow.split(",")).noneMatch(h->h.strip().equalsIgnoreCase(uri.getHost()))))throw ApiException.bad("Remote host must be HTTPS and present in yunfan.remote.allowed-hosts");
        } catch(IllegalArgumentException e) {
            throw ApiException.bad("Invalid URL");
        }
    }
    public List<Map<String,Object>> list(AuthContext actor) {
        auth.policy.check(actor,"chat",null);
        return store.list("model").stream().filter(m->actor.tenantId().equals(m.get("tenantId"))).toList();
    }
    public Map<String,Object> get(AuthContext actor,String id) {
        return auth.owned(store,"model",id,actor,"chat");
    }
    public Map<String,Object> select(AuthContext actor,String id) {
        if(!id.isBlank()) {
            var m=get(actor,id);
            if(!Json.bool(m,"enabled",false))throw ApiException.bad("Model disabled");
            return m;
        }
        return list(actor).stream().filter(m->Json.bool(m,"enabled",false)&&!Json.bool(m,"embeddingOnly",false)).sorted(Comparator.comparing(m->!Json.bool(m,"default",false))).findFirst().orElseThrow(()->new ApiException(503,"MODEL_UNAVAILABLE","Configure an enabled model first"));
    }
    public Map<String,Object> action(AuthContext actor,String id,String action) {
        auth.policy.check(actor,"admin",null);
        return store.transaction(tx-> {
            Map<String,Object> m=tx.get("model",id);
            if(m==null)throw ApiException.missing("model");
            auth.policy.check(actor,"admin",m);
            if(action.equals("default")) {
                for(var row:tx.list("model"))if(actor.tenantId().equals(row.get("tenantId"))) {
                    row.put("default",false);
                    tx.put("model",row.get("id").toString(),row);
                }
                m.put("default",true);
            } else m.put("enabled",action.equals("enable"));
            m.put("version",Json.integer(m,"version",0)+1);
            tx.put("model",id,m);
            return m;
        } );
    }
    public void delete(AuthContext actor,String id) {
        get(actor,id);
        auth.policy.check(actor,"admin",null);
        store.transaction(tx-> {
            tx.delete("model",id);
            return null;
        } );
    }
}
