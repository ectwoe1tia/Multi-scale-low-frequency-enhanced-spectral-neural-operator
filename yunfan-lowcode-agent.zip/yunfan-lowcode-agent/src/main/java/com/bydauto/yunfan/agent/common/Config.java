package com.bydauto.yunfan.agent.common;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
public final class Config {
    private final Properties values=new Properties();
    public Config(Path external) {
        loadResource("application.properties");
        if(external!=null) {
            try(var r=Files.newBufferedReader(external,StandardCharsets.UTF_8)) {
                values.load(r);
            } catch(IOException e) {
                throw new IllegalStateException("Cannot read config: "+external,e);
            }
        }
    }
    private void loadResource(String name) {
        try(var in=Config.class.getClassLoader().getResourceAsStream(name)) {
            if(in!=null)values.load(new InputStreamReader(in,StandardCharsets.UTF_8));
        } catch(IOException e) {
            throw new IllegalStateException(e);
        }
    }
    public String get(String key,String fallback) {
        String sys=System.getProperty(key);
        if(sys!=null)return sys;
        String env=System.getenv(key.toUpperCase(Locale.ROOT).replace('.','_').replace('-','_'));
        return env!=null?env:values.getProperty(key,fallback);
    }
    public int integer(String key,int fallback) {
        return Integer.parseInt(get(key,""+fallback));
    }
    public boolean bool(String key,boolean fallback) {
        return Boolean.parseBoolean(get(key,""+fallback));
    }
    public String secret(String ref) {
        if(ref==null||ref.isBlank())return "";
        if(!ref.matches("[A-Z][A-Z0-9_]{1,127}"))throw ApiException.bad("credentialRef must be an environment variable name");
        String v=System.getenv(ref);
        if(v==null||v.isBlank())throw new ApiException(503,"CREDENTIAL_UNAVAILABLE","Missing credential environment variable: "+ref);
        return v;
    }
}
