package com.bydauto.yunfan.agent.auth;
import java.util.List;
import java.util.Map;
/** Implement and register using ServiceLoader for production SSO/JWT integration. */
public interface AuthContextResolver {
    AuthContext resolve(Map<String,List<String>> headers);
}
