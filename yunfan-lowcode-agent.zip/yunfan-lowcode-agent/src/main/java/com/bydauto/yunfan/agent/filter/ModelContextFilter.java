package com.bydauto.yunfan.agent.filter;

import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.modelconfig.ModelClient;
import java.util.*;

/** Last boundary before any model transport, including stream and injected SDK clients. */
public final class ModelContextFilter {
    private final Config config;private final PersistenceProjectionFilter structural=new PersistenceProjectionFilter();
    public ModelContextFilter(Config config){this.config=config;}
    public com.bydauto.yunfan.agent.context.ModelContext validate(List<Map<String,Object>> messages,List<Map<String,Object>> tools,Map<String,Object> model){
        for(var message:messages)structural.validate(message);
        for(var tool:tools)structural.validate(tool);
        int chars=Json.write(messages).length()+Json.write(tools).length();
        if(chars>Json.integer(Json.child(model,"options"),"contextChars",32000))throw new ApiException(413,"CONTEXT_LIMIT_EXCEEDED","Final model request exceeds character budget");
        int reserve=Math.max(config.integer("yunfan.context.output-reserve",2048),Math.max(Json.integer(Json.child(model,"options"),"max_tokens",0),Json.integer(Json.child(model,"options"),"max_completion_tokens",0)));
        int available=config.integer("yunfan.context.window-tokens",32768)-reserve-config.integer("yunfan.context.safety-tokens",512);
        if(com.bydauto.yunfan.agent.chat.ContextPlanner.tokens(messages)+com.bydauto.yunfan.agent.chat.ContextPlanner.tokens(tools)>available)throw new ApiException(413,"CONTEXT_LIMIT_EXCEEDED","Final model request exceeds input budget");
        return new com.bydauto.yunfan.agent.context.ModelContext(messages,tools,com.bydauto.yunfan.agent.chat.ContextPlanner.tokens(messages)+com.bydauto.yunfan.agent.chat.ContextPlanner.tokens(tools));
    }
    public ModelClient wrap(ModelClient client,Map<String,Object> model){return (messages,tools,stream,delta)->{
        var context=validate(messages,tools,model);var result=client.complete(context.messages(),context.tools(),stream,delta);
        structural.validate(result.message());return result;
    };}
}
