package com.bydauto.yunfan.agent.chat;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
public final class ChatHistoryLogic {
    public record Window(List<Map<String,Object>> messages,List<Map<String,Object>> dropped) {
    }
    /** Conservative character budget; preserve full assistant/tool groups and repeated user text. */
    public Window select(List<Map<String,Object>> history,int characterBudget) {
        List<List<Map<String,Object>>> groups=new ArrayList<>();
        List<Map<String,Object>> group=null;
        Set<String> seen=new HashSet<>();
        for(var m:normalize(history)) {
            if(!seen.add(Json.required(m,"id")))continue;
            String role=Json.required(m,"role");
            if(group==null||role.equals("user")) {
                group=new ArrayList<>();
                groups.add(group);
            }
            group.add(m);
        }
        List<Map<String,Object>> keep=new ArrayList<>(),drop=new ArrayList<>();
        int size=0;
        for(int i=groups.size()-1; i>=0; i--) {
            List<Map<String,Object>> g=groups.get(i);
            int n=Json.write(g).length();
            if(size+n<=characterBudget) {
                keep.addAll(0,g);
                size+=n;
            } else {
                for(int j=0; j<=i; j++)drop.addAll(groups.get(j));
                break;
            }
        }
        if(!history.isEmpty()&&keep.isEmpty())throw new ApiException(413,"CONTEXT_LIMIT_EXCEEDED","Current complete conversation group exceeds context budget");
        return new Window(keep,drop);
    }
    /** A cancelled/failed run may leave an incomplete tool group in raw history. Do not send invalid role sequences to a model. */
    public List<Map<String,Object>> normalize(List<Map<String,Object>> history) {
        List<Map<String,Object>> out=new ArrayList<>();
        for(int i=0; i<history.size(); i++) {
            Map<String,Object> message=history.get(i);
            if("REMINDER".equals(message.get("contextKind")))continue;
            String role=Json.required(message,"role");
            if(role.equals("tool"))continue;
            List<Object> calls=Json.list(message,"tool_calls");
            if(!role.equals("assistant")||calls.isEmpty()) {
                out.add(message);
                continue;
            }
            Set<String> required=new HashSet<>();
            for(Object call:calls)required.add(Json.required(Json.object(call),"id"));
            List<Map<String,Object>> results=new ArrayList<>();
            int j=i+1;
            while(j<history.size()&&"tool".equals(history.get(j).get("role")))results.add(history.get(j++));
            Set<String> actual=new HashSet<>();
            for(var result:results)actual.add(Json.required(result,"tool_call_id"));
            if(required.equals(actual)&&actual.size()==results.size()) {
                out.add(message);
                out.addAll(results);
            }else {
                Map<String,Object> note=new LinkedHashMap<>(message);
                note.remove("tool_calls");
                note.put("content",Json.str(message,"content","")+"\n[上次工具调用未完整结束；实际结果见运行记录，不得自动重放。]");
                if(!results.isEmpty())note.put("seq",results.get(results.size()-1).get("seq"));
                out.add(note);
            }
            i=j-1;
        }
        return out;
    }
    public Map<String,Object> modelMessage(Map<String,Object> source) {
        Map<String,Object> out=Json.map("role",source.get("role"),"content",source.get("content"));
        if(source.get("tool_calls")!=null)out.put("tool_calls",source.get("tool_calls"));
        if(source.get("tool_call_id")!=null)out.put("tool_call_id",source.get("tool_call_id"));
        return out;
    }
}
