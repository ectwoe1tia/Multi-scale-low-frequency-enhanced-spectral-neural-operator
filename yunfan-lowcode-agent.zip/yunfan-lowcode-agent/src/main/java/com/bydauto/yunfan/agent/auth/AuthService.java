package com.bydauto.yunfan.agent.auth;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
public final class AuthService {
    public final AuthorizationPolicy policy;
    public final DownstreamCredentialProvider credentials;
    private final AuthContextResolver resolver;
    public AuthService(Config config) {
        boolean development=Set.of("local","test").contains(config.get("yunfan.profile","local"));
        resolver=ServiceLoader.load(AuthContextResolver.class).findFirst().orElseGet(()-> {
            if(!development)throw new IllegalStateException("Production requires an AuthContextResolver ServiceLoader adapter");
            return headers->new AuthContext("local","developer",Set.of("*"),Util.id());
        } );
        policy=ServiceLoader.load(AuthorizationPolicy.class).findFirst().orElseGet(()-> {
            if(!development)throw new IllegalStateException("Production requires an AuthorizationPolicy adapter");
            return AuthorizationPolicy.defaultPolicy();
        } );
        credentials=ServiceLoader.load(DownstreamCredentialProvider.class).findFirst().orElse((auth,server,ref,refresh)->config.secret(ref));
    }
    public AuthContext resolve(Map<String,List<String>> headers) {
        AuthContext context=resolver.resolve(Collections.unmodifiableMap(headers));
        if(context==null||context.userId()==null||context.tenantId()==null)throw new ApiException(401,"UNAUTHENTICATED","Authenticated identity required");
        return context;
    }
    public Map<String,Object> owned(DocumentStore store,String kind,String id,AuthContext auth,String action) {
        Map<String,Object> value=store.get(kind,id);
        if(value==null)throw ApiException.missing(kind);
        policy.check(auth,action,value);
        return value;
    }
}
