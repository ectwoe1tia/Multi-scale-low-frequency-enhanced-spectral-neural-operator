package com.bydauto.yunfan.agent.chat;
import com.bydauto.yunfan.agent.common.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
public final class SseOutbound implements StreamOutbound {
    private final OutputStream stream;
    private final AtomicBoolean closed=new AtomicBoolean();
    public SseOutbound(OutputStream stream) {
        this.stream=stream;
    }
    public synchronized void send(Map<String,Object> event)throws IOException {
        if(closed.get())throw new IOException("SSE closed");
        String text="id: "+event.get("runId")+":"+event.get("seq")+"\nevent: "+event.get("type")+"\ndata: "+Json.write(event)+"\n\n";
        stream.write(text.getBytes(StandardCharsets.UTF_8));
        stream.flush();
    }
    public synchronized void heartbeat()throws IOException {
        if(!closed.get()) {
            stream.write(": heartbeat\n\n".getBytes(StandardCharsets.UTF_8));
            stream.flush();
        }
    }
    public synchronized void close() {
        if(closed.compareAndSet(false,true))try {
            stream.close();
        } catch(IOException ignored) {
        }
    }
}
