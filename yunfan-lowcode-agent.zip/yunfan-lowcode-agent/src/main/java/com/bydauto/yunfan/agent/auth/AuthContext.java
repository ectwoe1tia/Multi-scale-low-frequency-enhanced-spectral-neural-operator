package com.bydauto.yunfan.agent.auth;
import java.util.Set;
public record AuthContext(String tenantId,String userId,Set<String> permissions,String traceId) {
    public AuthContext {
        permissions=Set.copyOf(permissions);
    }
    public boolean allows(String action) {
        return permissions.contains("*")||permissions.contains(action);
    }
}
