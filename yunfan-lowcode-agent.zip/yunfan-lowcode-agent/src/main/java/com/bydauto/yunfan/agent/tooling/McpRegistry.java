package com.bydauto.yunfan.agent.tooling;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.modelconfig.ModelConfigService;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public final class McpRegistry {
    public record Catalog(List<ToolDefinition> tools,List<Map<String,Object>> failures,String version) {
    }
    private record Entry(Catalog catalog,Instant expires) {
    }
    private final DocumentStore store;
    private final AuthService auth;
    private final McpConnection connection;
    private final ModelConfigService models;
    private final Map<String,Entry> cache=new ConcurrentHashMap<>();
    public McpRegistry(DocumentStore store,AuthService auth,McpConnection connection,ModelConfigService models) {
        this.store=store;
        this.auth=auth;
        this.connection=connection;
        this.models=models;
    }
    public List<Map<String,Object>> servers(AuthContext actor) {
        auth.policy.check(actor,"admin",null);
        return store.list("mcp-server").stream().filter(s->actor.tenantId().equals(s.get("tenantId"))).toList();
    }
    public Map<String,Object> save(AuthContext actor,String id,Map<String,Object> body) {
        auth.policy.check(actor,"admin",null);
        Map<String,Object> result=store.transaction(tx-> {
            Map<String,Object> prior=id==null?null:tx.get("mcp-server",id);
            if(id!=null&&prior==null)throw ApiException.missing("MCP server");
            if(prior!=null)auth.policy.check(actor,"admin",prior);
            Map<String,Object> s=prior==null?Json.map():new LinkedHashMap<>(prior);
            for(String field:List.of("name","url","protocolVersion","credentialRef","enabled","timeoutSeconds","allowedTools","baseTools","toolPolicies","versionChecks"))if(body.containsKey(field))s.put(field,body.get(field));
            String key=id==null?Json.str(body,"serverId",Util.id().substring(0,8)):id;
            if(!key.matches("[A-Za-z0-9_-]{1,24}"))throw ApiException.bad("serverId must be 1-24 ASCII name characters");
            if(id==null&&tx.get("mcp-server",key)!=null)throw ApiException.conflict("SERVER_EXISTS","serverId already exists");
            models.validateUrl(Json.required(s,"url"));
            String protocol=Json.str(s,"protocolVersion","2025-11-25");
            if(!Set.of("2025-03-26","2025-06-18","2025-11-25").contains(protocol))throw ApiException.bad("Unsupported MCP protocolVersion");
            s.put("protocolVersion",protocol);
            int timeout=Json.integer(s,"timeoutSeconds",30);
            if(timeout<1||timeout>120)throw ApiException.bad("MCP timeoutSeconds must be between 1 and 120");
            for(var policy:Json.child(s,"toolPolicies").values())if(!Set.of("READ","WRITE","HIGH_RISK","DISABLED").contains(policy))throw ApiException.bad("Invalid tool risk policy");
            Json.strings(s.get("allowedTools"));
            Json.strings(s.get("baseTools"));
            s.put("id",key);
            s.put("tenantId",actor.tenantId());
            s.put("enabled",Json.bool(s,"enabled",true));
            s.put("version",prior==null?1:Json.integer(prior,"version",0)+1);
            tx.put("mcp-server",key,s);
            return s;
        } );
        cache.clear();
        return result;
    }
    public void delete(AuthContext actor,String id) {
        auth.owned(store,"mcp-server",id,actor,"admin");
        store.transaction(tx-> {
            tx.delete("mcp-server",id);
            return null;
        } );
        cache.clear();
        connection.invalidate();
    }
    private String key(AuthContext a) {
        return a.tenantId()+":"+a.userId()+":"+Util.hash(new TreeSet<>(a.permissions()).toString());
    }
    public Catalog catalog(AuthContext actor,boolean refresh) {
        String key=key(actor);
        Entry prior=cache.get(key);
        if(refresh)cache.clear();
        if(!refresh&&prior!=null&&prior.expires.isAfter(Instant.now()))return prior.catalog;
        List<ToolDefinition> tools=new ArrayList<>();
        List<Map<String,Object>> errors=new ArrayList<>();
        for(var s:store.list("mcp-server")) {
            if(!actor.tenantId().equals(s.get("tenantId"))||!Json.bool(s,"enabled",false))continue;
            try {
                Set<String> allowed=Json.strings(s.get("allowedTools")),base=Json.strings(s.get("baseTools"));
                Map<String,Object> policies=Json.child(s,"toolPolicies");
                String cursor="";
                Set<String> cursors=new HashSet<>();
                int count=0;
                do {
                    Map<String,Object> params=cursor.isBlank()?Json.map():Json.map("cursor",cursor);
                    Map<String,Object> response=connection.call(actor,s,"tools/list",params,true);
                    for(Object item:Json.list(response,"tools")) {
                        if(++count>1000)throw ApiException.bad("MCP catalog limit exceeded");
                        Map<String,Object> t=Json.object(item);
                        String name=Json.required(t,"name");
                        if(!allowed.isEmpty()&&!allowed.contains(name))continue;
                        String risk=Json.str(policies,name,"HIGH_RISK");
                        if(risk.equals("DISABLED"))continue;
                        String alias=s.get("id")+"__"+name.replaceAll("[^A-Za-z0-9_-]","_");
                        if(alias.length()>64)alias=alias.substring(0,47)+"_"+Util.hash(name).substring(0,16);
                        tools.add(new ToolDefinition(alias,name,s.get("id").toString(),Json.str(t,"description",name),Json.child(t,"inputSchema"),risk,base.contains(name),s.get("version").toString()));
                    }
                    cursor=Json.str(response,"nextCursor","");
                    if(!cursor.isBlank()&&!cursors.add(cursor))throw ApiException.bad("MCP repeated pagination cursor");
                }
                while(!cursor.isBlank());
            } catch(RuntimeException e) {
                errors.add(Json.map("serverId",s.get("id"),"code",e instanceof ApiException a?a.code:"MCP_DISCOVERY_FAILED","message","Tool discovery failed; previous snapshot retained if available"));
                if(prior!=null)prior.catalog.tools.stream().filter(t->t.serverId().equals(s.get("id"))).forEach(tools::add);
            }
        }
        Set<String> names=new HashSet<>();
        for(var t:tools)if(!names.add(t.name()))throw ApiException.conflict("TOOL_NAME_COLLISION","MCP tool alias collision");
        tools.sort(Comparator.comparing(ToolDefinition::name));
        String version=Util.hash(Json.write(tools.stream().map(ToolDefinition::snapshot).toList()));
        Catalog catalog=new Catalog(List.copyOf(tools),errors,version);
        if(cache.size()>256)cache.clear();
        cache.put(key,new Entry(catalog,Instant.now().plusSeconds(120)));
        return catalog;
    }
    public String currentRisk(AuthContext actor,ToolDefinition tool) {
        Map<String,Object> s=auth.owned(store,"mcp-server",tool.serverId(),actor,"tool:"+tool.name());
        if(!Json.bool(s,"enabled",false))throw new ApiException(403,"TOOL_DISABLED","MCP server disabled");
        Set<String> allowed=Json.strings(s.get("allowedTools"));
        if(!allowed.isEmpty()&&!allowed.contains(tool.originalName()))throw new ApiException(403,"TOOL_DISABLED","Tool was removed from allowed tools");
        String risk=Json.str(Json.child(s,"toolPolicies"),tool.originalName(),"HIGH_RISK");
        if(risk.equals("DISABLED"))throw new ApiException(403,"TOOL_DISABLED","Tool disabled");
        return risk;
    }
    public void verifyPreconditions(AuthContext actor,ToolDefinition tool,Map<String,Object> args) {
        Map<String,Object> server=auth.owned(store,"mcp-server",tool.serverId(),actor,"tool:"+tool.name());
        Map<String,Object> check=Json.child(Json.child(server,"versionChecks"),tool.originalName());
        if(check.isEmpty())return;
        String expectedKey=Json.str(check,"expectedArgument","expectedVersion"),resourceKey=Json.str(check,"resourceArgument","processId"),readTool=Json.required(check,"tool");
        Object expected=args.get(expectedKey),resource=args.get(resourceKey);
        if(expected==null||resource==null)throw new ApiException(422,"PRECONDITION_REQUIRED","Expected version and resource identifier are required");
        if(!"READ".equals(Json.str(Json.child(server,"toolPolicies"),readTool,"")))throw ApiException.bad("Version preflight tool must be configured READ");
        auth.policy.check(actor,"tool:"+server.get("id")+"__"+readTool,Json.map("tenantId",actor.tenantId()));
        Map<String,Object> response=connection.call(actor,server,"tools/call",Json.map("name",readTool,"arguments",Json.map(resourceKey,resource)),true);
        if(Json.bool(response,"isError",false))throw new ApiException(502,"PRECONDITION_CHECK_FAILED","Version preflight failed");
        Map<String,Object> data=Json.child(response,"structuredContent");
        if(data.isEmpty()) {
            List<Object> content=Json.list(response,"content");
            if(!content.isEmpty())data=Json.object(Json.parse(Json.required(Json.object(content.get(0)),"text")));
        }
        Object actual=data.get(Json.str(check,"versionField","version"));
        if(actual==null||!actual.toString().equals(expected.toString()))throw ApiException.conflict("RESOURCE_VERSION_CONFLICT","Target changed since the operation was proposed; obtain a new version and confirmation");
    }
    public Map<String,Object> invoke(AuthContext actor,ToolDefinition tool,Map<String,Object> args) {
        return invoke(actor,tool,args,"");
    }
    public Map<String,Object> invoke(AuthContext actor,ToolDefinition tool,Map<String,Object> args,String idempotencyKey) {
        currentRisk(actor,tool);
        Map<String,Object> server=auth.owned(store,"mcp-server",tool.serverId(),actor,"tool:"+tool.name());
        Map<String,Object> params=Json.map("name",tool.originalName(),"arguments",args);
        if(!idempotencyKey.isBlank())params.put("_meta",Json.map("yunfan/idempotencyKey",idempotencyKey));
        Map<String,Object> result=connection.call(actor,server,"tools/call",params,currentRisk(actor,tool).equals("READ"));
        if(Json.bool(result,"isError",false))throw new ApiException(502,"TOOL_REPORTED_ERROR","MCP tool reported an execution error");
        return result;
    }
}
