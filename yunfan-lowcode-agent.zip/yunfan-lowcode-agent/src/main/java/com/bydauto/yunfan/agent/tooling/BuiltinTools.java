package com.bydauto.yunfan.agent.tooling;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.governance.GovernanceService;
import java.time.*;
import java.util.*;
public final class BuiltinTools {
    private final DocumentStore store;
    private final GovernanceService governance;
    private final Config config;
    private final com.bydauto.yunfan.agent.data.DataTools data;
    public BuiltinTools(DocumentStore store,GovernanceService governance,Config config) {
        this(store,governance,config,null);
    }
    public BuiltinTools(DocumentStore store,GovernanceService governance,Config config,com.bydauto.yunfan.agent.data.DataTools data) {
        this.store=store;
        this.governance=governance;
        this.config=config;
        this.data=data;
    }
    private static Map<String,Object> schema(Map<String,Object> properties,String... required) {
        return Json.map("type","object","properties",properties,"required",List.of(required),"additionalProperties",false);
    }
    private static Map<String,Object> text() {
        return Json.map("type","string","minLength",1,"maxLength",20000);
    }
    public List<ToolDefinition> definitions() {
        List<ToolDefinition> all=new ArrayList<>(coreDefinitions());
        if(data!=null)all.addAll(data.definitions());
        return all;
    }
    private List<ToolDefinition> coreDefinitions() {
        return List.of( new ToolDefinition("system__time","","","获取当前 UTC 时间及指定时区时间。",schema(Json.map("timezone",text())),"READ",true,"1"), new ToolDefinition("system__calculator","","","计算 + - * / % 和括号组成的十进制算式。",schema(Json.map("expression",text()),"expression"),"READ",true,"1"), new ToolDefinition("system__ask_user","","","缺少必要信息时请求用户澄清；运行暂停等待输入。",schema(Json.map("question",text()),"question"),"READ",true,"1"), new ToolDefinition("governance__check","","","检查流程定义及可选实例，返回带证据的报告。process 是包含 id/version/nodes/edges 的标准快照；也可使用请求 context.processSnapshot。demo-purchase 仅在开发演示可用。",schema(Json.map("process",Json.map("type","object"),"processId",text(),"instances",Json.map("type","array","items",Json.map("type","object")))),"READ",true,"1"), new ToolDefinition("todo__create","","","创建本服务内的整改待办，写操作需用户确认。创建外部平台待办应使用其 MCP 工具。",schema(Json.map("title",text(),"description",text(),"reportId",text()),"title"),"WRITE",false,"1"), new ToolDefinition("todo__list","","","查看当前用户在本服务创建的待办。",schema(Json.map()),"READ",true,"1") );
    }
    public Object invoke(AuthContext actor,String runId,String executionId,String name,Map<String,Object> args,Map<String,Object> context) {
        if(name.startsWith("data__")&&data!=null)return data.invoke(actor,runId,name,args);
        return switch(name) {
            case "system__time"-> {
                ZoneId zone;
                try {
                    zone=ZoneId.of(Json.str(args,"timezone","Asia/Shanghai"));
                } catch(DateTimeException e) {
                    throw ApiException.bad("Invalid timezone");
                }
                Instant now=Instant.now();
                yield Json.map("utc",now.toString(),"local",now.atZone(zone).toString());
            }
            case "system__calculator"->Json.map("expression",args.get("expression"),"result",Calculator.evaluate(Json.required(args,"expression")));
            case "system__ask_user"->Json.map("question",Json.required(args,"question"));
            case "governance__check"-> {
                Map<String,Object> process=Json.child(args,"process");
                if(process.isEmpty())process=Json.child(context,"processSnapshot");
                if(process.isEmpty()&&Json.str(args,"processId","").equals("demo-purchase")&&Set.of("local","test").contains(config.get("yunfan.profile","local")))process=GovernanceService.demoProcess();
                if(process.isEmpty())throw ApiException.bad("Provide process snapshot or obtain it through a workflow MCP tool first");
                yield governance.check(actor,runId,process,Json.list(args,"instances"));
            }
            case "todo__create"-> {
                String id=Util.hash(executionId);
                Map<String,Object> todo=Json.map("id",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"runId",runId,"title",Json.required(args,"title"),"description",Json.str(args,"description",""),"reportId",Json.str(args,"reportId",""),"status","OPEN","createdAt",Util.now());
                store.transaction(tx-> {
                    if(tx.get("todo",id)==null)tx.put("todo",id,todo);
                    return null;
                } );
                yield store.get("todo",id);
            }
            case "todo__list"->store.list("todo").stream().filter(t->actor.tenantId().equals(t.get("tenantId"))&&actor.userId().equals(t.get("userId"))).toList();
            default->throw ApiException.missing("builtin tool");
        } ;
    }
}
