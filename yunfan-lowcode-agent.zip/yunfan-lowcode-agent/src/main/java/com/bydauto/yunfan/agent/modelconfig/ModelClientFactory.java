package com.bydauto.yunfan.agent.modelconfig;
import com.bydauto.yunfan.agent.common.*;
import java.util.Map;
public final class ModelClientFactory {
    private final Config config;
    public ModelClientFactory(Config config) {
        this.config=config;
    }
    public ModelClient create(Map<String,Object> model) {
        return Json.str(model,"provider","openai").equals("mock")?new MockModelClient():new OpenAiModelClient(model,config);
    }
}
