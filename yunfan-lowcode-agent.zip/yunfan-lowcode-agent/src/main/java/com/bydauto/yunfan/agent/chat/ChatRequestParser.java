package com.bydauto.yunfan.agent.chat;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
public final class ChatRequestParser {
    public Map<String,Object> parse(Map<String,Object> body) {
        String message=Json.required(body,"message");
        if(message.length()>60000)throw ApiException.bad("message is too long");
        if(body.containsKey("history")||body.containsKey("messages"))throw ApiException.bad("Use server-managed sessions; arbitrary historical roles are not accepted");
        String requestId=Json.str(body,"requestId",Util.id());
        if(requestId.length()>128||requestId.isBlank())throw ApiException.bad("Invalid requestId");
        Set<String> skills=Json.strings(body.get("skillIds"));
        if(body.get("skillId")!=null)skills.add(Json.required(body,"skillId"));
        Map<String,Object> format=Json.child(body,"responseFormat");
        if(!format.isEmpty()&&!Set.of("json_object","json_schema").contains(Json.required(format,"type")))throw ApiException.bad("responseFormat.type must be json_object or json_schema");
        return Json.map("message",message,"requestId",requestId,"sessionId",Json.str(body,"sessionId",""),"modelConfigId",Json.str(body,"modelConfigId",""),"skillIds",new ArrayList<>(skills),"context",Json.child(body,"context"),"responseFormat",format);
    }
}
