package com.bydauto.yunfan.agent.skill;
import com.bydauto.yunfan.agent.common.*;
import java.net.URI;
import java.net.http.HttpRequest;
import java.time.Duration;
import java.util.*;
public final class SkillEmbeddingService {
    private final Config config;
    public SkillEmbeddingService(Config config) {
        this.config=config;
    }
    public String version() {
        return config.get("yunfan.embedding.model","").isBlank()?"local-lexical-ngram-v1":config.get("yunfan.embedding.base-url","")+"/"+config.get("yunfan.embedding.model","");
    }
    public List<Object> embed(String text) {
        String model=config.get("yunfan.embedding.model","");
        if(model.isBlank())return lexical(text);
        String url=config.get("yunfan.embedding.base-url","").replaceAll("/+$","")+"/embeddings";
        HttpRequest.Builder b=HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(30)).header("Content-Type","application/json");
        String key=config.secret(config.get("yunfan.embedding.credential-ref",""));
        if(!key.isBlank())b.header("Authorization","Bearer "+key);
        RemoteHttp.Reply reply=RemoteHttp.send(b.POST(HttpRequest.BodyPublishers.ofString(Json.write(Json.map("model",model,"input",text)))).build(),30,s-> {
        } );
        if(reply.status()!=200)throw new ApiException(502,"EMBEDDING_UNAVAILABLE","Embedding HTTP "+reply.status());
        List<Object> rows=Json.list(Json.object(Json.parse(reply.text())),"data");
        if(rows.size()!=1)throw ApiException.bad("Invalid embedding result");
        List<Object> vector=Json.list(Json.object(rows.get(0)),"embedding");
        validate(vector);
        return vector;
    }
    private List<Object> lexical(String text) {
        double[] v=new double[256];
        String s=text.toLowerCase(Locale.ROOT).replaceAll("\\s+","");
        for(int i=0; i<s.length(); i++)for(int n=1; n<=2&&i+n<=s.length(); n++)v[Math.floorMod(s.substring(i,i+n).hashCode(),v.length)]++;
        List<Object> out=new ArrayList<>();
        for(double x:v)out.add(x);
        return out;
    }
    public static void validate(List<Object> v) {
        if(v.isEmpty()||v.size()>65536)throw ApiException.bad("Invalid embedding dimension");
        for(Object x:v)if(!(x instanceof Number n)||!Double.isFinite(n.doubleValue()))throw ApiException.bad("Invalid embedding value");
    }
    public static double cosine(List<Object> a,List<Object> b) {
        if(a.size()!=b.size()||a.isEmpty())return -1;
        double dot=0,aa=0,bb=0;
        for(int i=0; i<a.size(); i++) {
            double x=((Number)a.get(i)).doubleValue(),y=((Number)b.get(i)).doubleValue();
            dot+=x*y;
            aa+=x*x;
            bb+=y*y;
        }
        return aa==0||bb==0?0:dot/Math.sqrt(aa*bb);
    }
}
