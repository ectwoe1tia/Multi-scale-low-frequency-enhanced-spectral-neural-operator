package com.bydauto.yunfan.agent.modelconfig;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
import java.util.function.BiConsumer;
/** Explicit offline demonstration only. Real general tasks use OpenAiModelClient. */
public final class MockModelClient implements ModelClient {
    public Result complete(List<Map<String,Object>> messages,List<Map<String,Object>> tools,boolean stream,BiConsumer<String,String> delta) {
        String question=messages.stream().filter(m->"user".equals(m.get("role"))).reduce((a,b)->b).map(m->Json.str(m,"content","")).orElse("");
        Map<String,Object> last=messages.get(messages.size()-1);
        Set<String> available=new HashSet<>();
        for(var t:tools)available.add(Json.required(Json.child(t,"function"),"name"));
        if("tool".equals(last.get("role"))) {
            String result=Json.str(last,"content","");
            Object decoded=Json.parse(result);
            if((question.contains("待办")||question.contains("todo"))&&decoded instanceof Map<?,?> report&&report.containsKey("findings")&&report.containsKey("reportId")&&available.contains("todo__create"))return call("todo__create",Json.map("title","流程治理整改","description",result,"reportId",report.get("reportId")));
            String answer="[本地演示模型] 工具执行结果：\n"+result;
            delta.accept("message.delta",answer);
            return new Result(answer,List.of(),Json.map());
        }
        if((question.contains("检查")||question.contains("治理"))&&available.contains("governance__check"))return call("governance__check",Json.map("processId","demo-purchase"));
        if(question.contains("时间")&&available.contains("system__time"))return call("system__time",Json.map());
        if(question.startsWith("计算")&&available.contains("system__calculator"))return call("system__calculator",Json.map("expression",question.substring(2).strip()));
        if(question.startsWith("澄清")&&available.contains("system__ask_user"))return call("system__ask_user",Json.map("question","请提供具体的流程标识或任务约束。"));
        String answer="[本地演示模型] 已收到："+question+"。当前为离线演示，可尝试“计算 12*(3+4)”“现在时间”“检查采购流程并创建待办”。连接真实模型后可执行普通问答、分析及已接入的工具任务。";
        delta.accept("message.delta",answer);
        return new Result(answer,List.of(),Json.map());
    }
    private Result call(String name,Map<String,Object> args) {
        return new Result("",List.of(Json.map("id","call-"+Util.id(),"type","function","function",Json.map("name",name,"arguments",Json.write(args)))),Json.map());
    }
}
