package com.bydauto.yunfan.agent.audit;
import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
public final class AuditService {
    private final DocumentStore store;
    public AuditService(DocumentStore store) {
        this.store=store;
    }
    public void record(AuthContext auth,String action,String target,Object details) {
        String id=Util.id();
        store.put("audit",id,Json.map("id",id,"tenantId",auth.tenantId(),"userId",auth.userId(),"traceId",auth.traceId(),"action",action,"target",target,"details",Util.redact(details),"createdAt",Util.now()));
    }
}
