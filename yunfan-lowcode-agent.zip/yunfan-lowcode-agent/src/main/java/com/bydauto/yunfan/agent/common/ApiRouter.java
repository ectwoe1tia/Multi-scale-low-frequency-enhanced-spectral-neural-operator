package com.bydauto.yunfan.agent.common;
import com.bydauto.yunfan.agent.AppServices;
import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.runtime.AgentRunService;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Consumer;
/** Transport-neutral HTTP application. Native HTTP and optional Spring MVC use exactly these routes. */
public final class ApiRouter {
    public record Request(String method,String path,Map<String,List<String>> headers,Map<String,String> query,byte[] body) {
        public Map<String,Object> json() {
            return body.length==0?Json.map():Json.object(Json.parse(new String(body,StandardCharsets.UTF_8)));
        }
        public int number(String key,int fallback) {
            try {
                return Integer.parseInt(query.getOrDefault(key,""+fallback));
            } catch(NumberFormatException e) {
                throw ApiException.bad("Invalid query integer: "+key);
            }
        }
    }
    public record Response(int status,String contentType,byte[] body,Consumer<StreamOutbound> stream) {
    }
    private final AppServices s;
    public ApiRouter(AppServices services) {
        s=services;
    }
    public Response handle(Request request) {
        String traceId=Util.id();
        try {
            if(request.path().equals("/actuator/health"))return json(200,Json.map("status","UP","javaBaseline",17));
            if(request.path().equals("/")&&request.method().equals("GET"))return resource("static/index.html","text/html; charset=utf-8");
            if(request.path().equals("/openapi.json"))return resource("openapi.json","application/json; charset=utf-8");
            AuthContext actor=s.auth.resolve(request.headers());
            traceId=actor.traceId();
            return dispatch(request,actor);
        } catch(ApiException e) {
            return json(e.status,Json.map("code",e.code,"message",e.getMessage(),"data",null,"traceId",traceId));
        } catch(Exception e) {
            System.err.println("HTTP failure traceId="+traceId+" type="+e.getClass().getSimpleName());
            return json(500,Json.map("code","INTERNAL_ERROR","message","Internal server error","data",null,"traceId",traceId));
        }
    }
    private Response dispatch(Request r,AuthContext actor) {
        String path=r.path(),method=r.method();
        List<String> parts=Arrays.stream(path.split("/")).filter(x->!x.isBlank()).toList();
        if(path.equals("/api/me")&&method.equals("GET"))return ok(actor,Json.map("tenantId",actor.tenantId(),"userId",actor.userId(),"permissions",new TreeSet<>(actor.permissions()),"profile",s.config.get("yunfan.profile","local")));
        if(path.equals("/api/chat")||path.equals("/api/chat/stream")) {
            require(method,"POST");
            Map<String,Object> run=s.runs.start(actor,r.json());
            String id=run.get("id").toString();
            if(path.endsWith("/stream"))return streaming(actor,id,0);
            Map<String,Object> done=s.runs.await(actor,id,s.config.integer("yunfan.http.sync-wait-seconds",25)*1000L);
            return result(actor,done,isWaitingOrDone(done)?200:202);
        }
        if(parts.size()>=3&&parts.get(1).equals("runs")) {
            String id=parts.get(2);
            if(parts.size()==3) {
                require(method,"GET");
                return ok(actor,s.runs.get(actor,id));
            }
            if(parts.size()==4) {
                String action=parts.get(3);
                if(action.equals("events")) {
                    require(method,"GET");
                    return streaming(actor,id,r.number("afterSeq",0));
                }
                if(action.equals("cancel")) {
                    require(method,"POST");
                    return ok(actor,s.runs.cancel(actor,id));
                }
                if(action.equals("input")) {
                    require(method,"POST");
                    String text=Json.required(r.json(),"message");
                    if(text.length()>60000)throw ApiException.bad("Input too long");
                    return result(actor,s.runs.input(actor,id,text),202);
                }
            }
        }
        if(parts.size()==4&&parts.get(1).equals("confirmations")&&parts.get(3).equals("decision")) {
            require(method,"POST");
            var body=r.json();
            return result(actor,s.runs.resumeConfirmation(actor,parts.get(2),Json.required(body,"decision"),Json.integer(body,"version",1)),202);
        }
        if(path.equals("/api/sessions")) {
            if(method.equals("GET"))return page(actor,s.sessions.list(actor),r);
            require(method,"POST");
            return result(actor,s.sessions.create(actor,Json.str(r.json(),"title","新会话")),201);
        }
        if(parts.size()>=3&&parts.get(1).equals("sessions")) {
            String id=parts.get(2);
            if(parts.size()==4&&parts.get(3).equals("messages")) {
                require(method,"GET");
                return page(actor,s.sessions.messages(actor,id),r);
            }
            if(parts.size()==3) {
                if(method.equals("GET"))return ok(actor,s.sessions.get(actor,id));
                if(method.equals("PATCH")) {
                    var body=r.json();
                    Map<String,Object> session=s.sessions.get(actor,id);
                    if(body.containsKey("title"))session=s.sessions.rename(actor,id,Json.required(body,"title"));
                    if(body.containsKey("modelConfigId")) {
                        String modelId=Json.required(body,"modelConfigId");
                        s.models.get(actor,modelId);
                        session=s.sessions.configureModel(actor,id,modelId);
                    }
                    return ok(actor,session);
                }
                if(method.equals("DELETE")) {
                    s.sessions.delete(actor,id);
                    return ok(actor,Json.map("deleted",true));
                }
            }
        }
        if(path.equals("/api/skills/import")) {
            require(method,"POST");
            Map<String,Object> skill=s.skills.importZip(actor,r.body());
            s.audit.record(actor,"skill.imported",skill.get("id").toString(),Json.map());
            return result(actor,skill,201);
        }
        if(path.equals("/api/skills")) {
            if(method.equals("GET"))return page(actor,s.skills.list(actor),r);
            require(method,"POST");
            var skill=s.skills.save(actor,null,Json.required(r.json(),"markdown"));
            s.audit.record(actor,"skill.created",skill.get("id").toString(),Json.map());
            return result(actor,skill,201);
        }
        if(parts.size()>=3&&parts.get(1).equals("skills")) {
            String id=parts.get(2);
            if(parts.size()==3) {
                if(method.equals("GET"))return ok(actor,s.skills.get(actor,id));
                if(method.equals("PUT")) {
                    var updated=s.skills.save(actor,id,Json.required(r.json(),"markdown"));
                    s.audit.record(actor,"skill.updated",id,Json.map("version",updated.get("version")));
                    return ok(actor,updated);
                }
                if(method.equals("DELETE")) {
                    s.skills.delete(actor,id);
                    s.audit.record(actor,"skill.deleted",id,Json.map());
                    return ok(actor,Json.map("deleted",true));
                }
            }
            if(parts.size()==4&&Set.of("enable","disable","reindex").contains(parts.get(3))) {
                require(method,"POST");
                var updated=s.skills.action(actor,id,parts.get(3));
                s.audit.record(actor,"skill."+parts.get(3),id,Json.map());
                return ok(actor,updated);
            }
        }
        if(path.equals("/api/model-configs")) {
            if(method.equals("GET"))return page(actor,s.models.list(actor),r);
            require(method,"POST");
            var m=s.models.save(actor,null,r.json());
            s.audit.record(actor,"model.created",m.get("id").toString(),Json.map());
            return result(actor,m,201);
        }
        if(parts.size()>=3&&parts.get(1).equals("model-configs")) {
            String id=parts.get(2);
            if(parts.size()==3) {
                if(method.equals("GET"))return ok(actor,s.models.get(actor,id));
                if(method.equals("PUT")) {
                    var m=s.models.save(actor,id,r.json());
                    s.audit.record(actor,"model.updated",id,Json.map("version",m.get("version")));
                    return ok(actor,m);
                }
                if(method.equals("DELETE")) {
                    s.models.delete(actor,id);
                    s.audit.record(actor,"model.deleted",id,Json.map());
                    return ok(actor,Json.map("deleted",true));
                }
            }
            if(parts.size()==4) {
                String action=parts.get(3);
                require(method,"POST");
                if(action.equals("test")) {
                    s.auth.policy.check(actor,"admin",null);
                    var response=s.clients.create(s.models.get(actor,id)).complete(List.of(Json.map("role","user","content","Reply OK")),List.of(),false,(t,d)-> {
                    } );
                    return ok(actor,Json.map("connected",true,"response",response.content(),"usage",response.usage()));
                }
                if(Set.of("enable","disable","default").contains(action)) {
                    var m=s.models.action(actor,id,action);
                    s.audit.record(actor,"model."+action,id,Json.map());
                    return ok(actor,m);
                }
            }
        }
        if(path.equals("/api/admin/mcp/servers")) {
            s.auth.policy.check(actor,"admin",null);
            if(method.equals("GET"))return page(actor,s.mcp.servers(actor),r);
            require(method,"POST");
            var server=s.mcp.save(actor,null,r.json());
            s.audit.record(actor,"mcp.created",server.get("id").toString(),Json.map());
            return result(actor,server,201);
        }
        if(parts.size()==5&&parts.subList(0,4).equals(List.of("api","admin","mcp","servers"))) {
            String id=parts.get(4);
            if(method.equals("PUT")) {
                var server=s.mcp.save(actor,id,r.json());
                s.audit.record(actor,"mcp.updated",id,Json.map());
                return ok(actor,server);
            }
            if(method.equals("DELETE")) {
                s.mcp.delete(actor,id);
                s.audit.record(actor,"mcp.deleted",id,Json.map());
                return ok(actor,Json.map("deleted",true));
            }
        }
        if(path.equals("/api/admin/mcp/tools")||path.equals("/api/admin/mcp/reload")) {
            s.auth.policy.check(actor,"admin",null);
            boolean reload=path.endsWith("reload");
            require(method,reload?"POST":"GET");
            var catalog=s.mcp.catalog(actor,reload);
            if(reload)s.audit.record(actor,"mcp.reload","registry",Json.map("failures",catalog.failures()));
            return ok(actor,Json.map("tools",catalog.tools().stream().map(t->t.snapshot()).toList(),"failures",catalog.failures(),"version",catalog.version()));
        }
        if(path.equals("/api/governance/checks")) {
            require(method,"POST");
            var body=r.json();
            Map<String,Object> arguments=Json.map("instances",Json.list(body,"instances"));
            if(!Json.child(body,"process").isEmpty())arguments.put("process",Json.child(body,"process"));
            if(!Json.str(body,"processId","").isBlank())arguments.put("processId",Json.required(body,"processId"));
            Map<String,Object> context=Json.map("directTool","governance__check","toolArgs",arguments);
            var input=Json.map("message","执行结构化流程治理检查","requestId",Json.str(body,"requestId",Util.id()),"context",context,"modelConfigId",Json.str(body,"modelConfigId",""),"sessionId",Json.str(body,"sessionId",""));
            return result(actor,s.runs.start(actor,input),202);
        }
        if(path.equals("/api/governance/rules")) {
            if(method.equals("GET"))return page(actor,s.governance.rules(actor),r);
            require(method,"POST");
            var rule=s.governance.saveRule(actor,null,r.json());
            s.audit.record(actor,"rule.created",rule.get("id").toString(),Json.map());
            return result(actor,rule,201);
        }
        if(parts.size()==4&&parts.subList(0,3).equals(List.of("api","governance","rules"))) {
            String id=parts.get(3);
            if(method.equals("PUT")) {
                var rule=s.governance.saveRule(actor,id,r.json());
                s.audit.record(actor,"rule.updated",id,Json.map());
                return ok(actor,rule);
            }
            if(method.equals("DELETE")) {
                s.governance.deleteRule(actor,id);
                s.audit.record(actor,"rule.deleted",id,Json.map());
                return ok(actor,Json.map("deleted",true));
            }
        }
        if(path.equals("/api/governance/reports")) {
            require(method,"GET");
            return page(actor,ownedList(actor,"report","governance:read"),r);
        }
        if(parts.size()==4&&parts.subList(0,3).equals(List.of("api","governance","reports"))) {
            require(method,"GET");
            return ok(actor,s.auth.owned(s.store,"report",parts.get(3),actor,"governance:read"));
        }
        if(path.equals("/api/todos")) {
            if(method.equals("GET"))return page(actor,ownedList(actor,"todo","chat"),r);
            require(method,"POST");
            var body=r.json();
            Set<String> ids=new LinkedHashSet<>();
            for(var skill:s.skills.rawList(actor))if(Json.bool(skill,"enabled",false)&&Json.strings(Json.child(skill,"metadata").get("allowedTools")).contains("todo__create"))ids.add(skill.get("id").toString());
            Map<String,Object> arguments=Json.map("title",Json.required(body,"title"));
            for(String key:List.of("description","reportId"))if(!Json.str(body,key,"").isBlank())arguments.put(key,Json.required(body,key));
            return result(actor,s.runs.start(actor,Json.map("requestId",Json.str(body,"requestId",Util.id()),"message","创建整改待办 "+Json.required(body,"title"),"skillIds",new ArrayList<>(ids),"context",Json.map("directTool","todo__create","toolArgs",arguments))),202);
        }
        if(path.equals("/api/admin/audits")) {
            s.auth.policy.check(actor,"admin",null);
            require(method,"GET");
            return page(actor,ownedList(actor,"audit","admin"),r);
        }
        if(path.equals("/api/tool-executions")) {
            require(method,"GET");
            return page(actor,ownedList(actor,"tool-execution","chat").stream().map(row-> {
                Map<String,Object> view=new LinkedHashMap<>(row);
                view.remove("args");
                return view;
            } ).toList(),r);
        }
        if(parts.size()==3&&parts.get(1).equals("tool-results")) {
            require(method,"GET");
            return ok(actor,s.auth.owned(s.store,"tool-result",parts.get(2),actor,"chat"));
        }
        if(path.equals("/api/admin/metrics")) {
            require(method,"GET");
            s.auth.policy.check(actor,"admin",null);
            List<Map<String,Object>> runs=ownedList(actor,"run","admin"),executions=ownedList(actor,"tool-execution","admin");
            Map<String,Object> states=Json.map();
            for(var run:runs) {
                String key=Json.required(run,"status");
                states.put(key,((Number)states.getOrDefault(key,0)).longValue()+1);
            }
            long tokens=runs.stream().mapToLong(run->((Number)Json.child(run,"usage").getOrDefault("total_tokens",0)).longValue()).sum();
            return ok(actor,Json.map("runs",runs.size(),"runStates",states,"toolCalls",executions.size(),"toolFailures",executions.stream().filter(e->"FAILED".equals(e.get("status"))).count(),"unknownWrites",executions.stream().filter(e->"UNKNOWN".equals(e.get("status"))).count(),"totalTokens",tokens));
        }
        if(parts.size()==4&&parts.get(1).equals("tool-executions")&&parts.get(3).equals("reconcile")) {
            require(method,"POST");
            return ok(actor,s.tools.reconcile(actor,parts.get(2),r.json()));
        }
        throw ApiException.missing("route");
    }
    private List<Map<String,Object>> ownedList(AuthContext actor,String kind,String permission) {
        s.auth.policy.check(actor,permission,null);
        return s.store.list(kind).stream().filter(v->actor.tenantId().equals(v.get("tenantId"))&&(actor.allows("admin")||!v.containsKey("userId")||actor.userId().equals(v.get("userId")))).sorted(Comparator.comparing((Map<String,Object> m)->Json.str(m,"createdAt","")).reversed()).toList();
    }
    private Response streaming(AuthContext actor,String id,int after) {
        s.runs.get(actor,id);
        if(after<0)throw ApiException.bad("afterSeq cannot be negative");
        s.runs.events(actor,id,after);
        return new Response(200,"text/event-stream; charset=utf-8",null,out-> {
            int cursor=after;
            long lastHeartbeat=0;
            try {
                while(true) {
                    List<Map<String,Object>> events=s.runs.events(actor,id,cursor);
                    for(var event:events) {
                        out.send(event);
                        cursor=Json.integer(event,"seq",cursor);
                    }
                    Map<String,Object> run=s.runs.get(actor,id);
                    boolean finished=isWaitingOrDone(run);
                    if(finished&&cursor>=Json.integer(run,"eventSeq",0))break;
                    if(System.currentTimeMillis()-lastHeartbeat>10000) {
                        out.heartbeat();
                        lastHeartbeat=System.currentTimeMillis();
                    }
                    Thread.sleep(100);
                }
            } catch(InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch(Exception e) {
                /* Disconnect is a transport event; the run continues independently. */
            } finally {
                out.close();
            }
        } );
    }
    private boolean isWaitingOrDone(Map<String,Object> run) {
        String state=Json.required(run,"status");
        return AgentRunService.TERMINAL.contains(state)||state.startsWith("WAITING_");
    }
    private Response page(AuthContext actor,List<Map<String,Object>> list,Request r) {
        return ok(actor,Json.map("items",Util.page(list,r.number("offset",0),r.number("limit",50)),"total",list.size()));
    }
    private Response ok(AuthContext actor,Object data) {
        return result(actor,data,200);
    }
    private Response result(AuthContext actor,Object data,int status) {
        return json(status,Json.map("code","OK","message","success","data",data,"traceId",actor.traceId()));
    }
    private Response json(int status,Object value) {
        return new Response(status,"application/json; charset=utf-8",Json.write(value).getBytes(StandardCharsets.UTF_8),null);
    }
    private Response resource(String path,String type) {
        try(var in=ApiRouter.class.getClassLoader().getResourceAsStream(path)) {
            if(in==null)throw ApiException.missing("resource");
            return new Response(200,type,in.readAllBytes(),null);
        } catch(java.io.IOException e) {
            throw new IllegalStateException(e);
        }
    }
    private void require(String actual,String expected) {
        if(!actual.equals(expected))throw new ApiException(405,"METHOD_NOT_ALLOWED","Expected "+expected);
    }
}
