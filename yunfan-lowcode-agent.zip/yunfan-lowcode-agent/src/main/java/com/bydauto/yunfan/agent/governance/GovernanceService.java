package com.bydauto.yunfan.agent.governance;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import java.time.*;
import java.util.*;
public final class GovernanceService {
    public static final Set<String> HANDLERS=Set.of("NODE_REFERENCE","REACHABILITY","APPROVER","BRANCH","SLA","INSTANCE_SLA");
    private final DocumentStore store;
    private final AuthService auth;
    public GovernanceService(DocumentStore store,AuthService auth) {
        this.store=store;
        this.auth=auth;
    }
    public Map<String,Object> check(AuthContext actor,String runId,Map<String,Object> process,List<Object> instances) {
        auth.policy.check(actor,"governance:read",null);
        Json.required(process,"id");
        Json.required(process,"version");
        List<Object> nodes=Json.list(process,"nodes"),edges=Json.list(process,"edges");
        if(nodes.size()>5000||edges.size()>20000||instances.size()>10000)throw ApiException.bad("Process analysis size limit exceeded");
        Map<String,Map<String,Object>> index=new LinkedHashMap<>();
        Set<String> duplicates=new LinkedHashSet<>();
        for(Object n:nodes) {
            var node=Json.object(n);
            String id=Json.required(node,"id");
            if(index.put(id,node)!=null)duplicates.add(id);
        }
        List<Map<String,Object>> rules=rules(actor);
        List<Object> findings=new ArrayList<>();
        Map<String,Object> versions=Json.map();
        for(var rule:rules) {
            if(!Json.bool(rule,"enabled",false))continue;
            String scope=Json.str(rule,"processId","");
            if(!scope.isBlank()&&!scope.equals(process.get("id")))continue;
            String type=Json.required(rule,"handler");
            versions.put(rule.get("id").toString(),rule.get("version"));
            int before=findings.size();
            switch(type) {
                case "NODE_REFERENCE"-> {
                    for(String duplicate:duplicates)add(findings,rule,"FAIL",duplicate,"节点 ID 重复",Json.map("nodeId",duplicate));
                    for(Object item:edges) {
                        var e=Json.object(item);
                        String source=Json.required(e,"source"),target=Json.required(e,"target");
                        if(!index.containsKey(source)||!index.containsKey(target))add(findings,rule,"FAIL",Json.str(e,"id",source+"->"+target),"连线引用不存在的节点",e);
                    }
                    if(index.isEmpty())add(findings,rule,"FAIL","process","流程没有节点",Json.map());
                }
                case "REACHABILITY"-> {
                    Set<String> starts=new LinkedHashSet<>(),ends=new LinkedHashSet<>();
                    index.forEach((id,n)-> {
                        if("start".equals(n.get("type")))starts.add(id);
                        if("end".equals(n.get("type")))ends.add(id);
                    } );
                    if(starts.isEmpty()||ends.isEmpty())add(findings,rule,"FAIL","process","缺少开始或结束节点",Json.map("starts",starts,"ends",ends));
                    else {
                        Set<String> forward=walk(starts,edges,false),backward=walk(ends,edges,true);
                        for(String id:index.keySet()) {
                            if(!forward.contains(id))add(findings,rule,"FAIL",id,"节点无法从开始节点到达",Json.map("nodeId",id));
                            else if(!backward.contains(id))add(findings,rule,"FAIL",id,"节点不存在通向结束节点的路径",Json.map("nodeId",id));
                        }
                    }
                }
                case "APPROVER"-> {
                    boolean applicable=false;
                    for(var n:index.values())if("approval".equals(n.get("type"))) {
                        applicable=true;
                        Object approvers=n.get("approvers");
                        if(!(approvers instanceof List<?> l)||l.isEmpty())add(findings,rule,"FAIL",n.get("id").toString(),"审批节点缺少审批人配置",Json.map("nodeId",n.get("id")));
                        else add(findings,rule,"UNKNOWN",n.get("id").toString(),"审批人已配置；人员有效性需要组织目录工具验证",Json.map("approvers",approvers));
                    }
                    if(!applicable)add(findings,rule,"NOT_APPLICABLE","process","无审批节点",Json.map());
                }
                case "BRANCH"-> {
                    boolean applicable=false;
                    for(var n:index.values())if("gateway".equals(n.get("type"))) {
                        applicable=true;
                        List<Map<String,Object>> outgoing=edges.stream().map(Json::object).filter(e->n.get("id").equals(e.get("source"))).toList();
                        long defaults=outgoing.stream().filter(e->Json.bool(e,"default",false)).count();
                        if(outgoing.isEmpty()||defaults!=1)add(findings,rule,"FAIL",n.get("id").toString(),"条件网关应有且仅有一个默认分支",Json.map("outgoingCount",outgoing.size(),"defaultCount",defaults));
                        else add(findings,rule,"UNKNOWN",n.get("id").toString(),"默认分支有效；条件表达式互斥性与完备性未检查",Json.map("conditions",outgoing));
                    }
                    if(!applicable)add(findings,rule,"NOT_APPLICABLE","process","无条件网关",Json.map());
                }
                case "SLA"-> {
                    boolean applicable=false;
                    for(var n:index.values())if(n.containsKey("slaMinutes")) {
                        applicable=true;
                        try {
                            double minutes=Double.parseDouble(n.get("slaMinutes").toString());
                            if(!Double.isFinite(minutes)||minutes<=0)add(findings,rule,"FAIL",n.get("id").toString(),"SLA 必须是正数分钟",n);
                        } catch(Exception e) {
                            add(findings,rule,"FAIL",n.get("id").toString(),"SLA 分钟数格式错误",n);
                        }
                    }
                    if(!applicable)add(findings,rule,"NOT_APPLICABLE","process","未配置 SLA",Json.map());
                }
                case "INSTANCE_SLA"-> {
                    if(instances.isEmpty())add(findings,rule,"UNKNOWN","process","未提供实例数据，未检查运行超期",Json.map());
                    for(Object item:instances) {
                        Map<String,Object> instance=Json.object(item);
                        String id=Json.str(instance,"id","unknown");
                        Map<String,Object> node=index.get(Json.str(instance,"nodeId",""));
                        Object sla=instance.getOrDefault("slaMinutes",node==null?null:node.get("slaMinutes"));
                        if(sla==null) {
                            add(findings,rule,"UNKNOWN",id,"缺少实例或节点 SLA",instance);
                            continue;
                        }
                        if(instance.containsKey("businessCalendar")||process.containsKey("businessCalendar")) {
                            add(findings,rule,"UNKNOWN",id,"工作日历未接入，无法按自然时间替代业务 SLA",instance);
                            continue;
                        }
                        try {
                            Instant start=Instant.parse(Json.required(instance,"startedAt"));
                            Instant end=instance.get("endedAt")==null?Instant.now():Instant.parse(instance.get("endedAt").toString());
                            double limit=Double.parseDouble(sla.toString());
                            if(!Double.isFinite(limit)||limit<=0||end.isBefore(start))throw ApiException.bad("Invalid SLA or instance interval");
                            long elapsed=Duration.between(start,end).toMinutes();
                            add(findings,rule,elapsed>limit?"FAIL":"PASS",id,elapsed>limit?"实例节点超过 SLA":"实例节点未超过 SLA",Json.map("elapsedMinutes",elapsed,"slaMinutes",limit,"startedAt",start.toString(),"evaluatedAt",end.toString()));
                        } catch(RuntimeException e) {
                            add(findings,rule,"UNKNOWN",id,"时间或 SLA 格式无效，无法判定",instance);
                        }
                    }
                }
                default->throw ApiException.bad("Unknown rule handler");
            }
            if(findings.size()==before)add(findings,rule,"PASS","process","规则检查通过",Json.map());
        }
        String id=Util.id();
        Map<String,Object> counts=Json.map();
        for(String status:List.of("PASS","FAIL","UNKNOWN","NOT_APPLICABLE"))counts.put(status,findings.stream().map(Json::object).filter(f->status.equals(f.get("status"))).count());
        Map<String,Object> report=Json.map("id",id,"reportId",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"runId",runId,"processId",process.get("id"),"processVersion",process.get("version"),"snapshotHash",Util.hash(Util.canonical(process)),"ruleVersions",versions,"findings",findings,"coverage",counts,"suggestions",List.of("按 FAIL 项逐项整改；UNKNOWN 项补充数据或接入专用校验工具后复核。"),"suggestionSource","DETERMINISTIC_TEMPLATE","createdAt",Util.now());
        store.put("report",id,report);
        store.put("process-snapshot",id,Json.map("id",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"process",process));
        return report;
    }
    private Set<String> walk(Set<String> roots,List<Object> edges,boolean reverse) {
        Map<String,List<String>> adjacency=new HashMap<>();
        for(Object e:edges) {
            Map<String,Object> edge=Json.object(e);
            String a=Json.required(edge,reverse?"target":"source"),b=Json.required(edge,reverse?"source":"target");
            adjacency.computeIfAbsent(a,k->new ArrayList<>()).add(b);
        }
        Set<String> seen=new HashSet<>(roots);
        ArrayDeque<String> queue=new ArrayDeque<>(roots);
        while(!queue.isEmpty())for(String next:adjacency.getOrDefault(queue.remove(),List.of()))if(seen.add(next))queue.add(next);
        return seen;
    }
    private void add(List<Object> out,Map<String,Object> rule,String status,String target,String message,Object evidence) {
        out.add(Json.map("ruleId",rule.get("id"),"ruleVersion",rule.get("version"),"handler",rule.get("handler"),"status",status,"severity",status.equals("FAIL")?Json.str(rule,"severity","WARNING"):"INFO","target",target,"message",message,"evidence",evidence));
    }
    public List<Map<String,Object>> rules(AuthContext actor) {
        auth.policy.check(actor,"governance:read",null);
        return store.list("rule").stream().filter(r->actor.tenantId().equals(r.get("tenantId"))).toList();
    }
    public Map<String,Object> saveRule(AuthContext actor,String id,Map<String,Object> body) {
        auth.policy.check(actor,"admin",null);
        return store.transaction(tx-> {
            Map<String,Object> previous=id==null?null:tx.get("rule",id);
            if(id!=null&&previous==null)throw ApiException.missing("rule");
            if(previous!=null)auth.policy.check(actor,"admin",previous);
            Map<String,Object> r=previous==null?Json.map():new LinkedHashMap<>(previous);
            for(String key:List.of("name","handler","severity","enabled","processId"))if(body.containsKey(key))r.put(key,body.get(key));
            if(!HANDLERS.contains(Json.required(r,"handler")))throw ApiException.bad("Unsupported rule handler");
            if(!Set.of("INFO","WARNING","ERROR","CRITICAL").contains(Json.str(r,"severity","WARNING")))throw ApiException.bad("Invalid severity");
            String key=id==null?Util.id():id;
            r.put("id",key);
            r.put("tenantId",actor.tenantId());
            r.put("version",previous==null?1:Json.integer(previous,"version",0)+1);
            r.putIfAbsent("enabled",true);
            tx.put("rule",key,r);
            tx.put("rule-version",key+":"+r.get("version"),r);
            return r;
        } );
    }
    public void deleteRule(AuthContext actor,String id) {
        auth.owned(store,"rule",id,actor,"admin");
        store.transaction(tx-> {
            tx.delete("rule",id);
            return null;
        } );
    }
    public static Map<String,Object> demoProcess() {
        return Json.map("id","demo-purchase","version","1","nodes",List.of(Json.map("id","start","type","start"),Json.map("id","approve","type","approval","approvers",List.of(),"slaMinutes",60),Json.map("id","end","type","end")),"edges",List.of(Json.map("source","start","target","approve"),Json.map("source","approve","target","end")));
    }
}
