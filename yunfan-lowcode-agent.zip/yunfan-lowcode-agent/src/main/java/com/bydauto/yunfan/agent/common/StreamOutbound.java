package com.bydauto.yunfan.agent.common;
import java.util.Map;
public interface StreamOutbound extends AutoCloseable {
    void send(Map<String,Object> event) throws Exception;
    default void heartbeat() throws Exception {
    }
    @Override void close();
}
