package com.bydauto.yunfan.agent.memory;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.filter.PersistenceProjectionFilter;
import java.time.Instant;
import java.util.*;

/** Explicit, owner-scoped facts only. Tool transcripts are never automatically memorized. */
public final class MemoryRepository {
    private final DocumentStore store;private final AuthorizationPolicy policy;
    public MemoryRepository(DocumentStore store,AuthorizationPolicy policy){this.store=store;this.policy=policy;}
    public Map<String,Object> put(AuthContext actor,Map<String,Object> input){
        policy.check(actor,"memory:write",null);String text=Json.required(input,"fact"),source=Json.required(input,"source");
        if(text.length()>1000||source.length()>256||Json.write(input).length()>1800)throw ApiException.bad("Memory fact/source limit");
        new PersistenceProjectionFilter().validate(input);
        if(text.matches("(?s).*(dataRef|artifact_id|storage_uri|/api/data/artifacts/).*"))throw ApiException.bad("Transient artifacts are not persistent facts");
        String expires=Json.str(input,"expiresAt","");if(!expires.isBlank())try{if(!Instant.parse(expires).isAfter(Instant.now()))throw ApiException.bad("Memory expiry must be in the future");}catch(java.time.format.DateTimeParseException e){throw ApiException.bad("Invalid memory expiry");}
        String id=Util.id();var value=Json.map("id",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"fact",text,"source",source,"expiresAt",expires,"createdAt",Util.now());
        return store.transaction(tx->{if(tx.list("persistent-memory").stream().filter(m->activeOwned(actor,m)).count()>=200)throw new ApiException(429,"MEMORY_LIMIT","Memory quota reached");tx.put("persistent-memory",id,value);return value;});
    }
    private boolean activeOwned(AuthContext actor,Map<String,Object> m){return actor.tenantId().equals(m.get("tenantId"))&&actor.userId().equals(m.get("userId"))&&(Json.str(m,"expiresAt","").isBlank()||Instant.parse(Json.required(m,"expiresAt")).isAfter(Instant.now()));}
    public List<Map<String,Object>> list(AuthContext actor){policy.check(actor,"memory:read",null);return store.list("persistent-memory").stream().filter(m->activeOwned(actor,m)).toList();}
    public void delete(AuthContext actor,String id){policy.check(actor,"memory:write",null);var m=store.get("persistent-memory",id);if(m==null||!actor.tenantId().equals(m.get("tenantId"))||!actor.userId().equals(m.get("userId")))throw ApiException.missing("memory");store.transaction(tx->{tx.delete("persistent-memory",id);return null;});}
    public List<Map<String,Object>> retrieve(AuthContext actor,String query){
        if(!actor.allows("memory:read"))return List.of();Set<String> terms=new HashSet<>(Arrays.asList(query.toLowerCase(Locale.ROOT).split("[^\\p{L}\\p{N}_]+")));
        return list(actor).stream().filter(m->terms.stream().anyMatch(t->t.length()>1&&Json.required(m,"fact").toLowerCase(Locale.ROOT).contains(t))).limit(3).map(m->Json.map("memoryId",m.get("id"),"fact",m.get("fact"),"source",m.get("source"))).toList();
    }
}
