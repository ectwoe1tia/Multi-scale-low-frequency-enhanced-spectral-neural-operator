package com.bydauto.yunfan.agent.common;
import java.util.*;
import java.util.function.Function;
/** Transactions are atomic across document kinds. Returned data is detached. */
public interface DocumentStore extends AutoCloseable {
    interface Tx {
        Map<String,Object> get(String kind,String id);
        List<Map<String,Object>> list(String kind);
        void put(String kind,String id,Map<String,Object> value);
        void delete(String kind,String id);
    }
    <T> T transaction(Function<Tx,T> action);
    default Map<String,Object> get(String kind,String id) {
        return transaction(t->t.get(kind,id));
    }
    default List<Map<String,Object>> list(String kind) {
        return transaction(t->t.list(kind));
    }
    default void put(String kind,String id,Map<String,Object> value) {
        transaction(t-> {
            t.put(kind,id,value);
            return null;
        } );
    }
    default void close() {
    }
}
