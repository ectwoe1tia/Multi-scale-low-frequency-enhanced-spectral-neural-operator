package com.bydauto.yunfan.agent.data;

import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;

/** Single choke point shared by native execution, legacy history migration and Spring AI callbacks. */
public final class ToolResultPolicy {
    private final DataWorkspace data;
    public ToolResultPolicy(DataWorkspace data){this.data=data;}
    public Object modelView(AuthContext actor,String run,String tool,Object result,boolean trustedDataTool){
        String json=Json.write(result);
        // Only the built-in data tools may return bounded, explicitly requested pages/aggregates.
        if(trustedDataTool&&json.length()<=3000)return result;
        if(!trustedDataTool&&claimsReference(result))return data.capture(actor,run,tool,result);
        if(json.length()>3000||DataWorkspace.table(result)!=null)return data.capture(actor,run,tool,result);
        return result;
    }
    public static boolean claimsReference(Object result){return result instanceof Map<?,?> m&&(m.containsKey("dataRef")||m.containsKey("artifactId")||m.get("kind") instanceof String kind&&Set.of("dataset_ref","artifact_ref","aggregate_result","data_page","program_ref").contains(kind));}
    public List<Map<String,Object>> sanitizeHistory(AuthContext actor,String run,List<Map<String,Object>> source){
        List<Map<String,Object>> safe=new ArrayList<>();
        for(var original:source){var m=new LinkedHashMap<>(original);
            if("tool".equals(m.get("role"))){String content=Json.str(m,"content","");Object value;try{value=Json.parse(content);}catch(ApiException e){value=content;}
                if(value instanceof Map<?,?> old&&Boolean.TRUE.equals(old.get("truncated"))&&old.get("resultRef") instanceof String ref){Object full=data.legacy(actor,ref);if(full!=null)value=full;}
                if(value instanceof Map<?,?> p&&"program_ref".equals(p.get("kind"))&&Json.write(value).length()<=16000&&data.trustedProgramProjection(actor,value)){
                    new com.bydauto.yunfan.agent.filter.PersistenceProjectionFilter().validate(value);m.put("content",Json.write(value));safe.add(m);continue;
                }
                // A persisted small reference is safe; verify identity again when it is actually read.
                boolean bounded=value instanceof Map<?,?> v&&("dataset_ref".equals(v.get("kind"))||"artifact_ref".equals(v.get("kind"))||"data_page".equals(v.get("kind"))||"aggregate_result".equals(v.get("kind")));
                m.put("content",Json.write(modelView(actor,run,"history",value,bounded)));
            }safe.add(m);
        }return safe;
    }
}
