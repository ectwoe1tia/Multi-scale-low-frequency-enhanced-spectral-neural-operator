package com.bydauto.yunfan.agent.process;

import com.bydauto.yunfan.agent.common.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/** Operational isolation, NOT an OS security sandbox. Commands come only from deployment configuration. */
public final class ProcessSupervisor implements AutoCloseable {
    private final Config config;
    private final Semaphore slots;
    private final Set<Child> children=ConcurrentHashMap.newKeySet();
    private volatile boolean closed;
    public ProcessSupervisor(Config config) {
        this.config=config;
        slots=new Semaphore(Math.max(1,config.integer("yunfan.process.max-children",8)));
    }
    public List<String> command(String profile) {
        if(!profile.matches("[a-zA-Z0-9_-]{1,48}"))throw ApiException.bad("Invalid process command profile");
        if(!config.bool("yunfan.process.enabled",false))throw new ApiException(403,"PROCESS_DISABLED","Local process execution is disabled by deployment policy");
        String raw=config.get("yunfan.process.command."+profile,"");
        if(raw.isBlank())throw new ApiException(403,"PROCESS_COMMAND_DENIED","Command profile is not configured: "+profile);
        List<String> command=new ArrayList<>();
        for(Object item:Json.array(Json.parse(raw))) {
            if(!(item instanceof String s)||s.indexOf('\0')>=0)throw ApiException.bad("Command profile must be a JSON string array");
            command.add(s);
        }
        if(command.isEmpty()||!Path.of(command.get(0)).isAbsolute()||!Files.isRegularFile(Path.of(command.get(0))))throw ApiException.bad("Command executable must be an existing absolute path");
        return command;
    }
    public Path workspace() {
        try {
            Path root=Path.of(config.get("yunfan.process.directory","data/processes")).toAbsolutePath().normalize();
            Files.createDirectories(root);
            return Files.createTempDirectory(root.toRealPath(),"job-").toRealPath();
        } catch(IOException e) {throw new ApiException(500,"PROCESS_WORKSPACE_FAILED","Cannot create process workspace");}
    }
    public Child start(String profile,List<String> suffix,Map<String,Object> envRefs,Path directory) {
        List<String> argv=command(profile);
        argv.addAll(suffix);
        if(closed||!slots.tryAcquire())throw new ApiException(503,"PROCESS_CAPACITY","Process capacity exhausted or supervisor closed");
        Child started=null;
        try {
            ProcessBuilder builder=new ProcessBuilder(argv).directory(directory.toFile());
            Map<String,String> env=builder.environment();
            env.clear();
            // Windows loader needs these; no credentials, PATH, JVM options, or shell startup environment are inherited.
            for(String key:List.of("SystemRoot","WINDIR"))if(System.getenv(key)!=null)env.put(key,System.getenv(key));
            env.put("HOME",directory.toString());
            env.put("USERPROFILE",directory.toString());
            env.put("TMP",directory.toString());
            env.put("TEMP",directory.toString());
            env.put("TMPDIR",directory.toString());
            env.put("LANG","C.UTF-8");
            for(var entry:envRefs.entrySet()) {
                if(!entry.getKey().matches("[A-Z][A-Z0-9_]{0,127}")||!(entry.getValue() instanceof String))throw ApiException.bad("envRefs must map environment names to credential references");
                env.put(entry.getKey(),config.secret(entry.getValue().toString()));
            }
            Child child=new Child(builder.start());
            started=child;
            children.add(child);
            if(closed) {child.close();throw new ApiException(503,"PROCESS_CLOSED","Process supervisor is closed");}
            return child;
        } catch(IOException e) {if(started!=null)started.close();else slots.release();throw new ApiException(502,"PROCESS_START_FAILED","Could not start configured process");}
        catch(RuntimeException e) {if(started!=null)started.close();else slots.release();throw e;}
    }
    public Map<String,Object> execute(String profile,List<String> suffix,Path directory,String input,int seconds,int maxBytes) {
        try(Child child=start(profile,suffix,Map.of(),directory)) {
            ExecutorService io=Executors.newFixedThreadPool(3,r->{Thread t=new Thread(r,"skill-process-io");t.setDaemon(true);return t;});
            try {
                long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(seconds);
                Future<String> stdout=io.submit(()->readBounded(child.process.getInputStream(),maxBytes));
                Future<String> stderr=io.submit(()->readBounded(child.process.getErrorStream(),maxBytes));
                Future<?> writer=io.submit(()->{try(var out=child.process.getOutputStream()){out.write(input.getBytes(StandardCharsets.UTF_8));}return null;});
                while(child.process.isAlive()) {
                    if(stdout.isDone())stdout.get();
                    if(stderr.isDone())stderr.get();
                    if(System.nanoTime()>deadline)throw new TimeoutException();
                    child.rememberDescendants();
                    child.process.waitFor(25,TimeUnit.MILLISECONDS);
                }
                writer.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS);
                String out=stdout.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS);
                String err=stderr.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS);
                if(child.process.exitValue()!=0)throw new ApiException(502,"SCRIPT_EXIT_NONZERO","Script exited with code "+child.process.exitValue()+"; effects may have occurred");
                return Json.map("exitCode",0,"stdout",out,"stderr",err,"isolation","SUBPROCESS_NOT_SANDBOX");
            } catch(TimeoutException e) {throw new ApiException(504,"PROCESS_TIMEOUT","Process exceeded its deadline; effects may have occurred");}
            catch(InterruptedException e) {Thread.currentThread().interrupt();throw new ApiException(409,"PROCESS_CANCELLED","Process interrupted; effects may have occurred");}
            catch(ExecutionException e) {if(e.getCause() instanceof ApiException a)throw a;throw new ApiException(502,"PROCESS_IO_FAILED","Process IO failed; effects may have occurred");}
            finally {child.close();io.shutdownNow();}
        }
    }
    private static String readBounded(InputStream stream,int limit)throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buffer=new byte[4096];
        for(int n;(n=stream.read(buffer))!=-1;) {
            if(out.size()+n>limit)throw new ApiException(413,"PROCESS_OUTPUT_LIMIT","Process output limit exceeded; effects may have occurred");
            out.write(buffer,0,n);
        }
        return out.toString(StandardCharsets.UTF_8);
    }
    public final class Child implements AutoCloseable {
        public final Process process;
        private final Set<ProcessHandle> descendants=ConcurrentHashMap.newKeySet();
        private boolean ended;
        private Child(Process p) {process=p;}
        public void rememberDescendants() {process.descendants().forEach(descendants::add);}
        public synchronized void close() {
            if(ended)return;
            ended=true;
            rememberDescendants();
            descendants.forEach(p->{if(p.isAlive())p.destroyForcibly();});
            if(process.isAlive())process.destroyForcibly();
            try {process.getOutputStream().close();process.getInputStream().close();process.getErrorStream().close();}catch(IOException ignored) {}
            children.remove(this);
            slots.release();
        }
    }
    public void close() {closed=true;new ArrayList<>(children).forEach(Child::close);}
}
