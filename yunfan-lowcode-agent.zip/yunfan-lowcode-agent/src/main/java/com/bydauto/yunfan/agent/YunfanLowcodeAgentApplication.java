package com.bydauto.yunfan.agent;
import com.bydauto.yunfan.agent.common.*;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
public final class YunfanLowcodeAgentApplication {
    public static void main(String[] args)throws Exception {
        String file=System.getProperty("yunfan.config",System.getenv("YUNFAN_CONFIG"));
        Config config=new Config(file==null?null:Path.of(file));
        if(config.get("yunfan.http.adapter","jdk").equals("spring")) {
            Class<?> spring=Class.forName("com.bydauto.yunfan.agent.spring.SpringAgentApplication");
            spring.getMethod("main",String[].class).invoke(null,(Object)args);
            return;
        }
        AppServices services=new AppServices(config);
        JdkHttpServer server=new JdkHttpServer(services);
        Runtime.getRuntime().addShutdownHook(new Thread(()-> {
            server.close();
            services.close();
        } ,"agent-shutdown"));
        System.out.println("Yunfan Agent ready: http://"+config.get("yunfan.http.host","127.0.0.1")+":"+server.port()+" profile="+config.get("yunfan.profile","local")+" (JDK 17 compatible)");
        new CountDownLatch(1).await();
    }
}
