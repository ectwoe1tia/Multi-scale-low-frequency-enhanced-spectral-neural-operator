package com.bydauto.yunfan.agent.common;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
public final class Util {
    private Util() {
    }
    public static String id() {
        return UUID.randomUUID().toString();
    }
    public static String now() {
        return Instant.now().toString();
    }
    public static String hash(String text) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8)));
        } catch(Exception e) {
            throw new IllegalStateException(e);
        }
    }
    public static String canonical(Object value) {
        if(value instanceof Number number)return new java.math.BigDecimal(number.toString()).stripTrailingZeros().toString();
        if(value instanceof Map<?,?> m) {
            Map<String,Object> out=new TreeMap<>();
            m.forEach((k,v)->out.put(k.toString(),Json.parse(canonical(v))));
            return Json.write(out);
        }
        if(value instanceof List<?> l)return Json.write(l.stream().map(v->Json.parse(canonical(v))).toList());
        return Json.write(value);
    }
    public static Object redact(Object v) {
        if(v instanceof Map<?,?> m) {
            Map<String,Object> out=Json.map();
            m.forEach((k,x)->out.put(k.toString(),k.toString().matches("(?i).*(authorization|password|secret|token|api.?key|credential).*" )?"[REDACTED]":redact(x)));
            return out;
        }
        if(v instanceof List<?> l)return l.stream().map(Util::redact).toList();
        return v;
    }
    public static List<Map<String,Object>> page(List<Map<String,Object>> rows,int offset,int limit) {
        if(offset<0||limit<1||limit>200)throw ApiException.bad("offset >= 0 and 1 <= limit <= 200 required");
        int start=Math.min(offset,rows.size());
        return rows.subList(start,Math.min(rows.size(),start+limit));
    }
}
