package com.bydauto.yunfan.agent.tooling;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.audit.AuditService;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.skill.SkillExecutionService;
import java.time.Instant;
import java.util.*;
import java.util.function.BiConsumer;
public final class ToolExecutionService {
    public record Outcome(String status,Object result,String confirmationId,String executionId) {
    }
    private final DocumentStore store;
    private final AuthService auth;
    private final McpRegistry registry;
    private final BuiltinTools builtins;
    private final AuditService audit;
    private final SkillExecutionService scripts;
    private final JsonSchemaValidator validator=new JsonSchemaValidator();
    public ToolExecutionService(DocumentStore store,AuthService auth,McpRegistry registry,BuiltinTools builtins,AuditService audit) {
        this(store,auth,registry,builtins,audit,null);
    }
    public ToolExecutionService(DocumentStore store,AuthService auth,McpRegistry registry,BuiltinTools builtins,AuditService audit,SkillExecutionService scripts) {
        this.store=store;
        this.auth=auth;
        this.registry=registry;
        this.builtins=builtins;
        this.audit=audit;
        this.scripts=scripts;
    }
    public List<ToolDefinition> catalog(AuthContext actor,List<Map<String,Object>> skills) {
        List<ToolDefinition> all=new ArrayList<>(builtins.definitions());
        all.addAll(registry.catalog(actor,false).tools());
        if(scripts!=null)all.addAll(scripts.catalog(skills));
        Set<String> allow=new HashSet<>();
        for(var skill:skills)allow.addAll(Json.strings(Json.child(skill,"metadata").get("allowedTools")));
        return all.stream().filter(t->t.base()||allow.contains(t.name())||SkillExecutionService.handles(t)).filter(t->actor.allows("tool:"+t.name())).sorted(Comparator.comparing(ToolDefinition::name)).toList();
    }
    public Outcome execute(AuthContext actor,String runId,String toolCallId,ToolDefinition tool,Map<String,Object> args,Map<String,Object> context,boolean skillConfirmation,BiConsumer<String,Object> event) {
        auth.policy.check(actor,"tool:"+tool.name(),Json.map("tenantId",actor.tenantId()));
        validator.validate(args,tool.schema());
        String risk=SkillExecutionService.handles(tool)?scripts.risk(actor,tool):tool.serverId().isBlank()?tool.risk():registry.currentRisk(actor,tool);
        String id=Util.hash(runId+":"+toolCallId),argsHash=Util.hash(Util.canonical(args));
        Map<String,Object> execution=store.transaction(tx-> {
            Map<String,Object> existing=tx.get("tool-execution",id);
            if(existing!=null) {
                if(!argsHash.equals(existing.get("argsHash")))throw ApiException.conflict("TOOL_ARGUMENT_CHANGED","Tool call arguments changed");
                return existing;
            }
            Map<String,Object> e=Json.map("id",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"runId",runId,"toolCallId",toolCallId,"tool",tool.snapshot(),"args",args,"argsHash",argsHash,"idempotencyKey",id,"risk",risk,"status","PREPARED","createdAt",Util.now());
            tx.put("tool-execution",id,e);
            return e;
        } );
        String status=Json.required(execution,"status");
        if(status.equals("SUCCEEDED"))return new Outcome("SUCCEEDED",execution.get("result"),null,id);
        if(status.equals("REJECTED"))return new Outcome("REJECTED",Json.map("error","Operation rejected by user"),null,id);
        if(status.equals("UNKNOWN")||status.equals("EXECUTING"))return new Outcome("UNKNOWN",null,null,id);
        boolean confirmation=!risk.equals("READ")||skillConfirmation;
        if(confirmation&&!Json.bool(execution,"approved",false)) {
            Map<String,Object> pending=store.transaction(tx-> {
                Map<String,Object> current=tx.get("tool-execution",id);
                String prior=Json.str(current,"confirmationId","");
                if(!prior.isBlank())return tx.get("confirmation",prior);
                String cid=Util.id();
                Map<String,Object> record=Json.map("id",cid,"tenantId",actor.tenantId(),"userId",actor.userId(),"runId",runId,"executionId",id,"toolName",tool.name(),"args",args,"argsHash",argsHash,"targetVersion",args.getOrDefault("expectedVersion",args.get("processVersion")),"status","PENDING","version",1,"expiresAt",Instant.now().plusSeconds(1800).toString(),"createdAt",Util.now());
                record.put("risk",risk);
                record.put("toolVersion",tool.version());
                record.put("warning",SkillExecutionService.handles(tool)?"脚本将在独立子进程中运行，可能读写当前系统账户可访问的文件或访问网络；子进程隔离不等于系统沙箱。":"操作可能修改业务数据；超时或取消不能撤销已经发生的写入。");
                tx.put("confirmation",cid,record);
                current.put("confirmationId",cid);
                current.put("status","WAITING_CONFIRMATION");
                tx.put("tool-execution",id,current);
                return record;
            } );
            if("EXPIRED".equals(pending.get("status")))throw new ApiException(409,"CONFIRMATION_EXPIRED","Confirmation expired");
            event.accept("confirmation.required",pending);
            return new Outcome("WAITING_CONFIRMATION",null,pending.get("id").toString(),id);
        }
        if(confirmation) {
            String cid=Json.required(execution,"confirmationId");
            Map<String,Object> approved=store.get("confirmation",cid);
            if(approved==null||!"APPROVED".equals(approved.get("status"))||Instant.parse(approved.get("expiresAt").toString()).isBefore(Instant.now()))throw new ApiException(409,"CONFIRMATION_EXPIRED","Confirmation expired before execution");
            if(!argsHash.equals(approved.get("argsHash")))throw ApiException.conflict("TOOL_ARGUMENT_CHANGED","Confirmed arguments changed");
        }
        if(!tool.serverId().isBlank()&&!SkillExecutionService.handles(tool)&&!risk.equals("READ"))registry.verifyPreconditions(actor,tool,args);
        // Claim before network IO; recovery treats an interrupted write as UNKNOWN, never blindly replays it.
        store.transaction(tx-> {
            Map<String,Object> run=tx.get("run",runId);
            if(run==null||!"RUNNING".equals(run.get("status")))throw ApiException.conflict("RUN_STOPPED","Run was stopped before tool execution");
            Map<String,Object> current=tx.get("tool-execution",id);
            if("EXECUTING".equals(current.get("status")))throw ApiException.conflict("TOOL_ALREADY_EXECUTING","Tool is already running");
            current.put("status","EXECUTING");
            current.put("startedAt",Util.now());
            tx.put("tool-execution",id,current);
            return null;
        } );
        event.accept("tool.started",Json.map("executionId",id,"toolCallId",toolCallId,"tool",tool.name(),"risk",risk));
        audit.record(actor,"tool.started",id,Json.map("runId",runId,"tool",tool.name(),"argsHash",argsHash,"risk",risk));
        try {
            Object result=SkillExecutionService.handles(tool)?scripts.invoke(actor,tool,args):tool.serverId().isBlank()?builtins.invoke(actor,runId,id,tool.name(),args,context):registry.invoke(actor,tool,args,id);
            String full=Json.write(result);
            Object modelResult=result;
            if(full.length()>20000) {
                store.put("tool-result",id,Json.map("id",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"result",result));
                modelResult=Json.map("truncated",true,"resultRef",id,"preview",full.substring(0,18000));
            }
            Object saved=modelResult;
            store.transaction(tx-> {
                Map<String,Object> e=tx.get("tool-execution",id);
                e.put("status","SUCCEEDED");
                e.put("result",saved);
                e.put("finishedAt",Util.now());
                tx.put("tool-execution",id,e);
                Map<String,Object> parent=tx.get("run",runId);
                if(parent!=null&&"RECONCILIATION_REQUIRED".equals(parent.get("status"))) {
                    boolean unresolved=tx.list("tool-execution").stream().anyMatch(other->runId.equals(other.get("runId"))&&Set.of("UNKNOWN","EXECUTING").contains(other.get("status")));
                    parent.put("reconciliationStatus",unresolved?"PENDING":"RESOLVED");
                    tx.put("run",runId,parent);
                }
                return null;
            } );
            event.accept("tool.completed",Json.map("executionId",id,"toolCallId",toolCallId,"tool",tool.name(),"result",modelResult));
            if(result instanceof Map<?,?> m&&m.containsKey("reportId"))event.accept("report.created",Json.map("reportId",m.get("reportId")));
            audit.record(actor,"tool.succeeded",id,Json.map("runId",runId,"tool",tool.name()));
            return new Outcome(tool.name().equals("system__ask_user")?"WAITING_INPUT":"SUCCEEDED",modelResult,null,id);
        } catch(RuntimeException error) {
            String code=error instanceof ApiException a?a.code:"TOOL_FAILED";
            boolean unknown=!risk.equals("READ")&&!tool.serverId().isBlank();
            store.transaction(tx-> {
                Map<String,Object> e=tx.get("tool-execution",id);
                e.put("status",unknown?"UNKNOWN":"FAILED");
                e.put("errorCode",code);
                e.put("finishedAt",Util.now());
                tx.put("tool-execution",id,e);
                return null;
            } );
            event.accept("tool.failed",Json.map("executionId",id,"toolCallId",toolCallId,"tool",tool.name(),"code",code,"resultUnknown",unknown));
            audit.record(actor,"tool.failed",id,Json.map("code",code,"resultUnknown",unknown));
            return new Outcome(unknown?"UNKNOWN":"FAILED",Json.map("error",code,"message",error instanceof ApiException?error.getMessage():"Tool execution failed"),null,id);
        }
    }
    public Map<String,Object> decision(AuthContext actor,String confirmationId,String decision,int version) {
        if(!Set.of("APPROVE","REJECT").contains(decision))throw ApiException.bad("decision must be APPROVE or REJECT");
        Map<String,Object> result=store.transaction(tx-> {
            Map<String,Object> c=tx.get("confirmation",confirmationId);
            if(c==null)throw ApiException.missing("confirmation");
            auth.policy.check(actor,"chat",c);
            String wanted=decision.equals("APPROVE")?"APPROVED":"REJECTED";
            if(wanted.equals(c.get("status")))return c;
            if(!"PENDING".equals(c.get("status"))||version!=Json.integer(c,"version",0))throw ApiException.conflict("RESOURCE_VERSION_CONFLICT","Confirmation already decided or version changed");
            if(Instant.parse(c.get("expiresAt").toString()).isBefore(Instant.now()))throw new ApiException(409,"CONFIRMATION_EXPIRED","Confirmation expired");
            Map<String,Object> run=tx.get("run",c.get("runId").toString());
            if(run==null||!"WAITING_CONFIRMATION".equals(run.get("status")))throw ApiException.conflict("RUN_NOT_WAITING","Run is not waiting for confirmation");
            Map<String,Object> e=tx.get("tool-execution",c.get("executionId").toString());
            if(!Objects.equals(e.get("argsHash"),c.get("argsHash")))throw ApiException.conflict("TOOL_ARGUMENT_CHANGED","Tool arguments changed");
            auth.policy.check(actor,"tool:"+c.get("toolName"),Json.map("tenantId",actor.tenantId()));
            c.put("status",wanted);
            c.put("version",version+1);
            c.put("decidedBy",actor.userId());
            c.put("decidedAt",Util.now());
            e.put("approved",decision.equals("APPROVE"));
            e.put("status",decision.equals("APPROVE")?"PREPARED":"REJECTED");
            tx.put("confirmation",confirmationId,c);
            tx.put("tool-execution",e.get("id").toString(),e);
            return c;
        } );
        audit.record(actor,"confirmation."+decision.toLowerCase(Locale.ROOT),confirmationId,Json.map("runId",result.get("runId")));
        return result;
    }
    /** Records an operator's verified external result; this endpoint never replays a tool or fabricates an automatic lookup. */
    public Map<String,Object> reconcile(AuthContext actor,String id,Map<String,Object> body) {
        auth.owned(store,"tool-execution",id,actor,"admin");
        String resolution=Json.required(body,"resolution"),evidence=Json.required(body,"evidence");
        if(!Set.of("SUCCEEDED","NOT_EXECUTED","FAILED").contains(resolution))throw ApiException.bad("resolution must be SUCCEEDED, NOT_EXECUTED or FAILED");
        Map<String,Object> result=store.transaction(tx-> {
            Map<String,Object> e=tx.get("tool-execution",id);
            if(!"UNKNOWN".equals(e.get("status")))throw ApiException.conflict("NOT_UNKNOWN","Only an UNKNOWN execution can be reconciled");
            e.put("status","RECONCILED");
            e.put("resolution",resolution);
            e.put("reconciliationEvidence",evidence);
            e.put("externalOperationId",Json.str(body,"externalOperationId",""));
            e.put("reconciledAt",Util.now());
            e.put("reconciledBy",actor.userId());
            e.put("resolutionSource","OPERATOR_VERIFIED");
            tx.put("tool-execution",id,e);
            Map<String,Object> run=tx.get("run",e.get("runId").toString());
            if(run!=null) {
                boolean more=tx.list("tool-execution").stream().anyMatch(other->run.get("id").equals(other.get("runId"))&&Set.of("UNKNOWN","EXECUTING").contains(other.get("status")));
                run.put("reconciliationStatus",more?"PENDING":"RESOLVED");
                tx.put("run",run.get("id").toString(),run);
            }
            return e;
        });
        audit.record(actor,"tool.reconciled",id,Json.map("resolution",resolution,"evidenceHash",Util.hash(evidence)));
        return result;
    }
}
