package com.bydauto.yunfan.agent.filter;

import com.bydauto.yunfan.agent.common.*;
import java.util.*;

/** Structural control-plane boundary. Never inspects or materializes an artifact. */
public final class PersistenceProjectionFilter {
    private static final Set<String> INTERNAL=Set.of("storage_uri","storageUri","storageLocator","physicalPath","access_token","boundArguments");
    public void validate(Object value){visit(value,0);}
    private void visit(Object value,int depth){
        if(depth>40)fail();
        if(value instanceof Map<?,?> map){
            for(var entry:map.entrySet()){
                if(INTERNAL.contains(entry.getKey().toString()))fail();
                if("arguments".equals(entry.getKey())&&entry.getValue() instanceof String args&&args.length()>24000)fail();
                visit(entry.getValue(),depth+1);
            }
        }else if(value instanceof List<?> list){
            if(list.size()>128||list.size()>32&&list.stream().anyMatch(v->v instanceof Map<?,?>||v instanceof List<?>))fail();
            for(Object child:list)visit(child,depth+1);
        }else if(value instanceof String text){
            String stripped=text.stripLeading();
            if(stripped.startsWith("{")||stripped.startsWith("[")){
                Object parsed;try{parsed=Json.parse(text);}catch(ApiException ignored){return;}visit(parsed,depth+1);
            }
        }
    }
    public static void fail(){throw new ApiException(422,"CONTEXT_POLICY_VIOLATION","Bulk structured data or private storage metadata cannot enter the control plane; use an artifact reference");}
}
