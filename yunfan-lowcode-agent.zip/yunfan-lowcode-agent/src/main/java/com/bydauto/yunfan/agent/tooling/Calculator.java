package com.bydauto.yunfan.agent.tooling;
import com.bydauto.yunfan.agent.common.ApiException;
import java.math.*;
public final class Calculator {
    private final String text;
    private int p,depth;
    private Calculator(String text) {
        if(text.length()>512)throw ApiException.bad("Expression too long");
        this.text=text;
    }
    public static String evaluate(String text) {
        try {
            Calculator c=new Calculator(text);
            BigDecimal value=c.sum();
            c.space();
            if(c.p!=text.length())throw ApiException.bad("Unexpected calculator input");
            return value.stripTrailingZeros().toPlainString();
        } catch(ArithmeticException|NumberFormatException e) {
            throw ApiException.bad("Invalid arithmetic operation");
        }
    }
    private void space() {
        while(p<text.length()&&Character.isWhitespace(text.charAt(p)))p++;
    }
    private boolean take(char c) {
        space();
        if(p<text.length()&&text.charAt(p)==c) {
            p++;
            return true;
        }
        return false;
    }
    private BigDecimal sum() {
        BigDecimal n=product();
        while(true) {
            if(take('+'))n=n.add(product(),MathContext.DECIMAL128);
            else if(take('-'))n=n.subtract(product(),MathContext.DECIMAL128);
            else return n;
        }
    }
    private BigDecimal product() {
        BigDecimal n=atom();
        while(true) {
            if(take('*'))n=n.multiply(atom(),MathContext.DECIMAL128);
            else if(take('/'))n=n.divide(atom(),MathContext.DECIMAL128);
            else if(take('%'))n=n.remainder(atom(),MathContext.DECIMAL128);
            else return n;
        }
    }
    private BigDecimal atom() {
        if(++depth>64)throw ApiException.bad("Expression nested too deeply");
        try {
            if(take('+'))return atom();
            if(take('-'))return atom().negate();
            if(take('(')) {
                BigDecimal n=sum();
                if(!take(')'))throw ApiException.bad("Missing closing parenthesis");
                return n;
            }
            space();
            int start=p;
            while(p<text.length()&&("0123456789.".indexOf(text.charAt(p))>=0))p++;
            if(start==p)throw ApiException.bad("Number expected");
            return new BigDecimal(text.substring(start,p),MathContext.DECIMAL128);
        } finally {
            depth--;
        }
    }
}
