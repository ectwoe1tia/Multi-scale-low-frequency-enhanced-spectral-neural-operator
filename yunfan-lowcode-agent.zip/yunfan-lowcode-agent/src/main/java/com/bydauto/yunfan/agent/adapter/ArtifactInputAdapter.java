package com.bydauto.yunfan.agent.adapter;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.contract.*;
import com.bydauto.yunfan.agent.artifact.ArtifactStore;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Bound arguments exist only inside the invocation scope and must never be persisted. */
public final class ArtifactInputAdapter {
    private final ArtifactStore data;
    public ArtifactInputAdapter(ArtifactStore data){this.data=data;}
    public record BoundInvocation(Map<String,Object> wireArguments,Map<String,Object> fingerprints,List<ArtifactStore.ReadLease> leases) implements AutoCloseable {
        public void close(){for(var lease:leases)lease.close();}
    }
    public BoundInvocation bind(AuthContext actor,ToolContract contract,Map<String,Object> logical){
        var wire=Json.object(Json.copy(logical));Map<String,Object> fingerprints=Json.map();List<ArtifactStore.ReadLease> leases=new ArrayList<>();
        try{for(var binding:contract.bindings()){
            if(!logical.containsKey(binding.field()))continue;
            if(!binding.field().equals(binding.wireField())&&logical.containsKey(binding.wireField()))throw ApiException.bad("Artifact wire field cannot overwrite a logical argument");
            Object value=logical.get(binding.field());String id=value instanceof String?(String)value:Json.required(Json.object(value),"artifact_id");
            if(value instanceof Map<?,?> m&&m.size()!=1)throw ApiException.bad("Artifact input must contain only artifact_id");
            var lease=data.lease(actor,id);leases.add(lease);var meta=data.describe(actor,new ArtifactStore.ArtifactHandle(id));
            if(!"dataset".equals(meta.kind()))throw ApiException.bad("Expected table artifact");
            if(binding.mode()==ToolContract.Mode.HANDLE&&meta.bytes()>binding.maxBytes())throw new ApiException(413,"DATA_BINDING_UNSUPPORTED","Artifact exceeds the handle input contract limit");
            if(binding.requireComplete()&&!"COMPLETE".equals(meta.completeness()))throw new ApiException(422,"DATA_INCOMPLETE","This tool requires a complete dataset");
            fingerprints.put(binding.field(),Json.map("artifact_id",id,"sha256",data.contentHash(actor,id),"contractHash",contract.hash(),"completeness",meta.completeness()));
            wire.remove(binding.field());
            if(binding.mode()==ToolContract.Mode.HANDLE)wire.put(binding.wireField(),id);
            else{
                long[] bytes={2};List<Object> rows=new ArrayList<>();data.scan(actor,id,row->{bytes[0]+=Json.write(row).getBytes(StandardCharsets.UTF_8).length+1;if(bytes[0]>binding.maxBytes())throw new ApiException(413,"DATA_BINDING_UNSUPPORTED","Legacy inline input exceeds its trusted contract limit; configure a handle-aware tool");rows.add(row);});wire.put(binding.wireField(),rows);
            }
        }return new BoundInvocation(wire,fingerprints,leases);}catch(RuntimeException e){leases.forEach(ArtifactStore.ReadLease::close);throw e;}
    }
}
