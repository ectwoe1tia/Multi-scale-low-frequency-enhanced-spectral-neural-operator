package com.bydauto.yunfan.agent.tooling;

import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.process.ProcessSupervisor;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Newline framed JSON-RPC. Each identity and configuration version owns a child process. */
public final class StdioMcpConnection implements AutoCloseable {
    private final ProcessSupervisor supervisor;
    private final Map<String,Channel> channels=new ConcurrentHashMap<>();
    public StdioMcpConnection(ProcessSupervisor supervisor) {this.supervisor=supervisor;}
    public Map<String,Object> call(AuthContext actor,Map<String,Object> server,String method,Map<String,Object> params,boolean readOnly) {
        String key=Util.hash(actor.tenantId()+":"+actor.userId()+":"+new TreeSet<>(actor.permissions())+":"+server.get("id")+":"+server.get("version"));
        Channel channel;
        synchronized(channels) {
            channels.entrySet().removeIf(e->{if(e.getValue().idle()||!e.getValue().child.process.isAlive()){e.getValue().close();return true;}return false;});
            channel=channels.get(key);
            if(channel==null) {
                channel=new Channel(server);
                try {
                    Map<String,Object> init=channel.rpc("initialize",Json.map("protocolVersion",server.get("protocolVersion"),"capabilities",Json.map(),"clientInfo",Json.map("name","yunfan-lowcode-agent","version","1.1.0")));
                    if(!Objects.equals(server.get("protocolVersion"),init.get("protocolVersion")))throw new ApiException(502,"MCP_PROTOCOL_MISMATCH","Unsupported negotiated stdio protocol");
                    channel.send(Json.map("jsonrpc","2.0","method","notifications/initialized"));
                    channels.put(key,channel);
                } catch(RuntimeException error) {channel.close();throw error;}
            }
        }
        try {return channel.rpc(method,params);}
        catch(RuntimeException error) {
            channels.remove(key,channel);
            channel.close();
            if(!readOnly)throw new ApiException(502,"TOOL_RESULT_UNKNOWN","stdio MCP write did not complete reliably; reconcile before retrying");
            throw error;
        }
    }
    private final class Channel implements AutoCloseable {
        final ProcessSupervisor.Child child;
        final BufferedWriter stdin;
        final Map<String,CompletableFuture<Map<String,Object>>> pending=new ConcurrentHashMap<>();
        final ExecutorService sender=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"mcp-stdio-writer");t.setDaemon(true);return t;});
        final int timeout,maxBytes;
        volatile long touched=System.currentTimeMillis();
        volatile boolean busy;
        Channel(Map<String,Object> server) {
            timeout=Json.integer(server,"timeoutSeconds",30);
            maxBytes=Json.integer(server,"maxResponseBytes",1048576);
            child=supervisor.start(Json.required(server,"commandProfile"),List.of(),Json.child(server,"envRefs"),supervisor.workspace());
            stdin=new BufferedWriter(new OutputStreamWriter(child.process.getOutputStream(),StandardCharsets.UTF_8));
            Thread reader=new Thread(this::read,"mcp-stdio-reader");reader.setDaemon(true);reader.start();
            Thread errors=new Thread(()->{
                try(var stream=child.process.getErrorStream()) {
                    // Drain stderr without retaining secrets or allowing it to block the protocol.
                    byte[] bytes=new byte[4096];
                    while(stream.read(bytes)!=-1)child.rememberDescendants();
                } catch(IOException ignored) {}
            },"mcp-stdio-stderr");errors.setDaemon(true);errors.start();
        }
        boolean idle() {return !busy&&System.currentTimeMillis()-touched>900000;}
        synchronized Map<String,Object> rpc(String method,Map<String,Object> params) {
            String id=Util.id();
            CompletableFuture<Map<String,Object>> reply=new CompletableFuture<>();
            busy=true;touched=System.currentTimeMillis();pending.put(id,reply);
            try {
                send(Json.map("jsonrpc","2.0","id",id,"method",method,"params",params));
                Map<String,Object> message=reply.get(timeout,TimeUnit.SECONDS);
                if(message.containsKey("error"))throw new ApiException(502,"MCP_RPC_ERROR","stdio MCP returned JSON-RPC error");
                if(!message.containsKey("result"))throw new ApiException(502,"MCP_INVALID_RESPONSE","stdio MCP response has no result");
                return Json.child(message,"result");
            } catch(TimeoutException e) {throw new ApiException(504,"MCP_TIMEOUT","stdio MCP response deadline exceeded");}
            catch(InterruptedException e) {Thread.currentThread().interrupt();throw new ApiException(409,"MCP_CANCELLED","stdio MCP call interrupted");}
            catch(ExecutionException e) {throw new ApiException(502,"MCP_PROCESS_FAILED","stdio MCP process ended or sent invalid framing");}
            finally {pending.remove(id);busy=false;touched=System.currentTimeMillis();}
        }
        void send(Map<String,Object> message) {
            try {sender.submit(()->{stdin.write(Json.write(message));stdin.newLine();stdin.flush();return null;}).get(timeout,TimeUnit.SECONDS);}
            catch(InterruptedException e) {Thread.currentThread().interrupt();throw new ApiException(409,"MCP_CANCELLED","stdio MCP write interrupted");}
            catch(TimeoutException|ExecutionException|RejectedExecutionException e) {throw new ApiException(502,"MCP_PROCESS_FAILED","Cannot write to stdio MCP process before deadline");}
        }
        void read() {
            try(var stream=child.process.getInputStream()) {
                ByteArrayOutputStream line=new ByteArrayOutputStream();
                for(int c;(c=stream.read())!=-1;) {
                    if(c!='\n') {
                        if(line.size()>=maxBytes)throw new IOException("frame limit");
                        line.write(c);continue;
                    }
                    Map<String,Object> message=Json.object(Json.parse(line.toString(StandardCharsets.UTF_8)));line.reset();
                    if(!"2.0".equals(message.get("jsonrpc")))throw new IOException("invalid JSON-RPC version");
                    if(message.containsKey("method")) {
                        if(message.containsKey("id"))send("ping".equals(message.get("method"))?Json.map("jsonrpc","2.0","id",message.get("id"),"result",Json.map()):Json.map("jsonrpc","2.0","id",message.get("id"),"error",Json.map("code",-32601,"message","Client capability not supported")));
                    } else {
                        CompletableFuture<Map<String,Object>> response=pending.get(String.valueOf(message.get("id")));
                        if(response!=null)response.complete(message);
                    }
                    child.rememberDescendants();
                }
            } catch(IOException|RuntimeException ignored) {}
            finally {close();}
        }
        public void close() {pending.values().forEach(f->f.completeExceptionally(new IOException("connection closed")));child.close();sender.shutdownNow();}
    }
    public void close() {synchronized(channels){channels.values().forEach(Channel::close);channels.clear();}}
}
