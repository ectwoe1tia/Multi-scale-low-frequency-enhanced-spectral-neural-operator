package com.bydauto.yunfan.agent.data;

import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.tooling.ToolDefinition;
import java.io.*;
import java.math.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Deterministic operations over handles; never asks an LLM to count or sum rows. */
public final class DataTools {
    private final DataWorkspace data;private final ReadOnlySql sql;
    public DataTools(DataWorkspace data,Config config){this.data=data;sql=new ReadOnlySql(data,config);}
    private static Map<String,Object> text(){return Json.map("type","string","minLength",1,"maxLength",128);}
    private static Map<String,Object> strings(int max){return Json.map("type","array","items",text(),"maxItems",max,"uniqueItems",true);}
    private static Map<String,Object> schema(Map<String,Object> props,String... required){return Json.map("type","object","properties",props,"required",List.of(required),"additionalProperties",false);}
    private static ToolDefinition tool(String name,String description,Map<String,Object> schema){return new ToolDefinition(name,"","",description,schema,"READ",true,"2");}
    public List<ToolDefinition> definitions(){
        var filters=Json.map("type","array","maxItems",8,"items",schema(Json.map("field",text(),"op",Json.map("type","string","enum",List.of("eq","ne","gt","gte","lt","lte","in","isNull")),"value",Json.map()),"field","op"));
        List<ToolDefinition> out=new ArrayList<>(List.of(
            tool("data__schema","查看数据集字段及完整性。输入 dataRef，不要重新查询或回填明细。",schema(Json.map("dataRef",text(),"offset",Json.map("type","integer","minimum",0),"limit",Json.map("type","integer","minimum",1,"maximum",12)),"dataRef")),
            tool("data__page","仅用于核对少量样本，最多 10 行、8 列，每个运行最多 3 次；统计必须用 data__aggregate，全部数据用 data__export。",schema(Json.map("dataRef",text(),"offset",Json.map("type","integer","minimum",0),"limit",Json.map("type","integer","minimum",1,"maximum",10),"columns",strings(8)),"dataRef")),
            tool("data__aggregate","在服务端扫描数据集计算统计，禁止模型靠样本估算总数。支持筛选、分组、COUNT/SUM/AVG/MIN/MAX；结果标明是否完整。output=dataset returns an artifact for downstream aggregation/export. groupBy=[] 表示全体统计。",schema(Json.map("dataRef",text(),"groupBy",strings(3),"output",Json.map("type","string","enum",List.of("summary","dataset")),"filters",filters,"metrics",Json.map("type","array","minItems",1,"maxItems",8,"items",schema(Json.map("op",Json.map("type","string","enum",List.of("count","sum","avg","min","max")),"field",text(),"as",text()),"op","as"))),"dataRef","metrics")),
            tool("data__export","直接将完整已捕获数据集导出 XLSX/HTML/CSV，返回下载引用；不要先分页获取全部行。可选 columns 选择列，filters 筛选。",schema(Json.map("dataRef",text(),"format",Json.map("type","string","enum",List.of("xlsx","html","csv")),"columns",strings(64),"filters",filters),"dataRef","format"))
        ));if(sql.enabled())out.add(tool("data__sql_query","在部署配置的只读数据库执行单条 SELECT（支持 ? 参数），结果自动落盘；统计优先 SELECT COUNT/SUM/... GROUP BY，禁止 SELECT * 后让模型计算。大结果/行数上限会明确标注。",schema(Json.map("sql",Json.map("type","string","maxLength",16000),"parameters",Json.map("type","array","maxItems",100)),"sql")));return out;
    }
    public Object invoke(AuthContext actor,String run,String name,Map<String,Object> args){
        return switch(name){case "data__schema"->schemaView(actor,args);case "data__page"->page(actor,args);case "data__aggregate"->aggregate(actor,run,args);case "data__export"->export(actor,run,args);case "data__sql_query"->sql.query(actor,run,args);default->throw ApiException.missing("data tool");};
    }
    private Map<String,Object> dataset(AuthContext actor,Map<String,Object> args){var m=data.owned(actor,Json.required(args,"dataRef"));if(!"dataset".equals(m.get("kind")))throw ApiException.bad("Expected dataset reference");return m;}
    private List<String> columns(Map<String,Object> m,Map<String,Object> args,int max){List<String> out=new ArrayList<>(Json.strings(args.get("columns")));if(out.isEmpty())out.addAll(Json.child(m,"fields").keySet().stream().limit(max).toList());for(String c:out)field(m,c);if(out.size()>max)throw ApiException.bad("Too many selected columns");return out;}
    private void field(Map<String,Object> m,String name){if(!Json.child(m,"fields").containsKey(name))throw ApiException.bad("Unknown field: "+name);}
    private Object schemaView(AuthContext actor,Map<String,Object> args){var m=dataset(actor,args);int start=Json.integer(args,"offset",0),limit=Json.integer(args,"limit",12);if(start<0||limit<1||limit>12)throw ApiException.bad("Schema page out of range");return Json.map("dataRef",m.get("id"),"rowCount",m.get("rowCount"),"completeness",m.get("completeness"),"columnCount",Json.child(m,"fields").size(),"fields",Json.child(m,"fields").entrySet().stream().skip(start).limit(limit).map(e->Json.map("name",e.getKey(),"type",e.getValue())).toList());}
    private Object page(AuthContext actor,Map<String,Object> args){var m=dataset(actor,args);List<String> columns=columns(m,args,8);int start=Json.integer(args,"offset",0),limit=Json.integer(args,"limit",5);if(start<0||limit<1||limit>10)throw ApiException.bad("Data page out of range");
        List<Object> rows=new ArrayList<>();boolean[] full={false};int[] index={0};data.scan(actor,m.get("id").toString(),row->{int i=index[0]++;if(i>=start&&rows.size()<limit&&!full[0]){Map<String,Object> selected=Json.map();for(String c:columns){Object v=row.get(c);String s=v instanceof String?(String)v:Json.write(v);selected.put(c,s.length()>120?s.substring(0,120)+"[truncated]":v);}if(Json.write(rows).length()+Json.write(selected).length()<2000)rows.add(selected);else {if(rows.isEmpty())throw ApiException.bad("Sample row is too wide; select fewer columns");full[0]=true;}}});
        return Json.map("kind","data_page","dataRef",m.get("id"),"offset",start,"returned",rows.size(),"nextOffset",start+rows.size(),"rowCount",m.get("rowCount"),"completeness",m.get("completeness"),"sampleOnly",true,"cellLimit",120,"rows",rows,"notice","Sample is not evidence of totals. Use data__aggregate or data__export.");
    }
    private List<Map<String,Object>> filters(Map<String,Object> metadata,Map<String,Object> args){var f=Json.list(args,"filters").stream().map(Json::object).toList();if(f.size()>8)throw ApiException.bad("Too many filters");for(var v:f){field(metadata,Json.required(v,"field"));if(!Set.of("eq","ne","gt","gte","lt","lte","in","isNull").contains(Json.required(v,"op")))throw ApiException.bad("Unsupported filter");if(!v.get("op").equals("isNull")&&!v.containsKey("value"))throw ApiException.bad("Filter value required");if(v.get("op").equals("in")&&Json.array(v.get("value")).size()>100)throw ApiException.bad("Filter IN limit");}return f;}
    private boolean matches(Map<String,Object> row,List<Map<String,Object>> filters){for(var f:filters){Object v=row.get(f.get("field")),wanted=f.get("value");String op=Json.required(f,"op");boolean yes=switch(op){
        case "isNull"->v==null;case "eq"->equal(v,wanted);case "ne"->!equal(v,wanted);case "in"->Json.array(wanted).stream().anyMatch(x->equal(v,x));
        default->{if(v==null||wanted==null)yield false;int c=compare(v,wanted);yield switch(op){case "gt"->c>0;case "gte"->c>=0;case "lt"->c<0;case "lte"->c<=0;default->false;};}};if(!yes)return false;}return true;}
    private static boolean equal(Object a,Object b){return a instanceof Number && b instanceof Number ? new BigDecimal(a.toString()).compareTo(new BigDecimal(b.toString()))==0 : Objects.equals(Util.canonical(a),Util.canonical(b));}
    private static int compare(Object a,Object b){if(a instanceof Number&&b instanceof Number)return new BigDecimal(a.toString()).compareTo(new BigDecimal(b.toString()));if(a instanceof String&&b instanceof String)return a.toString().compareTo(b.toString());throw ApiException.bad("Comparison requires compatible scalar types");}
    private static final class Metric {long count;BigDecimal sum=BigDecimal.ZERO;Object min,max;
        void add(Object value,String op,boolean countRows){if(op.equals("count")){if(countRows||value!=null)count++;return;}if(value==null)return;count++;
            if(op.equals("sum")||op.equals("avg")){if(!(value instanceof Number))throw ApiException.bad("SUM/AVG require numeric values; numeric strings are not silently coerced");sum=sum.add(new BigDecimal(value.toString()));}
            else{if(!(value instanceof Number||value instanceof String))throw ApiException.bad("MIN/MAX require numbers or strings");if(min==null||compare(value,min)<0)min=value;if(max==null||compare(value,max)>0)max=value;}}
        Object result(String op){return switch(op){case "count"->count;case "sum"->count==0?null:sum;case "avg"->count==0?null:sum.divide(BigDecimal.valueOf(count),MathContext.DECIMAL128);case "min"->min;case "max"->max;default->throw ApiException.bad("Unknown metric");};}}
    private Object aggregate(AuthContext actor,String run,Map<String,Object> args){var m=dataset(actor,args);List<String> groups=new ArrayList<>(Json.strings(args.get("groupBy")));if(groups.size()>3)throw ApiException.bad("Group field limit");groups.forEach(g->field(m,g));var filter=filters(m,args);
        List<Map<String,Object>> metrics=Json.list(args,"metrics").stream().map(Json::object).toList();if(metrics.isEmpty()||metrics.size()>8)throw ApiException.bad("Expected 1..8 metrics");Set<String> aliases=new HashSet<>(groups);
        for(var metric:metrics){String op=Json.required(metric,"op"),as=Json.required(metric,"as");if(!Set.of("count","sum","avg","min","max").contains(op)||!aliases.add(as)||as.length()>128)throw ApiException.bad("Invalid metric or duplicate output name");String f=Json.str(metric,"field","");if(!f.isEmpty())field(m,f);else if(!op.equals("count"))throw ApiException.bad("Metric field required");}
        Map<String,List<Object>> keys=new LinkedHashMap<>();Map<String,Metric[]> accum=new LinkedHashMap<>();long[] matched={0};
        if(groups.isEmpty()){keys.put("[]",List.of());accum.put("[]",metrics.stream().map(x->new Metric()).toArray(Metric[]::new));}
        data.scan(actor,m.get("id").toString(),row->{if(!matches(row,filter))return;matched[0]++;List<Object> key=groups.stream().map(row::get).toList();String hash=Util.canonical(key);
            if(!accum.containsKey(hash)){if(accum.size()>=10000)throw new ApiException(413,"GROUP_LIMIT","More than 10000 groups; aggregate at SQL source or narrow grouping");keys.put(hash,key);accum.put(hash,metrics.stream().map(x->new Metric()).toArray(Metric[]::new));}
            for(int i=0;i<metrics.size();i++){var spec=metrics.get(i);String f=Json.str(spec,"field","");accum.get(hash)[i].add(row.get(f),Json.required(spec,"op"),f.isEmpty());}});
        List<Map<String,Object>> rows=new ArrayList<>();for(var e:accum.entrySet()){Map<String,Object> row=Json.map();for(int i=0;i<groups.size();i++)row.put(groups.get(i),keys.get(e.getKey()).get(i));for(int i=0;i<metrics.size();i++)row.put(Json.required(metrics.get(i),"as"),e.getValue()[i].result(Json.required(metrics.get(i),"op")));rows.add(row);}
        var out=Json.map("kind","aggregate_result","sourceRef",m.get("id"),"completeness",m.get("completeness"),"scope","captured rows only","scannedRows",m.get("rowCount"),"matchedRows",matched[0],"groupCount",rows.size(),"rows",rows);
        if(!"dataset".equals(Json.str(args,"output","summary"))&&Json.write(out).length()<=2600)return out;
        var ref=data.saveRows(actor,run,"aggregate:"+m.get("id"),rows.iterator(),Json.required(m,"completeness"),null);ref.put("sourceRef",m.get("id"));ref.put("matchedRows",matched[0]);return ref;
    }
    private Object export(AuthContext actor,String run,Map<String,Object> args){var m=dataset(actor,args);List<String> columns=columns(m,args,64);if(!args.containsKey("columns")&&Json.child(m,"fields").size()>64)throw ApiException.bad("Select at most 64 export columns explicitly");var filter=filters(m,args);String format=Json.required(args,"format");if(!Set.of("xlsx","html","csv").contains(format))throw ApiException.bad("Unsupported export format");long[] count={0};
        var exported=data.export(actor,run,"export:"+m.get("id"),format,out->{
            if(format.equals("xlsx"))xlsx(out,columns,actor,m,filter,count);
            else{Writer writer=new OutputStreamWriter(out,StandardCharsets.UTF_8);if(format.equals("html")){writer.write("<!doctype html><meta charset=\"utf-8\"><meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; style-src 'unsafe-inline'\"><title>Data export</title><p>Completeness: "+escape(Json.required(m,"completeness"))+"; captured rows only</p><table><thead><tr>");for(String c:columns)writer.write("<th>"+escape(c)+"</th>");writer.write("</tr></thead><tbody>");}
                else{writer.write('\uFEFF');csv(writer,columns);}
                data.scan(actor,m.get("id").toString(),row->{if(!matches(row,filter))return;try{List<String> cells=columns.stream().map(c->display(row.get(c))).toList();if(format.equals("html")){writer.write("<tr>");for(String c:cells)writer.write("<td>"+escape(c)+"</td>");writer.write("</tr>");}else csv(writer,cells);count[0]++;}catch(IOException e){throw new UncheckedIOException(e);}});
                if(format.equals("html"))writer.write("</tbody></table>");writer.flush();}
        });exported.put("sourceRef",m.get("id"));exported.put("exportedRows",count[0]);exported.put("completeness",m.get("completeness"));return exported;
    }
    private static String display(Object o){return o==null?"":o instanceof String?(String)o:Json.write(o);}
    private static String escape(String s){StringBuilder b=new StringBuilder();s.codePoints().filter(c->c==9||c==10||c==13||c>=32&&c!=0xfffe&&c!=0xffff).forEach(c->b.appendCodePoint(c));return b.toString().replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private static void csv(Writer w,List<String> values)throws IOException{boolean comma=false;for(String s:values){if(comma)w.write(',');if(!s.isEmpty()&&"=+-@\t\r\n".indexOf(s.charAt(0))>=0)s="'"+s;w.write('"');w.write(s.replace("\"","\"\""));w.write('"');comma=true;}w.write("\r\n");}
    private void xlsx(OutputStream output,List<String> columns,AuthContext actor,Map<String,Object> m,List<Map<String,Object>> filters,long[] count)throws IOException{
        try(ZipOutputStream zip=new ZipOutputStream(output,StandardCharsets.UTF_8)){
            entry(zip,"[Content_Types].xml","<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
            entry(zip,"_rels/.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            entry(zip,"xl/workbook.xml","<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Captured data\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            entry(zip,"xl/_rels/workbook.xml.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
            zip.putNextEntry(new ZipEntry("xl/worksheets/sheet1.xml"));Writer writer=new OutputStreamWriter(zip,StandardCharsets.UTF_8);writer.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");xmlRow(writer,new ArrayList<>(columns));
            data.scan(actor,m.get("id").toString(),row->{if(!matches(row,filters))return;try{xmlRow(writer,columns.stream().map(row::get).toList());count[0]++;}catch(IOException e){throw new UncheckedIOException(e);}});writer.write("</sheetData></worksheet>");writer.flush();zip.closeEntry();
        }
    }
    private static void xmlRow(Writer out,List<?> cells)throws IOException{out.write("<row>");for(Object v:cells){String s=display(v);if(s.length()>32767)throw new IOException("Excel cell exceeds 32767 characters; use CSV/HTML");boolean numeric=v instanceof Number&&new BigDecimal(v.toString()).precision()<=15;out.write(numeric?"<c t=\"n\"><v>"+s+"</v></c>":"<c t=\"inlineStr\"><is><t xml:space=\"preserve\">"+escape(s)+"</t></is></c>");}out.write("</row>");}
    private static void entry(ZipOutputStream zip,String name,String xml)throws IOException{zip.putNextEntry(new ZipEntry(name));zip.write(xml.getBytes(StandardCharsets.UTF_8));zip.closeEntry();}
}
