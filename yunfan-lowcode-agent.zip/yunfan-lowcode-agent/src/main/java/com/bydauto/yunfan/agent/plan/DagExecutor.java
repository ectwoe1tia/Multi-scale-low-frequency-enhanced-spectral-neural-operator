package com.bydauto.yunfan.agent.plan;

import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.data.DataWorkspace;
import com.bydauto.yunfan.agent.state.TaskStateRepository;
import com.bydauto.yunfan.agent.tooling.*;
import java.util.*;
import java.util.function.BiConsumer;

/** Checkpointed sequential topology. All nodes execute through the existing guarded gateway. */
public final class DagExecutor {
    private final DocumentStore store;private final ToolExecutionService tools;private final PlanCompiler compiler;private final TaskStateRepository states;private final DataWorkspace data;private final Config config;
    public DagExecutor(DocumentStore store,ToolExecutionService tools,PlanCompiler compiler,TaskStateRepository states,DataWorkspace data,Config config){this.store=store;this.tools=tools;this.compiler=compiler;this.states=states;this.data=data;this.config=config;}
    public static ToolDefinition definition(){return new ToolDefinition("runtime__execute_plan","","","执行受限 DAG。plan 含 schemaVersion=1、nodes、result。节点含 id/tool/dependsOn/inputs。数据使用 {\"$ref\":{\"node\":\"前置节点\",\"output\":\"dataset\"}}，输出可为 dataset/file/summary/result；禁止把原始行放入参数。",Json.map("type","object","properties",Json.map("plan",Json.map("type","object")),"required",List.of("plan"),"additionalProperties",false),"READ",true,"1");}
    public ToolExecutionService.Outcome execute(AuthContext actor,String runId,String callId,Map<String,Object> json,BiConsumer<String,Object> event){
        var run=store.get("run",runId);if(run==null||!actor.tenantId().equals(run.get("tenantId"))||!actor.userId().equals(run.get("userId")))throw ApiException.missing("run");
        List<ToolDefinition> catalog=Json.list(run,"tools").stream().map(Json::object).map(ToolDefinition::from).toList();
        ExecutionPlan plan=compiler.compile(actor,json,catalog);String taskId=Util.hash(runId+":"+callId);
        List<Map<String,Object>> nodes=new ArrayList<>();Map<String,Object> outputs=Json.map();var previous=store.get("task-state",taskId);
        if(previous!=null){previous=states.get(actor,taskId);if(!plan.hash().equals(previous.get("planHash")))throw ApiException.conflict("PLAN_CHANGED","Plan, catalog or contract changed during execution");nodes.addAll(Json.list(previous,"nodes").stream().map(Json::object).toList());outputs.putAll(Json.child(previous,"outputs"));}
        else{if(states.forRun(actor,runId).stream().filter(s->!runId.equals(s.get("id"))).count()>=config.integer("yunfan.plan.max-stages",3))throw new ApiException(422,"RUN_BUDGET_EXCEEDED","Maximum plan stages reached");for(var node:plan.nodes())nodes.add(Json.map("id",node.id(),"tool",node.tool().name(),"contractHash",node.contractHash(),"status","PENDING"));save(actor,taskId,runId,"RUNNING",nodes,outputs,plan.hash());}
        for(int i=0;i<plan.nodes().size();i++){
            var node=plan.nodes().get(i);var checkpoint=nodes.get(i);String state=Json.required(checkpoint,"status");if(state.equals("SUCCEEDED"))continue;
            if(Set.of("FAILED","SKIPPED","UNKNOWN","CANCELLED").contains(state))return new ToolExecutionService.Outcome(state.equals("UNKNOWN")?"UNKNOWN":"FAILED",summary(taskId,"FAILED",nodes,null),null,Json.str(checkpoint,"executionId",taskId));
            if(!"RUNNING".equals(Json.required(store.get("run",runId),"status")))throw ApiException.conflict("RUN_STOPPED","Run stopped before DAG node");
            if(!checkpoint.containsKey("reserved")){
                store.transaction(tx->{var current=tx.get("run",runId);int count=Json.integer(current,"toolCallsCount",0);if(count>=config.integer("yunfan.agent.max-tool-calls",20))throw new ApiException(422,"RUN_BUDGET_EXCEEDED","DAG tool budget exceeded");current.put("toolCallsCount",count+1);tx.put("run",runId,current);return null;});checkpoint.put("reserved",true);
            }
            checkpoint.put("status","RUNNING");save(actor,taskId,runId,"RUNNING",nodes,outputs,plan.hash());
            boolean confirmation=Json.list(run,"skills").stream().map(Json::object).anyMatch(s->Json.bool(Json.child(s,"metadata"),"requiresConfirmation",false)&&Json.strings(Json.child(s,"metadata").get("allowedTools")).contains(node.tool().name()));
            ToolExecutionService.Outcome outcome;
            try{var args=Json.object(resolve(actor,node.inputs(),outputs));outcome=tools.execute(actor,runId,"dag-"+taskId+"-"+node.id(),node.tool(),args,Json.child(Json.child(run,"request"),"context"),confirmation,event);}
            catch(ApiException e){outcome=new ToolExecutionService.Outcome("FAILED",Json.map("error",e.code),null,null);}
            checkpoint.put("status",outcome.status());checkpoint.put("executionId",outcome.executionId());
            var parent=store.get("run",runId);if(parent==null||!"RUNNING".equals(parent.get("status"))){save(actor,taskId,runId,parent==null?"FAILED":Json.required(parent,"status"),nodes,outputs,plan.hash());throw ApiException.conflict("RUN_STOPPED","Run stopped during DAG invocation");}
            if(outcome.result() instanceof Map<?,?> failure&&failure.get("error")!=null)checkpoint.put("errorCode",failure.get("error"));
            if(outcome.status().equals("WAITING_CONFIRMATION")){save(actor,taskId,runId,"WAITING_APPROVAL",nodes,outputs,plan.hash());return outcome;}
            if(!outcome.status().equals("SUCCEEDED")){
                for(int j=i+1;j<nodes.size();j++)nodes.get(j).put("status","SKIPPED");save(actor,taskId,runId,outcome.status(),nodes,outputs,plan.hash());
                return new ToolExecutionService.Outcome(outcome.status().equals("UNKNOWN")?"UNKNOWN":"FAILED",summary(taskId,"FAILED",nodes,null),null,outcome.executionId());
            }
            outputs.put(node.id(),outcome.result());save(actor,taskId,runId,"RUNNING",nodes,outputs,plan.hash());
            event.accept("plan.node.completed",Json.map("taskId",taskId,"nodeId",node.id()));
        }
        Object finalValue=resolve(actor,plan.result(),outputs);
        var finalRef=Json.child(plan.result(),"$ref");
        if(finalRef.containsKey("artifact_id")||Set.of("dataset","file").contains(Json.str(finalRef,"output",""))){var metadata=data.owned(actor,(String)finalValue);finalValue=data.reference(metadata);}
        save(actor,taskId,runId,"COMPLETED",nodes,outputs,plan.hash());
        var result=summary(taskId,"COMPLETED",nodes,finalValue);event.accept("plan.completed",result);return new ToolExecutionService.Outcome("SUCCEEDED",result,null,taskId);
    }
    private Object resolve(AuthContext actor,Object value,Map<String,Object> outputs){
        if(value instanceof Map<?,?> map){if(map.containsKey("$ref")){
            var ref=Json.object(map.get("$ref"));if(ref.containsKey("artifact_id")){String id=Json.required(ref,"artifact_id");data.owned(actor,id);return id;}
            Object produced=outputs.get(Json.required(ref,"node"));if(produced==null)throw new ApiException(422,"PLAN_OUTPUT_UNAVAILABLE","Dependency output is not committed");
            String port=Json.required(ref,"output");if(port.equals("result")||port.equals("summary"))return Json.copy(produced);
            var result=Json.object(produced);String id=Json.str(result,port.equals("file")?"artifactId":"dataRef","");if(id.isBlank())throw new ApiException(422,"PLAN_OUTPUT_TYPE_MISMATCH","Dependency did not produce the requested artifact port");
            var meta=data.owned(actor,id);if(port.equals("dataset")&&!"dataset".equals(meta.get("kind")))throw ApiException.bad("Expected table artifact output");return id;
        }var out=Json.map();for(var entry:map.entrySet())out.put(entry.getKey().toString(),resolve(actor,entry.getValue(),outputs));return out;
        }else if(value instanceof List<?> list)return list.stream().map(v->resolve(actor,v,outputs)).toList();return value;
    }
    private void save(AuthContext actor,String task,String run,String status,List<Map<String,Object>> nodes,Map<String,Object> outputs,String hash){states.save(actor,new TaskStateRepository.TaskState(task,run,status,nodes,outputs),hash);}
    private Map<String,Object> summary(String task,String status,List<Map<String,Object>> nodes,Object result){var value=Json.map("kind","execution_summary","taskId",task,"status",status,"completedNodes",nodes.stream().filter(n->"SUCCEEDED".equals(n.get("status"))).count(),"nodeCount",nodes.size(),"result",result);if(!status.equals("COMPLETED"))value.put("error","PLAN_FAILED");return value;}
}
