package com.bydauto.yunfan.agent.contract;

import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.tooling.ToolDefinition;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Optional trusted JSON configuration, never populated from tool results or model plans. */
public final class ToolContractRegistry {
    private final Map<String,ToolContract> configured=new ConcurrentHashMap<>();
    public ToolContractRegistry(Config config){
        String path=config.get("yunfan.contracts.file","");if(path.isBlank())return;
        try{for(Object item:Json.array(Json.parse(Files.readString(Path.of(path))))){var c=Json.object(item);List<ToolContract.Binding> bindings=new ArrayList<>();
            for(Object raw:Json.list(c,"bindings")){var b=Json.object(raw);bindings.add(new ToolContract.Binding(Json.required(b,"field"),Json.str(b,"wireField",Json.required(b,"field")),ToolContract.Mode.valueOf(Json.required(b,"mode")),Json.integer(b,"maxBytes",1048576),Json.bool(b,"requireComplete",false)));}
            List<String> outputPath=new ArrayList<>();for(Object key:Json.list(c,"outputPath")){if(!(key instanceof String s)||s.isBlank())throw ApiException.bad("Output path must contain nonempty strings");outputPath.add((String)key);}
            register(new ToolContract(Json.required(c,"tool"),Json.required(c,"version"),Json.child(c,"logicalSchema"),bindings,ToolContract.Exposure.valueOf(Json.str(c,"exposure","AUTO")),outputPath,Json.strings(c.get("summaryFields")),Json.integer(c,"maxSummaryBytes",2048),Json.str(c,"outputKind","value")));
        }}catch(java.io.IOException e){throw new IllegalStateException("Cannot load tool contracts",e);}
    }
    public void register(ToolContract contract){configured.put(contract.tool(),contract);}
    public ToolContract get(ToolDefinition tool){
        var configuredContract=configured.get(tool.name());if(configuredContract!=null)return configuredContract;
        if(tool.serverId().isBlank()&&Set.of("data__schema","data__page","data__aggregate","data__export").contains(tool.name()))return new ToolContract(tool.name(),"2",tool.schema(),List.of(new ToolContract.Binding("dataRef","dataRef",ToolContract.Mode.HANDLE,33554432,false)),ToolContract.Exposure.AUTO,List.of(),Set.of(),2048,tool.name().equals("data__export")?"file":"table");
        return ToolContract.fallback(tool);
    }
    public ToolDefinition logical(ToolDefinition tool){return get(tool).logical(tool);}
    public ToolDefinition wire(ToolDefinition tool){return new ToolDefinition(tool.name(),tool.originalName(),tool.serverId(),tool.description(),tool.wireSchema(),tool.risk(),tool.base(),tool.version());}
    public List<Map<String,Object>> describe(){return configured.values().stream().sorted(Comparator.comparing(ToolContract::tool)).map(c->Json.map("tool",c.tool(),"version",c.version(),"hash",c.hash(),"exposure",c.exposure().name(),"outputKind",c.outputKind(),"bindings",c.bindings().stream().map(b->Json.map("field",b.field(),"mode",b.mode().name())).toList())).toList();}
}
