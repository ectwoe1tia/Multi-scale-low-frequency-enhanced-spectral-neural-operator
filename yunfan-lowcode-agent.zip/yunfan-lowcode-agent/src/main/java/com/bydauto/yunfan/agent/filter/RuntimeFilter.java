package com.bydauto.yunfan.agent.filter;

import com.bydauto.yunfan.agent.auth.AuthContext;
import java.util.Map;

/** Optional ServiceLoader policy hooks. Hooks never receive bound row payloads. */
public interface RuntimeFilter {
    record Invocation(AuthContext actor,String runId,String tool,Map<String,Object> logicalArguments) {}
    default void beforeInvocation(Invocation invocation) {}
    default void afterProjection(Invocation invocation,Object publicResult) {}
}
