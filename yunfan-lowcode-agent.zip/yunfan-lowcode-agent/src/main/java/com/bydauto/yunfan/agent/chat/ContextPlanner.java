package com.bydauto.yunfan.agent.chat;

import com.bydauto.yunfan.agent.common.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Rule-first, dependency-aware greedy packing. No extra model invocation and no optimality claim. */
public final class ContextPlanner {
    public record Plan(List<Map<String,Object>> messages,int removedGroups,Map<String,Object> diagnostics) {}
    private record Unit(int id,List<Map<String,Object>> messages,int parent,boolean pinned,int cost,double score,String hash) {}
    private final Config config;
    public ContextPlanner(Config config){this.config=config;}
    public static int tokens(Object value){return Json.write(value).getBytes(StandardCharsets.UTF_8).length+16;} // conservative byte upper estimate, not billing tokens
    public Plan plan(List<Map<String,Object>> source,List<Map<String,Object>> reminders,List<Map<String,Object>> tools,Map<String,Object> run,int charCap){
        Map<String,Object> request=Json.child(run,"request");String task=Json.str(request,"message","");
        int window=config.integer("yunfan.context.window-tokens",32768),reserve=config.integer("yunfan.context.output-reserve",2048),margin=config.integer("yunfan.context.safety-tokens",512);
        var modelOptions=Json.child(Json.child(run,"model"),"options");reserve=Math.max(reserve,Math.max(Json.integer(modelOptions,"max_tokens",0),Json.integer(modelOptions,"max_completion_tokens",0)));
        int budget=window-reserve-margin;if(budget<256)throw ApiException.bad("Invalid context budget");
        String requested=Json.str(Json.child(request,"context"),"contextMode","AUTO").toUpperCase(Locale.ROOT);if(!Set.of("AUTO","STATELESS","STATEFUL","RETRIEVAL").contains(requested))throw ApiException.bad("Unknown contextMode");
        int current=0;for(int i=0;i<source.size();i++)if("user".equals(source.get(i).get("role"))&&task.equals(source.get(i).get("content")))current=i;
        var taskPolicy=new TaskContextPolicy().classify(request);
        if(taskPolicy.shortHistory()&&current>1){var scoped=new ArrayList<Map<String,Object>>();for(int i=0;i<current;i++)if("system".equals(source.get(i).get("role")))scoped.add(source.get(i));scoped.addAll(source.subList(current,source.size()));source=scoped;current=0;for(int i=0;i<source.size();i++)if("user".equals(source.get(i).get("role"))&&task.equals(source.get(i).get("content")))current=i;}
        List<Unit> units=new ArrayList<>();Set<String> references=new LinkedHashSet<>();int parent=-1;double alpha=weight("alpha",0.5),beta=weight("beta",0.2),gamma=weight("gamma",0.3),eta=weight("eta",0.8);
        Set<String> query=terms(task);int sourceBytes=tokens(source)+tokens(tools)+tokens(reminders);
        for(int i=0;i<source.size();i++){
            int start=i;Map<String,Object> first=source.get(i);String role=Json.required(first,"role");List<Map<String,Object>> group=new ArrayList<>();group.add(first);
            if(role.equals("tool"))throw ApiException.bad("Orphan tool response in context");
            if(role.equals("assistant")&&!Json.list(first,"tool_calls").isEmpty()){
                Set<String> expected=new HashSet<>();for(Object call:Json.list(first,"tool_calls"))if(!expected.add(Json.required(Json.object(call),"id")))throw ApiException.bad("Duplicate tool call ID");
                while(i+1<source.size()&&"tool".equals(source.get(i+1).get("role"))){var response=source.get(++i);if(!expected.remove(Json.required(response,"tool_call_id")))throw ApiException.bad("Unexpected tool result");group.add(response);}
                if(!expected.isEmpty())throw ApiException.bad("Incomplete tool group at model boundary");
            }
            for(var m:group)if("tool".equals(m.get("role")))try{var parsed=Json.object(Json.parse(Json.str(m,"content","{}")));if(parsed.get("dataRef") instanceof String ref){references.remove(ref);references.add(ref);if(references.size()>12)references.remove(references.iterator().next());}}catch(ApiException ignored){}
            if(role.equals("user"))parent=units.size();
            boolean pin=role.equals("system")||role.equals("user")&&start>=current||i==source.size()-1;
            Set<String> words=terms(Json.write(group));long overlap=query.stream().filter(words::contains).count();double relevance=query.isEmpty()?0:(double)overlap/query.size();double fresh=1.0/(1+source.size()-1-i);double utility=group.size()>1?0.9:role.equals("user")?0.7:0.3;
            int cost=tokens(group);double score=(alpha*relevance+beta*fresh+gamma*utility)/Math.pow(Math.max(1,cost),eta);
            units.add(new Unit(units.size(),group,role.equals("assistant")?parent:-1,pin,cost,score,Util.hash(Json.write(group))));
        }
        String mode=requested.equals("AUTO")?(current<=1?"STATELESS":"STATEFUL"):requested;
        List<String> reasons=new ArrayList<>();if(!references.isEmpty()||sourceBytes>budget){mode="RETRIEVAL";reasons.add(!references.isEmpty()?"data_handles_present":"history_budget_pressure");}
        else if(mode.equals("STATELESS")&&(source.stream().anyMatch(m->"tool".equals(m.get("role")))||current>1&&task.matches("(?s).*(上次|刚才|之前|继续|previous|continue).*"))){mode="STATEFUL";reasons.add("state_dependency");}
        List<Map<String,Object>> suffix=new ArrayList<>();if(!references.isEmpty())suffix.add(Json.map("role","user","content","[执行状态：数据引用] "+Json.write(references)+"。完整数据保留在服务端。统计使用 data__aggregate；下载使用 data__export。历史裁剪不表示工具未执行，禁止因此重放写操作。"));suffix.addAll(reminders);
        Set<Integer> selected=new HashSet<>();for(Unit unit:units)if(unit.pinned())include(unit.id(),units,selected);
        ensureBudget(selected,units,suffix,tools,budget,charCap,true);
        List<Unit> sorted=units.stream().filter(u->!u.pinned()).sorted(Comparator.comparingDouble(Unit::score).reversed().thenComparing(Comparator.comparingInt(Unit::id).reversed())).toList();Set<String> hashes=new HashSet<>();for(int id:selected)hashes.add(units.get(id).hash());List<Object> decisions=new ArrayList<>();
        for(Unit unit:sorted){if(selected.contains(unit.id()))continue;String reason="";
            if(mode.equals("STATELESS"))reason="stateless_history";else if(hashes.contains(unit.hash())&&unit.messages().stream().noneMatch(m->"user".equals(m.get("role"))))reason="duplicate";
            else{Set<Integer> next=new HashSet<>(selected);include(unit.id(),units,next);if(ensureBudget(next,units,suffix,tools,budget,charCap,false)){selected=next;hashes.add(unit.hash());reason="selected";}else reason="budget";}
            decisions.add(Json.map("unit",unit.id(),"score",unit.score(),"estimatedTokens",unit.cost(),"decision",reason));
        }
        List<Map<String,Object>> messages=assemble(selected,units,suffix);int used=tokens(messages)+tokens(tools);
        return new Plan(messages,units.size()-selected.size(),Json.map("strategy","rules-first-greedy-v1","requestedMode",requested,"mode",mode,"upgradeReasons",reasons,"tokenEstimator","utf8-bytes-upper-estimate","windowTokens",window,"outputReserve",reserve,"safetyTokens",margin,"inputBudget",budget,"estimatedInputTokens",used,"sourceEstimatedTokens",sourceBytes,"selectedUnits",selected.stream().sorted().toList(),"omittedUnits",units.size()-selected.size(),"candidateDecisions",decisions.stream().limit(200).toList()));
    }
    private double weight(String name,double fallback){double value=Double.parseDouble(config.get("yunfan.context."+name,""+fallback));if(!Double.isFinite(value)||value<0||value>10)throw ApiException.bad("Invalid planner weight");return value;}
    private static void include(int id,List<Unit> units,Set<Integer> selected){if(id<0||!selected.add(id))return;include(units.get(id).parent(),units,selected);}
    private static List<Map<String,Object>> assemble(Set<Integer> selected,List<Unit> units,List<Map<String,Object>> suffix){List<Map<String,Object>> out=new ArrayList<>();for(Unit unit:units)if(selected.contains(unit.id()))out.addAll(unit.messages());out.addAll(suffix);return out;}
    private static boolean ensureBudget(Set<Integer> selected,List<Unit> units,List<Map<String,Object>> suffix,List<Map<String,Object>> tools,int budget,int charCap,boolean required){var messages=assemble(selected,units,suffix);boolean fits=tokens(messages)+tokens(tools)<=budget&&Json.write(messages).length()+Json.write(tools).length()<=charCap;
        if(!fits&&required)throw new ApiException(413,"CONTEXT_LIMIT_EXCEEDED","Mandatory policy/task/latest result exceed the context budget; narrow the tool catalog or task. Mandatory constraints were not dropped.");return fits;}
    private static Set<String> terms(String text){Set<String> words=new HashSet<>();for(String word:text.toLowerCase(Locale.ROOT).split("[^\\p{L}\\p{N}_]+")){if(word.length()>1)words.add(word);if(words.size()>256)break;}return words;}
}
