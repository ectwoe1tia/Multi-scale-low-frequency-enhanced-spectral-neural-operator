package com.bydauto.yunfan.agent.adapter;

import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.contract.*;
import com.bydauto.yunfan.agent.data.*;
import com.bydauto.yunfan.agent.filter.PersistenceProjectionFilter;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class ToolOutputAdapter {
    private final DataWorkspace data;private final ToolResultPolicy fallback;private final PersistenceProjectionFilter filter=new PersistenceProjectionFilter();
    public ToolOutputAdapter(DataWorkspace data,ToolResultPolicy fallback){this.data=data;this.fallback=fallback;}
    public Object normalize(AuthContext actor,String run,ToolContract contract,Object raw,boolean internalDataTool){
        return normalize(actor,run,contract,raw,internalDataTool,Json.map());
    }
    public Object normalize(AuthContext actor,String run,ToolContract contract,Object raw,boolean internalDataTool,Map<String,Object> fingerprints){
        Object selected=raw;for(String key:contract.outputPath()){if(selected instanceof String s)selected=Json.parse(s);selected=Json.object(selected).get(key);if(selected==null)throw ApiException.bad("Tool contract output selector not found");}
        Object result;
        if(contract.exposure()==ToolContract.Exposure.REFERENCE_ONLY){
            if("table".equals(contract.outputKind())&&DataWorkspace.table(selected)==null)throw ApiException.bad("Contract expected a table result");result=data.capture(actor,run,contract.tool(),selected);
        }else if(contract.exposure()==ToolContract.Exposure.BOUNDED_SUMMARY){
            Map<String,Object> projection=Json.map();var source=Json.object(selected);for(String field:contract.summaryFields())if(source.containsKey(field))projection.put(field,source.get(field));
            if(Json.write(projection).getBytes(StandardCharsets.UTF_8).length>contract.maxSummaryBytes()||ToolResultPolicy.claimsReference(projection))result=data.capture(actor,run,contract.tool(),selected);else result=projection;
        }else result=fallback.modelView(actor,run,contract.tool(),selected,internalDataTool);
        var inputs=Json.child(fingerprints,"artifacts").values().stream().map(Json::object).toList();
        if(!inputs.isEmpty()&&result instanceof Map<?,?>){
            var projected=Json.object(Json.copy(result));String completeness=inputs.stream().anyMatch(i->"PARTIAL".equals(i.get("completeness")))?"PARTIAL":inputs.stream().anyMatch(i->!"COMPLETE".equals(i.get("completeness")))?"UNKNOWN":"COMPLETE";
            projected.put("inputCompleteness",completeness);projected.put("completeness",DataWorkspace.combineCompleteness(Json.str(projected,"completeness","COMPLETE"),completeness));
            String artifact=Json.str(projected,"dataRef",Json.str(projected,"artifactId",""));if(!artifact.isBlank())data.provenance(actor,artifact,inputs.stream().map(i->Json.required(i,"artifact_id")).toList(),completeness);result=projected;
        }
        filter.validate(result);return result;
    }
}
