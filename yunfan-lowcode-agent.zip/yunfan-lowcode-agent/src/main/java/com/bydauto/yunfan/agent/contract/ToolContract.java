package com.bydauto.yunfan.agent.contract;

import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.tooling.ToolDefinition;
import java.util.*;

/** Deployment-owned contract. Remote result payloads cannot declare their own trust. */
public record ToolContract(String tool,String version,Map<String,Object> logicalSchema,List<Binding> bindings,
                           Exposure exposure,List<String> outputPath,Set<String> summaryFields,int maxSummaryBytes,String outputKind) {
    public enum Exposure { AUTO, REFERENCE_ONLY, BOUNDED_SUMMARY }
    public enum Mode { HANDLE, BOUNDED_INLINE }
    public record Binding(String field,String wireField,Mode mode,int maxBytes,boolean requireComplete) {}
    public ToolContract {
        logicalSchema=Json.object(Json.copy(logicalSchema));bindings=List.copyOf(bindings);outputPath=List.copyOf(outputPath);summaryFields=Set.copyOf(summaryFields);
        if(maxSummaryBytes<128||maxSummaryBytes>2600||!Set.of("table","file","value").contains(outputKind))throw ApiException.bad("Invalid tool contract limits/type");
        Set<String> names=new HashSet<>(),targets=new HashSet<>();
        for(var b:bindings)if(b.field()==null||b.field().isBlank()||b.wireField()==null||b.wireField().isBlank()||b.mode()==null||!names.add(b.field())||!targets.add(b.wireField())||b.maxBytes()<1||b.maxBytes()>32*1024*1024)throw ApiException.bad("Invalid or duplicate artifact binding");
        for(var b:bindings)if(!b.field().equals(b.wireField())&&(names.contains(b.wireField())||Json.child(logicalSchema,"properties").containsKey(b.wireField())))throw ApiException.bad("Artifact wire field collides with a logical input");
    }
    public static ToolContract fallback(ToolDefinition tool){return new ToolContract(tool.name(),tool.version(),tool.schema(),List.of(),Exposure.AUTO,List.of(),Set.of(),2048,"value");}
    public ToolDefinition logical(ToolDefinition source){return new ToolDefinition(source.name(),source.originalName(),source.serverId(),source.description(),logicalSchema,source.risk(),source.base(),source.version(),source.wireSchema());}
    public String hash(){return Util.hash(Json.write(Json.map("tool",tool,"version",version,"schema",logicalSchema,"bindings",bindings.stream().map(b->Json.map("field",b.field(),"wireField",b.wireField(),"mode",b.mode().name(),"maxBytes",b.maxBytes(),"complete",b.requireComplete())).toList(),"exposure",exposure.name(),"path",outputPath,"fields",new TreeSet<>(summaryFields),"summaryBytes",maxSummaryBytes,"outputKind",outputKind)));}
}
