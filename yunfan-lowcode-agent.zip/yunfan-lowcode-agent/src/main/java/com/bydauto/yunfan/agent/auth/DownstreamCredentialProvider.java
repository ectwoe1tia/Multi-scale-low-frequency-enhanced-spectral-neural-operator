package com.bydauto.yunfan.agent.auth;
/** Implement audience-specific credential exchange / refresh here. Never forwards an unvalidated incoming token. */
public interface DownstreamCredentialProvider {
    String resolve(AuthContext context,String serverId,String credentialRef,boolean refresh);
}
