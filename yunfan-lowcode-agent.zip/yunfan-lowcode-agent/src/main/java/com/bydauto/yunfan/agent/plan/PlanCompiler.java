package com.bydauto.yunfan.agent.plan;

import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.contract.*;
import com.bydauto.yunfan.agent.filter.PersistenceProjectionFilter;
import com.bydauto.yunfan.agent.tooling.*;
import java.util.*;

/** Small declarative DAG language; no expression evaluator, code, URLs or arbitrary JSONPath. */
public final class PlanCompiler {
    private final ToolContractRegistry contracts;private final int maxNodes;
    public PlanCompiler(ToolContractRegistry contracts,Config config){this.contracts=contracts;maxNodes=Math.min(32,Math.max(1,config.integer("yunfan.plan.max-nodes",32)));}
    public ExecutionPlan compile(AuthContext actor,Map<String,Object> json,List<ToolDefinition> catalog){
        if(!Set.of("schemaVersion","nodes","result").containsAll(json.keySet())||!"1".equals(Json.str(json,"schemaVersion","1")))bad("Unsupported plan schema");
        if(Json.write(json).length()>24000)bad("Plan size limit");new PersistenceProjectionFilter().validate(json);
        var raw=Json.list(json,"nodes");if(raw.isEmpty()||raw.size()>maxNodes)bad("Plan node limit");Map<String,ExecutionPlan.Node> all=new LinkedHashMap<>();
        for(Object item:raw){var n=Json.object(item);if(!Set.of("id","tool","dependsOn","inputs").containsAll(n.keySet()))bad("Unknown node field");String id=Json.required(n,"id"),name=Json.required(n,"tool");
            if(!id.matches("[A-Za-z][A-Za-z0-9_-]{0,47}")||all.containsKey(id))bad("Invalid or duplicate node ID");
            ToolDefinition tool=catalog.stream().filter(t->t.name().equals(name)).findFirst().orElseThrow(()->new ApiException(403,"PLAN_TOOL_FORBIDDEN","Tool is not in the authorized catalog"));
            if(!actor.allows("tool:"+name)||name.startsWith("runtime__")||name.equals("system__ask_user"))bad("Nested runtime programs/plans and interactive nodes are not supported");
            Set<String> deps=Json.strings(n.get("dependsOn"));var inputs=Json.child(n,"inputs");
            all.put(id,new ExecutionPlan.Node(id,tool,deps,Json.object(Json.copy(inputs)),contracts.get(tool).hash()));
        }
        List<ExecutionPlan.Node> sorted=new ArrayList<>();Set<String> done=new HashSet<>();
        while(sorted.size()<all.size()){boolean progress=false;for(var node:all.values())if(!done.contains(node.id())){
            if(!all.keySet().containsAll(node.dependencies()))bad("Unknown dependency");if(done.containsAll(node.dependencies())){sorted.add(node);done.add(node.id());progress=true;}}
            if(!progress)bad("Cyclic dependency");
        }
        for(var node:sorted){Set<String> ancestors=new HashSet<>();closure(node.id(),all,ancestors);ancestors.remove(node.id());validateRefs(node.inputs(),ancestors,all);validateInputs(node,all);}
        var result=Json.child(json,"result");if(result.isEmpty())bad("Plan requires a final $ref result");if(!result.containsKey("$ref"))bad("Final result must be a reference");validateRefs(result,all.keySet(),all);
        String hash=Util.hash(Json.write(Json.map("plan",json,"contracts",sorted.stream().map(ExecutionPlan.Node::contractHash).toList(),"tools",sorted.stream().map(n->n.tool().snapshot()).toList())));
        return new ExecutionPlan(List.copyOf(sorted),Json.object(Json.copy(result)),hash);
    }
    private void validateInputs(ExecutionPlan.Node node,Map<String,ExecutionPlan.Node> nodes){
        var schema=node.tool().schema();Set<String> required=Json.strings(schema.get("required"));if(!node.inputs().keySet().containsAll(required))bad("Missing required node inputs");
        var props=Json.child(schema,"properties");if(Boolean.FALSE.equals(schema.get("additionalProperties"))&&!props.keySet().containsAll(node.inputs().keySet()))bad("Unknown node input");
        for(var e:node.inputs().entrySet())if(!containsRef(e.getValue())&&props.containsKey(e.getKey()))new JsonSchemaValidator().validate(e.getValue(),Json.object(props.get(e.getKey())));
        var bindings=contracts.get(node.tool()).bindings();
        for(var entry:node.inputs().entrySet()){
            boolean binding=bindings.stream().anyMatch(b->b.field().equals(entry.getKey()));
            if(containsArtifactRef(entry.getValue())&&(!isArtifactRef(entry.getValue())||!binding))bad("Artifact references must be direct values of declared artifact input bindings");
            if(!(entry.getValue() instanceof Map<?,?> m)||!m.containsKey("$ref"))continue;
            var ref=Json.object(m.get("$ref"));String output=Json.str(ref,"output","");
            if(binding&&!isArtifactRef(entry.getValue()))bad("Artifact inputs require an artifact output port");
            if(!output.isBlank()&&output.equals("dataset")){var producer=nodes.get(Json.required(ref,"node"));if("file".equals(contracts.get(producer.tool()).outputKind()))bad("File output cannot bind to a table input");}
        }
    }
    private boolean isArtifactRef(Object value){if(!(value instanceof Map<?,?> m)||!m.containsKey("$ref"))return false;var ref=Json.object(m.get("$ref"));return ref.containsKey("artifact_id")||Set.of("dataset","file").contains(Json.str(ref,"output",""));}
    private boolean containsArtifactRef(Object value){if(isArtifactRef(value))return true;if(value instanceof Map<?,?> m)return m.values().stream().anyMatch(this::containsArtifactRef);if(value instanceof List<?> l)return l.stream().anyMatch(this::containsArtifactRef);return false;}
    private boolean containsRef(Object v){if(v instanceof Map<?,?> m)return m.containsKey("$ref")||m.values().stream().anyMatch(this::containsRef);if(v instanceof List<?> l)return l.stream().anyMatch(this::containsRef);return false;}
    private void validateRefs(Object value,Set<String> allowed,Map<String,ExecutionPlan.Node> all){
        if(value instanceof Map<?,?> map){if(map.containsKey("$ref")){
            if(map.size()!=1)bad("Reference object must contain only $ref");var ref=Json.object(map.get("$ref"));
            if(ref.containsKey("artifact_id")){if(ref.size()!=1)bad("Invalid artifact reference");Json.required(ref,"artifact_id");}
            else{if(!ref.keySet().equals(Set.of("node","output"))||!allowed.contains(Json.required(ref,"node")))bad("Reference must point to an ancestor output");if(!Set.of("dataset","file","summary","result").contains(Json.required(ref,"output")))bad("Unknown output port");}
        }else for(Object child:map.values())validateRefs(child,allowed,all);
        }else if(value instanceof List<?> list)for(Object child:list)validateRefs(child,allowed,all);
    }
    private void closure(String id,Map<String,ExecutionPlan.Node> all,Set<String> out){if(out.add(id))for(String dep:all.get(id).dependencies())closure(dep,all,out);}
    public static void bad(String message){throw new ApiException(422,"PLAN_INVALID",message);}
}
