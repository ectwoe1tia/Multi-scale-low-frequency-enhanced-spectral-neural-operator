package com.bydauto.yunfan.agent.tooling;
import com.bydauto.yunfan.agent.common.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Pattern;
/** Validates the common JSON Schema subset used by tool inputs, including local references. */
public final class JsonSchemaValidator {
    public void validate(Object value,Map<String,Object> schema) {
        check(value,schema,schema,"$",0);
    }
    private void check(Object v,Map<String,Object> s,Map<String,Object> root,String path,int depth) {
        if(depth>40)throw ApiException.bad("Schema recursion too deep");
        if(s.containsKey("$ref")) {
            String ref=Json.required(s,"$ref");
            if(!ref.startsWith("#/"))throw ApiException.bad("Only local tool schema references are supported");
            Object resolved=root;
            for(String key:ref.substring(2).split("/"))resolved=Json.object(resolved).get(key.replace("~1","/").replace("~0","~"));
            if(resolved==null)throw ApiException.bad("Unresolved schema reference");
            check(v,Json.object(resolved),root,path,depth+1);
        }
        if(s.containsKey("const")&&!Util.canonical(v).equals(Util.canonical(s.get("const"))))bad(path,"constant mismatch");
        if(s.containsKey("enum")&&Json.array(s.get("enum")).stream().noneMatch(x->Util.canonical(x).equals(Util.canonical(v))))bad(path,"not in enum");
        for(String mode:List.of("allOf","anyOf","oneOf"))if(s.containsKey(mode)) {
            int matches=0;
            List<Object> variants=Json.array(s.get(mode));
            for(Object variant:variants)try {
                check(v,Json.object(variant),root,path,depth+1);
                matches++;
            } catch(ApiException ignored) {
            }
            if(mode.equals("allOf")&&matches!=variants.size()||mode.equals("anyOf")&&matches==0||mode.equals("oneOf")&&matches!=1)bad(path,mode+" mismatch");
        }
        if(s.containsKey("not")) {
            boolean matches=true;
            try {
                check(v,Json.object(s.get("not")),root,path,depth+1);
            } catch(ApiException e) {
                matches=false;
            }
            if(matches)bad(path,"forbidden schema");
        }
        Object type=s.get("type");
        if(type!=null) {
            List<?> types=type instanceof List<?> l?l:List.of(type);
            if(types.stream().noneMatch(t->matches(v,t.toString())))bad(path,"wrong type "+type);
        }
        if(v instanceof Map<?,?>) {
            Map<String,Object> object=Json.object(v),properties=Json.child(s,"properties");
            for(Object req:Json.list(s,"required"))if(!object.containsKey(req.toString()))bad(path,"missing "+req);
            for(var e:object.entrySet()) {
                if(properties.containsKey(e.getKey()))check(e.getValue(),Json.object(properties.get(e.getKey())),root,path+"."+e.getKey(),depth+1);
                else if(Boolean.FALSE.equals(s.get("additionalProperties")))bad(path,"unknown property "+e.getKey());
                else if(s.get("additionalProperties") instanceof Map<?,?>)check(e.getValue(),Json.object(s.get("additionalProperties")),root,path+"."+e.getKey(),depth+1);
            }
            if(s.containsKey("minProperties")&&object.size()<Json.integer(s,"minProperties",0)||s.containsKey("maxProperties")&&object.size()>Json.integer(s,"maxProperties",0))bad(path,"property count");
        }
        if(v instanceof List<?> list) {
            if(s.containsKey("minItems")&&list.size()<Json.integer(s,"minItems",0)||s.containsKey("maxItems")&&list.size()>Json.integer(s,"maxItems",0))bad(path,"array length");
            if(Json.bool(s,"uniqueItems",false)&&list.stream().map(Util::canonical).distinct().count()!=list.size())bad(path,"array items must be unique");
            if(s.get("items") instanceof Map<?,?>)for(int i=0; i<list.size(); i++)check(list.get(i),Json.object(s.get("items")),root,path+"["+i+"]",depth+1);
        }
        if(v instanceof String text) {
            if(s.containsKey("minLength")&&text.length()<Json.integer(s,"minLength",0)||s.containsKey("maxLength")&&text.length()>Json.integer(s,"maxLength",0))bad(path,"string length");
            if(s.containsKey("pattern")) {
                String pattern=Json.required(s,"pattern");
                if(pattern.length()>256||text.length()>4096)bad(path,"pattern input too large");
                if(!Pattern.compile(pattern).matcher(text).find())bad(path,"pattern mismatch");
            }
        }
        if(v instanceof Number n) {
            BigDecimal number=new BigDecimal(n.toString());
            for(String bound:List.of("minimum","maximum","exclusiveMinimum","exclusiveMaximum"))if(s.containsKey(bound)) {
                int cmp=number.compareTo(new BigDecimal(s.get(bound).toString()));
                if(bound.equals("minimum")&&cmp<0||bound.equals("maximum")&&cmp>0||bound.equals("exclusiveMinimum")&&cmp<=0||bound.equals("exclusiveMaximum")&&cmp>=0)bad(path,bound+" violation");
            }
        }
    }
    private boolean matches(Object v,String type) {
        return switch(type) {
            case "null"->v==null;
            case "object"->v instanceof Map<?,?>;
            case "array"->v instanceof List<?>;
            case "string"->v instanceof String;
            case "boolean"->v instanceof Boolean;
            case "number"->v instanceof Number;
            case "integer"->v instanceof Number n&&new BigDecimal(n.toString()).stripTrailingZeros().scale()<=0;
            default->throw ApiException.bad("Unsupported schema type: "+type);
        } ;
    }
    private void bad(String path,String message) {
        throw new ApiException(422,"TOOL_ARGUMENT_INVALID",path+": "+message);
    }
}
