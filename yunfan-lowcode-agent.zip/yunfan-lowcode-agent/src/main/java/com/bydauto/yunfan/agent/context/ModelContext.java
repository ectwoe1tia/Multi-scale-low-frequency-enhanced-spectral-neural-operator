package com.bydauto.yunfan.agent.context;

import com.bydauto.yunfan.agent.common.Json;
import java.util.*;

/** Ephemeral single-call value, independent of TaskState and persistent memory records. */
public record ModelContext(List<Map<String,Object>> messages,List<Map<String,Object>> tools,int estimatedInputTokens) {
    public ModelContext {messages=messages.stream().map(m->Json.object(Json.copy(m))).toList();tools=tools.stream().map(t->Json.object(Json.copy(t))).toList();}
}
