package com.bydauto.yunfan.agent.common;
import java.sql.*;
import java.util.*;
import java.util.function.Function;
/** Portable PostgreSQL/MySQL document persistence. SQL scripts create the tables and coordinator row. */
public final class JdbcDocumentStore implements DocumentStore {
    private final String url,user,password;
    private final Connection serviceLease;
    public JdbcDocumentStore(String url,String user,String password) {
        this.url=url;
        this.user=user;
        this.password=password;
        Connection candidate=null;
        try {
            candidate=DriverManager.getConnection(url,user,password);
            candidate.setAutoCommit(false);
            try(PreparedStatement p=candidate.prepareStatement("SELECT lock_name FROM agent_store_lock WHERE lock_name='service' FOR UPDATE NOWAIT")) {
                try(ResultSet rows=p.executeQuery()) {
                    if(!rows.next())throw new SQLException("Missing service lock row");
                }
            }
            serviceLease=candidate;
        } catch(SQLException e) {
            if(candidate!=null)try {
                candidate.close();
            }catch(SQLException ignored) {
            }
            throw new IllegalStateException("Cannot acquire exclusive service lease; apply migration and ensure only one active service",e);
        }
    }
    @Override public <T>T transaction(Function<Tx,T> action) {
        try {
            if(serviceLease.isClosed()||!serviceLease.isValid(2))throw new IllegalStateException("Service lease connection was lost; restart this instance");
        }catch(SQLException e) {
            throw new IllegalStateException("Service lease verification failed",e);
        }
        try(Connection c=DriverManager.getConnection(url,user,password)) {
            c.setAutoCommit(false);
            c.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            try(PreparedStatement guard=c.prepareStatement("SELECT lock_name FROM agent_store_lock WHERE lock_name='global' FOR UPDATE")) {
                try(ResultSet rs=guard.executeQuery()) {
                    if(!rs.next())throw new SQLException("Missing store coordinator row; apply SQL migration");
                }
            }
            try {
                Tx tx=new Tx() {
                    public Map<String,Object> get(String kind,String id) {
                        try(PreparedStatement p=c.prepareStatement("SELECT payload FROM agent_document WHERE kind=? AND document_id=?")) {
                            p.setString(1,kind);
                            p.setString(2,id);
                            try(ResultSet rs=p.executeQuery()) {
                                return rs.next()?Json.object(Json.parse(rs.getString(1))):null;
                            }
                        } catch(SQLException e) {
                            throw new IllegalStateException(e);
                        }
                    }
                    public List<Map<String,Object>> list(String kind) {
                        try(PreparedStatement p=c.prepareStatement("SELECT payload FROM agent_document WHERE kind=? ORDER BY document_id")) {
                            p.setString(1,kind);
                            List<Map<String,Object>> out=new ArrayList<>();
                            try(ResultSet rs=p.executeQuery()) {
                                while(rs.next())out.add(Json.object(Json.parse(rs.getString(1))));
                            }
                            return out;
                        } catch(SQLException e) {
                            throw new IllegalStateException(e);
                        }
                    }
                    public void put(String kind,String id,Map<String,Object> value) {
                        try {
                            boolean exists=get(kind,id)!=null;
                            try(PreparedStatement p=c.prepareStatement(exists?"UPDATE agent_document SET payload=? WHERE kind=? AND document_id=?":"INSERT INTO agent_document(payload,kind,document_id) VALUES(?,?,?)")) {
                                p.setString(1,Json.write(value));
                                p.setString(2,kind);
                                p.setString(3,id);
                                p.executeUpdate();
                            }
                        } catch(SQLException e) {
                            throw new IllegalStateException(e);
                        }
                    }
                    public void delete(String kind,String id) {
                        try(PreparedStatement p=c.prepareStatement("DELETE FROM agent_document WHERE kind=? AND document_id=?")) {
                            p.setString(1,kind);
                            p.setString(2,id);
                            p.executeUpdate();
                        } catch(SQLException e) {
                            throw new IllegalStateException(e);
                        }
                    }
                } ;
                T out=action.apply(tx);
                c.commit();
                return out;
            } catch(RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch(SQLException e) {
            throw new IllegalStateException("Database transaction failed",e);
        }
    }
    @Override public void close() {
        try {
            serviceLease.rollback();
            serviceLease.close();
        } catch(SQLException e) {
            throw new IllegalStateException(e);
        }
    }
}
