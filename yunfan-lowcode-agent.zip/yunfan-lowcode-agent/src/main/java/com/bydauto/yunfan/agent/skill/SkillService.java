package com.bydauto.yunfan.agent.skill;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
public final class SkillService {
    private final DocumentStore store;
    private final AuthService auth;
    private final SkillEmbeddingService embeddings;
    private final SkillMdParser parser=new SkillMdParser();
    public SkillService(DocumentStore store,AuthService auth,SkillEmbeddingService embeddings) {
        this.store=store;
        this.auth=auth;
        this.embeddings=embeddings;
    }
    public Map<String,Object> save(AuthContext actor,String id,String markdown) {
        auth.policy.check(actor,"admin",null);
        Map<String,Object> parsed=parser.parse(markdown),meta=Json.child(parsed,"metadata");
        List<Object> vector=null;
        String vectorError=null;
        try {
            vector=embeddings.embed(Json.required(meta,"description")+" "+Json.write(Json.list(meta,"triggerExamples")));
        } catch(RuntimeException e) {
            vectorError="Embedding unavailable; explicit activation remains available";
        }
        final List<Object> embedded=vector;
        final String error=vectorError;
        return store.transaction(tx-> {
            Map<String,Object> prior=id==null?null:tx.get("skill",id);
            if(id!=null&&prior==null)throw ApiException.missing("skill");
            if(prior!=null)auth.policy.check(actor,"admin",prior);
            String key=id==null?Util.id():id;
            int version=prior==null?1:Json.integer(prior,"version",0)+1;
            Map<String,Object> result=Json.map("id",key,"tenantId",actor.tenantId(),"name",meta.get("name"),"description",meta.get("description"),"enabled",prior==null||Json.bool(prior,"enabled",false),"version",version,"metadata",meta,"body",parsed.get("body"),"markdown",markdown,"contentHash",Util.hash(markdown),"embeddingVersion",embeddings.version(),"embeddingStatus",embedded==null?"FAILED":"READY","embedding",embedded,"embeddingError",error,"updatedAt",Util.now());
            tx.put("skill",key,result);
            tx.put("skill-version",key+":"+version,result);
            return publicView(result);
        } );
    }
    public Map<String,Object> importZip(AuthContext actor,byte[] zip) {
        auth.policy.check(actor,"admin",null);
        if(zip.length>4*1024*1024)throw ApiException.bad("ZIP exceeds 4 MiB");
        String markdown=null;
        Map<String,Object> resources=Json.map();
        int count=0,total=0;
        try(ZipInputStream in=new ZipInputStream(new ByteArrayInputStream(zip),StandardCharsets.UTF_8)) {
            ZipEntry e;
            Set<String> names=new HashSet<>();
            while((e=in.getNextEntry())!=null) {
                String name=e.getName().replace('\\','/');
                if(++count>100||name.startsWith("/")||name.contains(":")||Arrays.asList(name.split("/")).contains("..")||!names.add(name))throw ApiException.bad("Unsafe or duplicate ZIP entry");
                if(e.isDirectory())continue;
                byte[] content=in.readNBytes(1024*1024+1);
                total+=content.length;
                if(content.length>1024*1024||total>8*1024*1024)throw ApiException.bad("ZIP expansion limit exceeded");
                if(name.equals("SKILL.md")||name.endsWith("/SKILL.md")) {
                    if(markdown!=null)throw ApiException.bad("ZIP must contain exactly one SKILL.md");
                    markdown=new String(content,StandardCharsets.UTF_8);
                } else resources.put(name,Base64.getEncoder().encodeToString(content));
            }
        } catch(IOException e) {
            throw ApiException.bad("Invalid ZIP file");
        }
        if(markdown==null)throw ApiException.bad("ZIP missing SKILL.md");
        Map<String,Object> skill=save(actor,null,markdown);
        String id=skill.get("id").toString();
        store.put("skill-resources",id,Json.map("id",id,"tenantId",actor.tenantId(),"resources",resources));
        return skill;
    }
    public List<Map<String,Object>> list(AuthContext actor) {
        return rawList(actor).stream().map(SkillService::publicView).toList();
    }
    public List<Map<String,Object>> rawList(AuthContext actor) {
        auth.policy.check(actor,"chat",null);
        return store.list("skill").stream().filter(s->actor.tenantId().equals(s.get("tenantId"))).toList();
    }
    public Map<String,Object> get(AuthContext actor,String id) {
        return publicView(auth.owned(store,"skill",id,actor,"chat"));
    }
    public Map<String,Object> action(AuthContext actor,String id,String action) {
        auth.policy.check(actor,"admin",null);
        if(action.equals("reindex")) {
            Map<String,Object> s=auth.owned(store,"skill",id,actor,"admin");
            List<Object> v=embeddings.embed(Json.required(s,"description")+" "+Json.write(Json.list(Json.child(s,"metadata"),"triggerExamples")));
            return store.transaction(tx-> {
                Map<String,Object> current=tx.get("skill",id);
                if(current==null||!Objects.equals(current.get("contentHash"),s.get("contentHash")))throw ApiException.conflict("RESOURCE_VERSION_CONFLICT","Skill changed during embedding");
                current.put("embedding",v);
                current.put("embeddingVersion",embeddings.version());
                current.put("embeddingStatus","READY");
                current.put("embeddingError",null);
                tx.put("skill",id,current);
                tx.put("skill-version",id+":"+current.get("version"),current);
                return publicView(current);
            } );
        }
        return store.transaction(tx-> {
            Map<String,Object> s=tx.get("skill",id);
            if(s==null)throw ApiException.missing("skill");
            auth.policy.check(actor,"admin",s);
            s.put("enabled",action.equals("enable"));
            tx.put("skill",id,s);
            return publicView(s);
        } );
    }
    public void delete(AuthContext actor,String id) {
        auth.owned(store,"skill",id,actor,"admin");
        store.transaction(tx-> {
            tx.delete("skill",id);
            tx.delete("skill-resources",id);
            return null;
        } );
    }
    public static Map<String,Object> publicView(Map<String,Object> source) {
        Map<String,Object> out=new LinkedHashMap<>(source);
        out.remove("embedding");
        return out;
    }
}
