package com.bydauto.yunfan.agent.tooling;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import java.net.URI;
import java.net.http.HttpRequest;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
/** MCP Streamable HTTP, 2025 protocol family. JSON and SSE RPC responses are both supported. */
public final class McpConnection implements AutoCloseable {
    private record Session(String id,Instant expires) {
    }
    private final Map<String,Session> sessions=new ConcurrentHashMap<>();
    private final AuthService auth;
    private final StdioMcpConnection stdio;
    public McpConnection(AuthService auth) {
        this(auth,null);
    }
    public McpConnection(AuthService auth,com.bydauto.yunfan.agent.process.ProcessSupervisor processes) {
        this.auth=auth;
        this.stdio=processes==null?null:new StdioMcpConnection(processes);
    }
    public Map<String,Object> call(AuthContext actor,Map<String,Object> server,String method,Map<String,Object> params,boolean readOnly) {
        if("stdio".equals(Json.str(server,"transport","http"))) {
            if(stdio==null)throw new ApiException(403,"PROCESS_DISABLED","stdio transport is not configured");
            return stdio.call(actor,server,method,params,readOnly);
        }
        String protocol=Json.str(server,"protocolVersion","2025-11-25");
        if(!Set.of("2025-03-26","2025-06-18","2025-11-25").contains(protocol))throw ApiException.bad("Unsupported MCP protocol; this adapter supports the 2025 Streamable HTTP family");
        String token=auth.credentials.resolve(actor,server.get("id").toString(),Json.str(server,"credentialRef",""),false);
        String key=key(actor,server,token);
        Session session=sessions.get(key);
        if(session==null||session.expires.isBefore(Instant.now()))session=initialize(actor,server,token,key);
        RemoteHttp.Reply[] response= {
            null
        } ;
        Map<String,Object> result=rpc(server,token,session.id,method,params,response);
        if(response[0].status()==401) {
            sessions.remove(key);
            if(!readOnly)throw new ApiException(502,"TOOL_RESULT_UNKNOWN","MCP rejected a write credential; reconcile the operation before retrying");
            String fresh=auth.credentials.resolve(actor,server.get("id").toString(),Json.str(server,"credentialRef",""),true);
            key=key(actor,server,fresh);
            session=initialize(actor,server,fresh,key);
            result=rpc(server,fresh,session.id,method,params,response);
        } else if(response[0].status()==404&&!session.id.isBlank()) {
            sessions.remove(key);
            if(!readOnly)throw new ApiException(502,"TOOL_RESULT_UNKNOWN","MCP session expired during write; reconcile before retrying");
            session=initialize(actor,server,token,key);
            result=rpc(server,token,session.id,method,params,response);
        }
        if(response[0].status()<200||response[0].status()>=300)throw new ApiException(502,readOnly?"MCP_UNAVAILABLE":"TOOL_RESULT_UNKNOWN","MCP HTTP "+response[0].status());
        if(result==null)throw new ApiException(502,readOnly?"MCP_INVALID_RESPONSE":"TOOL_RESULT_UNKNOWN","Missing matching MCP RPC response");
        if(result.containsKey("error"))throw new ApiException(502,"MCP_RPC_ERROR","MCP returned JSON-RPC error "+Json.str(Json.child(result,"error"),"code","unknown"));
        return Json.child(result,"result");
    }
    private String key(AuthContext a,Map<String,Object> s,String token) {
        return Util.hash(s.get("id")+":"+s.get("version")+":"+a.tenantId()+":"+a.userId()+":"+new TreeSet<>(a.permissions())+":"+token);
    }
    private Session initialize(AuthContext actor,Map<String,Object> server,String token,String key) {
        synchronized(sessions) {
            Session prior=sessions.get(key);
            if(prior!=null&&prior.expires.isAfter(Instant.now()))return prior;
            RemoteHttp.Reply[] response= {
                null
            } ;
            Map<String,Object> result=rpc(server,token,"","initialize",Json.map("protocolVersion",Json.str(server,"protocolVersion","2025-11-25"),"capabilities",Json.map(),"clientInfo",Json.map("name","yunfan-lowcode-agent","version","1.0.0")),response);
            if(response[0].status()!=200||result==null||!result.containsKey("result"))throw new ApiException(502,"MCP_INITIALIZATION_FAILED","MCP initialize failed with HTTP "+response[0].status());
            String selected=Json.str(Json.child(result,"result"),"protocolVersion","");
            if(!selected.equals(Json.str(server,"protocolVersion","2025-11-25")))throw new ApiException(502,"MCP_PROTOCOL_MISMATCH","MCP negotiated an unsupported protocol version");
            String id=response[0].headers().firstValue("Mcp-Session-Id").orElse("");
            notifyInitialized(server,token,id);
            Session session=new Session(id,Instant.now().plusSeconds(900));
            if(sessions.size()>256)sessions.clear();
            sessions.put(key,session);
            return session;
        }
    }
    private HttpRequest.Builder builder(Map<String,Object> server,String token,String session) {
        int seconds=Json.integer(server,"timeoutSeconds",30);
        HttpRequest.Builder b=HttpRequest.newBuilder(URI.create(Json.required(server,"url"))).timeout(Duration.ofSeconds(seconds)).header("Accept","application/json, text/event-stream").header("Content-Type","application/json").header("MCP-Protocol-Version",Json.str(server,"protocolVersion","2025-11-25"));
        if(!token.isBlank())b.header("Authorization","Bearer "+token);
        if(!session.isBlank())b.header("Mcp-Session-Id",session);
        return b;
    }
    private Map<String,Object> rpc(Map<String,Object> server,String token,String session,String method,Map<String,Object> params,RemoteHttp.Reply[] response) {
        String id=Util.id();
        List<Map<String,Object>> received=new ArrayList<>();
        HttpRequest req=builder(server,token,session).POST(HttpRequest.BodyPublishers.ofString(Json.write(Json.map("jsonrpc","2.0","id",id,"method",method,"params",params)))).build();
        response[0]=RemoteHttp.send(req,Json.integer(server,"timeoutSeconds",30),data-> {
            if(!data.isBlank()&&!data.equals("[DONE]")) {
                Map<String,Object> message=Json.object(Json.parse(data));
                if(id.equals(message.get("id"))) {
                    received.add(message);
                    throw new RemoteHttp.StreamComplete();
                }
            }
        } );
        if(!response[0].text().isBlank()&&response[0].status()>=200&&response[0].status()<300) {
            Map<String,Object> message=Json.object(Json.parse(response[0].text()));
            if(id.equals(message.get("id")))received.add(message);
        }
        if(received.size()>1)throw new ApiException(502,"MCP_INVALID_RESPONSE","Duplicate matching JSON-RPC response");
        return received.isEmpty()?null:received.get(0);
    }
    private void notifyInitialized(Map<String,Object> server,String token,String session) {
        RemoteHttp.Reply r=RemoteHttp.send(builder(server,token,session).POST(HttpRequest.BodyPublishers.ofString(Json.write(Json.map("jsonrpc","2.0","method","notifications/initialized")))).build(),Json.integer(server,"timeoutSeconds",30),s-> {
        } );
        if(r.status()<200||r.status()>=300)throw new ApiException(502,"MCP_INITIALIZATION_FAILED","MCP initialized notification rejected");
    }
    public void invalidate() {
        sessions.clear();
        if(stdio!=null)stdio.close();
    }
    @Override public void close() {invalidate();}
}
