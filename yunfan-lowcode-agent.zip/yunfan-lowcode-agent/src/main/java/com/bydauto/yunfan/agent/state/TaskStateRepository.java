package com.bydauto.yunfan.agent.state;

import com.bydauto.yunfan.agent.auth.AuthContext;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.filter.PersistenceProjectionFilter;
import java.util.*;

/** Independent task checkpoints: no chat messages and no bound data arguments. */
public final class TaskStateRepository {
    public record TaskState(String id,String runId,String status,List<Map<String,Object>> nodes,Map<String,Object> outputs) {}
    private final DocumentStore store;private final PersistenceProjectionFilter filter=new PersistenceProjectionFilter();
    public TaskStateRepository(DocumentStore store){this.store=store;}
    public Map<String,Object> get(AuthContext actor,String id){var value=store.get("task-state",id);if(value==null||!actor.tenantId().equals(value.get("tenantId"))||!actor.userId().equals(value.get("userId")))throw ApiException.missing("task state");return value;}
    public void save(AuthContext actor,TaskState state,String planHash){
        for(var node:state.nodes())filter.validate(node);filter.validate(state.outputs());
        var checkpoint=Json.map("id",state.id(),"runId",state.runId(),"tenantId",actor.tenantId(),"userId",actor.userId(),"status",state.status(),"nodes",state.nodes(),"outputs",state.outputs(),"planHash",planHash,"updatedAt",Util.now());
        checkpoint.put("nextNode",state.nodes().stream().filter(n->Set.of("PENDING","READY","RUNNING","WAITING_CONFIRMATION").contains(Json.str(n,"status",""))).map(n->n.get("id")).findFirst().orElse(null));store.put("task-state",state.id(),checkpoint);
    }
    public List<Map<String,Object>> forRun(AuthContext actor,String runId){return store.list("task-state").stream().filter(s->runId.equals(s.get("runId"))&&actor.tenantId().equals(s.get("tenantId"))&&actor.userId().equals(s.get("userId"))).toList();}
    public Map<String,Object> projection(AuthContext actor,String runId){var states=forRun(actor,runId).stream().filter(s->!runId.equals(s.get("id"))).toList();return Json.map("tasks",states.stream().skip(Math.max(0,states.size()-3)).map(s->Json.map("taskId",s.get("id"),"status",s.get("status"),"completedNodes",Json.list(s,"nodes").stream().map(Json::object).filter(n->"SUCCEEDED".equals(n.get("status"))).count(),"blockedNodes",Json.list(s,"nodes").stream().map(Json::object).filter(n->!"SUCCEEDED".equals(n.get("status"))).map(n->Json.map("id",n.get("id"),"status",n.get("status"))).limit(4).toList())).toList());}
}
