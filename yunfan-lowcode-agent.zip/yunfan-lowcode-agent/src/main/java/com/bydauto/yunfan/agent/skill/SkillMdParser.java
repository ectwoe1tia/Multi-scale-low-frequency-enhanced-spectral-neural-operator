package com.bydauto.yunfan.agent.skill;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
/** Deliberately bounded front matter subset: scalars, inline arrays and block string lists. */
public final class SkillMdParser {
    public Map<String,Object> parse(String markdown) {
        String normalized=markdown.replace("\r\n","\n");
        if(!normalized.startsWith("---\n"))throw ApiException.bad("SKILL.md requires YAML front matter");
        int end=normalized.indexOf("\n---\n",4);
        if(end<0)throw ApiException.bad("Unterminated SKILL.md front matter");
        Map<String,Object> meta=Json.map();
        String listKey=null;
        for(String raw:normalized.substring(4,end).split("\n")) {
            String line=raw.strip();
            if(line.isBlank()||line.startsWith("#"))continue;
            if(line.startsWith("- ")) {
                if(listKey==null)throw ApiException.bad("List item without field");
                Json.array(meta.get(listKey)).add(unquote(line.substring(2).strip()));
                continue;
            }
            int colon=line.indexOf(':');
            if(colon<1)throw ApiException.bad("Unsupported YAML front matter line");
            String key=line.substring(0,colon).strip(),v=line.substring(colon+1).strip();
            if(!Set.of("name","description","version","tags","allowedTools","triggerExamples","priority","requiresConfirmation").contains(key))throw ApiException.bad("Unknown skill front matter field: "+key);
            if(meta.containsKey(key))throw ApiException.bad("Duplicate skill field: "+key);
            listKey=null;
            if(v.isEmpty()) {
                meta.put(key,new ArrayList<>());
                listKey=key;
            } else if(v.startsWith("[")) {
                if(!v.endsWith("]"))throw ApiException.bad("Unterminated array");
                List<Object> items=new ArrayList<>();
                String inner=v.substring(1,v.length()-1).strip();
                if(!inner.isEmpty())for(String item:inner.split(","))items.add(unquote(item.strip()));
                meta.put(key,items);
            } else if(key.equals("priority")) {
                try {
                    meta.put(key,Integer.parseInt(v));
                } catch(NumberFormatException e) {
                    throw ApiException.bad("priority must be integer");
                }
            } else if(key.equals("requiresConfirmation")) {
                if(!v.equals("true")&&!v.equals("false"))throw ApiException.bad("requiresConfirmation must be boolean");
                meta.put(key,Boolean.parseBoolean(v));
            } else meta.put(key,unquote(v));
        }
        Json.required(meta,"name");
        Json.required(meta,"description");
        for(String field:List.of("allowedTools","tags","triggerExamples"))if(meta.containsKey(field))Json.strings(meta.get(field));
        String body=normalized.substring(end+5).strip();
        if(body.isBlank())throw ApiException.bad("Skill body is empty");
        return Json.map("metadata",meta,"body",body,"markdown",markdown);
    }
    private String unquote(String s) {
        if(s.length()>=2&&((s.startsWith("\"")&&s.endsWith("\""))||(s.startsWith("'")&&s.endsWith("'"))))return s.substring(1,s.length()-1);
        if(s.startsWith("&")||s.startsWith("*")||s.startsWith("!")||s.equals("|")||s.equals(">"))throw ApiException.bad("YAML tags, anchors and block scalars are not supported");
        return s;
    }
}
