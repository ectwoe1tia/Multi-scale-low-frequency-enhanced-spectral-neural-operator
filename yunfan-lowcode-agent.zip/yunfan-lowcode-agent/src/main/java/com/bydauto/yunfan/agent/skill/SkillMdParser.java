package com.bydauto.yunfan.agent.skill;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;

/** Bounded YAML subset; fenced code is never implicitly executed. */
public final class SkillMdParser {
    private static final Set<String> LISTS=Set.of("allowedTools","tags","triggerExamples");
    private static final Set<String> FIELDS=Set.of("name","description","version","tags","allowedTools","triggerExamples","priority","requiresConfirmation","type","runtime","entrypoint","timeoutSeconds","license","compatibility");
    public Map<String,Object> parse(String markdown) {
        if(markdown.length()>65536)throw ApiException.bad("SKILL.md exceeds 64 Ki characters");
        String normalized=markdown.replace("\r\n","\n").replace('\r','\n');
        if(normalized.startsWith("\uFEFF"))normalized=normalized.substring(1);
        if(!normalized.startsWith("---\n"))throw ApiException.bad("SKILL.md requires YAML front matter");
        int end=normalized.indexOf("\n---\n",4);
        if(end<0)throw ApiException.bad("Unterminated SKILL.md front matter");
        String[] lines=normalized.substring(4,end).split("\n",-1);
        Map<String,Object> meta=Json.map();
        for(int i=0;i<lines.length;i++) {
            String raw=lines[i],line=raw.strip();
            if(line.isBlank()||line.startsWith("#"))continue;
            if(Character.isWhitespace(raw.charAt(0)))throw ApiException.bad("Unexpected front matter indentation");
            int colon=line.indexOf(':');
            if(colon<1)throw ApiException.bad("Unsupported YAML front matter line");
            String key=line.substring(0,colon).strip(),v=line.substring(colon+1).strip();
            if(key.equals("allowed-tools"))key="allowedTools";
            if(!FIELDS.contains(key))throw ApiException.bad("Unknown skill front matter field: "+key);
            if(meta.containsKey(key))throw ApiException.bad("Duplicate skill field: "+key);
            if(Set.of("|",">","|-",">-").contains(v)) {
                if(LISTS.contains(key)||Set.of("priority","timeoutSeconds","requiresConfirmation").contains(key))throw ApiException.bad("This field cannot use a block scalar");
                List<String> block=new ArrayList<>();
                int indent=-1;
                while(i+1<lines.length&&(lines[i+1].isBlank()||lines[i+1].startsWith(" "))) {
                    String next=lines[++i];
                    if(next.isBlank()){block.add("");continue;}
                    int spaces=next.length()-next.stripLeading().length();
                    if(indent<0)indent=spaces;
                    if(spaces<indent)throw ApiException.bad("Inconsistent block scalar indentation");
                    block.add(next.substring(indent));
                }
                meta.put(key,String.join(v.startsWith(">")?" ":"\n",block).strip());
            } else if(LISTS.contains(key)) {
                List<Object> items=new ArrayList<>();
                if(v.isEmpty()) {
                    while(i+1<lines.length&&lines[i+1].strip().startsWith("- "))items.add(scalar(lines[++i].strip().substring(2).strip()));
                } else {
                    if(!v.startsWith("[")||!v.endsWith("]"))throw ApiException.bad(key+" must be a list");
                    String inner=v.substring(1,v.length()-1);
                    char quote=0;boolean escape=false;StringBuilder item=new StringBuilder();
                    for(int j=0;j<inner.length();j++) {
                        char c=inner.charAt(j);
                        if(c==','&&quote==0) {items.add(scalar(item.toString().strip()));item.setLength(0);continue;}
                        item.append(c);
                        if(escape){escape=false;continue;}
                        if(c=='\\'&&quote=='"'){escape=true;continue;}
                        if(c==quote)quote=0;else if(quote==0&&(c=='\''||c=='"'))quote=c;
                    }
                    if(quote!=0)throw ApiException.bad("Unterminated quoted list item");
                    if(!item.toString().isBlank())items.add(scalar(item.toString().strip()));
                }
                meta.put(key,items);
            } else if(key.equals("priority")||key.equals("timeoutSeconds")) {
                try {meta.put(key,Integer.parseInt(v));}catch(NumberFormatException e){throw ApiException.bad(key+" must be integer");}
            } else if(key.equals("requiresConfirmation")) {
                if(!Set.of("true","false").contains(v))throw ApiException.bad("requiresConfirmation must be boolean");
                meta.put(key,Boolean.parseBoolean(v));
            } else meta.put(key,scalar(v));
        }
        Json.required(meta,"name");Json.required(meta,"description");
        String type=Json.str(meta,"type","text");
        if(!Set.of("text","script").contains(type))throw ApiException.bad("Skill type must be text or script");
        meta.put("type",type);
        if(type.equals("script")) {
            if(!Json.required(meta,"runtime").matches("[A-Za-z0-9_-]{1,48}"))throw ApiException.bad("Invalid runtime command profile");
            validatePath(Json.required(meta,"entrypoint"));
            int timeout=Json.integer(meta,"timeoutSeconds",30);
            if(timeout<1||timeout>120)throw ApiException.bad("Script timeoutSeconds must be 1..120");
            meta.put("requiresConfirmation",true);
        } else if(meta.containsKey("entrypoint")||meta.containsKey("runtime"))throw ApiException.bad("Only script skills may declare runtime/entrypoint");
        String body=normalized.substring(end+5).strip();
        if(body.isBlank())throw ApiException.bad("Skill body is empty");
        return Json.map("metadata",meta,"body",body,"markdown",markdown);
    }
    public static void validatePath(String path) {
        if(path.isBlank()||path.length()>240||path.startsWith("/")||path.contains("\\")||path.contains(":")||path.chars().anyMatch(c->c<32||"<>\"|?*".indexOf(c)>=0))throw ApiException.bad("Unsafe skill resource path");
        for(String part:path.split("/",-1))if(part.isBlank()||part.equals(".")||part.equals("..")||part.endsWith(".")||part.endsWith(" ")||part.matches("(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\\..*)?"))throw ApiException.bad("Unsafe skill resource path");
    }
    private String scalar(String s) {
        if(s.startsWith("\"")) {
            Object value=Json.parse(s);
            if(!(value instanceof String))throw ApiException.bad("Expected quoted string");
            return value.toString();
        }
        if(s.startsWith("'")) {
            if(s.length()<2||!s.endsWith("'"))throw ApiException.bad("Unterminated string");
            return s.substring(1,s.length()-1).replace("''","'");
        }
        if(s.startsWith("&")||s.startsWith("*")||s.startsWith("!")||s.startsWith("{")||s.startsWith("["))throw ApiException.bad("YAML tags, anchors and nested structures are not supported");
        int comment=s.indexOf(" #");
        return (comment<0?s:s.substring(0,comment)).strip();
    }
}
