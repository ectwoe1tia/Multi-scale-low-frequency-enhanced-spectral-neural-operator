package com.bydauto.yunfan.agent.plan;

import com.bydauto.yunfan.agent.auth.AuthContext;
import java.util.*;

/** Deployment-owned extension. Throw ApiException to reject; implementations must not execute tools. */
public interface PlannerPolicy {
    default void validatePlan(AuthContext actor,Map<String,Object> request,ExecutionPlan plan) {}
    default void validateCompletion(AuthContext actor,Map<String,Object> request,List<Map<String,Object>> evidence) {}
}
