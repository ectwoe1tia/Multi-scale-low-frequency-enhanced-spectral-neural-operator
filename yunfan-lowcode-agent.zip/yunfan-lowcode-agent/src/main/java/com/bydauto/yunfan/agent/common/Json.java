package com.bydauto.yunfan.agent.common;
import java.math.BigDecimal;
import java.util.*;
/** Small, strict JSON codec used by the dependency-free runtime. Never evaluates input. */
public final class Json {
    private Json() {
    }
    public static Object parse(String text) {
        return new Parser(text).parse();
    }
    @SuppressWarnings("unchecked") public static Map<String,Object> object(Object value) {
        if (!(value instanceof Map<?,?>)) throw ApiException.bad("Expected JSON object");
        return (Map<String,Object>) value;
    }
    @SuppressWarnings("unchecked") public static List<Object> array(Object value) {
        if (!(value instanceof List<?>)) throw ApiException.bad("Expected JSON array");
        return (List<Object>) value;
    }
    public static Map<String,Object> map(Object... pairs) {
        Map<String,Object> out = new LinkedHashMap<>();
        for (int i=0; i<pairs.length; i+=2) out.put((String)pairs[i], pairs[i+1]);
        return out;
    }
    public static String str(Map<String,Object> m, String key, String fallback) {
        Object v=m.get(key);
        return v==null ? fallback : String.valueOf(v);
    }
    public static String required(Map<String,Object> m,String key) {
        String v=str(m,key,"").strip();
        if(v.isEmpty()) throw ApiException.bad(key+" is required");
        return v;
    }
    public static int integer(Map<String,Object> m,String key,int fallback) {
        Object v=m.get(key);
        if(v==null)return fallback;
        try {
            return new BigDecimal(v.toString()).intValueExact();
        } catch(Exception e) {
            throw ApiException.bad(key+" must be an integer");
        }
    }
    public static boolean bool(Map<String,Object> m,String key,boolean fallback) {
        Object v=m.get(key);
        if(v==null)return fallback;
        if(v instanceof Boolean b)return b;
        throw ApiException.bad(key+" must be boolean");
    }
    public static Map<String,Object> child(Map<String,Object> m,String key) {
        return m.get(key)==null?map():object(m.get(key));
    }
    public static List<Object> list(Map<String,Object> m,String key) {
        return m.get(key)==null?new ArrayList<>():array(m.get(key));
    }
    public static Set<String> strings(Object value) {
        Set<String> out=new LinkedHashSet<>();
        if(value==null)return out;
        for(Object item:array(value)) {
            if(!(item instanceof String s))throw ApiException.bad("Expected array of strings");
            out.add(s);
        }
        return out;
    }
    public static Object copy(Object value) {
        return parse(write(value));
    }
    public static String write(Object value) {
        StringBuilder out=new StringBuilder();
        encode(value,out);
        return out.toString();
    }
    private static void encode(Object v,StringBuilder out) {
        if(v==null) {
            out.append("null");
            return;
        }
        if(v instanceof String || v instanceof Enum<?>) {
            quote(v.toString(),out);
            return;
        }
        if(v instanceof Number n) {
            if(n instanceof Double d && !Double.isFinite(d) || n instanceof Float f && !Float.isFinite(f))throw new IllegalArgumentException("Non-finite JSON number");
            out.append(n);
            return;
        }
        if(v instanceof Boolean) {
            out.append(v);
            return;
        }
        if(v instanceof Map<?,?> m) {
            out.append('{');
            boolean comma=false;
            for(var e:m.entrySet()) {
                if(comma)out.append(',');
                quote(e.getKey().toString(),out);
                out.append(':');
                encode(e.getValue(),out);
                comma=true;
            }
            out.append('}');
            return;
        }
        if(v instanceof Iterable<?> list) {
            out.append('[');
            boolean comma=false;
            for(Object item:list) {
                if(comma)out.append(',');
                encode(item,out);
                comma=true;
            }
            out.append(']');
            return;
        }
        throw new IllegalArgumentException("Unsupported JSON type: "+v.getClass());
    }
    private static void quote(String s,StringBuilder out) {
        out.append('"');
        for(int i=0; i<s.length(); i++) {
            char c=s.charAt(i);
            switch(c) {
                case '"'->out.append("\\\"");
                case '\\'->out.append("\\\\");
                case '\n'->out.append("\\n");
                case '\r'->out.append("\\r");
                case '\t'->out.append("\\t");
                case '\b'->out.append("\\b");
                case '\f'->out.append("\\f");
                default-> {
                    if(c<32)out.append(String.format("\\u%04x",(int)c));
                    else out.append(c);
                }
            }
        }
        out.append('"');
    }
    private static final class Parser {
        final String s;
        int p;
        int depth;
        Parser(String s) {
            this.s=Objects.requireNonNull(s);
            if(s.length()>256*1024*1024)throw ApiException.bad("JSON too large");
        }
        Object parse() {
            Object value=value();
            ws();
            if(p!=s.length())fail();
            return value;
        }
        void ws() {
            while(p<s.length()&&" \n\r\t".indexOf(s.charAt(p))>=0)p++;
        }
        void fail() {
            throw ApiException.bad("Malformed JSON at offset "+p);
        }
        Object value() {
            ws();
            if(++depth>100)throw ApiException.bad("JSON nesting too deep");
            try {
                if(p==s.length()) {
                    fail();
                }
                char c=s.charAt(p);
                if(c=='"')return string();
                if(c=='{')return object();
                if(c=='[')return array();
                for(String literal:List.of("true","false","null")) {
                    if(s.startsWith(literal,p)) {
                        p+=literal.length();
                        return literal.equals("null")?null:literal.equals("true");
                    }
                }
                return number();
            } finally {
                depth--;
            }
        }
        String string() {
            p++;
            StringBuilder out=new StringBuilder();
            while(p<s.length()) {
                char c=s.charAt(p++);
                if(c=='"')return out.toString();
                if(c<32)fail();
                if(c=='\\') {
                    if(p==s.length())fail();
                    char e=s.charAt(p++);
                    switch(e) {
                        case '"','\\','/'->out.append(e);
                        case 'b'->out.append('\b');
                        case 'f'->out.append('\f');
                        case 'n'->out.append('\n');
                        case 'r'->out.append('\r');
                        case 't'->out.append('\t');
                        case 'u'-> {
                            if(p+4>s.length())fail();
                            try {
                                out.append((char)Integer.parseInt(s.substring(p,p+4),16));
                            } catch(Exception x) {
                                fail();
                            }
                            p+=4;
                        }
                        default->fail();
                    }
                } else out.append(c);
            }
            fail();
            return null;
        }
        Map<String,Object> object() {
            p++;
            Map<String,Object> out=map();
            ws();
            if(take('}'))return out;
            do {
                ws();
                if(p==s.length()||s.charAt(p)!='"')fail();
                String key=string();
                ws();
                if(!take(':')||out.containsKey(key))fail();
                out.put(key,value());
                ws();
                if(take('}'))return out;
            }
            while(take(','));
            fail();
            return out;
        }
        List<Object> array() {
            p++;
            List<Object> out=new ArrayList<>();
            ws();
            if(take(']'))return out;
            do {
                out.add(value());
                ws();
                if(take(']'))return out;
            }
            while(take(','));
            fail();
            return out;
        }
        boolean take(char c) {
            if(p<s.length()&&s.charAt(p)==c) {
                p++;
                return true;
            }
            return false;
        }
        Number number() {
            int start=p;
            if(take('-')) {
            }
            if(!take('0')) {
                if(p==s.length()||s.charAt(p)<'1'||s.charAt(p)>'9')fail();
                while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;
            }
            if(take('.'))digits();
            if(p<s.length()&&(s.charAt(p)=='e'||s.charAt(p)=='E')) {
                p++;
                if(p<s.length()&&(s.charAt(p)=='+'||s.charAt(p)=='-'))p++;
                digits();
            }
            try {
                return new BigDecimal(s.substring(start,p));
            } catch(Exception e) {
                fail();
                return 0;
            }
        }
        void digits() {
            int start=p;
            while(p<s.length()&&s.charAt(p)>='0'&&s.charAt(p)<='9')p++;
            if(start==p)fail();
        }
    }
}
