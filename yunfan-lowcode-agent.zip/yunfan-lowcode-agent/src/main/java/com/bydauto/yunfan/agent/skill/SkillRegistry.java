package com.bydauto.yunfan.agent.skill;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
public final class SkillRegistry {
    public record Selection(List<Map<String,Object>> skills,Map<String,String> reasons,String retrievalMode) {
    }
    private final SkillService service;
    private final SkillEmbeddingService embeddings;
    private final Config config;
    public SkillRegistry(SkillService service,SkillEmbeddingService embeddings,Config config) {
        this.service=service;
        this.embeddings=embeddings;
        this.config=config;
    }
    public Selection select(AuthContext actor,Set<String> explicit,String query) {
        List<Map<String,Object>> all=service.rawList(actor);
        Map<String,Map<String,Object>> selected=new LinkedHashMap<>();
        Map<String,String> reasons=new LinkedHashMap<>();
        for(String id:explicit) {
            var s=all.stream().filter(x->id.equals(x.get("id"))).findFirst().orElseThrow(()->ApiException.missing("skill "+id));
            if(!Json.bool(s,"enabled",false))throw ApiException.bad("Explicit skill disabled: "+id);
            selected.put(id,s);
            reasons.put(id,"explicit");
        }
        String mode=embeddings.version();
        try {
            List<Object> q=embeddings.embed(query);
            List<Map<String,Object>> candidates=new ArrayList<>();
            for(var s:all)if(Json.bool(s,"enabled",false)&&mode.equals(s.get("embeddingVersion"))&&s.get("embedding")!=null) {
                double score=SkillEmbeddingService.cosine(q,Json.array(s.get("embedding")));
                if(score>=Double.parseDouble(config.get("yunfan.skill.similarity-threshold","0.30"))) {
                    Map<String,Object> copy=new LinkedHashMap<>(s);
                    copy.put("matchScore",score);
                    candidates.add(copy);
                }
            }
            candidates.sort(Comparator.<Map<String,Object>>comparingDouble(s->((Number)s.get("matchScore")).doubleValue()).reversed().thenComparing(s->s.get("id").toString()));
            int top=config.integer("yunfan.skill.top-k",3);
            for(var s:candidates.subList(0,Math.min(top,candidates.size()))) {
                String id=s.get("id").toString();
                if(selected.putIfAbsent(id,s)==null)reasons.put(id,"similarity:"+s.get("matchScore"));
            }
        } catch(RuntimeException e) {
            mode="unavailable-explicit-only";
        }
        List<Map<String,Object>> result=new ArrayList<>(selected.values());
        result.sort(Comparator.<Map<String,Object>>comparingInt(s->explicit.contains(s.get("id"))?0:1).thenComparing(Comparator.comparingInt((Map<String,Object> s)->Json.integer(Json.child(s,"metadata"),"priority",0)).reversed()).thenComparing(s->s.get("id").toString()));
        return new Selection(result,reasons,mode);
    }
}
