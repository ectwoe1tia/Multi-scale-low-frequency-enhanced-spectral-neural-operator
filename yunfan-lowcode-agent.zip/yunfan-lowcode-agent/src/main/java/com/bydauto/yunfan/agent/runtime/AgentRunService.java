package com.bydauto.yunfan.agent.runtime;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.audit.AuditService;
import com.bydauto.yunfan.agent.chat.*;
import com.bydauto.yunfan.agent.common.*;
import com.bydauto.yunfan.agent.modelconfig.*;
import com.bydauto.yunfan.agent.session.SessionStore;
import com.bydauto.yunfan.agent.skill.*;
import com.bydauto.yunfan.agent.tooling.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
/** The single orchestration loop shared by synchronous, SSE and structured governance requests. */
public final class AgentRunService implements AutoCloseable {
    public static final Set<String> TERMINAL=Set.of("COMPLETED","FAILED","CANCELLED","EXPIRED","RECONCILIATION_REQUIRED");
    private final DocumentStore store;
    private final AuthService auth;
    private final SessionStore sessions;
    private final ModelConfigService models;
    private final ModelClientFactory clients;
    private final SkillRegistry skills;
    private final ToolExecutionService tools;
    private final AuditService audit;
    private final Config config;
    public final RunContextService context;
    public final com.bydauto.yunfan.agent.plan.TaskPlanner planner;
    private final ThreadPoolExecutor executor;
    private final ScheduledExecutorService watchdog;
    private final ConcurrentHashMap<String,FutureTask<Void>> tasks=new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String,Long> activeSince=new ConcurrentHashMap<>();
    private int cleanupTicks;
    public AgentRunService(DocumentStore store,AuthService auth,SessionStore sessions,ModelConfigService models,ModelClientFactory clients,SkillRegistry skills,ToolExecutionService tools,AuditService audit,Config config) {
        this.store=store;
        this.auth=auth;
        this.sessions=sessions;
        this.models=models;
        this.clients=clients;
        this.skills=skills;
        this.tools=tools;
        this.audit=audit;
        this.config=config;
        this.context=new RunContextService(store,auth,sessions,config);
        this.planner=new com.bydauto.yunfan.agent.plan.TaskPlanner(store,tools,config);this.context.taskPlanner=planner;
        executor=new ThreadPoolExecutor(config.integer("yunfan.agent.workers",4),config.integer("yunfan.agent.workers",4),0,TimeUnit.SECONDS,new ArrayBlockingQueue<>(64),r->new Thread(r,"agent-worker"),new ThreadPoolExecutor.AbortPolicy());
        watchdog=Executors.newSingleThreadScheduledExecutor(r-> {
            Thread t=new Thread(r,"agent-watchdog");
            t.setDaemon(true);
            return t;
        } );
        recover();
        watchdog.scheduleAtFixedRate(this::expire,1,1,TimeUnit.SECONDS);
    }
    public Map<String,Object> start(AuthContext actor,Map<String,Object> input) {
        Map<String,Object> request=new ChatRequestParser().parse(input);
        new com.bydauto.yunfan.agent.filter.PersistenceProjectionFilter().validate(request);
        new TaskContextPolicy().classify(request);
        var requestContext=Json.child(request,"context");
        String planMode=Json.str(requestContext,"planMode","DIRECT");if(!Set.of("DIRECT","HYBRID","PLANNED").contains(planMode))throw ApiException.bad("planMode must be DIRECT, HYBRID or PLANNED");
        String requestId=Json.required(request,"requestId"),requestKey=Util.hash(actor.tenantId()+":"+actor.userId()+":"+requestId),hash=Util.hash(Util.canonical(request));
        Map<String,Object> previous=store.get("request",requestKey);
        if(previous!=null) {
            if(!hash.equals(previous.get("hash")))throw ApiException.conflict("REQUEST_ID_CONFLICT","requestId already used for different content");
            return get(actor,previous.get("runId").toString());
        }
        String modelId=Json.str(request,"modelConfigId","");
        String requestedSession=Json.str(request,"sessionId","");
        if(modelId.isBlank()&&!requestedSession.isBlank())modelId=Json.str(sessions.get(actor,requestedSession),"modelConfigId","");
        Map<String,Object> model=models.select(actor,modelId);
        if(!Json.child(request,"responseFormat").isEmpty()) {
            if(!Json.bool(Json.child(model,"capabilities"),"structuredOutput",false))throw new ApiException(422,"MODEL_CAPABILITY_MISMATCH","Selected model does not support structured output");
            Json.child(model,"options").put("response_format",Json.child(request,"responseFormat"));
        }
        SkillRegistry.Selection selected=skills.select(actor,Json.strings(request.get("skillIds")),Json.required(request,"message"));
        List<ToolDefinition> available=tools.catalog(actor,selected.skills());
        if((Json.bool(requestContext,"programming",false)||"runtime__program".equals(Json.str(requestContext,"directTool","")))&&tools.programs!=null&&actor.allows("tool:runtime__program")){
            available=new ArrayList<>(available);available.add(com.bydauto.yunfan.agent.program.ProgramService.definition());
        }
        if(!Json.bool(Json.child(model,"capabilities"),"toolCalling",true)&&!planMode.equals("PLANNED")&&!RunContextService.isDirect(Json.map("request",request)))available=List.of();
        List<ToolDefinition> catalog=available;
        if(planMode.equals("PLANNED"))planner.validateRequest(request,catalog);
        if(!Json.child(requestContext,"executionPlan").isEmpty()){
            if(!Json.str(requestContext,"directTool","").isBlank()||!Json.child(requestContext,"dataPlan").isEmpty())throw ApiException.bad("Do not combine executionPlan with directTool or dataPlan");
            if(!actor.allows("tool:runtime__execute_plan"))throw new ApiException(403,"PLAN_TOOL_FORBIDDEN","Plan execution permission required");
            tools.planCompiler.compile(actor,Json.child(requestContext,"executionPlan"),catalog);
        }
        Map<String,Object> run=store.transaction(tx-> {
            Map<String,Object> old=tx.get("request",requestKey);
            if(old!=null) {
                if(!hash.equals(old.get("hash")))throw ApiException.conflict("REQUEST_ID_CONFLICT","requestId conflict");
                return tx.get("run",old.get("runId").toString());
            }
            String sid=Json.str(request,"sessionId","");
            Map<String,Object> session;
            if(sid.isBlank()) {
                sid=Util.id();
                session=Json.map("id",sid,"tenantId",actor.tenantId(),"userId",actor.userId(),"title",Json.required(request,"message").substring(0,Math.min(60,Json.required(request,"message").length())),"messageCount",0,"summary","","summaryThroughSeq",0,"createdAt",Util.now(),"updatedAt",Util.now());
            } else {
                session=tx.get("session",sid);
                if(session==null)throw ApiException.missing("session");
                auth.policy.check(actor,"chat",session);
            }
            if(session.get("activeRunId")!=null)throw ApiException.conflict("SESSION_BUSY","Session already has an active or waiting run");
            auth.policy.check(actor,"chat",session);
            String id=Util.id();
            Map<String,Object> r=Json.map("id",id,"runId",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"sessionId",sid,"requestId",requestId,"request",request,"status","CREATED","model",model,"skills",selected.skills().stream().map(SkillService::publicView).toList(),"skillReasons",selected.reasons(),"retrievalMode",selected.retrievalMode(),"tools",catalog.stream().map(ToolDefinition::snapshot).toList(),"catalogVersion",Util.hash(Json.write(catalog.stream().map(ToolDefinition::snapshot).toList())),"rounds",0,"toolCallsCount",0,"eventSeq",0,"pendingIndex",0,"createdAt",Util.now(),"updatedAt",Util.now(),"activeMillis",0);
            session.put("activeRunId",id);
            tx.put("session",sid,session);
            tx.put("run",id,r);
            r.put("contextPermissions",new ArrayList<>(actor.permissions()));tx.put("run",id,r);
            tx.put("task-state",id,Json.map("id",id,"runId",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"goal",Json.required(request,"message").substring(0,Math.min(200,Json.required(request,"message").length())),"status","CREATED","nodes",List.of(),"outputs",Json.map(),"updatedAt",Util.now()));
            tx.put("request",requestKey,Json.map("runId",id,"hash",hash));
            return r;
        } );
        if("CREATED".equals(run.get("status"))) {
            audit.record(actor,"run.created",run.get("id").toString(),Json.map("modelId",model.get("id"),"modelVersion",model.get("version"),"skills",selected.reasons()));
            schedule(actor,run.get("id").toString());
        }
        return get(actor,run.get("id").toString());
    }
    private void schedule(AuthContext actor,String id) {
        FutureTask<Void> task=new FutureTask<>(()-> {
            activeSince.put(id,System.currentTimeMillis());
            try {
                drive(actor,id);
            } finally {
                Long started=activeSince.remove(id);
                if(started!=null)patch(id,r->r.put("activeMillis",((Number)r.getOrDefault("activeMillis",0)).longValue()+System.currentTimeMillis()-started));
                tasks.remove(id);
                if("CREATED".equals(raw(id).get("status"))&&!executor.isShutdown())schedule(actor,id);
            }
            return null;
        } );
        if(tasks.putIfAbsent(id,task)!=null)return;
        try {
            executor.execute(task);
        } catch(RejectedExecutionException e) {
            tasks.remove(id,task);
            finish(id,"FAILED",Json.map("code","SERVER_BUSY","message","Agent queue is full"));
        }
    }
    private void drive(AuthContext actor,String id) {
        try {
            String initial=Json.required(raw(id),"status");
            if(TERMINAL.contains(initial))return;
            patch(id,r-> {
                r.put("contextPermissions",new ArrayList<>(actor.permissions()));
                if(!TERMINAL.contains(r.get("status")))r.put("status","RUNNING");
            } );
            checkActive(actor,id);
            event(id,"run.started",Json.map("sessionId",raw(id).get("sessionId")));
            Map<String,Object> run=raw(id);
            String sid=Json.required(run,"sessionId");
            Map<String,Object> request=Json.child(run,"request");
            ModelClient client=clients.create(Json.child(run,"model"));
            if(run.get("modelMessages")==null)prepareHistory(actor,id,client);
            String direct=Json.str(Json.child(request,"context"),"directTool","");
            var declaredPlan=Json.child(Json.child(request,"context"),"executionPlan");
            boolean planDirect=!declaredPlan.isEmpty()&&Json.str(Json.child(request,"context"),"planMode","DIRECT").equals("DIRECT");
            if(planDirect)direct="runtime__execute_plan";
            if((!direct.isBlank()||!declaredPlan.isEmpty())&&Json.integer(raw(id),"rounds",0)==0) {
                String firstTool=declaredPlan.isEmpty()?direct:"runtime__execute_plan";
                Map<String,Object> firstArgs=declaredPlan.isEmpty()?Json.child(Json.child(request,"context"),"toolArgs"):Json.map("plan",declaredPlan);
                Map<String,Object> call=Json.map("id","direct-"+id,"type","function","function",Json.map("name",firstTool,"arguments",Json.write(firstArgs)));
                sessions.append(sid,id,"direct-assistant","assistant","",List.of(call),null);
                patch(id,r-> {
                    Json.list(r,"modelMessages").add(Json.map("role","assistant","content","","tool_calls",List.of(call)));
                    r.put("pendingCalls",List.of(call));
                    r.put("pendingIndex",0);
                    r.put("rounds",1);
                    r.put("toolCallsCount",1);
                } );
            }
            while(true) {
                checkActive(actor,id);
                run=raw(id);
                List<Object> pending=Json.list(run,"pendingCalls");
                int pendingIndex=Json.integer(run,"pendingIndex",0);
                if(pendingIndex<pending.size()) {
                    Map<String,Object> call=Json.object(pending.get(pendingIndex)),function=Json.child(call,"function");
                    String name=Json.required(function,"name"),callId=Json.required(call,"id");
                    ToolDefinition definition=Json.list(run,"tools").stream().map(Json::object).map(ToolDefinition::from).filter(t->t.name().equals(name)).findFirst().orElse(null);
                    Object result;
                    if(definition==null)result=Json.map("error","TOOL_NOT_ALLOWED","message","Requested tool is not in the run's allowed catalog");
                    else {
                        Map<String,Object> args;
                        try {
                            args=Json.object(Json.parse(Json.str(function,"arguments","{}")));
                        } catch(ApiException e) {
                            args=null;
                        }
                        if(args==null)result=Json.map("error","TOOL_ARGUMENT_INVALID");
                        else {
                            boolean requires=Json.list(run,"skills").stream().map(Json::object).anyMatch(s->Json.bool(Json.child(s,"metadata"),"requiresConfirmation",false)&&Json.strings(Json.child(s,"metadata").get("allowedTools")).contains(name));
                            ToolExecutionService.Outcome outcome;
                            try {
                                outcome=tools.execute(actor,id,callId,definition,args,Json.child(request,"context"),requires,(type,data)->event(id,type,data));
                            } catch(ApiException e) {
                                outcome=new ToolExecutionService.Outcome("FAILED",Json.map("error",e.code,"message",e.getMessage()),null,null);
                            }
                            planner.observe(raw(id),callId,outcome);
                            if(outcome.status().equals("WAITING_CONFIRMATION")) {
                                waitState(id,"WAITING_CONFIRMATION",Json.map("confirmationId",outcome.confirmationId()));
                                return;
                            }
                            if(outcome.status().equals("UNKNOWN")) {
                                finish(id,"RECONCILIATION_REQUIRED",Json.map("code","TOOL_RESULT_UNKNOWN","executionId",outcome.executionId()));
                                return;
                            }
                            result=outcome.result();
                            appendTool(id,callId,pendingIndex,result);
                            if(outcome.status().equals("WAITING_INPUT")) {
                                event(id,"input.required",result);
                                waitState(id,"WAITING_INPUT",result);
                                return;
                            }
                            continue;
                        }
                    }
                    appendTool(id,callId,pendingIndex,result);
                    continue;
                }
                if(!direct.isBlank()) {
                    List<Object> messages=Json.list(run,"modelMessages");
                    String answer=Json.str(Json.object(messages.get(messages.size()-1)),"content","");
                    patch(id,r->r.put("answer",answer));
                    event(id,"message.delta",Json.map("delta",answer));
                    Object decoded=Json.parse(answer);
                    if(decoded instanceof Map<?,?> m&&m.containsKey("error"))finish(id,"FAILED",decoded);
                    else finish(id,"COMPLETED",null);
                    return;
                }
                int rounds=Json.integer(run,"rounds",0);
                if(!com.bydauto.yunfan.agent.plan.TaskPlanner.enabled(run)&&queueDataAction(actor,id,run,request))continue;
                if(rounds>=config.integer("yunfan.agent.max-rounds",12))throw new ApiException(422,"RUN_BUDGET_EXCEEDED","Maximum model rounds reached");
                List<Map<String,Object>> safe=tools.results.sanitizeHistory(actor,id,Json.list(run,"modelMessages").stream().map(Json::object).toList());
                patch(id,r->r.put("modelMessages",safe));
                RunContextService.Prepared prepared=context.prepare(id);
                List<Map<String,Object>> messages=prepared.messages();
                boolean planned=com.bydauto.yunfan.agent.plan.TaskPlanner.enabled(run);
                List<Map<String,Object>> specs=planned?List.of():Json.list(run,"tools").stream().map(Json::object).map(ToolDefinition::from).map(ToolDefinition::modelSpec).toList();
                if(!prepared.appliedIds().isEmpty())event(id,"context.applied",Json.map("invocationId",prepared.invocationId(),"entryIds",prepared.appliedIds()));
                if(prepared.removedGroups()>0)event(id,"context.compacted",Json.map("invocationId",prepared.invocationId(),"removedGroups",prepared.removedGroups(),"contextChars",prepared.chars()));
                event(id,"step.started",Json.map("step","model","round",rounds+1,"invocationId",prepared.invocationId(),"parentInvocationId",prepared.parentInvocationId(),"contextChars",prepared.chars()));
                ModelClient.Result transported=client.complete(messages,specs,!planned,(type,text)-> {
                    checkActive(actor,id);
                    if(!planned)event(id,type,Json.map("delta",text));
                } );
                context.completed(prepared.invocationId(),transported.usage());
                checkActive(actor,id);
                ModelClient.Result interpreted=transported;
                if(planned){
                    try{interpreted=planner.decide(actor,raw(id),transported);}
                    catch(ApiException e){
                        int consumedRounds=rounds+1;
                        patch(id,r->{r.put("rounds",consumedRounds);r.put("usage",mergeUsage(Json.child(r,"usage"),transported.usage()));});
                        if(planner.repair(raw(id),e)){event(id,"planner.repair",Json.map("code",e.code,"round",consumedRounds));continue;}
                        throw e;
                    }
                    event(id,"planner.decision",planner.view(raw(id)));
                }
                final ModelClient.Result response=interpreted;
                int count=Json.integer(run,"toolCallsCount",0)+response.toolCalls().size();
                if(count>config.integer("yunfan.agent.max-tool-calls",20))throw new ApiException(422,"RUN_BUDGET_EXCEEDED","Maximum tool calls reached");
                Set<String> known=new HashSet<>(Json.strings(run.get("seenCallIds")));
                for(var c:response.toolCalls())if(!known.add(Json.required(c,"id")))throw new ApiException(502,"MODEL_INVALID_RESPONSE","Repeated tool call id");
                if(response.toolCalls().size()>1&&response.toolCalls().stream().anyMatch(c->"system__ask_user".equals(Json.child(c,"function").get("name"))))throw new ApiException(502,"MODEL_INVALID_RESPONSE","ask_user must be the sole tool call in its turn");
                if(!planned&&response.toolCalls().size()==1) {
                    String signature=Util.hash(Util.canonical(Json.child(response.toolCalls().get(0),"function")));
                    if(signature.equals(run.get("lastToolSignature")))patch(id,r->r.put("repeatCount",Json.integer(r,"repeatCount",0)+1));
                    else patch(id,r-> {
                        r.put("repeatCount",0);
                        r.put("lastToolSignature",signature);
                    } );
                    if(Json.integer(raw(id),"repeatCount",0)>=2)throw new ApiException(422,"RUN_LOOP_DETECTED","Repeated identical tool calls; task stopped");
                }
                Map<String,Object> assistant=response.message();
                new com.bydauto.yunfan.agent.filter.PersistenceProjectionFilter().validate(assistant);
                sessions.append(sid,id,"assistant:"+rounds,"assistant",response.content(),response.toolCalls().isEmpty()?null:response.toolCalls(),null);
                patch(id,r-> {
                    Json.list(r,"modelMessages").add(assistant);
                    r.put("rounds",rounds+1);
                    r.put("toolCallsCount",count);
                    r.put("pendingCalls",response.toolCalls());
                    r.put("pendingIndex",0);
                    r.put("seenCallIds",new ArrayList<>(known));
                    r.put("usage",mergeUsage(Json.child(r,"usage"),response.usage()));
                } );
                if(response.toolCalls().isEmpty()) {
                    if(planned)event(id,"message.delta",Json.map("delta",response.content()));
                    var latestPlan=store.list("task-state").stream().filter(s->id.equals(s.get("runId"))&&!id.equals(s.get("id"))).max(Comparator.comparing(s->Instant.parse(Json.required(s,"updatedAt"))));
                    if(!planned&&latestPlan.isPresent()&&!"COMPLETED".equals(latestPlan.get().get("status")))throw new ApiException(422,"PLAN_INCOMPLETE","Latest execution plan did not complete; inspect its node states before retrying");
                    if(!Json.child(Json.child(request,"context"),"dataPlan").isEmpty()&&store.list("tool-execution").stream().noneMatch(e->id.equals(e.get("runId"))&&Json.str(e,"toolCallId","").startsWith("data-plan-")&&"SUCCEEDED".equals(e.get("status"))))throw new ApiException(422,"DATA_PLAN_INCOMPLETE","Declared data plan did not succeed. Supply an owned dataRef or obtain one unambiguous dataset from an authorized query; inspect tool errors before retrying.");
                    Map<String,Object> format=Json.child(request,"responseFormat");
                    if(!format.isEmpty()) {
                        Map<String,Object> structured=Json.object(Json.parse(response.content()));
                        if("json_schema".equals(format.get("type")))new JsonSchemaValidator().validate(structured,Json.child(Json.child(format,"json_schema"),"schema"));
                        patch(id,r->r.put("structuredResult",structured));
                    }
                    patch(id,r->r.put("answer",response.content()));
                    if(finish(id,"COMPLETED",null))return;
                }
            }
        } catch(Throwable error) {
            if(error instanceof Error fatal)throw fatal;
            Map<String,Object> current=raw(id);
            context.failed(Json.str(current,"lastInvocationId",""),error instanceof ApiException a?a.code:"MODEL_CALL_FAILED");
            if(!TERMINAL.contains(current.get("status"))) {
                String code=error instanceof ApiException a?a.code:"AGENT_EXECUTION_FAILED";
                event(id,"error",Json.map("code",code,"message",error instanceof ApiException?error.getMessage():"Agent execution failed; inspect server diagnostics"));
                finish(id,"FAILED",Json.map("code",code,"message",error instanceof ApiException?error.getMessage():"Agent execution failed"));
            }
        }
    }
    private Map<String,Object> mergeUsage(Map<String,Object> prior,Map<String,Object> next) {
        Map<String,Object> result=new LinkedHashMap<>(prior);
        for(var e:next.entrySet())if(e.getValue() instanceof Number n)result.put(e.getKey(),((Number)result.getOrDefault(e.getKey(),0)).longValue()+n.longValue());
        return result;
    }
    private boolean queueDataAction(AuthContext actor,String id,Map<String,Object> run,Map<String,Object> request) {
        if(Json.bool(run,"dataPlanApplied",false))return false;
        Map<String,Object> reference=Json.map();List<Object> pending=Json.list(run,"pendingCalls");
        if(pending.size()==1&&!Json.str(Json.child(Json.object(pending.get(0)),"function"),"name","").matches("data__(aggregate|export|page|schema)")){
            List<Object> messages=Json.list(run,"modelMessages");if(!messages.isEmpty())try{var last=Json.object(messages.get(messages.size()-1));if("tool".equals(last.get("role"))){var value=Json.object(Json.parse(Json.str(last,"content","{}")));if("dataset_ref".equals(value.get("kind")))reference=value;}}catch(ApiException ignored){}
        }
        var action=new com.bydauto.yunfan.agent.data.DataActionRouter().choose(request,reference);if(action==null)return false;
        if(Json.list(run,"tools").stream().map(Json::object).noneMatch(t->action.tool().equals(t.get("name"))))throw new ApiException(403,"DATA_ACTION_FORBIDDEN","Requested data action is not in this run's authorized tools");
        if(Json.integer(run,"toolCallsCount",0)>=config.integer("yunfan.agent.max-tool-calls",20))throw new ApiException(422,"RUN_BUDGET_EXCEEDED","Tool budget exceeded before data action");
        String callId="data-plan-"+Util.id();var call=Json.map("id",callId,"type","function","function",Json.map("name",action.tool(),"arguments",Json.write(action.arguments())));
        sessions.append(Json.required(run,"sessionId"),id,callId,"assistant","",List.of(call),null);
        patch(id,r->{Json.list(r,"modelMessages").add(Json.map("role","assistant","content","","tool_calls",List.of(call)));r.put("pendingCalls",List.of(call));r.put("pendingIndex",0);r.put("dataPlanApplied",true);r.put("toolCallsCount",Json.integer(r,"toolCallsCount",0)+1);});
        event(id,"data.action.routed",Json.map("tool",action.tool(),"reason",action.reason(),"dataRef",action.arguments().get("dataRef")));return true;
    }
    private void prepareHistory(AuthContext actor,String id,ModelClient client) {
        Map<String,Object> run=raw(id),request=Json.child(run,"request");
        String sid=Json.required(run,"sessionId");
        sessions.append(sid,id,"user:"+id,"user",Json.required(request,"message"),null,null);
        List<Map<String,Object>> history=sessions.messages(sid);
        String prompt=new PromptFactory().build(Json.list(run,"skills").stream().map(Json::object).toList(),Json.child(request,"context"));
        if(com.bydauto.yunfan.agent.plan.TaskPlanner.enabled(run))prompt+="\n"+com.bydauto.yunfan.agent.plan.TaskPlanner.INSTRUCTIONS;
        // Raw history is an audit log, not model memory. Offload legacy tool bodies first.
        ChatHistoryLogic logic=new ChatHistoryLogic();
        List<Map<String,Object>> safe=tools.results.sanitizeHistory(actor,id,logic.normalize(history));
        List<Object> messages=new ArrayList<>();
        messages.add(Json.map("role","system","content",prompt));
        for(var m:safe)messages.add(logic.modelMessage(m));
        patch(id,r->r.put("modelMessages",messages));
    }

    private void appendTool(String id,String callId,int index,Object result) {
        Map<String,Object> run=raw(id);
        sessions.append(Json.required(run,"sessionId"),id,"tool:"+callId,"tool",Json.write(result),null,callId);
        patch(id,r-> {
            Json.list(r,"modelMessages").add(Json.map("role","tool","tool_call_id",callId,"content",Json.write(result)));
            r.put("pendingIndex",index+1);
        } );
    }
    private void checkActive(AuthContext actor,String id) {
        Map<String,Object> run=raw(id);
        if(!"RUNNING".equals(run.get("status"))||Thread.currentThread().isInterrupted())throw new ApiException(409,"RUN_STOPPED","Run is not active");
        auth.policy.check(actor,"chat",run);
        Map<String,Object> model=models.get(actor,Json.child(run,"model").get("id").toString());
        if(!Json.bool(model,"enabled",false))throw new ApiException(403,"MODEL_DISABLED","Model disabled while running");
        for(Object item:Json.list(run,"skills")) {
            var s=Json.object(item);
            Map<String,Object> live=store.get("skill",s.get("id").toString());
            if(live==null||!Json.bool(live,"enabled",false))throw new ApiException(403,"SKILL_DISABLED","An active skill was disabled");
        }
        long elapsed=((Number)run.getOrDefault("activeMillis",0)).longValue()+System.currentTimeMillis()-activeSince.getOrDefault(id,System.currentTimeMillis());
        if(elapsed>config.integer("yunfan.agent.max-seconds",180)*1000L)throw new ApiException(422,"RUN_BUDGET_EXCEEDED","Active execution time exceeded");
        long tokens=((Number)Json.child(run,"usage").getOrDefault("total_tokens",0)).longValue();
        if(tokens>config.integer("yunfan.agent.max-tokens",32000))throw new ApiException(422,"RUN_BUDGET_EXCEEDED","Token budget exceeded");
    }
    public Map<String,Object> get(AuthContext actor,String id) {
        Map<String,Object> r=auth.owned(store,"run",id,actor,"chat");
        Map<String,Object> view=new LinkedHashMap<>(r);
        for(String key:List.of("modelMessages","model","skills","tools","request","seenCallIds","pendingCalls","inbox","contextPermissions"))view.remove(key);
        view.put("queuedContext",Json.list(r,"inbox").stream().map(Json::object).filter(e->"QUEUED".equals(e.get("status"))).count());
        view.put("modelConfigId",Json.child(r,"model").get("id"));
        view.put("modelConfigVersion",Json.child(r,"model").get("version"));
        if(com.bydauto.yunfan.agent.plan.TaskPlanner.enabled(r))view.put("planner",planner.view(r));
        return view;
    }
    public List<Map<String,Object>> events(AuthContext actor,String id,int after) {
        Map<String,Object> view=get(actor,id);
        if(after<Json.integer(view,"eventsExpiredThrough",0))throw new ApiException(410,"EVENTS_EXPIRED","Requested events have expired; query the final run and messages instead");
        if(after>Json.integer(view,"eventSeq",0))throw ApiException.bad("afterSeq exceeds the last event sequence");
        return store.list("event").stream().filter(e->id.equals(e.get("runId"))&&Json.integer(e,"seq",0)>after).sorted(Comparator.comparingInt(e->Json.integer(e,"seq",0))).toList();
    }
    public void event(String id,String type,Object payload) {
        store.transaction(tx-> {
            Map<String,Object> run=tx.get("run",id);
            if(run==null||TERMINAL.contains(run.get("status")))return null;
            appendEvent(tx,run,type,payload);
            return null;
        } );
    }
    private void appendEvent(DocumentStore.Tx tx,Map<String,Object> run,String type,Object payload) {
        String id=Json.required(run,"id");
        int seq=Json.integer(run,"eventSeq",0)+1;
        if(seq>20000&&!type.equals("done"))throw new ApiException(422,"RUN_EVENT_LIMIT","Run event limit reached");
        Map<String,Object> item=Json.map("runId",id,"seq",seq,"type",type,"timestamp",Util.now(),"payload",payload);
        tx.put("event",id+":"+String.format("%08d",seq),item);
        run.put("eventSeq",seq);
        tx.put("run",id,run);
    }
    public Map<String,Object> input(AuthContext actor,String id,String text) {
        get(actor,id);
        store.transaction(tx-> {
            Map<String,Object> r=tx.get("run",id);
            if(!"WAITING_INPUT".equals(r.get("status")))throw ApiException.conflict("RUN_NOT_WAITING","Run does not need user input");
            Json.list(r,"modelMessages").add(Json.map("role","user","content",text));
            sessions.append(tx,Json.required(r,"sessionId"),id,"input:"+Util.id(),"user",text,null,null);
            r.put("status","CREATED");
            tx.put("run",id,r);
            return null;
        } );
        schedule(actor,id);
        return get(actor,id);
    }
    public Map<String,Object> resumeConfirmation(AuthContext actor,String confirmationId,String decision,int version) {
        var c=tools.decision(actor,confirmationId,decision,version);
        String id=Json.required(c,"runId");
        store.transaction(tx-> {
            Map<String,Object> r=tx.get("run",id);
            if("WAITING_CONFIRMATION".equals(r.get("status"))) {
                r.put("status","CREATED");
                tx.put("run",id,r);
            }
            return null;
        } );
        if("CREATED".equals(raw(id).get("status")))schedule(actor,id);
        return get(actor,id);
    }
    public Map<String,Object> cancel(AuthContext actor,String id) {
        get(actor,id);
        if(TERMINAL.contains(raw(id).get("status")))return get(actor,id);
        boolean writing=store.list("tool-execution").stream().anyMatch(e->id.equals(e.get("runId"))&&"EXECUTING".equals(e.get("status"))&&!"READ".equals(e.get("risk")));
        finish(id,writing?"RECONCILIATION_REQUIRED":"CANCELLED",writing?Json.map("code","TOOL_RESULT_UNKNOWN","message","Cancellation cannot roll back an in-flight write"):null);
        FutureTask<Void> t=tasks.get(id);
        if(t!=null) {
            t.cancel(true);
            if(!activeSince.containsKey(id)) {
                executor.remove(t);
                tasks.remove(id,t);
            }
        }
        audit.record(actor,"run.cancelled",id,Json.map("writeInFlight",writing));
        return get(actor,id);
    }
    public Map<String,Object> await(AuthContext actor,String id,long millis) {
        long until=System.currentTimeMillis()+millis;
        while(System.currentTimeMillis()<until) {
            var r=get(actor,id);
            String state=Json.required(r,"status");
            if(TERMINAL.contains(state)||state.startsWith("WAITING_"))return r;
            try {
                Thread.sleep(25);
            } catch(InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return get(actor,id);
    }
    private Map<String,Object> raw(String id) {
        Map<String,Object> r=store.get("run",id);
        if(r==null)throw ApiException.missing("run");
        return r;
    }
    private void patch(String id,Consumer<Map<String,Object>> change) {
        store.transaction(tx-> {
            var r=tx.get("run",id);
            if(r!=null) {
                change.accept(r);
                var state=tx.get("task-state",id);if(state!=null){state.put("status",r.get("status"));state.put("modelRounds",Json.integer(r,"rounds",0));state.put("toolCalls",Json.integer(r,"toolCallsCount",0));state.put("updatedAt",Util.now());tx.put("task-state",id,state);}
                r.put("updatedAt",Util.now());
                tx.put("run",id,r);
            }
            return null;
        } );
    }
    private void waitState(String id,String status,Object reason) {
        store.transaction(tx-> {
            var r=tx.get("run",id);
            if(!TERMINAL.contains(r.get("status"))) {
                r.put("status",status);
                var task=tx.get("task-state",id);if(task!=null){task.put("status",status);tx.put("task-state",id,task);}
                r.put("waitingReason",reason);
                r.put("waitingUntil",Instant.now().plusSeconds(config.integer("yunfan.agent.wait-seconds",1800)).toString());
                appendEvent(tx,r,"done",Json.map("runStatus",status));
            }
            return null;
        } );
    }
    private boolean finish(String id,String status,Object error) {
        return store.transaction(tx-> {
            var r=tx.get("run",id);
            if(r==null||TERMINAL.contains(r.get("status")))return true;
            // Enqueue and final completion share the store transaction: accepted late input cannot be lost.
            if(status.equals("COMPLETED")&&RunContextService.hasQueued(r)&&!RunContextService.isDirect(r))return false;
            for(Object item:Json.list(r,"inbox")) {
                var entry=Json.object(item);
                if("ACTIVE".equals(entry.get("status")))entry.put("status","RUN_ENDED");
                else if("QUEUED".equals(entry.get("status")))entry.put("status","UNDELIVERED");
            }
            r.put("status",status);
            var plannerState=tx.get("planner-state",id);if(plannerState!=null){plannerState.put("phase",status.equals("COMPLETED")?"ACCEPTED":status);if(error!=null)plannerState.put("lastError",error);plannerState.put("updatedAt",Util.now());tx.put("planner-state",id,plannerState);}
            for(var state:tx.list("task-state"))if(id.equals(state.get("runId"))){
                if(id.equals(state.get("id"))||!Set.of("COMPLETED","FAILED","SUCCEEDED","SKIPPED","CANCELLED","UNKNOWN").contains(Json.str(state,"status","")))state.put("status",status);
                for(Object item:Json.list(state,"nodes")){var node=Json.object(item);if(!Set.of("SUCCEEDED","FAILED","SKIPPED","REJECTED").contains(Json.str(node,"status","")))node.put("status",status.equals("RECONCILIATION_REQUIRED")?"UNKNOWN":status.equals("COMPLETED")?"FAILED":status);}
                tx.put("task-state",Json.required(state,"id"),state);
            }
            r.put("finishedAt",Util.now());
            if(error!=null)r.put("error",error);
            appendEvent(tx,r,"done",Json.map("runStatus",status,"error",error));
            var s=tx.get("session",Json.required(r,"sessionId"));
            if(s!=null&&id.equals(s.get("activeRunId"))) {
                s.remove("activeRunId");
                s.put("updatedAt",Util.now());
                tx.put("session",s.get("id").toString(),s);
            }
            return true;
        } );
    }
    private void recover() {
        for(var run:store.list("run")) {
            String id=run.get("id").toString(),state=Json.required(run,"status");
            if(state.equals("RUNNING")||state.equals("CREATED")) {
                context.failed(Json.str(run,"lastInvocationId",""),"SERVICE_RESTARTED");
                boolean unknown=false;
                for(var e:store.list("tool-execution"))if(id.equals(e.get("runId"))&&"EXECUTING".equals(e.get("status"))) {
                    boolean write=!"READ".equals(e.get("risk"));
                    e.put("status",write?"UNKNOWN":"FAILED");
                    store.put("tool-execution",e.get("id").toString(),e);
                    unknown|=write;
                }
                finish(id,unknown?"RECONCILIATION_REQUIRED":"FAILED",Json.map("code","SERVICE_RESTARTED","message","Interrupted runs are not automatically replayed"));
            }
        }
    }
    private void expire() {
        try {
            if(++cleanupTicks>=60) {
                cleanupTicks=0;
                cleanupEvents();
            }
            for(var run:store.list("run")) {
                String state=Json.required(run,"status"),id=run.get("id").toString();
                if(state.startsWith("WAITING_")&&Instant.parse(run.get("waitingUntil").toString()).isBefore(Instant.now()))finish(id,"EXPIRED",Json.map("code","WAIT_EXPIRED"));
                else if(state.equals("RUNNING")&&activeSince.containsKey(id)) {
                    long elapsed=((Number)run.getOrDefault("activeMillis",0)).longValue()+System.currentTimeMillis()-activeSince.get(id);
                    if(elapsed>config.integer("yunfan.agent.max-seconds",180)*1000L) {
                        boolean writing=store.list("tool-execution").stream().anyMatch(e->id.equals(e.get("runId"))&&"EXECUTING".equals(e.get("status"))&&!"READ".equals(e.get("risk")));
                        finish(id,writing?"RECONCILIATION_REQUIRED":"FAILED",Json.map("code","RUN_BUDGET_EXCEEDED"));
                        FutureTask<Void> task=tasks.get(id);
                        if(task!=null)task.cancel(true);
                    }
                }
            }
        } catch(RuntimeException e) {
            System.err.println("Watchdog check failed: "+e.getClass().getSimpleName());
        }
    }
    public void cleanupEvents() {
        Instant cutoff=Instant.now().minus(Duration.ofDays(Math.max(1,config.integer("yunfan.stream.event-retention-days",7))));
        store.transaction(tx-> {
            Map<String,Integer> purged=new HashMap<>();
            for(var event:tx.list("event")) {
                String id=Json.required(event,"runId");
                Map<String,Object> run=tx.get("run",id);
                if(run!=null&&TERMINAL.contains(run.get("status"))&&Instant.parse(Json.required(event,"timestamp")).isBefore(cutoff)) {
                    int seq=Json.integer(event,"seq",0);
                    tx.delete("event",id+":"+String.format("%08d",seq));
                    purged.merge(id,seq,Math::max);
                }
            }
            for(var entry:purged.entrySet()) {
                var run=tx.get("run",entry.getKey());
                run.put("eventsExpiredThrough",entry.getValue());
                tx.put("run",entry.getKey(),run);
            }
            return null;
        });
    }
    @Override public void close() {
        watchdog.shutdownNow();
        executor.shutdown();
        try {
            if(!executor.awaitTermination(5,TimeUnit.SECONDS)) {
                executor.shutdownNow();
                executor.awaitTermination(5,TimeUnit.SECONDS);
            }
        } catch(InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
