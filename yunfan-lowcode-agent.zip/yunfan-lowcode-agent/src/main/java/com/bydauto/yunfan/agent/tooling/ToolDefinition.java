package com.bydauto.yunfan.agent.tooling;
import com.bydauto.yunfan.agent.common.*;
import java.util.Map;
public record ToolDefinition(String name,String originalName,String serverId,String description,Map<String,Object> schema,String risk,boolean base,String version,Map<String,Object> wireSchema) {
    public ToolDefinition(String name,String originalName,String serverId,String description,Map<String,Object> schema,String risk,boolean base,String version) {
        this(name,originalName,serverId,description,schema,risk,base,version,schema);
    }
    public ToolDefinition {
        schema=Json.object(Json.copy(schema));
        wireSchema=Json.object(Json.copy(wireSchema));
    }
    public Map<String,Object> modelSpec() {
        return Json.map("type","function","function",Json.map("name",name,"description",description,"parameters",schema));
    }
    public Map<String,Object> snapshot() {
        return Json.map("name",name,"originalName",originalName,"serverId",serverId,"description",description,"schema",schema,"risk",risk,"base",base,"version",version,"wireSchema",wireSchema);
    }
    public static ToolDefinition from(Map<String,Object> m) {
        return new ToolDefinition(Json.required(m,"name"),Json.str(m,"originalName",""),Json.str(m,"serverId",""),Json.str(m,"description",""),Json.child(m,"schema"),Json.str(m,"risk","HIGH_RISK"),Json.bool(m,"base",false),Json.str(m,"version","1"),m.containsKey("wireSchema")?Json.child(m,"wireSchema"):Json.child(m,"schema"));
    }
}
