package com.bydauto.yunfan.agent.modelconfig;
import com.bydauto.yunfan.agent.common.Json;
import java.util.*;
import java.util.function.BiConsumer;
public interface ModelClient {
    record Result(String content,List<Map<String,Object>> toolCalls,Map<String,Object> usage) {
        public Map<String,Object> message() {
            Map<String,Object> m=Json.map("role","assistant","content",content);
            if(!toolCalls.isEmpty())m.put("tool_calls",toolCalls);
            return m;
        }
    }
    Result complete(List<Map<String,Object>> messages,List<Map<String,Object>> tools,boolean stream,BiConsumer<String,String> delta);
}
