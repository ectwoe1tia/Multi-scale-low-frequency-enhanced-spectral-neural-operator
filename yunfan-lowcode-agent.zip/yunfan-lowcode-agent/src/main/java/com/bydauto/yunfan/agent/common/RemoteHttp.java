package com.bydauto.yunfan.agent.common;
import java.io.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.*;
import java.util.function.Consumer;
public final class RemoteHttp {
    public static final HttpClient CLIENT=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).followRedirects(HttpClient.Redirect.NEVER).build();
    private static final ScheduledExecutorService TIMER=Executors.newSingleThreadScheduledExecutor(r-> {
        Thread t=new Thread(r,"http-deadlines");
        t.setDaemon(true);
        return t;
    } );
    public record Reply(int status,HttpHeaders headers,String text) {
    }
    public static final class StreamComplete extends RuntimeException {
    }
    public static Reply send(HttpRequest request,int timeoutSeconds,Consumer<String> dataConsumer) {
        try {
            HttpResponse<InputStream> response=CLIENT.send(request,HttpResponse.BodyHandlers.ofInputStream());
            InputStream stream=response.body();
            Thread owner=Thread.currentThread();
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(timeoutSeconds);
            ScheduledFuture<?> timeout=TIMER.scheduleAtFixedRate(()-> {
                if(owner.isInterrupted()||System.nanoTime()>deadline)try {
                    stream.close();
                } catch(IOException ignored) {
                }
            } ,100,100,TimeUnit.MILLISECONDS);
            try(stream) {
                String type=response.headers().firstValue("content-type").orElse("");
                if(response.statusCode()>=200&&response.statusCode()<300&&type.contains("text/event-stream")) {
                    BufferedReader reader=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8));
                    String line;
                    StringBuilder data=new StringBuilder();
                    int count=0;
                    while((line=reader.readLine())!=null) {
                        if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                        count+=line.length();
                        if(count>16*1024*1024)throw new IOException("Remote stream too large");
                        if(line.isEmpty()) {
                            if(data.length()>0) {
                                try {
                                    dataConsumer.accept(data.substring(0,data.length()-1));
                                }catch(StreamComplete complete) {
                                    return new Reply(response.statusCode(),response.headers(),"");
                                }
                                data.setLength(0);
                            }
                        } else if(line.startsWith("data:")) {
                            String v=line.substring(5);
                            if(v.startsWith(" "))v=v.substring(1);
                            data.append(v).append('\n');
                        }
                    }
                    if(data.length()>0)try {
                        dataConsumer.accept(data.substring(0,data.length()-1));
                    }catch(StreamComplete complete) {
                        /* Completed at stream boundary. */
                    }
                    return new Reply(response.statusCode(),response.headers(),"");
                }
                byte[] bytes=stream.readNBytes(8*1024*1024+1);
                if(bytes.length>8*1024*1024)throw new IOException("Remote result too large");
                return new Reply(response.statusCode(),response.headers(),new String(bytes,StandardCharsets.UTF_8));
            } finally {
                timeout.cancel(false);
            }
        } catch(InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ApiException(503,"REQUEST_INTERRUPTED","Remote request interrupted");
        } catch(IOException e) {
            throw new ApiException(502,"REMOTE_IO_ERROR","Remote transport failed or timed out");
        }
    }
}
