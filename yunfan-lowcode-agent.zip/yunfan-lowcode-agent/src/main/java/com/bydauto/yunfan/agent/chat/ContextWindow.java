package com.bydauto.yunfan.agent.chat;

import com.bydauto.yunfan.agent.common.*;
import java.util.*;

/** Evicts complete assistant/tool groups only; all user instructions and the newest result are pinned. */
public final class ContextWindow {
    public record Result(List<Map<String,Object>> messages,int removedGroups) {}
    public Result fit(List<Map<String,Object>> source,int budget,String runId) {
        List<Map<String,Object>> messages=new ArrayList<>(source);
        int removed=0;
        while(Json.write(messages).length()>budget) {
            int start=-1,end=-1;
            for(int i=0;i<messages.size();i++) {
                Map<String,Object> m=messages.get(i);
                if(!"assistant".equals(m.get("role")))continue;
                int j=i+1;
                List<Object> calls=Json.list(m,"tool_calls");
                if(!calls.isEmpty()) {
                    Set<String> expected=new HashSet<>();
                    for(Object c:calls)expected.add(Json.required(Json.object(c),"id"));
                    Set<String> actual=new HashSet<>();
                    while(j<messages.size()&&"tool".equals(messages.get(j).get("role"))) {
                        if(!actual.add(Json.required(messages.get(j++),"tool_call_id")))throw ApiException.bad("Duplicate tool result in context");
                    }
                    if(!expected.equals(actual))throw ApiException.bad("Incomplete tool call group at model boundary");
                }
                boolean newer=false;
                for(int k=j;k<messages.size();k++)if("assistant".equals(messages.get(k).get("role"))){newer=true;break;}
                if(newer){start=i;end=j;break;}
            }
            if(start<0)throw new ApiException(413,"CONTEXT_LIMIT_EXCEEDED","Pinned instructions and latest tool group exceed context budget; reduce input or tool output");
            messages.subList(start,end).clear();removed++;
            // One stable notice, never a fabricated summary of omitted results.
            String notice="[历史执行片段已从模型窗口裁剪；完整记录保留在 runId="+runId+"。不得据此假设操作未执行或自动重放写入。]";
            if(messages.stream().noneMatch(m->notice.equals(m.get("content"))))messages.add(1,Json.map("role","system","content",notice));
        }
        return new Result(messages,removed);
    }
}
