package com.bydauto.yunfan.agent.session;
import com.bydauto.yunfan.agent.auth.*;
import com.bydauto.yunfan.agent.common.*;
import java.util.*;
public final class SessionStore {
    private final DocumentStore store;
    private final AuthService auth;
    public SessionStore(DocumentStore store,AuthService auth) {
        this.store=store;
        this.auth=auth;
    }
    public Map<String,Object> create(AuthContext actor,String title) {
        auth.policy.check(actor,"chat",null);
        String id=Util.id();
        Map<String,Object> s=Json.map("id",id,"tenantId",actor.tenantId(),"userId",actor.userId(),"title",title,"messageCount",0,"summary","","summaryThroughSeq",0,"createdAt",Util.now(),"updatedAt",Util.now());
        store.put("session",id,s);
        return s;
    }
    public Map<String,Object> get(AuthContext actor,String id) {
        return auth.owned(store,"session",id,actor,"chat");
    }
    public List<Map<String,Object>> list(AuthContext actor) {
        return store.list("session").stream().filter(s->actor.tenantId().equals(s.get("tenantId"))&&actor.userId().equals(s.get("userId"))).sorted(Comparator.comparing((Map<String,Object> s)->s.get("updatedAt").toString()).reversed()).toList();
    }
    public Map<String,Object> rename(AuthContext actor,String id,String title) {
        return store.transaction(tx-> {
            Map<String,Object> s=tx.get("session",id);
            if(s==null)throw ApiException.missing("session");
            auth.policy.check(actor,"chat",s);
            s.put("title",title);
            s.put("updatedAt",Util.now());
            tx.put("session",id,s);
            return s;
        } );
    }
    public Map<String,Object> configureModel(AuthContext actor,String id,String modelId) {
        return store.transaction(tx-> {
            Map<String,Object> session=tx.get("session",id);
            if(session==null)throw ApiException.missing("session");
            auth.policy.check(actor,"chat",session);
            session.put("modelConfigId",modelId);
            tx.put("session",id,session);
            return session;
        });
    }
    public void delete(AuthContext actor,String id) {
        get(actor,id);
        store.transaction(tx-> {
            Map<String,Object> s=tx.get("session",id);
            auth.policy.check(actor,"chat",s);
            if(s.get("activeRunId")!=null)throw ApiException.conflict("SESSION_BUSY","Cancel or finish the active run before deletion");
            for(var m:tx.list("message"))if(id.equals(m.get("sessionId")))tx.delete("message",m.get("id").toString());
            tx.delete("session",id);
            return null;
        } );
    }
    public List<Map<String,Object>> messages(AuthContext actor,String id) {
        get(actor,id);
        return messages(id);
    }
    public List<Map<String,Object>> messages(String id) {
        return store.list("message").stream().filter(m->id.equals(m.get("sessionId"))).sorted(Comparator.comparingInt(m->Json.integer(m,"seq",0))).toList();
    }
    public Map<String,Object> append(String sessionId,String runId,String messageKey,String role,Object content,Object toolCalls,String toolCallId) {
        return store.transaction(tx-> {
            String id=Util.hash(sessionId+":"+messageKey);
            Map<String,Object> existing=tx.get("message",id);
            if(existing!=null)return existing;
            Map<String,Object> session=tx.get("session",sessionId);
            if(session==null)throw ApiException.missing("session");
            int seq=Json.integer(session,"messageCount",0)+1;
            Map<String,Object> message=Json.map("id",id,"sessionId",sessionId,"runId",runId,"seq",seq,"role",role,"content",content,"createdAt",Util.now());
            if(toolCalls!=null)message.put("tool_calls",toolCalls);
            if(toolCallId!=null)message.put("tool_call_id",toolCallId);
            tx.put("message",id,message);
            session.put("messageCount",seq);
            session.put("updatedAt",Util.now());
            tx.put("session",sessionId,session);
            return message;
        } );
    }
}
