package com.bydauto.yunfan.agent.common;
import java.io.*;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.function.Function;
/** Single-node durable store: exclusive process lock, atomic snapshot replacement, rollback on failure. */
public final class FileDocumentStore implements DocumentStore {
    private Map<String,Object> data;
    private final Path path;
    private final FileChannel channel;
    private final FileLock lock;
    private boolean closed;
    public FileDocumentStore(Path directory) {
        FileChannel candidate=null;
        FileLock candidateLock=null;
        try {
            Files.createDirectories(directory);
            path=directory.resolve("agent-state.json");
            candidate=FileChannel.open(directory.resolve("agent.lock"),StandardOpenOption.CREATE,StandardOpenOption.WRITE);
            candidateLock=candidate.tryLock();
            if(candidateLock==null)throw new IllegalStateException("Data directory is already in use");
            if(Files.exists(path)&&Files.size(path)>128L*1024*1024)throw new IllegalStateException("Local snapshot exceeds 128 MiB; migrate to JDBC storage");
            data=Files.exists(path)?Json.object(Json.parse(Files.readString(path))):Json.map();
            channel=candidate;
            lock=candidateLock;
        } catch(IOException|RuntimeException e) {
            if(candidateLock!=null)try {
                candidateLock.release();
            }catch(IOException ignored) {
            }
            if(candidate!=null)try {
                candidate.close();
            }catch(IOException ignored) {
            }
            throw new IllegalStateException("Cannot open state store",e);
        }
    }
    @Override public synchronized <T>T transaction(Function<Tx,T> action) {
        if(closed)throw new IllegalStateException("State store is closed");
        Map<String,Object> working=new LinkedHashMap<>(data);
        Set<String> copied=new HashSet<>();
        boolean[] dirty= {
            false
        } ;
        Tx tx=new Tx() {
            Map<String,Object> bucket(String kind,boolean write) {
                Map<String,Object> b=working.get(kind)==null?Json.map():Json.object(working.get(kind));
                if(write&&copied.add(kind)) {
                    b=new LinkedHashMap<>(b);
                    working.put(kind,b);
                }
                return b;
            }
            public Map<String,Object> get(String kind,String id) {
                Object v=bucket(kind,false).get(id);
                return v==null?null:Json.object(Json.copy(v));
            }
            public List<Map<String,Object>> list(String kind) {
                return bucket(kind,false).values().stream().map(v->Json.object(Json.copy(v))).toList();
            }
            public void put(String kind,String id,Map<String,Object> value) {
                bucket(kind,true).put(id,Json.copy(value));
                dirty[0]=true;
            }
            public void delete(String kind,String id) {
                bucket(kind,true).remove(id);
                dirty[0]=true;
            }
        } ;
        T result=action.apply(tx);
        if(dirty[0]) {
            Path tmp=path.resolveSibling("agent-state.tmp");
            try {
                byte[] bytes=Json.write(working).getBytes(StandardCharsets.UTF_8);
                if(bytes.length>128L*1024*1024)throw new IOException("Local snapshot limit reached; migrate to JDBC storage");
                try(FileChannel output=FileChannel.open(tmp,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING,StandardOpenOption.WRITE)) {
                    java.nio.ByteBuffer buffer=java.nio.ByteBuffer.wrap(bytes);
                    while(buffer.hasRemaining())output.write(buffer);
                    output.force(true);
                }
                try {
                    Files.move(tmp,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
                } catch(AtomicMoveNotSupportedException e) {
                    throw new IOException("Store requires atomic file replacement",e);
                }
                data=working;
            } catch(IOException e) {
                throw new IllegalStateException("State persistence failed",e);
            }
        }
        return result;
    }
    @Override public synchronized void close() {
        if(closed)return;
        closed=true;
        try {
            lock.release();
            channel.close();
        } catch(IOException e) {
            throw new IllegalStateException(e);
        }
    }
}
