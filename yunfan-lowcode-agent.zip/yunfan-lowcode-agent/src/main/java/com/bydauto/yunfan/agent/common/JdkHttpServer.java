package com.bydauto.yunfan.agent.common;
import com.bydauto.yunfan.agent.AppServices;
import com.bydauto.yunfan.agent.chat.SseOutbound;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
public final class JdkHttpServer implements AutoCloseable {
    private final HttpServer server;
    private final ExecutorService threads;
    private final AppServices services;
    private final Semaphore streams=new Semaphore(16);
    public JdkHttpServer(AppServices services)throws IOException {
        this.services=services;
        server=HttpServer.create(new InetSocketAddress(services.config.get("yunfan.http.host","127.0.0.1"),services.config.integer("yunfan.http.port",8080)),64);
        threads=new ThreadPoolExecutor(4,64,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(128),new ThreadPoolExecutor.AbortPolicy());
        server.setExecutor(threads);
        server.createContext("/",this::handle);
        server.start();
    }
    public int port() {
        return server.getAddress().getPort();
    }
    private void handle(HttpExchange exchange)throws IOException {
        boolean held=false;
        try {
            Headers headers=exchange.getResponseHeaders();
            headers.set("X-Content-Type-Options","nosniff");
            headers.set("Cache-Control","no-store");
            String origin=exchange.getRequestHeaders().getFirst("Origin");
            if(origin!=null) {
                boolean allowed=Arrays.stream(services.config.get("yunfan.http.cors-origins","http://localhost:8080,http://127.0.0.1:8080").split(",")).anyMatch(x->x.strip().equals(origin));
                if(!allowed) {
                    exchange.sendResponseHeaders(403,-1);
                    return;
                }
                headers.set("Access-Control-Allow-Origin",origin);
                headers.set("Vary","Origin");
                headers.set("Access-Control-Allow-Methods","GET,POST,PUT,PATCH,DELETE,OPTIONS");
                headers.set("Access-Control-Allow-Headers","Content-Type,Authorization,Last-Event-ID");
            }
            if(exchange.getRequestMethod().equals("OPTIONS")) {
                exchange.sendResponseHeaders(204,-1);
                return;
            }
            byte[] body=exchange.getRequestBody().readNBytes(4*1024*1024+1);
            if(body.length>4*1024*1024) {
                exchange.sendResponseHeaders(413,-1);
                return;
            }
            Map<String,String> query=new LinkedHashMap<>();
            String raw=exchange.getRequestURI().getRawQuery();
            if(raw!=null)for(String part:raw.split("&")) {
                String[] pair=part.split("=",2);
                query.put(URLDecoder.decode(pair[0],StandardCharsets.UTF_8),pair.length==2?URLDecoder.decode(pair[1],StandardCharsets.UTF_8):"");
            }
            String path=exchange.getRequestURI().getPath();
            boolean likelyStream=path.endsWith("/stream")||path.matches("/api/runs/[^/]+/events");
            if(likelyStream) {
                held=streams.tryAcquire();
                if(!held) {
                    exchange.sendResponseHeaders(429,-1);
                    return;
                }
            }
            ApiRouter.Response response=services.router.handle(new ApiRouter.Request(exchange.getRequestMethod(),path,new LinkedHashMap<>(exchange.getRequestHeaders()),query,body));
            headers.set("Content-Type",response.contentType());
            if(response.stream()!=null) {
                headers.set("X-Accel-Buffering","no");
                exchange.sendResponseHeaders(response.status(),0);
                response.stream().accept(new SseOutbound(exchange.getResponseBody()));
            } else {
                exchange.sendResponseHeaders(response.status(),response.body().length);
                try(OutputStream out=exchange.getResponseBody()) {
                    out.write(response.body());
                }
            }
        } catch(IllegalArgumentException e) {
            try {
                exchange.sendResponseHeaders(400,-1);
            } catch(IOException ignored) {
            }
        } finally {
            if(held)streams.release();
            exchange.close();
        }
    }
    @Override public void close() {
        server.stop(1);
        threads.shutdownNow();
    }
}
