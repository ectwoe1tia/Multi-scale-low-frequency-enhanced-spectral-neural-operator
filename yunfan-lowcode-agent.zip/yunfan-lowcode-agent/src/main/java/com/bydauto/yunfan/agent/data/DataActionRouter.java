package com.bydauto.yunfan.agent.data;

import com.bydauto.yunfan.agent.common.*;
import java.util.*;

/** High-confidence routing only. Business measures and grouping columns are never guessed. */
public final class DataActionRouter {
    public record Action(String tool,Map<String,Object> arguments,String reason) {}
    public Action choose(Map<String,Object> request,Map<String,Object> reference){
        Map<String,Object> declared=Json.child(Json.child(request,"context"),"dataPlan");String ref=Json.str(declared,"dataRef",Json.str(reference,"dataRef",""));if(ref.isBlank())return null;
        if(!declared.isEmpty()){
            String op=Json.required(declared,"operation");if(!Set.of("aggregate","export").contains(op))throw ApiException.bad("dataPlan.operation must be aggregate or export");
            Set<String> allowed=op.equals("aggregate")?Set.of("operation","dataRef","groupBy","metrics","filters"):Set.of("operation","dataRef","format","columns","filters");
            if(!allowed.containsAll(declared.keySet()))throw ApiException.bad("Unknown dataPlan field");
            var args=new LinkedHashMap<>(declared);args.remove("operation");args.put("dataRef",ref);return new Action("data__"+op,args,"explicit_structured_data_plan");
        }
        String text=Json.str(request,"message","").toLowerCase(Locale.ROOT);
        if(text.matches("(?s).*(不要|不需要|别导出|不导出|don't|do not|without).*"))return null;
        if(text.matches("(?s).*(导出|下载|export|download).*")){
            List<String> formats=new ArrayList<>();if(text.contains("excel")||text.contains("xlsx"))formats.add("xlsx");if(text.contains("html"))formats.add("html");if(text.contains("csv"))formats.add("csv");
            if(formats.size()==1)return new Action("data__export",Json.map("dataRef",ref,"format",formats.get(0)),"explicit_export_format");
        }
        return null;
    }
}
