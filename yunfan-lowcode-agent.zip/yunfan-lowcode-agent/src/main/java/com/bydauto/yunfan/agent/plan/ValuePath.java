package com.bydauto.yunfan.agent.plan;

import com.bydauto.yunfan.agent.common.*;
import java.math.BigDecimal;
import java.util.*;

/** A bounded structural path, never JSONPath, reflection, interpolation or executable code. */
public final class ValuePath {
    private ValuePath() {}
    public static void validate(Object path) {
        if (!(path instanceof List<?> list) || list.size()>8) PlanCompiler.bad("path must be an array of at most 8 keys/indexes");
        for (Object part:(List<?>)path) {
            if (part instanceof String key && !key.isBlank() && key.length()<=128 && !Set.of("storage_uri","storageUri","localPath","__proto__","class").contains(key)) continue;
            if (part instanceof Number number) try {int index=new BigDecimal(number.toString()).intValueExact();if(index>=0&&index<32)continue;}catch(ArithmeticException ignored){}
            PlanCompiler.bad("Invalid structural path segment");
        }
    }
    public static Object read(Object value,List<?> path) {
        validate(path);
        for(Object part:path) {
            if(part instanceof String key && value instanceof Map<?,?> map && map.containsKey(key)) value=map.get(key);
            else if(part instanceof Number index && value instanceof List<?> list && index.intValue()<list.size()) value=list.get(index.intValue());
            else throw new ApiException(422,"PLAN_PATH_MISSING","Output does not contain the requested path");
        }
        return Json.copy(value);
    }
    public static boolean compare(Object actual,String op,Object expected) {
        if(op.equals("exists"))return actual!=null;
        boolean equal=actual instanceof Number a && expected instanceof Number b
                ?new BigDecimal(a.toString()).compareTo(new BigDecimal(b.toString()))==0:Objects.equals(actual,expected);
        if(op.equals("eq"))return equal;
        if(op.equals("ne"))return !equal;
        if(!(actual instanceof Number a)||!(expected instanceof Number b))return false;
        int c=new BigDecimal(a.toString()).compareTo(new BigDecimal(b.toString()));
        return switch(op){case "gt"->c>0;case "gte"->c>=0;case "lt"->c<0;case "lte"->c<=0;default->false;};
    }
}
