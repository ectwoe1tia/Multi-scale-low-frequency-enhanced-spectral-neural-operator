package com.bydauto.yunfan.agent.artifact;

import com.bydauto.yunfan.agent.auth.AuthContext;
import java.util.Map;
import java.util.function.Consumer;

/** Replaceable private data plane; public descriptors deliberately have no storage locator. */
public interface ArtifactStore {
    record ArtifactHandle(String id) {}
    record PublicArtifactDescriptor(String artifactId,String kind,long rowCount,long bytes,String completeness,String expiresAt) {}
    interface ReadLease extends AutoCloseable {void close();}
    PublicArtifactDescriptor describe(AuthContext actor,ArtifactHandle handle);
    ReadLease lease(AuthContext actor,String id);
    void scan(AuthContext actor,String id,Consumer<Map<String,Object>> consumer);
    String contentHash(AuthContext actor,String id);
}
