from pathlib import Path
import hashlib,json,re,sys,zipfile
d=Path(__file__).resolve().parents[2];s=d/'workflow-testing'
sys.path.insert(0,str(s/'scripts'))
import toolchain,advanced_tools
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
baseline=json.loads((d/'source-manifest.json').read_text(encoding='utf-8'));source=Path(baseline['source'])
unchanged=all((source/ref).is_file() and sha(source/ref)==h for ref,h in baseline['files'].items())
assert unchanged,'Original v4 was changed'
validation=json.loads((d/'verification/validation.json').read_text(encoding='utf-8'))
assert all(x['exit_code']==0 for x in validation['commands'])
log=(d/'verification/release-regression.stderr.log').read_text(encoding='utf-8')
assert 'Ran 129 tests' in log and log.strip().endswith('OK')
metrics=json.loads((d/'verification/release-static/metrics.json').read_text(encoding='utf-8'))
assert metrics['business_http_calls']==metrics['browser_replays']==0
report=d/'REPORT.md';text=report.read_text(encoding='utf-8')
text=text.replace('128 项全部通过','129 项全部通过').replace('新增 34 项','新增 35 项')
text=text.replace('verification/regression-final.stderr.log','verification/release-regression.stderr.log').replace('verification/static-release','verification/release-static')
text=text.replace('2.570 秒',f'{metrics["elapsed_seconds"]:.3f} 秒')
text=text.replace('源文件将在打包时逐项核对哈希','源文件已逐项核对哈希，确认未改变')
text=text.replace('生成物记录了','生成物记录了')
text=text.replace('- 并行、隐式并发和不透明结构不按 XOR 枚举；路径搜索截断可见，推导只在明确假设下成立。',
                  '- 并行、隐式并发和不透明结构不按 XOR 枚举；路径搜索截断可见，推导只在明确假设下成立。另设遍历与输出预算，缺少结束节点也能有界退出。生成物绑定生成器代码摘要，代码变化后也强制失效。')
report.write_text(text,encoding='utf-8')
changed=[];added=[]
for p in s.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or '.coordination' in p.parts or p.name=='change-request.json':continue
    ref=p.relative_to(s).as_posix()
    if ref not in baseline['files']:added.append(ref)
    elif sha(p)!=baseline['files'][ref]:changed.append(ref)
req=json.loads((s/'change-request.json').read_text(encoding='utf-8'))
req.update(status='implemented',changed_files=sorted(changed),new_files=sorted(added),
           contract_changes=['runner major version 3.0.0; JSON request protocol 1.0 retained',
              'Explicit runtime_init migration activates context receipts for every execution entrypoint',
              'Finite DSL and project rule tools; offline graph/trace tools and bounded queries',
              'Versioned artifact manifests bind source/product hashes and generator code digest'],
           compatibility='Legacy workspaces remain compatible until explicitly initialized. Original v4 retained. Strict migration rejects missing/stale receipts. Existing assertions/guards/raw FAIL remain.',
           validation={'status':'passed','commands':[c['command'] for c in validation['commands']],
               'exit_codes':[c['exit_code'] for c in validation['commands']],
               'evidence':['../verification/release-regression.stderr.log','../verification/release-static/metrics.json','../verification/validation.json']},
           review={'status':'pending','reviewer':'','notes':['No independent reviewer performed a review.']},
           rollback='Original v4 verified unchanged. Switch isolated Skill version and preserve evidence; do not delete project runtime policy to bypass strict workflow.',
           open_questions=['Company definition export profile, normalized engine history and authorized business fixtures require local acceptance.'],
           next_action='Read START_HERE.md and references/v5.md; register project runtime, then status -> context_refresh -> current request.')
save(s/'change-request.json',req)
lease=json.loads((d/'maintenance-lease.json').read_text(encoding='utf-8'))
release=toolchain.dispatch(s,{'protocol_version':'1.0','tool':'release','arguments':{'lease_token':lease['data']['lease_token']}})
assert release['ok'];save(d/'verification/lease-release.json',release)
save(d/'handoff.json',{'delivery':'workflow-testing-v5','runner_version':'3.0.0','protocol_version':'1.0',
     'status':'implemented_and_locally_verified','registered_new_tools':list(advanced_tools.TOOLS),
     'source_v4_unchanged':unchanged,'maintenance_lease_released':True,'tests':{'passed':129,'failed':0},
     'independent_review':'pending','company_business_acceptance':'not_executed','static_demo':metrics,
     'entry':'START_HERE.md','report':'REPORT.md','contracts':'workflow-testing/references/v5.md',
     'resume':'Initialize strict runtime explicitly, invoke project requests/status.json and its refresh_request; inspect focus and generated requests.',
     'known_limits':['Dynamic tools currently rule_evaluate recipes','No online definition fetch or general native history conversion',
                      'No full concurrent token/UEL feasibility solver','No SQLite or resident service needed/implemented']})
old_setup=Path(r'E:\AI\setup_workflow_v5.py')
if old_setup.is_file():old_setup.rename(d/'verification/maintenance-scripts/setup_workflow_v5.py')
files=sorted(p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.coordination' not in p.parts and p.name not in ('maintenance-lease.json','MANIFEST.sha256.json'))
save(d/'MANIFEST.sha256.json',{p.relative_to(d).as_posix():sha(p) for p in files})
files.append(d/'MANIFEST.sha256.json');archive=d.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,d.name+'/'+p.relative_to(d).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(files),
                  'changed':len(changed),'added':len(added),'source_v4_unchanged':unchanged,'lease_released':True},ensure_ascii=False))
