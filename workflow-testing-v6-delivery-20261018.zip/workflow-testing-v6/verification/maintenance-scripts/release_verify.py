from pathlib import Path
import json,subprocess,sys
d=Path(__file__).resolve().parents[2];s=d/'workflow-testing';v=d/'verification'
checks=[('release-regression',[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-v']),
        ('release-skill-validation',[sys.executable,'-X','utf8',r'C:\Users\jing\.codex\skills\.system\skill-creator\scripts\quick_validate.py',str(s)]),
        ('release-static',[sys.executable,'-X','utf8','scripts/demo_v5.py','--out',str(v/'release-static')])]
record=json.loads((v/'validation.json').read_text(encoding='utf-8'))
for label,cmd in checks:
    r=subprocess.run(cmd,cwd=s,capture_output=True,encoding='utf-8',timeout=180)
    for ext,content in [('stdout',r.stdout),('stderr',r.stderr)]:
        (v/(label+'.'+ext+'.log')).write_text(content,encoding='utf-8')
    record['commands'].append({'label':label,'command':cmd,'cwd':str(s),'exit_code':r.returncode,
          'stdout':'verification/'+label+'.stdout.log','stderr':'verification/'+label+'.stderr.log'})
    (v/'validation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'label':label,'exit_code':r.returncode,'tail':(r.stdout+r.stderr)[-500:]},ensure_ascii=False),flush=True)
    if r.returncode:sys.exit(r.returncode)
