import json, shutil, hashlib, sys
from pathlib import Path
src = Path(r'E:\AI\demo\workflow-testing-v4-delivery-20261013\workflow-testing')
d = Path(r'E:\AI\demo\workflow-testing-v5-delivery-20261013')
dst = d / 'workflow-testing'
dst.mkdir(parents=True, exist_ok=False)
for folder in ('scripts','tests','references','assets','agents'):
    shutil.copytree(src/folder, dst/folder, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for f in ('AGENTS.md','SKILL.md'):
    shutil.copyfile(src/f,dst/f)
shutil.copyfile(Path(r'E:\AI\designs\workflow-testing-v5\DESIGN.md'),d/'DESIGN.md')
sys.path.insert(0,str(dst/'scripts'))
import toolchain
files=['SKILL.md','scripts/toolchain.py','scripts/file_workflow.py','scripts/http_runner.py','references/extensions.md','references/toolchain.md','references/implementation.md','assets/tool-request.schema.json']
def call(tool,**args):
    return toolchain.dispatch(dst,{'protocol_version':'1.0','tool':tool,'arguments':args})
hashes=call('snapshot',files=files)['data']['base_hashes']
req=json.loads((dst/'assets/change-request.template.json').read_text(encoding='utf-8'))
req.update(change_id='CHANGE-V5-STATIC-RULES',owner='codex-maintainer',purpose='实现用户授权的 v5 蓝图：强制刷新、DSL/生成器、静态覆盖、Recorder/HAR、分层查询及接续。',base_version='2.2.0',base_hashes=hashes,changed_files=files,status='implementing')
(dst/'change-request.json').write_text(json.dumps(req,ensure_ascii=False,indent=2),encoding='utf-8')
lease=call('claim',owner=req['owner'],change_id=req['change_id'],base_hashes=hashes)
(d/'maintenance-lease.json').write_text(json.dumps(lease,indent=2),encoding='utf-8')
baseline={p.relative_to(src).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.coordination' not in p.parts}
(d/'source-manifest.json').write_text(json.dumps({'source':str(src),'files':baseline},ensure_ascii=False,indent=2),encoding='utf-8')
print(dst)
