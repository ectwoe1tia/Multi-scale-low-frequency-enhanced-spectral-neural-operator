from pathlib import Path
import datetime,json,subprocess,sys
d=Path(__file__).resolve().parents[2];s=d/'workflow-testing';v=d/'verification'
commands=[('regression',[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-v']),
          ('skill-validation',[sys.executable,'-X','utf8',r'C:\Users\jing\.codex\skills\.system\skill-creator\scripts\quick_validate.py',str(s)]),
          ('static-final',[sys.executable,'-X','utf8','scripts/demo_v5.py','--out',str(v/'static-final')])]
records=[]
for label,cmd in commands:
    result=subprocess.run(cmd,cwd=s,capture_output=True,encoding='utf-8',timeout=180)
    (v/(label+'.stdout.log')).write_text(result.stdout,encoding='utf-8')
    (v/(label+'.stderr.log')).write_text(result.stderr,encoding='utf-8')
    records.append({'label':label,'command':cmd,'cwd':str(s),'exit_code':result.returncode,'stdout':'verification/'+label+'.stdout.log','stderr':'verification/'+label+'.stderr.log'})
    (v/'validation.json').write_text(json.dumps({'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':records},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'label':label,'exit_code':result.returncode,'tail':(result.stdout+result.stderr)[-450:]},ensure_ascii=False),flush=True)
    if result.returncode:sys.exit(result.returncode)
