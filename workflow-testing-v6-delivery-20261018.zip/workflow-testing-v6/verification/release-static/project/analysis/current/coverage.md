# 静态流程覆盖报告

定义：expense:1:demo

| 证据基础 | 节点 | 边 | 决策出口 | 路径义务 |
|---|---|---|---|---|
| observed | 5/5; ratio=1.0 | 5/5; ratio=1.0 | 2/2; ratio=1.0 | 2/2; ratio=1.0 |
| derived | 5/5; ratio=1.0 | 0/5; ratio=0.0 | 0/2; ratio=0.0 | 0/2; ratio=0.0 |
| planned | 5/5; ratio=1.0 | 5/5; ratio=1.0 | 2/2; ratio=1.0 | 2/2; ratio=1.0 |

路径枚举：None；条件可行性未证明。
不透明节点：[]
