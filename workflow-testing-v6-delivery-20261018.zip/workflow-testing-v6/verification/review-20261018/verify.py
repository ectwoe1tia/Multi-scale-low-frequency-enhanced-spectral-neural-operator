"""Local regression plus real loopback session/report demonstration."""
import copy,json,shutil,subprocess,sys,threading
from http.server import ThreadingHTTPServer
from pathlib import Path
here=Path(__file__).resolve().parent;delivery=here.parents[1];skill=delivery/'workflow-testing'
if len(sys.argv)>1:
 here=Path(sys.argv[1]).resolve();here.mkdir(parents=True,exist_ok=False)
sys.path[:0]=[str(skill/'scripts'),str(skill/'tests')]
from test_session_reporting import assets,HeaderHandler


def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2)


def check(label,cmd):
 with (here/(label+'.stdout.log')).open('x',encoding='utf-8') as out,(here/(label+'.stderr.log')).open('x',encoding='utf-8') as err:
  p=subprocess.run(cmd,cwd=skill,stdout=out,stderr=err,timeout=180)
 if p.returncode:raise RuntimeError('Check failed: '+label)
 return {'command':cmd,'exit_code':p.returncode,'stdout':label+'.stdout.log','stderr':label+'.stderr.log'}


def demo():
 root=here/'session-demo';root.mkdir(exist_ok=False)
 server=ThreadingHTTPServer(('127.0.0.1',0),HeaderHandler);server.seen=[];server.fail=False
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 calls=[]
 try:
  suite,adapter,plan=assets(server.server_port)
  good=copy.deepcopy(suite['cases'][0]);good.update(id='TC-001',title='文件编制—成功保存（本地回环）')
  bad=copy.deepcopy(good);bad.update(id='TC-002',title='文件编制—缺少编号的失败诊断（故意不满足预期）',category='validation')
  suite['cases']=[good,bad]
  good_plan=copy.deepcopy(plan['cases'][0]);good_plan['case_id']='TC-001'
  bad_plan=copy.deepcopy(good_plan);bad_plan['case_id']='TC-002'
  plan['cases']=[good_plan,bad_plan]
  spec={'suite':'suite.json','adapter':'adapter.json','plan':'plan.json','project_dir':'project',
        'credentials_file':'private/tokens.json','execution_mode':'file_only'}
  for ref,value in [('suite.json',suite),('adapter.json',adapter),('plan.json',plan),('session-spec.json',spec),
                    ('private/tokens.json',{'version':'1.0','env':{'WF_DEMO_APPLICANT':'LOCAL-TOKEN-CANARY','WF_CLIENT_ID':'LOCAL-CLIENT-CANARY'}})]:save(root/ref,value)
  shell=shutil.which('powershell') or shutil.which('pwsh')
  def call(action,cid=None,expected=0):
   args=[shell,'-NoProfile','-File',str(skill/'scripts/Invoke-WorkflowSession.ps1'),'-Session',str(root/'session-spec.json'),'-Action',action]
   if cid:args+=['-CaseId',cid]
   p=subprocess.run(args,capture_output=True,encoding='utf-8',timeout=30)
   label=str(len(calls)+1).zfill(2)+'-'+action
   (root/(label+'.stdout.log')).write_text(p.stdout,encoding='utf-8')
   (root/(label+'.stderr.log')).write_text(p.stderr,encoding='utf-8')
   assert p.returncode==expected,(label,p.stdout,p.stderr)
   assert 'LOCAL-TOKEN-CANARY' not in p.stdout and 'LOCAL-CLIENT-CANARY' not in p.stdout
   brief=json.loads(p.stdout)
   calls.append({'action':action,'case_id':cid,'exit_code':p.returncode,'stdout_bytes':len(p.stdout.encode('utf-8')),'command':args,'response':brief['response_file']})
   return json.loads((root/brief['response_file']).read_text(encoding='utf-8'))
  call('init');call('prepare','TC-001');call('execute','TC-001')
  server.fail=True
  call('prepare','TC-002');call('execute','TC-002',10)
  sent=len(server.seen)
  call('execute','TC-002',10)
  assert sent==len(server.seen)
  report=call('report')['data']['report']
  text=(root/report).read_text(encoding='utf-8')
  for word in ['TC-001','TC-002','PASS','FAIL','文档编号不能为空','400','201','期望值','实际值','GET','POST']:assert word in text
  for secret in ('LOCAL-TOKEN-CANARY','LOCAL-CLIENT-CANARY'):
   for base in ('project','runs','.session-calls','.session-replies'):
    for p in (root/base).rglob('*'):
     if p.is_file():assert secret not in p.read_text(encoding='utf-8'),str(p)
  shutil.copyfile(root/report,here/'SAMPLE-REPORT.md')
  save(root/'commands.json',calls)
  metrics={'cases':2,'observed_statuses':{'PASS':1,'FAIL':1},'intentional_failure':True,
           'http_calls_loopback':len(server.seen),'external_business_calls':0,'repeated_execute_resent':False,
           'powershell_calls':len(calls),'stdout_total_bytes':sum(x['stdout_bytes'] for x in calls),
           'stdout_max_bytes':max(x['stdout_bytes'] for x in calls),'report_bytes':(root/report).stat().st_size,
           'report':report,'credentials_in_reports_or_generated_artifacts':False}
  save(root/'metrics.json',metrics)
  return metrics
 finally:server.shutdown();server.server_close();thread.join()


if __name__=='__main__':
 commands=[check('regression',[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-v']),
           check('boundaries',[sys.executable,'-X','utf8','scripts/check_boundaries.py']),
           check('skill',[sys.executable,'-X','utf8',r'C:\Users\jing\.codex\skills\.system\skill-creator\scripts\quick_validate.py',str(skill)]),
           check('static-demo',[sys.executable,'-X','utf8','scripts/demo_v5.py','--out',str(here/'static-demo')])]
 metrics=demo();save(here/'validation.json',{'commands':commands,'session_demo':metrics})
 print(json.dumps({'checks':len(commands),'session_demo':metrics},ensure_ascii=False))
