---
name: workflow-testing
description: 基于需求和接口资料维护流程测试；通过文件引用与强制刷新接续用例，编译项目规则 DSL 和工具描述，静态分析 BPMN/Flowable 定义快照的路径覆盖，对齐 Chrome Recorder/HAR，并保留证据和项目经验。
---

# 流程测试：文件调用与静态覆盖

动作通过 scripts/toolchain.py 或 Invoke-WorkflowTool.ps1 的注册 JSON 请求执行，完整回执用 --response-file 保存，终端优先加 --control（PowerShell: -Control）；已有 --brief 仍可用。上下文保留当前动作、结果码和文件引用；业务资料交给程序读取。

## 当前工作入口

1. 接手项目先调用其 requests/status.json，读取新 NEXT.json。新项目先 flow_init，再 runtime_init：启用严格刷新策略。只复制 Skill 不等于初始化项目。
2. 按 status 返回的 refresh_request 调 context_refresh，读当前 focus。生成的下一动作请求已经绑定 receipt，不手抄版本/哈希。规则、来源、状态变化或 600 秒后凭据失效，先刷新；CONTEXT_STALE 的完整回执附刷新请求引用。
3. 不清楚参数时调用 tool_help(name)，只查当前工具；完整 describe/schema 保存在文件。每次只处理当前 case，大输入用 $file 多级引用交给程序；图/规则查询用 artifact_query。
4. 实际执行：刷新 → flow_prepare → flow_diagnose 检查准备摘要 → 必要时 evidence_query 定位字段 → 调已绑定凭据的 execute 请求 → status。排查失败也先 flow_diagnose；evidence_query 默认只返回类型/大小，确需实际值才选 value。已完成 attempt 只复用证据；UNKNOWN/INCOMPLETE 先核对，不能改 run_id 重发。
5. 静态分析：规则文件 → rules_codegen；BPMN/Flowable 定义快照和 case/证据绑定 → flow_analysis；Recorder/HAR → trace_align。这些工具不发业务请求、不回放浏览器。
6. 失败/修正留 flow_note 或带适用版本的 knowledge_record，区分假设与确认；当前 focus 只带少量相关经验。交接保留 workspace、版本、status 请求和未决项，不复述大文件。

## 持续遵守

- ready 用例、角色/权限、guards、每步状态码和业务断言不能削弱；业务依据决定 expected，录制状态码/代码不是自动验收依据。候选规则不能自动启用。
- 原始 FAIL 保留，gate 单独表示处置。写请求不自动重试；不确定状态先查真实副作用并确认旧执行者停止。
- 区分 observed/derived/planned 覆盖；无证据、循环截断或不支持结构如实标明，不能报告虚构实际覆盖。不同定义版本/实例/attempt 不混合。
- 生成的项目工具是受限数据描述，由固定内核执行；不得 import 生成脚本、eval、任意 shell/URL/SQL。凭据不进参数、笔记或报告。
- 执行者不修改公共代码。维护用变更单、snapshot/claim/release；原证据不可覆盖，不清除他人租约。
- 诊断动作码是建议，不是自动重试或执行许可。正常排查不整份读取 plan/results/回执；先依证据指针查询。输出超限就缩小查询，不将大文件拆成多个聊天片段。业务结论要保留来源；结构校验、规约校验、真实执行分别记录。

## 按需加载

| 工作 | 资料 |
|---|---|
| 单工具参数、失败排查、字段查询、代码边界 | [诊断与确定性边界](references/diagnostics.md)；保持常驻上下文小，细节按需加载 |
| 刷新、DSL/动态工具、静态覆盖、双输入对齐、查询 | [v5 实际契约](references/v5.md)，字段以 assets/v5.schema.json 和请求 schema 为准 |
| 参数文件、attempt/重试/核对/报告 | [文件会话](references/file-workflow.md)；严格模式加上述刷新要求 |
| Word/PDF/Apifox/HAR 接入或需求分析 | [原任务路由](references/v3-routing.md)，只加载当前任务对应资料 |
| HTTP 执行语义 | [HTTP 契约](references/http-contract.md)、[工具入口](references/toolchain.md) |
| 维护接续 | [协作](references/collaboration.md)、[扩展](references/extensions.md) |

生成的项目 Skill 从 references/project-index.json 起步，逐 case 加载。工具参数以 tool_help/导出 schema 为准。交接保存版本、status 请求、当前诊断引用和未决项；本地合成演示不算公司业务验收，生成不等于安装。
