"""CI architecture fitness check for maintained offline modules (not a sandbox)."""
import ast
import json
from pathlib import Path

STATIC_MODULES = ('flow_model', 'flow_analysis', 'trace_align', 'rules_codegen', 'inspection')
FORBIDDEN_IMPORTS = {'subprocess', 'socket', 'http.client', 'urllib.request', 'requests',
                     'httpx', 'ftplib', 'toolchain', 'importlib', 'runpy', 'ctypes'}
FORBIDDEN_CALLS = {'eval', 'exec', 'compile', '__import__', 'run_plan', 'curl_request',
                   'dispatch', 'Popen', 'system', 'popen'}


def check_source(source, label):
    issues = []
    tree = ast.parse(source, filename=label)
    aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for item in node.names:
                aliases[item.asname or item.name] = item.name
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [x.name for x in node.names] if isinstance(node, ast.Import) else [node.module or '']
            for name in names:
                if any(name == x or name.startswith(x + '.') for x in FORBIDDEN_IMPORTS):
                    issues.append({'file': label, 'line': node.lineno, 'code': 'FORBIDDEN_IMPORT', 'name': name})
        if isinstance(node, ast.Call):
            name = node.func.id if isinstance(node.func, ast.Name) else node.func.attr if isinstance(node.func, ast.Attribute) else ''
            name = aliases.get(name, name)
            if name in FORBIDDEN_CALLS:
                issues.append({'file': label, 'line': node.lineno, 'code': 'FORBIDDEN_CALL', 'name': name})
    return issues


def check(directory=None):
    directory = directory or Path(__file__).resolve().parent
    issues = []
    for module in STATIC_MODULES:
        path = directory / (module + '.py')
        issues.extend(check_source(path.read_text(encoding='utf-8'), path.name))
    import toolchain
    import tool_contracts
    if set(toolchain.TOOLS) != set(tool_contracts.EFFECTS):
        issues.append({'code': 'REGISTRY_EFFECT_MISMATCH'})
    return {'ok': not issues, 'static_modules': len(STATIC_MODULES),
            'tools': len(toolchain.TOOLS), 'issues': issues}


if __name__ == '__main__':
    result = check()
    print(json.dumps(result, ensure_ascii=False))
    raise SystemExit(0 if result['ok'] else 1)
