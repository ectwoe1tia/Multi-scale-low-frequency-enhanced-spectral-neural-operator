"""Context receipts bound to files, phase, case and state; no transport."""
import hashlib
import json
import shutil
import time
import uuid
from pathlib import Path
import http_runner as rt
import file_workflow as fw
import v5_common as c

POLICY = '.workflow-runtime.json'

def strict(root):
    path=rt.workspace_path(root,POLICY)
    if not path.exists():
        return False
    policy=c.read(root,POLICY)
    rt.shape(policy,['version','strict','projects'],label='runtime policy')
    rt.need(policy['version']=='1.0' and policy['strict'] is True,'Invalid runtime policy')
    return True

def init(root,args):
    p,d=c.project(root,args['project'])
    target=rt.workspace_path(root,args['out'])
    rt.need(not target.exists(),'Runtime output exists','OUTPUT_EXISTS')
    # Workspace-exclusive lock also protects registering multiple projects.
    with c.lock(root,root,'init'):
        policy=c.read(root,POLICY) if strict(root) else {'version':'1.0','strict':True,'projects':[]}
        rt.need(args['project'] not in policy['projects'],'Project already initialized','OUTPUT_EXISTS')
        policy['projects'].append(args['project'])
        target.mkdir(parents=True,exist_ok=False)
        info={'runner_version':rt.VERSION,'static_ready':True,'execution_ready':bool(shutil.which('curl.exe') or shutil.which('curl')),
              'network_tested':False,'project':args['project'],'initialized_at':rt.utc_now()}
        c.write(root,args['out']+'/environment.json',info)
        c.replace(root,POLICY,policy)
    return {'environment':args['out']+'/environment.json','strict':True,'static_ready':True,'network_executed':False}

def dependencies(root,pref,cid,phase,plan=None):
    p,d=c.project(root,pref)
    rt.need(cid=='*' or cid in p['cases'],'Unknown case_id')
    refs=[pref,p['suite'],p['adapter'],POLICY]
    for case in ([cid] if cid!='*' else p['cases']):
        comp=fw.Composer(root)
        comp.file(p['cases'][case])
        refs.extend(comp.hashes)
    for folder in ('notes','knowledge','contracts'):
        path=rt.workspace_path(root,c.relative(root,d/folder))
        if path.exists():
            refs += [c.relative(root,x) for x in path.rglob('*') if x.is_file()]
    for name in ('active-rules.json','artifacts.json'):
        ref=c.relative(root,d/'runtime'/name)
        if rt.workspace_path(root,ref).exists():
            refs.append(ref)
            if name=='active-rules.json':
                pointer=c.read(root,ref); manifest=c.read(root,pointer['manifest'])
                refs += [pointer['manifest']]+list(manifest['inputs'])
                base=pointer['manifest'].rsplit('/',1)[0]
                refs += [base+'/'+x for x in manifest['products']]
    if plan:
        refs.append(plan)
    # Guard against pointer replacement and changes in core behavior/contract.
    package=Path(__file__).resolve().parents[1]
    core={str(x.relative_to(package)):hashlib.sha256(x.read_bytes()).hexdigest() for folder in ('scripts','references')
          for x in (package/folder).glob('*') if x.is_file() and x.suffix in ('.py','.md')}
    core['SKILL.md']=hashlib.sha256((package/'SKILL.md').read_bytes()).hexdigest()
    files={ref:c.hash_file(root,ref) for ref in sorted(set(refs))}
    # Discovery is repeated at verification; adding/removing notes, rules or case refs invalidates receipt.
    state=[]
    for case in ([cid] if cid!='*' else p['cases']):
        nums=fw.attempts(root,d,case)
        latest=fw.evidence(root,d,case,nums[-1]) if nums else {'status':'TODO'}
        state.append([case,nums,latest])
    return {'files':files,'core':rt.digest(core),'state':rt.digest(state)}

def refresh(root,args):
    rt.need(strict(root),'Initialize strict runtime first','RUNTIME_REQUIRED')
    pref,cid=args['project'],args['case_id']
    rt.need(pref in c.read(root,POLICY)['projects'],'Project not initialized')
    phase=args.get('phase','prepare')
    rt.need(phase in ('prepare','execute','run','query'),'Unsupported refresh phase')
    p,d=c.project(root,pref)
    plan=args.get('plan')
    if phase=='execute':
        nums=fw.attempts(root,d,cid)
        rt.need(nums,'Prepare case before execute refresh')
        plan=c.relative(root,fw.attempt_dir(root,d,cid,nums[-1])/'plan.json')
    if phase=='run':
        rt.need(plan and cid=='*','Legacy run refresh needs plan and case_id=*')
        rt.need(all(case['case_id'] in p['cases'] for case in c.read(root,plan)['cases']),'Legacy run plan exceeds project cases')
    dep=dependencies(root,pref,cid,phase,plan)
    bundle=None
    if plan:
        bundle=rt.digest({'suite':c.read(root,p['suite']),'adapter':c.read(root,p['adapter']),'plan':c.read(root,plan)})
    receipt={'receipt_version':'1.0','project':pref,'case_id':cid,'phase':phase,'plan':plan,
             'issued_at':time.time(),'ttl_seconds':600,'dependencies':dep,'bundle_digest':bundle}
    target=rt.workspace_path(root,args['out'])
    target.mkdir(parents=True,exist_ok=False)
    c.write(root,args['out']+'/receipt.json',receipt)
    # Checksum is for accidental changes, not cryptographic authentication of a local writer.
    c.write(root,args['out']+'/receipt.integrity.json',{'sha256':c.hash_file(root,args['out']+'/receipt.json')})
    focus=fw.focus(root,pref,p,d,cid) if cid!='*' else {'case_id':'*','scope':'Selected plan; full data stays on disk'}
    active=c.relative(root,d/'runtime/active-rules.json')
    focus['rules_ref']=active if rt.workspace_path(root,active).exists() else None
    if focus['rules_ref']:
        import rules_codegen
        relevant=[r for r in rules_codegen.active(root,pref) if cid=='*' or rules_codegen.applies(r,cid)]
        focus['rules_summary']={'count':len(relevant),'ids':[r['id'] for r in relevant[:5]],'details_ref':active}
    knowledge=rt.workspace_path(root,c.relative(root,d/'knowledge'))
    if knowledge.exists():
        candidates=[]
        for path in sorted(knowledge.glob('*.json'),reverse=True):
            n=c.read(root,c.relative(root,path))
            if n['case_id'] not in ('*',cid):continue
            valid=all(rt.workspace_path(root,x).is_file() and c.hash_file(root,x)==h for x,h in {**n['applicability'],**n['evidence_hashes']}.items())
            if valid:candidates.append({'kind':n['kind'],'summary':n['summary'][:240],'next_action':n['next_action'][:240],'ref':c.relative(root,path)})
            if len(candidates)==3:break
        focus['knowledge']=candidates
    focus['receipt']=args['out']+'/receipt.json'
    raw=json.dumps(focus,ensure_ascii=False,indent=2)
    if len(raw.encode('utf-8'))>4096:
        full=args['out']+'/focus-details.json'
        c.write(root,full,focus)
        focus={'case_id':cid,'details_ref':full,'receipt':focus['receipt'],'rule':'Load current required references before acting.'}
    c.write(root,args['out']+'/focus.json',focus)
    c.write(root,args['out']+'/changes.json',{'dependency_groups':list(dep),'note':'Receipt binds files, core and case state; refresh on changes or after 600s.'})
    action=None
    if phase=='prepare':
        action=fw.request('flow_prepare',project=pref,case_id=cid,context_receipt=args['out']+'/receipt.json')
    if phase=='execute':
        action=fw.request('flow_execute',project=pref,case_id=cid,attempt=fw.attempts(root,d,cid)[-1],context_receipt=args['out']+'/receipt.json')
    if action:
        c.write(root,args['out']+'/next.request.json',action)
    return {'focus':args['out']+'/focus.json','receipt':args['out']+'/receipt.json',
            'next_request':args['out']+'/next.request.json' if action else None,'network_executed':False}

def verify(root,ref,pref,phase,cid=None,ignore_state=False):
    rt.need(ref,'Refresh required: context_refresh; receipt missing','CONTEXT_REQUIRED')
    receipt=c.read(root,ref)
    rt.shape(receipt,['receipt_version','project','case_id','phase','plan','issued_at','ttl_seconds','dependencies','bundle_digest'],label='context receipt')
    checksum=c.read(root,ref.rsplit('/',1)[0]+'/receipt.integrity.json')
    rt.need(checksum.get('sha256')==c.hash_file(root,ref),'Receipt modified','EVIDENCE_CHANGED')
    rt.need(receipt['receipt_version']=='1.0' and receipt['project']==pref and receipt['phase']==phase and
            (cid is None or receipt['case_id']==cid),'Receipt scope/phase mismatch','CONTEXT_STALE')
    rt.need(type(receipt['issued_at']) in (int,float) and receipt['ttl_seconds']==600 and
            0<=time.time()-receipt['issued_at']<=600,'Refresh required: receipt expired','CONTEXT_STALE')
    latest=dependencies(root,pref,receipt['case_id'],phase,receipt['plan'])
    expected=receipt['dependencies']
    if ignore_state:
        latest.pop('state'); expected=dict(expected); expected.pop('state')
    changed=[key for key in latest if latest[key]!=expected.get(key)]
    if changed:
        changed_files=[x for x in set(latest.get('files',{}))|set(expected.get('files',{})) if latest.get('files',{}).get(x)!=expected.get('files',{}).get(x)]
        _,d=c.project(root,pref)
        request_ref=c.relative(root,d/'runtime'/('refresh-'+uuid.uuid4().hex+'.request.json'))
        output_ref=c.relative(root,d/'context'/('refresh-'+uuid.uuid4().hex))
        refresh_args={'project':pref,'case_id':receipt['case_id'],'phase':phase,'out':output_ref}
        if phase=='run':refresh_args['plan']=receipt['plan']
        c.write(root,request_ref,fw.request('context_refresh',**refresh_args))
        error=rt.ToolError('CONTEXT_STALE','Refresh required; changed dependency groups: '+','.join(changed))
        error.details={'changed_groups':changed,'changed_files':sorted(changed_files),'refresh_request':request_ref}
        raise error
    return receipt

def guard(root,tool,args):
    if not strict(root):
        return
    if tool=='flow_execute':
        p,d=c.project(root,args['project'])
        state=fw.evidence(root,d,args['case_id'],args['attempt'])
        if state['status'] in ('PASS','FAIL','ERROR'):
            return  # idempotent evidence retrieval is not a new execution
    if tool in ('flow_prepare','flow_execute','run'):
        pref=args.get('project')
        rt.need(pref and pref in c.read(root,POLICY)['projects'],'Initialized project context required','CONTEXT_REQUIRED')
        phase={'flow_prepare':'prepare','flow_execute':'execute','run':'run'}[tool]
        verify(root,args.get('context_receipt'),pref,phase,args.get('case_id','*'))

def runtime_guard(root,suite,adapter,plan,execution_context):
    if not strict(root):
        return
    rt.need(isinstance(execution_context,dict),'Direct runtime execution requires refreshed context','CONTEXT_REQUIRED')
    r=verify(root,execution_context.get('receipt'),execution_context.get('project'),execution_context.get('phase'),ignore_state=True)
    rt.need(r['bundle_digest']==rt.digest({'suite':suite,'adapter':adapter,'plan':plan}),'Execution bundle differs from context','CONTEXT_STALE')
    import rules_codegen
    rules_codegen.enforce(root,r['project'],plan)
