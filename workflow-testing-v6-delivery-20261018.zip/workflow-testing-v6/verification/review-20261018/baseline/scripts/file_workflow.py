"""File-backed sessions. Only registered toolchain dispatch may execute a workflow.

All paths in input documents are workspace-relative, never relative to another file.
Summaries are disposable; immutable attempts and checksummed run evidence are authoritative.
"""
import hashlib
import json
import os
import uuid
from pathlib import Path

import http_runner as rt
import capabilities
import suite as suite_tools

LIMIT = 16 * rt.MAX_BYTES
TOOLS = {
    'request_compose': (['spec', 'out'], []),
    'flow_init': (['spec', 'out'], []),
    'flow_prepare': (['project', 'case_id'], ['retry_note','context_receipt']),
    'flow_execute': (['project', 'case_id', 'attempt'], ['context_receipt']),
    'flow_status': (['project'], []),
    'flow_focus': (['project', 'case_id'], []),
    'flow_note': (['project', 'note'], []),
    'flow_reconcile': (['project', 'record'], []),
    'flow_cancel': (['project', 'case_id', 'attempt', 'reason'], []),
    'flow_report': (['project', 'out'], []),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(root, ref):
    return rt.read_json(rt.workspace_path(root, ref, existing=True), max_bytes=LIMIT)


def rel(root, path):
    return path.relative_to(root).as_posix()


def write(path, data):
    encoded = json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2)
    rt.need(len(encoded.encode('utf-8')) <= LIMIT, 'Output exceeds 16 MiB')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as handle:
        handle.write(encoded + '\n')


def replace_text(path, value):
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temp.open('x', encoding='utf-8') as handle:
            handle.write(value)
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


class Composer:
    """Explicit JSON references only; no eval, environment interpolation or shell."""
    def __init__(self, root):
        self.root, self.hashes, self.total = root, {}, 0

    def file(self, ref, pointer='', fmt='json', stack=()):
        path = rt.workspace_path(self.root, ref, existing=True)
        rt.need(path not in stack and len(stack) < 16, 'Reference cycle or depth > 16')
        size = path.stat().st_size
        self.total += size
        rt.need(size <= LIMIT and self.total <= 64 * rt.MAX_BYTES, 'Reference byte budget exceeded')
        self.hashes[ref] = sha(path)
        if fmt == 'text':
            rt.need(pointer == '', 'Text reference cannot have pointer')
            return path.read_text(encoding='utf-8-sig')
        rt.need(fmt == 'json', 'format must be json or text')
        value = rt.read_json(path, max_bytes=LIMIT)
        if pointer:
            rt.need(isinstance(pointer, str) and pointer.startswith('/'), 'Invalid JSON pointer')
            value = rt.json_pointer(value, pointer)
            rt.need(value is not rt.MISSING, 'Referenced JSON pointer does not exist')
        return self.expand(value, stack + (path,))

    def expand(self, value, stack=()):
        if isinstance(value, dict):
            if '$file' in value:
                rt.shape(value, ['$file'], ['pointer', 'format'], 'file reference')
                return self.file(value['$file'], value.get('pointer', ''), value.get('format', 'json'), stack)
            return {k: self.expand(v, stack) for k, v in value.items()}
        if isinstance(value, list):
            return [self.expand(v, stack) for v in value]
        return value


def request(tool, **arguments):
    return {'protocol_version': rt.PROTOCOL, 'tool': tool, 'arguments': arguments}


def project(root, ref):
    p = read(root, ref)
    rt.shape(p, ['schema_version', 'session_id', 'suite', 'adapter', 'plan_id', 'adapter_id', 'cases'], label='project')
    rt.need(p['schema_version'] == '1.0' and isinstance(p['cases'], dict) and 1 <= len(p['cases']) <= 100, 'Invalid project')
    rt.ident(p['session_id'], 'session_id')
    for cid, spec in p['cases'].items():
        rt.ident(cid, 'case_id')
        rt.workspace_path(root, spec, existing=True)
    directory = rt.workspace_path(root, ref, existing=True).parent
    return p, directory


def attempt_dir(root, directory, cid, attempt):
    rt.ident(cid, 'case_id')
    rt.need(isinstance(attempt, str) and len(attempt) == 4 and attempt.isdigit() and int(attempt) > 0, 'Invalid attempt')
    return rt.workspace_path(root, rel(root, directory / 'attempts' / cid / attempt))


def attempts(root, directory, cid):
    base = rt.workspace_path(root, rel(root, directory / 'attempts' / cid))
    return sorted(p.name for p in base.iterdir() if p.is_dir() and len(p.name) == 4 and p.name.isdigit()) if base.exists() else []


def evidence(root, directory, cid, number):
    ad = attempt_dir(root, directory, cid, number)
    if not (ad / 'meta.json').is_file():
        if (ad / 'resolution.json').is_file():
            record = read(root, rel(root, ad / 'resolution.json'))
            verify_hashes(root, record['evidence_hashes'])
            return {'status': 'ABANDONED', 'raw_status': 'INCOMPLETE', 'attempt': number, 'resolution': rel(root, ad / 'resolution.json')}
        return {'status': 'INCOMPLETE', 'attempt': number}
    meta = read(root, rel(root, ad / 'meta.json'))
    run = rt.workspace_path(root, 'runs/' + meta['run_id'] + '/results.json')
    checksum = run.with_suffix('.sha256')
    if run.exists() and checksum.exists():
        rt.need(checksum.read_text(encoding='ascii').strip() == sha(run), 'Run evidence changed', 'EVIDENCE_CHANGED')
        result = rt.read_json(run, max_bytes=LIMIT)
        rt.need(result.get('run_id') == meta['run_id'] and result.get('fingerprint') == meta['fingerprint'], 'Run identity changed', 'EVIDENCE_CHANGED')
        rt.need(result.get('finished_at') and result.get('status') in ('PASS', 'FAIL', 'ERROR'), 'Run incomplete', 'EVIDENCE_CHANGED')
        return {'status': result['status'], 'gate': result['gate'], 'attempt': number, 'run_id': meta['run_id'], 'results': rel(root, run)}
    if (ad / 'resolution.json').exists():
        record = read(root, rel(root, ad / 'resolution.json'))
        verify_hashes(root, record['evidence_hashes'])
        return {'status': 'ABANDONED', 'raw_status': 'UNKNOWN', 'attempt': number, 'resolution': rel(root, ad / 'resolution.json')}
    if (ad / 'intent.json').exists() and read(root, rel(root, ad / 'intent.json')).get('kind') == 'cancel':
        return {'status': 'CANCELLED', 'attempt': number, 'cancellation': rel(root, ad / 'intent.json')}
    return {'status': 'UNKNOWN' if (ad / 'intent.json').exists() or run.parent.exists() else 'PREPARED',
            'attempt': number, 'run_id': meta['run_id'], 'execute_request': rel(root, ad / 'execute.request.json')}


def verify_hashes(root, hashes):
    for ref, digest in hashes.items():
        path = rt.workspace_path(root, ref, existing=True)
        rt.need(sha(path) == digest, 'Referenced input changed: ' + ref, 'STALE_PLAN')


def checked_record(root, ref, required):
    record = read(root, ref)
    rt.shape(record, required + ['evidence'], label='record')
    for field in required:
        rt.need(isinstance(record[field], str) and 1 <= len(record[field]) <= 1000, 'Record fields require 1..1000 characters')
    refs = record['evidence']
    rt.need(isinstance(refs, list) and 1 <= len(refs) <= 10 and all(isinstance(x, str) for x in refs), 'Record needs 1..10 evidence refs')
    return record, {x: sha(rt.workspace_path(root, x, existing=True)) for x in refs}


def focus(root, pref, p, directory, cid):
    rt.need(cid in p['cases'], 'Unknown case_id')
    nums = attempts(root, directory, cid)
    last = evidence(root, directory, cid, nums[-1]) if nums else {'status': 'TODO'}
    notes = []
    nd = directory / 'notes'
    if nd.exists():
        for f in sorted(nd.glob('*.json'), reverse=True):
            n = read(root, rel(root, f))
            if n['case_id'] in ('*', cid):
                notes.append({'kind': n['kind'], 'summary': n['summary'][:240], 'next_action': n['next_action'][:240], 'ref': rel(root, f)})
            if len(notes) == 3:
                break
    return {'case_id': cid, 'latest': last, 'case_spec': p['cases'][cid], 'suite_ref': p['suite'],
            'adapter_ref': p['adapter'], 'lessons': notes,
            'prepare_request': rel(root, directory / 'requests' / (cid + '.prepare.json')),
            'rule': 'Read only current case and relevant references. UNKNOWN/INCOMPLETE requires reconciliation, never resend blindly.'}


def status(root, pref, p, directory):
    counts, rows, next_case = {}, [], None
    for cid in p['cases']:
        nums = attempts(root, directory, cid)
        state = evidence(root, directory, cid, nums[-1]) if nums else {'status': 'TODO'}
        counts[state['status']] = counts.get(state['status'], 0) + 1
        rows.append({'case_id': cid, 'attempts': len(nums), **state})
        if next_case is None and state['status'] != 'PASS':
            next_case = cid
    outline = directory / 'outline.json'
    replace_text(outline, json.dumps({'counts': counts, 'cases': rows}, ensure_ascii=False, indent=2) + '\n')
    current = focus(root, pref, p, directory, next_case) if next_case else {'status': 'ALL_SELECTED_PASSED'}
    next_path = directory / 'NEXT.json'
    summary = {'project': pref, 'counts': counts, 'next': current, 'outline': rel(root, outline),
               'resume_request': rel(root, directory / 'requests/status.json'),
               'scope': 'Latest attempt per selected case; historical failures remain in attempts/runs. Not release authorization.'}
    import freshness
    if next_case and freshness.strict(root) and pref in read(root,freshness.POLICY)['projects']:
        refresh_ref=rel(root,directory/'requests'/(next_case+'.refresh.json'))
        stage='execute' if current['latest']['status']=='PREPARED' else 'query' if current['latest']['status'] in ('UNKNOWN','INCOMPLETE') else 'prepare'
        refresh_request=request('context_refresh',project=pref,case_id=next_case,phase=stage,
                                out=rel(root,directory/'context'/('resume-'+uuid.uuid4().hex)))
        replace_text(rt.workspace_path(root,refresh_ref),json.dumps(refresh_request,ensure_ascii=False,indent=2)+'\n')
        summary['refresh_request']=refresh_ref
    replace_text(next_path, json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    return {'counts': counts, 'next_case': next_case, 'context': rel(root, next_path), 'outline': rel(root, outline),
            'resume_request': rel(root, directory / 'requests/status.json'),
            'refresh_request':summary.get('refresh_request')}


def dispatch(root, tool, args):
    import freshness
    freshness.guard(root,tool,args)
    if tool == 'request_compose':
        composer = Composer(root)
        value = composer.file(args['spec'])
        out = rt.workspace_path(root, args['out'])
        write(out, value)
        return {'file': args['out'], 'sha256': sha(out), 'bytes': out.stat().st_size, 'source_count': len(composer.hashes)}
    if tool == 'flow_init':
        spec = read(root, args['spec'])
        rt.shape(spec, ['suite', 'adapter', 'plan'], label='session spec')
        suite = read(root, spec['suite'])
        errors, _ = suite_tools.validate(suite)
        rt.need(not errors, 'Invalid suite: ' + '; '.join(errors))
        adapter = capabilities.load_adapter(root, rt.workspace_path(root, spec['adapter'], existing=True))
        rt.validate_adapter(adapter)
        plan = read(root, spec['plan'])
        rt.shape(plan, ['schema_version', 'plan_id', 'adapter_id', 'cases'], label='plan')
        rt.need(plan['schema_version'] == '1.0' and plan['adapter_id'] == adapter['adapter_id'], 'Invalid plan header')
        rt.ident(plan['plan_id'], 'plan_id')
        rt.need(isinstance(plan['cases'], list) and 1 <= len(plan['cases']) <= 100, 'Plan needs 1..100 cases')
        ids = [c.get('case_id') for c in plan['cases'] if isinstance(c, dict)]
        rt.need(len(ids) == len(plan['cases']) and len(set(ids)) == len(ids), 'Duplicate/invalid cases')
        for cid in ids:
            rt.ident(cid, 'case_id')
            rt.need(cid in {c['id'] for c in suite['cases']}, 'Case missing from suite')
        out = rt.workspace_path(root, args['out'])
        out.mkdir(parents=True, exist_ok=False)
        pref = rel(root, out / 'project.json')
        p = {'schema_version': '1.0', 'session_id': 'S' + uuid.uuid4().hex[:16],
             'suite': spec['suite'], 'adapter': spec['adapter'], 'plan_id': plan['plan_id'], 'adapter_id': plan['adapter_id'], 'cases': {}}
        for case in plan['cases']:
            cid = case['case_id']
            path = out / 'cases' / (cid + '.json')
            write(path, case)
            p['cases'][cid] = rel(root, path)
            write(out / 'requests' / (cid + '.prepare.json'), request('flow_prepare', project=pref, case_id=cid))
            write(out / 'requests' / (cid + '.focus.json'), request('flow_focus', project=pref, case_id=cid))
        write(out / 'project.json', p)
        write(out / 'requests/status.json', request('flow_status', project=pref))
        return {'project': pref, **status(root, pref, p, out), 'network_executed': False}
    p, directory = project(root, args['project'])
    if tool == 'flow_status':
        return status(root, args['project'], p, directory)
    if tool == 'flow_report':
        current = status(root, args['project'], p, directory)
        lines = ['# 文件会话测试报告', '', '只统计本会话选中用例；不是发布许可。历史失败不会因后次通过而消失。', '',
                 '最新状态统计：`' + json.dumps(current['counts'], ensure_ascii=False) + '`', '',
                 '| Case | Attempt | 原始/观察状态 | 处置 | 证据 |', '|---|---|---|---|---|']
        for cid in p['cases']:
            nums = attempts(root, directory, cid)
            if not nums:
                lines.append(f'| {cid} | — | TODO | — | — |')
            for number in nums:
                state = evidence(root, directory, cid, number)
                ref = state.get('results', state.get('resolution', state.get('cancellation', state.get('execute_request', ''))))
                lines.append('| ' + ' | '.join(suite_tools.md(x) for x in (cid, number, state.get('raw_status', state['status']), state.get('gate', state['status']), ref)) + ' |')
        lines += ['', '基线：' + suite_tools.md(p['suite']), '项目大纲：' + suite_tools.md(current['outline']),
                  '经验记录：' + suite_tools.md(rel(root, directory / 'notes')), '', '未选中范围见原基线与各 run 的 not_selected_cases。']
        target = rt.workspace_path(root, args['out'])
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('x', encoding='utf-8') as handle:
            handle.write('\n'.join(lines) + '\n')
        return {'report': args['out'], 'counts': current['counts'], 'network_executed': False}
    if tool == 'flow_focus':
        data = focus(root, args['project'], p, directory, args['case_id'])
        target = directory / 'FOCUS.json'
        replace_text(target, json.dumps(data, ensure_ascii=False, indent=2) + '\n')
        return {'case_id': args['case_id'], 'status': data['latest']['status'], 'context': rel(root, target)}
    if tool == 'flow_note':
        n, hashes = checked_record(root, args['note'], ['case_id', 'kind', 'summary', 'next_action'])
        rt.need(n['case_id'] == '*' or n['case_id'] in p['cases'], 'Invalid note case')
        rt.need(n['kind'] in ('confirmed', 'hypothesis'), 'Note kind must be confirmed or hypothesis')
        target = directory / 'notes' / (rt.utc_now().replace(':', '-').replace('.', '-') + '-' + uuid.uuid4().hex[:8] + '.json')
        write(target, {**n, 'evidence_hashes': hashes})
        return {'note': rel(root, target), 'network_executed': False}
    if tool == 'flow_reconcile':
        n, hashes = checked_record(root, args['record'], ['case_id', 'attempt', 'reason', 'side_effects', 'authorization', 'writer_stopped'])
        rt.need(n['writer_stopped'] == 'confirmed', 'Confirm old executor has stopped before abandonment')
        rt.need(n['case_id'] in p['cases'], 'Unknown case')
        ad = attempt_dir(root, directory, n['case_id'], n['attempt'])
        state = evidence(root, directory, n['case_id'], n['attempt'])
        rt.need(state['status'] in ('UNKNOWN', 'INCOMPLETE'), 'Only uncertain/interrupted attempts can be abandoned')
        # Abandonment records a human reconciliation; it never declares the raw test passed.
        write(ad / 'resolution.json', {**n, 'evidence_hashes': hashes})
        return {'resolution': rel(root, ad / 'resolution.json'), 'raw_status': state['status'], 'network_executed': False}
    cid = args['case_id']
    rt.need(cid in p['cases'], 'Unknown case_id')
    if tool == 'flow_cancel':
        rt.need(len(args['reason']) <= 1000, 'Cancellation reason too long')
        state = evidence(root, directory, cid, args['attempt'])
        rt.need(state['status'] == 'PREPARED', 'Only unsent prepared attempt can be cancelled', 'ATTEMPT_BLOCKED')
        ad = attempt_dir(root, directory, cid, args['attempt'])
        # Uses the SAME exclusive slot as execute: cancellation and sending cannot both win.
        write(ad / 'intent.json', {'kind': 'cancel', 'reason': args['reason'], 'created_at': rt.utc_now()})
        return {'status': 'CANCELLED', 'cancellation': rel(root, ad / 'intent.json'), 'network_executed': False}
    if tool == 'flow_prepare':
        nums = attempts(root, directory, cid)
        retry = None
        if nums:
            previous = evidence(root, directory, cid, nums[-1])
            rt.need(previous['status'] in ('PASS', 'FAIL', 'ERROR', 'ABANDONED', 'CANCELLED'), 'Existing attempt pending or uncertain; inspect/reconcile first', 'ATTEMPT_BLOCKED')
            rt.need('retry_note' in args, 'Explicit retry note required; no automatic retry', 'RETRY_REQUIRED')
            retry, hashes = checked_record(root, args['retry_note'], ['case_id', 'previous_attempt', 'reason', 'change', 'side_effects', 'authorization'])
            rt.need(retry['case_id'] == cid and retry['previous_attempt'] == nums[-1], 'Retry note does not match latest attempt')
            retry['evidence_hashes'] = hashes
        composer = Composer(root)
        case = composer.file(p['cases'][cid])
        rt.need(case.get('case_id') == cid, 'Composed case identity changed')
        suite = read(root, p['suite'])
        adapter = capabilities.load_adapter(root, rt.workspace_path(root, p['adapter'], existing=True))
        plan = {'schema_version': '1.0', 'plan_id': p['plan_id'], 'adapter_id': p['adapter_id'], 'cases': [case]}
        preview = rt.validate_bundle(suite, adapter, plan)
        if freshness.strict(root):
            import rules_codegen
            rules_codegen.enforce(root,args['project'],plan)
        number = f'{int(nums[-1]) + 1:04}' if nums else '0001'
        rt.need(int(number) <= 100, 'Maximum 100 attempts per case')
        ad = attempt_dir(root, directory, cid, number)
        ad.mkdir(parents=True, exist_ok=False)
        write(ad / 'plan.json', plan)
        write(ad / 'preview.json', preview)
        if retry:
            write(ad / 'retry.json', retry)
        hashes = {**composer.hashes, **{ref: sha(rt.workspace_path(root, ref, existing=True)) for ref in (args['project'], p['suite'], p['adapter'])}}
        rid = p['session_id'] + '-' + hashlib.sha256(cid.encode()).hexdigest()[:12] + '-' + number
        execute = request('flow_execute', project=args['project'], case_id=cid, attempt=number)
        write(ad / 'execute.request.json', execute)
        write(ad / 'meta.json', {'run_id': rid, 'fingerprint': preview['fingerprint'], 'source_hashes': hashes,
                                 'plan_hash': sha(ad / 'plan.json'), 'created_at': rt.utc_now()})
        if freshness.strict(root):
            refreshed=freshness.refresh(root,{'project':args['project'],'case_id':cid,'phase':'execute','out':rel(root,ad/'context-execute')})
            replacement=read(root,refreshed['next_request'])
            replace_text(ad/'execute.request.json',json.dumps(replacement,ensure_ascii=False,indent=2)+'\n')
        return {'case_id': cid, 'attempt': number, 'fingerprint': preview['fingerprint'],
                'preview': rel(root, ad / 'preview.json'), 'execute_request': rel(root, ad / 'execute.request.json'), 'network_executed': False}
    if tool == 'flow_execute':
        number = args['attempt']
        ad = attempt_dir(root, directory, cid, number)
        current = evidence(root, directory, cid, number)
        if current['status'] in ('PASS', 'FAIL', 'ERROR'):
            return {**current, 'reused_evidence': True, 'network_executed': False}
        rt.need(current['status'] == 'PREPARED', 'Attempt uncertain or incomplete; never resend blindly', 'ATTEMPT_BLOCKED')
        rt.need(attempts(root, directory, cid)[-1] == number, 'Only latest attempt can execute')
        meta = read(root, rel(root, ad / 'meta.json'))
        verify_hashes(root, meta['source_hashes'])
        rt.need(sha(ad / 'plan.json') == meta['plan_hash'], 'Prepared plan changed', 'STALE_PLAN')
        suite = read(root, p['suite'])
        adapter = capabilities.load_adapter(root, rt.workspace_path(root, p['adapter'], existing=True))
        plan = rt.read_json(ad / 'plan.json', max_bytes=LIMIT)
        preview = rt.validate_bundle(suite, adapter, plan)
        rt.need(preview['fingerprint'] == meta['fingerprint'], 'Prepared fingerprint changed', 'STALE_PLAN')
        # Exclusive durable intent comes BEFORE any auth check/transport. A crash is conservative UNKNOWN.
        write(ad / 'intent.json', {'run_id': meta['run_id'], 'started_at': rt.utc_now(), 'fingerprint': meta['fingerprint']})
        execution_context={'project':args['project'],'receipt':args.get('context_receipt'),'phase':'execute'} if freshness.strict(root) else None
        result = rt.run_plan(root, suite, adapter, plan, preview, meta['run_id'],execution_context=execution_context)
        result_path = rt.workspace_path(root, 'runs/' + meta['run_id'] + '/results.json', existing=True)
        with result_path.with_suffix('.sha256').open('x', encoding='ascii') as handle:
            handle.write(sha(result_path) + '\n')
        return {**evidence(root, directory, cid, number), 'reused_evidence': False, 'network_executed': True}
    raise rt.ToolError('INVALID_INPUT', 'Unknown file workflow tool')
