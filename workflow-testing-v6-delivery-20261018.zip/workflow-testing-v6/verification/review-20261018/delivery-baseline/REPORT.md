# Workflow Testing v5 实现与验证报告

**当前交付：v5 修订 20261014-control，版本号仍为 v5 / runner 3.0.0。** 本轮增加小型控制输出、诊断与字段查询、单工具契约、可测试的执行边界。155 项回归全部通过；2,881,060 字节合成证据只产生 1,698 字节诊断，5 次工具调用终端合计 1,227 字节。完整变更、官方架构参考、命令与限制见 [本次复查报告](verification/review-20261014/REPORT.md)。

下文保留 20261013 首次 v5 交付记录与当时的 129 项测试结果；最新结果以上述复查报告为准。

本交付基于 v4 / runner 2.2.0，在独立目录实现 **runner 3.0.0**。原 v4 保留，源文件已逐项核对哈希，确认未改变。新增工具已注册，可通过原有 JSON/PowerShell 文件入口调用。

## 已实现功能

| 蓝图模块 | 实际交付 |
|---|---|
| staleness 强制刷新 | runtime_init 显式启用工作区策略；context_refresh 生成 phase/case/状态/依赖绑定的凭据；旧 run、flow_prepare/execute、直接运行内核都检查；完成 attempt 查询继续复用证据 |
| rules_codegen + DSL | 受限 JSON 表达式、约束/路径义务、候选与确认、来源溯源、类型检查；编译 IR/索引、逐规则工具描述/schema 和调用模板；固定 project_tool_invoke 解释，无生成脚本导入 |
| flow_analysis | BPMN XML 和 Flowable 模型 JSON 快照统一图；case/定义/实例/attempt 绑定；observed/derived/planned 分别统计节点、边、决策出口、并行出口和路径义务；Mermaid 标注 case 数及详细索引 |
| Recorder + HAR | 单输入/双输入、显式一对多、候选/含糊/未匹配、时间/页信息、注册 operation 匹配；生成 JSONL 测试轨迹和活动推导锚点；不生成重放默认凭据或业务 expected |
| 分级和查询 | 项目不可覆盖产物 + 输入/输出校验和 + 索引；具名分页查询；版本化经验和失效判断；<=4 KiB 当前摘要；跨进程从文件恢复 |

新增注册工具为 runtime_init、context_refresh、rules_codegen、project_tool_invoke、flow_analysis、trace_align、artifact_query、knowledge_record。工具参数 schema 与命名文件 schema、示例、Skill 路由及生成项目 Skill 资源均已同步。

## 对蓝图的进一步修正

- 刷新错误提供变更文件和可直接调用的刷新请求；status 根据 TODO/PREPARED/UNKNOWN 状态生成不同阶段的入口，避免接续时错误地重新准备或重发。
- 规则编译拒绝未知 case/operation；分析检查规则的定义版本，避免规则拼写错误静默不生效或跨版本应用。
- 模板生成期间校验输入稳定性，不将旧计算结果登记为新文件版本；查询同时检验原始来源和生成产物。
- 活动首尾出现不能证明直达分支：增加 edges_in_order，区分节点子序列与真正分支义务。
- 保留缺值 UNKNOWN、bool/数值类型差别，包括容器内部；未知规则不当作 false 跳过。
- 并行、隐式并发和不透明结构不按 XOR 枚举；路径搜索截断可见，推导只在明确假设下成立。另设遍历与输出预算，缺少结束节点也能有界退出。生成物绑定生成器代码摘要，代码变化后也强制失效。

## 验证结果

最终全量回归 **129 项全部通过**，包含原有 94 项和新增 35 项。没有删除原测试、跳过失败或削弱业务断言。

[最终回归日志](verification/release-regression.stderr.log) 与 [命令/退出码](verification/validation.json) 已保存。Skill 格式校验通过，最新描述更新后也实际复验。

新增测试覆盖：严格模式缺凭据/过期/范围错误/文件与状态变化、旧入口及直接内核绕过、真实回环 HTTP 与重复查询、捕获任务 ID 的规则在第二次副作用前阻断、DSL 注入/类型/冲突/作用域、生成工具来源漂移、XML/REST 图等价、DTD/悬空/非 BPMN 输入拒绝、覆盖分母和证据等级、循环/并行边界、录制关联、来源变化竞态、经验版本失效及大数据不进入当前摘要。

## 60-case 文件调用演示

最新证据在 [static-release](verification/release-static/metrics.json)。全部流程由独立 Python 子进程调用注册工具，输入为合成资料：

| 实测项 | 结果 |
|---|---:|
| 用例数 | 60 |
| 导入的合成活动历史 fixture | 6 |
| 独立进程工具调用 | 14 |
| 业务 HTTP 请求 / 浏览器回放 | 0 / 0 |
| HAR 文件 | 3,966,026 字节 |
| 共享参数文本 | 131,092 字节 |
| 当前已展开计划 | 134,192 字节 |
| 所有终端简短回执合计 | 3,173 字节 |
| 单次回执最大值 | 236 字节 |
| 最终当前上下文 | 1,104 字节 |
| 本机端到端演示时间 | 2.582 秒 |

演示包括：编译并调用生成工具 → 取得凭据 → 修改契约 → 旧请求被 CONTEXT_STALE 阻断 → 沿错误提供的刷新文件接续 → 准备但不发送 → 新进程恢复 PREPARED=1/TODO=59 → 分析定义和导入轨迹 → 对齐约 4 MB HAR → 分页查询与经验归档。

[逐次调用记录](verification/release-static/commands.json)、[静态覆盖报告](verification/release-static/project/analysis/current/coverage.md)、[流程图](verification/release-static/project/analysis/current/graph.mmd)、[测试轨迹](verification/release-static/project/normalized/recording/test-trace.jsonl) 均保留。

图的 5 条边在合成导入证据中覆盖 5/5，只表示该 fixture 的图元素覆盖；**不表示 60 个 case 已执行业务系统测试**。演示没有创建 runs/。以上为实际文件/输出字节数及本机耗时，不是 token 费用或模型记忆准确率测量。

## 公司接续

使用 [START_HERE.md](START_HERE.md) 与 [v5 实际契约](workflow-testing/references/v5.md)。先沿用公司 suite/adapter/plan，注册严格工作区，再通过 status → refresh → 当前生成请求处理。静态分析只使用导出的定义与真实已有历史，不以重新操作系统补证据。

项目保留 sources/contracts/normalized/generated/analysis/knowledge/context/runtime/calls/replies，各自按引用加载。源码维护继续使用变更单与单写者租约。handoff.json、change-request.json 和验证日志记录实现状态与接手事项。

## 当前边界

- 初始化之前保留 v4 兼容执行；严格刷新必须通过 runtime_init 启用，复制 Skill 不会自动启用。
- 动态工具第一版为 rule_evaluate 描述，不是通用多步配方或生成 Python 执行器；不提供任意 SQL/shell/URL。
- Flowable 定义来自本地快照，未实现在线采集；原生历史 REST 多种格式需先规范化成明确 trace 契约。REST 模型类型信息不足时用显式 node_type_map，不能承诺兼容所有 Flowable 导出版本。
- 结构路径枚举不证明条件可满足性；完整并行 token、包容/复杂事件、任意 UEL 和跨调用子流程语义未实现。覆盖仍报告直接证明的节点/边与不透明范围。
- 明确关联/规范化历史是接入者提供的事实绑定；程序验证形状/版本/引用/哈希，不能证明人工证据真实。对齐候选不能自动升级为引擎执行证明。
- 采用文件产物和调用内 Python 数据结构，未增加 SQLite、常驻服务或 pgSQL 索引。当前规模可直接使用，后续性能扩展需真实需求与测试。
- 当前 Windows / Python 3.9.9 环境通过验证；公司真实接口、代理/证书环境和其他操作系统未实测。**独立评审 pending，公司业务验收未执行。**
