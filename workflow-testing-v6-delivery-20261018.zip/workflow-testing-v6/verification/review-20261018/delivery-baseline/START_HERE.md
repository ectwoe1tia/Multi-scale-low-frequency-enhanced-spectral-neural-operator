# Workflow Testing v5 使用入口

Skill 在 `workflow-testing/`，runner **3.0.0**，请求协议仍为 1.0。原 v4 保留；本交付未自动安装或接入公司业务系统。

本次为 **v5 修订 20261014-control**，继续使用 v5 版本号；以包哈希区分构建。新增小型诊断、字段查询、单工具契约及代码副作用边界，详见 [诊断与确定性边界](workflow-testing/references/diagnostics.md)。更新代码后按原契约刷新凭据/重新生成依赖代码摘要的产物。

先读 [报告](REPORT.md)，实际字段和边界读 [v5 契约](workflow-testing/references/v5.md)。`DESIGN.md` 保留原始蓝图，未实现的可选/后续能力以报告为准。

## 公司项目首次接入

1. 固定 workspace，把现有 suite、adapter、plan 和来源资料放入项目。参考旧接入契约保持 adapter 溯源，凭据仍来自环境变量。
2. 如尚无文件会话，调用 flow_init。已有 v4 文件会话可以复用其 project.json，保留原运行证据。
3. 调 runtime_init 登记项目并启用工作区严格策略。**复制包不会自动启用策略**；登记之前仍是兼容模式。
4. 调项目 requests/status.json，按回执的 refresh_request 调 context_refresh，读取当前 focus。工具生成的下一动作请求携带 receipt。
5. 准备后调用 flow_diagnose 读摘要；失败也先诊断。需要值才用 evidence_query 指定字段，sha256 可直接引用诊断文件。UNKNOWN/INCOMPLETE 进入核对，不能直接重发；重试仍须记录上一次副作用和新夹具依据。

所有调用保持文件入口：

```powershell
python -X utf8 <skill路径>\scripts\toolchain.py --workspace <workspace> --request <workspace中的请求文件绝对路径> --response-file replies/<本次唯一名称>.json --control
```

## 静态分析与项目生成

- `rules_codegen`：项目 DSL → IR、工具描述、参数 schema、请求模板。候选规则可以生成，但不能直接启用。
- `flow_analysis`：BPMN 或 Flowable REST 定义快照 + case/证据绑定 → 图、路径和覆盖报告。没有 URL 输入，不自动采集或执行业务请求。
- `trace_align`：Recorder、HAR 或双输入 → 观察轨迹、显式关联、候选和未匹配项。输出不能替代业务 expected。
- `artifact_query`：只查询当前需要的 case/规则/未覆盖边等，结果落文件并分页。
- `knowledge_record`：经验绑定证据和适用版本，刷新只取少量当前有效经验。

每个工具的请求示例与文件示例在 assets/；不清楚参数先用 tool_help(name)，返回精确的单工具参数 schema。完整 schema 保存到文件查询，不要全量读入聊天。

## 本地复验

```powershell
Set-Location E:\AI\demo\workflow-testing-v5-delivery-20261013\workflow-testing
python -X utf8 -m unittest discover -s tests -v
python -X utf8 scripts/check_boundaries.py
python -X utf8 scripts/demo_v5.py --out E:\AI\workflow-v5-demo-new
```

输出目录必须尚不存在。demo_v5 完全按文件和独立进程调用，不启动服务、不发业务请求、不回放浏览器。回归中的 HTTP 测试仅访问自带回环服务器。

## 额度耗尽或换模型

交接只需 workspace、版本、project.json/status 请求位置、最新回执引用和未决事项。先 status，按其 phase 选择刷新；不要把完整输入/响应重述进交接文本。原始证据、生成物、经验和临时摘要分别保存。

维护源码继续遵循 AGENTS.md 的租约协议，记录真实测试日志；独立评审和公司业务验收本交付均未代为完成。
