import hashlib,json,shutil,sys
from pathlib import Path
here=Path(__file__).resolve().parent
delivery=here.parents[1]; skill=delivery/'workflow-testing'
sys.path.insert(0,str(skill/'scripts'))
import toolchain
changed=['SKILL.md','scripts/http_runner.py','scripts/toolchain.py','scripts/file_workflow.py',
 'scripts/file_workflow_schema.py','scripts/freshness.py','scripts/capabilities.py','scripts/intake_schema.py',
 'scripts/inspection.py','assets/file-workflow.schema.json','assets/intake.schema.json',
 'references/http-contract.md','references/toolchain.md','references/extensions.md','change-request.json']
added=['scripts/business_headers.py','scripts/managed_session.py','scripts/session_cli.py',
 'scripts/Invoke-WorkflowSession.ps1','scripts/reporting.py','scripts/http_schema.py',
 'assets/http.schema.json','assets/managed-session.example.json','assets/tokens.example.json',
 'references/managed-session.md','tests/test_session_reporting.py']
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':
 hashes=toolchain.dispatch(skill,{'protocol_version':'1.0','tool':'snapshot','arguments':{'files':changed}})['data']['base_hashes']
 for ref in changed:
  target=here/'baseline'/ref;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(skill/ref,target)
 save(here/'baseline-manifest.json',{p.relative_to(skill).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in skill.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.coordination' not in p.parts})
 request={'change_id':'CHANGE-V5-SESSION-REPORT-HEADERS','owner':'codex-maintainer-20261018','status':'implementing',
 'purpose':'用户授权：会话文件入口、一次性凭据注入、业务请求头、人类可读报告及强制步骤。',
 'base_version':'v5 / 3.0.0','base_hashes':hashes,'changed_files':changed,'new_files':added,
 'business_expectations_changed':False,'review':{'status':'pending','reviewer':''},
 'rollback':'恢复 baseline 声明文件，保留全部证据；不得删除严格策略绕过入口。'}
 save(here/'change-request.json',request)
 save(here/'lease.json',toolchain.dispatch(skill,{'protocol_version':'1.0','tool':'claim','arguments':{'owner':request['owner'],'change_id':request['change_id'],'base_hashes':hashes}}))
 print('Claim acquired; 15 existing files and 11 new files declared')
