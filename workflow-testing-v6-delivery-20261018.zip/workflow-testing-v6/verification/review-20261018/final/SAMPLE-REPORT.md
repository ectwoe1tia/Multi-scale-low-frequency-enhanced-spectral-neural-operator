# 文件会话测试报告

只统计本会话选中用例；不是发布许可。历史失败不会因后次通过而消失。

最新状态统计：`{"PASS": 1, "FAIL": 1}`

| Case | Attempt | 原始/观察状态 | 处置 | 证据 |
|---|---|---|---|---|
| TC-001 | 0001 | PASS | PASS | runs/Se20e414d562446f1-f03eb1638702-0001/results.json |
| TC-002 | 0001 | FAIL | BLOCKED | runs/Se20e414d562446f1-47f555556416-0001/results.json |

## 当前选中用例目录

以下标题/分类来自当前基线；历史执行信息以各次运行保存的快照为准。

| 编号 | 标题 | 分类 | 优先级 | 设计状态 | 最新执行状态 |
|---|---|---|---|---|---|
| TC-001 | 文件编制—成功保存（本地回环） | happy_path | P0 | ready | PASS |
| TC-002 | 文件编制—缺少编号的失败诊断（故意不满足预期） | validation | P0 | ready | FAIL |

## 各次执行明细
## 运行 Se20e414d562446f1-f03eb1638702-0001

原始结果：**PASS**；处置 gate：PASS。
PASS=断言通过；FAIL=断言失败；ERROR=执行异常。gate 不会把 FAIL 改写为 PASS。

| 编号 | 标题 | 分类 | 优先级 | 设计状态 | 执行状态 | 原因 |
|---|---|---|---|---|---|---|
| TC-001 | 文件编制—成功保存（本地回环） | happy_path | P0 | ready | PASS | 全部步骤完成，最终断言通过；共记录 3 次断言检查（含轮询历史）。 |

### TC-001 — 文件编制—成功保存（本地回环）

状态：PASS；处置：PASS。全部步骤完成，最终断言通过；共记录 3 次断言检查（含轮询历史）。

证据：`runs/Se20e414d562446f1-f03eb1638702-0001/results.json#/cases/0`

用例信息来源：执行时快照。

#### ready · ready

HTTP：GET /ready；角色：applicant；请求状态：RECEIVED。

第 1 次请求：GET /ready；响应码 **200**；服务端消息：成功

证据位置：`runs/Se20e414d562446f1-f03eb1638702-0001/results.json#/cases/0/steps/0/attempts/0`

| 检查 | 业务断言 | 字段 / 比较 | 期望 | 实际 | 结果 |
|---|---|---|---|---|---|
| ready-http | HTTP/技术检查 | /status_code / eq | 200 | 200 | PASS |

#### save · save

HTTP：POST /documents；角色：applicant；请求状态：RECEIVED。

第 1 次请求：POST /documents；响应码 **201**；服务端消息：成功

证据位置：`runs/Se20e414d562446f1-f03eb1638702-0001/results.json#/cases/0/steps/1/attempts/0`

| 检查 | 业务断言 | 字段 / 比较 | 期望 | 实际 | 结果 |
|---|---|---|---|---|---|
| save-http | HTTP/技术检查 | /status_code / eq | 201 | 201 | PASS |
| saved | A-RESULT | /body/accepted / eq | true | true | PASS |

## 运行 Se20e414d562446f1-47f555556416-0001

原始结果：**FAIL**；处置 gate：BLOCKED。
PASS=断言通过；FAIL=断言失败；ERROR=执行异常。gate 不会把 FAIL 改写为 PASS。

| 编号 | 标题 | 分类 | 优先级 | 设计状态 | 执行状态 | 原因 |
|---|---|---|---|---|---|---|
| TC-002 | 文件编制—缺少编号的失败诊断（故意不满足预期） | validation | P0 | ready | FAIL | 2 个最终断言未满足；后续未执行步骤 0 个。 |

### TC-002 — 文件编制—缺少编号的失败诊断（故意不满足预期）

状态：FAIL；处置：BLOCKED。2 个最终断言未满足；后续未执行步骤 0 个。

证据：`runs/Se20e414d562446f1-47f555556416-0001/results.json#/cases/0`

用例信息来源：执行时快照。

最终失败断言：

| 步骤 | 检查 / 业务断言 | 位置 / 操作符 | 期望值 | 实际值 |
|---|---|---|---|---|
| save | save-http / HTTP/技术检查 | /status_code / eq | 201 | 400 |
| save | saved / A-RESULT | /body/accepted / eq | true | false |

#### ready · ready

HTTP：GET /ready；角色：applicant；请求状态：RECEIVED。

第 1 次请求：GET /ready；响应码 **200**；服务端消息：成功

证据位置：`runs/Se20e414d562446f1-47f555556416-0001/results.json#/cases/0/steps/0/attempts/0`

| 检查 | 业务断言 | 字段 / 比较 | 期望 | 实际 | 结果 |
|---|---|---|---|---|---|
| ready-http | HTTP/技术检查 | /status_code / eq | 200 | 200 | PASS |

#### save · save

HTTP：POST /documents；角色：applicant；请求状态：RECEIVED。

第 1 次请求：POST /documents；响应码 **400**；服务端消息：文档编号不能为空

证据位置：`runs/Se20e414d562446f1-47f555556416-0001/results.json#/cases/0/steps/1/attempts/0`

| 检查 | 业务断言 | 字段 / 比较 | 期望 | 实际 | 结果 |
|---|---|---|---|---|---|
| save-http | HTTP/技术检查 | /status_code / eq | 201 | 400 | FAIL |
| saved | A-RESULT | /body/accepted / eq | true | false | FAIL |


基线：suite.json
项目大纲：project/outline.json
经验记录：project/notes

未选中范围见原基线与各 run 的 not_selected_cases。
