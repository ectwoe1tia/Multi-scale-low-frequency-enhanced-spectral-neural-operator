"""Audit scope, preserve v5, publish v6/20261018 with verification references."""
import hashlib,json,re,shutil,sys,zipfile
from pathlib import Path
here=Path(__file__).resolve().parent
delivery=here.parents[1];skill=delivery/'workflow-testing';final=here/'final'
sys.path.insert(0,str(skill/'scripts'))
import toolchain,http_runner as rt,v5_common
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def included(p):
 return p.is_file() and '__pycache__' not in p.parts and '.coordination' not in p.parts and p.name not in ('lease.json','maintenance-lease.json','MANIFEST.sha256.json')

validation=read(final/'validation.json')
assert all(c['exit_code']==0 for c in validation['commands'])
log=(final/'regression.stderr.log').read_text(encoding='utf-8')
assert re.search(r'Ran 182 tests',log) and log.strip().endswith('OK')
assert rt.VERSION=='6.0.0'
before=read(here/'baseline-manifest.json');change=read(here/'change-request.json')
changed=[];added=[]
for p in skill.rglob('*'):
 if not included(p):continue
 ref=p.relative_to(skill).as_posix()
 if ref not in before:added.append(ref)
 elif sha(p)!=before[ref]:changed.append(ref)
assert set(changed)<=set(change['changed_files']),set(changed)-set(change['changed_files'])
assert set(added)==set(change['new_files']),(added,change['new_files'])
assert all((skill/ref).is_file() for ref in before)
source=read(delivery/'source-manifest.json')
assert all(sha(Path(source['source'])/ref)==digest for ref,digest in source['files'].items())
old=delivery.parent/'workflow-testing-v5-delivery-20261013'
with zipfile.ZipFile(delivery.parent/'workflow-testing-v5-delivery-20261014.zip') as z:
 for item in z.infolist():
  if item.is_dir():continue
  ref=Path(*Path(item.filename).parts[1:])
  assert (old/ref).read_bytes()==z.read(item),'Prior v5 changed: '+str(ref)

# Keep original delivery prose as historical evidence, not the active entry.
backup=here/'delivery-baseline';backup.mkdir(exist_ok=False)
for name in ('START_HERE.md','REPORT.md','handoff.json'):shutil.copyfile(delivery/name,backup/name)
m=validation['session_demo'];static=read(final/'static-demo/metrics.json')
report=f'''# Workflow Testing v6 实现与验证报告 · 20261018

本次按用户最新要求升级为 **v6 / runner 6.0.0**，日期 **20261018**。请求协议及数据版本保持 1.0；旧 v5 目录与已发布包逐文件核对一致，原 v4 源文件哈希也未变。当前 Skill 未自动安装。

## 本次修复

| 问题 | 实现与验证 |
|---|---|
| PowerShell 拼接/格式错误 | 新 Invoke-WorkflowSession.ps1 仅收 Session/Action/CaseId 等固定参数；参数数组传 Python，不拼 JSON；中文、空格路径、动作大小写、缺 Session 已验证 |
| 请求与 token 挤占上下文 | session-spec.json 引用 suite/adapter/plan/tokens；脚本生成请求与回执；实际 execute 内只读一次凭据并恢复进程环境；静态动作与已完成重复调用不读 token |
| 自定义业务头缺入口 | adapter → actor → operation → case → step；字符串或 env 引用；大小写无关覆盖；禁止保留头、重复键、CR/LF、未知变量；真实回环验证发送结果 |
| 报告无法解释失败 | 展示编号、标题、分类、优先级、设计与执行状态、PASS/FAIL 原因、期望/实际、msg/message，以及每步方法、路径、响应码和检查结果 |
| 模型跳过刷新/文件入口 | file_only 初始化绑定会话；固定动作链自动刷新与诊断；有效 receipt 也不能从旧入口直接执行该项目；execute 必须已有准备状态 |
| 重复调用与接力 | 完成 attempt 只复用封存证据；不确定结果必须核对；日志/回执/报告保存引用，模型只获取短控制输出 |

可直接查看 [实际生成的报告](verification/review-20261018/final/SAMPLE-REPORT.md)。示例 TC-001 为 PASS，TC-002 为有意制造的 FAIL：POST /documents 期望 201、实际 400，服务端 msg 为“文档编号不能为空”。这条失败用来验证报告与退出码，不是回归失败。

## 最终验证

- **182 项自动化测试全部通过**，包含原有 155 项与新增 27 项行为测试。
- 静态代码边界检查与 Skill 格式校验通过；40 个注册工具，8 个静态模块接受边界检查。
- 真实 PowerShell 文件入口演示：2 个用例、{m['powershell_calls']} 次调用、{m['http_calls_loopback']} 次本地回环 HTTP；重复 execute 未重发。
- 这 7 次调用 stdout 合计 **{m['stdout_total_bytes']} 字节**，单次最大 **{m['stdout_max_bytes']} 字节**；完整人类报告 **{m['report_bytes']} 字节**，保存在文件。
- 演示凭据未出现在报告或生成证据中；凭据只使用合成本地值。
- 60 用例静态演示继续通过；HAR {static['har_bytes']} 字节，业务 HTTP 调用 0。这并不表示 60 个业务用例已实际执行。

[验证命令与结果](verification/review-20261018/final/validation.json)、[全量测试日志](verification/review-20261018/final/regression.stderr.log)、[PowerShell 逐次命令](verification/review-20261018/final/session-demo/commands.json)、[输出测量](verification/review-20261018/final/session-demo/metrics.json) 可用于接力复验。字节数是实测输出量，不等于 token 计费或模型遵循率测量。

## 公司接续与限制

从 [START_HERE](START_HERE.md) 和 [文件会话契约](workflow-testing/references/managed-session.md) 接入。已有项目显式 init 迁移；未决 PREPARED/UNKNOWN/INCOMPLETE 先完成或核对，保留旧证据。代码升级后重新刷新并生成依赖代码摘要的产物。沿用 v5_schema 等接口名称，不代表发布版本仍是 v5。

强制入口只约束已初始化的受支持执行代码，不是 OS 沙箱；未迁移旧项目保留兼容入口。报告的服务端消息取响应顶层 msg/message；完整结构可通过证据查询。旧证据缺少元数据时仅在准备来源哈希一致时补充显示，否则标明未知，不改写证据。报告单元格有明确截短标记，完整值见证据。

独立评审仍为 **pending**；公司业务验收 **not_executed**。没有请求公司接口、读取公司凭据或修改宿主 PowerShell 策略。
'''
(delivery/'REPORT.md').write_text(report,encoding='utf-8')
(delivery/'START_HERE.md').write_text('''# Workflow Testing v6 使用入口 · 20261018

Skill 位于 `workflow-testing/`，runner **6.0.0**，协议 **1.0**。本次发布 v6，旧 v5 保留；历史契约文件名继续兼容。先看 [本次报告](REPORT.md)，需要参数时只读 [文件会话入口](workflow-testing/references/managed-session.md)。

## 首次接入

1. 将 suite.json、adapter.json、plan.json 和 session-spec.json 放到项目 workspace；session-spec 放根目录，内部路径均相对根目录。
2. 参考 assets/managed-session.example.json 配置 project_dir、credentials_file 和 execution_mode=file_only。真实 tokens.json 放在生成目录之外，由本机填写；模型不读取、不粘贴到聊天或命令。
3. 使用下列固定入口依次 init → prepare → execute。新入口不要混用 Invoke-WorkflowTool.ps1 的参数。

```powershell
& 'E:\\tools\\workflow-testing\\scripts\\Invoke-WorkflowSession.ps1' -Session 'E:\\company\\test workspace\\session-spec.json' -Action init
& 'E:\\tools\\workflow-testing\\scripts\\Invoke-WorkflowSession.ps1' -Session 'E:\\company\\test workspace\\session-spec.json' -Action prepare -CaseId TC-001
& 'E:\\tools\\workflow-testing\\scripts\\Invoke-WorkflowSession.ps1' -Session 'E:\\company\\test workspace\\session-spec.json' -Action execute -CaseId TC-001
& 'E:\\tools\\workflow-testing\\scripts\\Invoke-WorkflowSession.ps1' -Session 'E:\\company\\test workspace\\session-spec.json' -Action report
```

把示例路径换成本机实际路径。接手已初始化项目先用 `-Action status`；失败先 `-Action diagnose -CaseId TC-001`。脚本保存完整回执和报告，终端仅返回状态、动作及文件引用。prepare/execute 自动刷新和诊断；不确定写结果不能直接重发。

已有项目先阅读 [v6 迁移契约](workflow-testing/references/v6.md)，显式 init 登记 file_only；复制包本身不会迁移项目。生成 adapter 的业务头写入来源 policy，避免直接修改生成文件破坏溯源。

## 文件分层与接力

- 常驻上下文：SKILL.md、当前动作、状态码、少量相关经验与文件引用。
- 按需查询：tool_help、flow_diagnose、evidence_query、artifact_query；完整参数 schema 保存文件。
- 项目沉淀：sources/contracts/normalized/generated/analysis/knowledge/context；请求回执在 .session-calls/.session-replies，封存证据与报告单独保存。
- 静态规则、BPMN/Flowable 定义快照、Recorder/HAR 分析沿用注册工具文件入口，不执行业务请求。详见 [沿用契约](workflow-testing/references/v5.md)。

换模型只交接 workspace、v6/6.0.0/20261018、session-spec 路径、最近回执引用、当前 case 和未决项。不要复制业务大文件、凭据或完整报告进交接上下文。

## 本地复验

在 workflow-testing 目录运行：

```powershell
python -X utf8 -m unittest discover -s tests -v
python -X utf8 scripts/check_boundaries.py
```

完整回归与演示可从交付根目录运行 `python -X utf8 verification/review-20261018/verify.py <全新输出目录>`。测试 HTTP 只访问自带回环服务器。实际结果见 REPORT.md；独立评审和公司业务验收尚未完成。
''',encoding='utf-8')
change.update(status='implemented_and_locally_verified',version='v6',runner_version=rt.VERSION,build='20261018',
 validation={'status':'passed','tests':182,'evidence':'verification/review-20261018/final/validation.json'},
 review={'status':'pending','reviewer':'','notes':['Independent review pending; company acceptance not executed.']},
 next_action='公司环境使用 session-spec 文件入口接入；status 后逐 case 准备和执行，不复制 token 或完整证据进入对话。')
save(here/'change-request.json',change);save(skill/'change-request.json',change)
lease=read(here/'lease.json')['data']['lease_token']
release=toolchain.dispatch(skill,{'protocol_version':'1.0','tool':'release','arguments':{'lease_token':lease}})
assert release['ok'];save(here/'release.json',release)
save(delivery/'handoff.json',{
 'delivery':'workflow-testing-v6','runner_version':rt.VERSION,'protocol_version':'1.0','build':'20261018',
 'status':'implemented_and_locally_verified','entry':'START_HERE.md','report':'REPORT.md',
 'contracts':'workflow-testing/references/v6.md','execution_contract':'workflow-testing/references/managed-session.md',
 'tests':{'passed':182,'failed':0},'registered_tools':len(toolchain.TOOLS),'generator_digest':v5_common.generator_digest(),
 'source_v4_unchanged':True,'published_v5_preserved':True,'maintenance_lease_released':True,
 'validation':'verification/review-20261018/final/validation.json','session_demo':m,'static_demo':static,
 'independent_review':'pending','company_business_acceptance':'not_executed',
 'resume':'Read START_HERE; invoke session status using only session-spec.json; diagnose before querying selected evidence; prepare then authorized execute.',
 'known_limits':['Managed entry enforcement requires explicit file_only initialization; not an OS sandbox.',
                 'Historical v5_schema names retained; protocol remains 1.0.',
                 'Static Flowable analysis uses local exported definitions; no online retrieval or browser replay.',
                 'Reports use top-level msg/message; legacy metadata unknown unless preparation source verifies.']})
files=sorted(p for p in delivery.rglob('*') if included(p))
save(delivery/'MANIFEST.sha256.json',{p.relative_to(delivery).as_posix():sha(p) for p in files})
files.append(delivery/'MANIFEST.sha256.json')
archive=delivery.parent/'workflow-testing-v6-delivery-20261018.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,'workflow-testing-v6/'+p.relative_to(delivery).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for ref,digest in read(delivery/'MANIFEST.sha256.json').items():
  assert hashlib.sha256(z.read('workflow-testing-v6/'+ref)).hexdigest()==digest,ref
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(files),
         'changed_existing':len(set(changed)|{'change-request.json'}),'added':len(added),
         'version':'v6','runner_version':rt.VERSION,'date':'20261018','tests':182,'lease_released':True,
         'v5_preserved':True,'independent_review':'pending','company_acceptance':'not_executed'}
save(archive.with_suffix('.receipt.json'),receipt)
print(json.dumps(receipt,ensure_ascii=False))
