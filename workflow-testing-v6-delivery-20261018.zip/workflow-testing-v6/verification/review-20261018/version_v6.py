"""Record the user's v6/1018 correction and update current entry contracts."""
import hashlib,json,shutil,sys
from pathlib import Path
here=Path(__file__).resolve().parent
delivery=here.parents[1];skill=delivery/'workflow-testing'
sys.path.insert(0,str(skill/'scripts'))
import toolchain,http_schema
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
change=read(here/'change-request.json')
if 'AGENTS.md' not in change['changed_files']:
 hashes=toolchain.dispatch(skill,{'protocol_version':'1.0','tool':'snapshot','arguments':{'files':['AGENTS.md']}})['data']['base_hashes']
 shutil.copyfile(skill/'AGENTS.md',here/'baseline/AGENTS.md')
 change['base_hashes'].update(hashes);change['changed_files'].append('AGENTS.md')
if 'references/v6.md' not in change['new_files']:change['new_files'].append('references/v6.md')
change.update(target_version='v6 / 6.0.0',target_date='20261018',
 version_authorization='用户明确要求本次升级 v6，日期为 1018；保留已发布 v5。')
save(here/'change-request.json',change)
replacements={
 'AGENTS.md': [('through `scripts/toolchain.py` or `scripts/Invoke-WorkflowTool.ps1`','through the managed `scripts/Invoke-WorkflowSession.ps1` entry for file_only execution; use `scripts/toolchain.py` or `scripts/Invoke-WorkflowTool.ps1` for static tools and unmigrated legacy projects')],
 'SKILL.md':[('# 流程测试：文件调用与静态覆盖','# 流程测试 v6 · 20261018'),
 ('## 当前工作入口','当前发布 v6 / runner 6.0.0；迁移与兼容见 [v6 契约](references/v6.md)。\n\n## 当前工作入口'),
 ('[v5 实际契约]','[沿用的静态与刷新契约]')],
 'references/managed-session.md':[
 ('# v5 文件会话入口','# v6 文件会话入口'),
 ('修订 `20261018-session-report`；v5 / runner 3.0.0 / protocol 1.0 保持不变。','发布 `v6 / 20261018`；runner 6.0.0，protocol 仍为 1.0。'),
 ('支持四层 headers：adapter 默认 → actor → operation → plan step','支持五层 headers：adapter 默认 → actor → operation → plan case → plan step'),
 ('Adapter/Step/Plan','Adapter/Case/Step/Plan'),
 ('步骤字符串可以使用已有 `${变量}`','case 字符串只可引用初始 vars、run_id、case_id；步骤字符串可以使用已有 `${变量}`')],
 'references/toolchain.md':[('v5 `20261018-session-report`','v6 `20261018`'),('v5 日常调用','v6 日常调用')],
 'references/extensions.md':[
 ('`20261018-session-report` 同样保持 v5 / runner 3.0.0','本次按用户最新要求发布 v6 / runner 6.0.0，日期 `20261018`'),
 ('发布版本 runtime.VERSION 当前 3.0.0','发布版本 runtime.VERSION 当前 6.0.0'),
 ('新主版本 3.0.0 不静默给旧请求补凭据','沿用的严格模式不静默给旧请求补刷新凭据')],
 'references/http-contract.md':[('adapter/actor/operation/step','adapter/actor/operation/case/step')],
 'scripts/reporting.py':[("str(f.get('assertion_id'))","str(f.get('assertion_id') or 'HTTP/技术检查')")]
}
for ref,pairs in replacements.items():
 p=skill/ref;text=p.read_text(encoding='utf-8')
 for before,after in pairs:
  if before not in text:raise RuntimeError('Missing replacement in '+ref+': '+before)
  text=text.replace(before,after)
 p.write_text(text,encoding='utf-8')
save(skill/'assets/http.schema.json',http_schema.schema())
print('v6 / 6.0.0 / 20261018; historical v5 contract names retained for compatibility')
