"""Audit changes, release own maintenance lease and publish a same-v5 build."""
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
delivery = here.parents[1]
skill = delivery / 'workflow-testing'
sys.path.insert(0,str(skill/'scripts'))
import toolchain
import v5_common


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def included(path):
    return (path.is_file() and '__pycache__' not in path.parts and '.coordination' not in path.parts
            and path.name not in ('maintenance-lease.json','lease.json','MANIFEST.sha256.json'))


if __name__ == '__main__':
    validation = read(here/'validation.json')
    assert all(c['exit_code']==0 for c in validation['commands'])
    log = (here/'regression.stderr.log').read_text(encoding='utf-8')
    assert re.search(r'Ran 155 tests',log) and log.strip().endswith('OK')
    before = read(here/'baseline-manifest.json')
    change = read(here/'change-request.json')
    changed, added = [], []
    for path in skill.rglob('*'):
        if not included(path):
            continue
        ref = path.relative_to(skill).as_posix()
        if ref not in before:
            added.append(ref)
        elif sha(path) != before[ref]:
            changed.append(ref)
    assert set(changed) <= set(change['changed_files']), set(changed)-set(change['changed_files'])
    assert set(added) == set(change['new_files']), (added,change['new_files'])
    assert all((skill/ref).is_file() for ref in before), 'Unexpected deletion'
    source = read(delivery/'source-manifest.json')
    assert all(sha(Path(source['source'])/ref)==digest for ref,digest in source['files'].items()), 'Original v4 changed'
    change.update(status='implemented_and_locally_verified', build='20261014-control',
                  validation={'status':'passed','tests':155,'evidence':'../verification/review-20261014/validation.json'},
                  review={'status':'pending','reviewer':'','notes':['No independent review; company acceptance not executed.']},
                  next_action='公司环境使用脱敏 fixture 验证；正常接续 status -> refresh -> diagnose/query -> 已授权执行。')
    save(here/'change-request.json',change)
    save(skill/'change-request.json',change)
    lease = read(here/'lease.json')['data']['lease_token']
    release = toolchain.dispatch(skill,{'protocol_version':'1.0','tool':'release','arguments':{'lease_token':lease}})
    assert release['ok']
    save(here/'release.json',release)
    handoff = read(delivery/'handoff.json')
    handoff.update(build='20261014-control',status='implemented_and_locally_verified',
                   tests={'passed':155,'failed':0},maintenance_lease_released=True,
                   registered_tools=len(toolchain.TOOLS),generator_digest=v5_common.generator_digest(),
                   revision_report='verification/review-20261014/REPORT.md',
                   diagnostic_demo=validation['diagnostic_demo'],
                   static_demo=read(here/'static-demo/metrics.json'),
                   new_revision_tools=['tool_help','flow_diagnose','evidence_query'],
                   resume='Read START_HERE; --control; status -> context_refresh -> current request; diagnose then query exact evidence fields.',
                   independent_review='pending',company_business_acceptance='not_executed')
    handoff['known_limits'] += ['Execution boundary covers cooperating registered code, not an OS sandbox; legacy direct Python remains compatible.',
                               'Explicit value queries can expose requested business scalars; default structure queries contain no scalar values.']
    save(delivery/'handoff.json',handoff)
    files = sorted(p for p in delivery.rglob('*') if included(p))
    save(delivery/'MANIFEST.sha256.json',{p.relative_to(delivery).as_posix():sha(p) for p in files})
    files.append(delivery/'MANIFEST.sha256.json')
    archive = delivery.parent/'workflow-testing-v5-delivery-20261014.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p,'workflow-testing-v5/'+p.relative_to(delivery).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        manifest = json.loads(z.read('workflow-testing-v5/MANIFEST.sha256.json'))
        for ref,digest in manifest.items():
            assert hashlib.sha256(z.read('workflow-testing-v5/'+ref)).hexdigest()==digest,ref
    result = {'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
              'files':len(files),'changed_existing':len(set(changed)|{'change-request.json'}),'added':len(added),
              'tests':155,'version':'v5 / 3.0.0','build':'20261014-control','lease_released':True}
    # Keep the receipt next to the archive so packaging cannot invalidate its own manifest.
    save(archive.with_suffix('.receipt.json'),result)
    print(json.dumps(result,ensure_ascii=False))
