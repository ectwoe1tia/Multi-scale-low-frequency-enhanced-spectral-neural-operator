"""Coverage of independently declared obligations and trace evidence, entirely offline."""
import http_runner as rt
import re
import suite
import flow_model
import rules_codegen as rules
import v5_common as c

def subsequence(required,actual):
    index=0
    for x in actual:
        if index<len(required) and required[index]==x: index+=1
    return index==len(required)

def analyze(root,args):
    p,_=c.project(root,args['project'])
    spec=c.read(root,args['spec'])
    rt.shape(spec,['definition_ref','case_binding_ref','obligations_ref'],['trace_index_ref','coverage_policy','aligned_trace_ref'],label='flow analysis spec')
    graph,inputs=flow_model.load(root,spec['definition_ref'])
    inputs += [args['spec'],args['project'],p['suite'],spec['case_binding_ref'],spec['obligations_ref']]
    for ref in p['cases'].values():
        composer=__import__('file_workflow').Composer(root);composer.file(ref)
        for source,digest in composer.hashes.items():
            rt.need(c.remember(root,source)==digest,'Case input changed during analysis','STALE_INPUT')
            inputs.append(source)
    baseline=c.read(root,p['suite'])
    errors,_=suite.validate(baseline); rt.need(not errors,'Invalid suite for coverage')
    binding=c.read(root,spec['case_binding_ref'])
    rt.shape(binding,['definition_id','cases'],label='case flow binding')
    rt.need(binding['definition_id']==graph['definition']['id'],'Binding definition/version mismatch','DEFINITION_MISMATCH')
    rt.need(isinstance(binding['cases'],list) and len(binding['cases'])<=1000,'Invalid binding cases')
    known={x['id']:x for x in baseline['cases']}
    nodes={n['id']:n for n in graph['nodes']}; edges={e['id']:e for e in graph['edges']}
    outgoing={nid:[] for nid in nodes}
    for e in graph['edges']: outgoing[e['source']].append(e)
    mapped=[]; issues=[]
    for b in binding['cases']:
        rt.shape(b,['case_id','activities'],['edges','attempt'],label='case binding')
        rt.need(b['case_id'] in known and b['case_id'] in p['cases'],'Unknown/unselected case binding')
        rt.need(isinstance(b['activities'],list) and all(x in nodes for x in b['activities']),'Unknown planned activity')
        es=b.get('edges',[])
        rt.need(isinstance(es,list) and all(x in edges for x in es),'Unknown planned edge')
        if es:
            expected=[edges[es[0]]['source']]+[edges[x]['target'] for x in es]
            rt.need(all(edges[a]['target']==edges[z]['source'] for a,z in zip(es,es[1:])) and expected==b['activities'],'Planned path edge/node order inconsistent')
            rt.need(not any(nodes[x]['type']=='parallelGateway' for x in expected),'Parallel path must be a partial-order block, not one linear branch')
        mapped.append({'case_id':b['case_id'],'attempt':b.get('attempt'),'basis':'planned','nodes':b['activities'],'edges':es,'evidence_ref':spec['case_binding_ref']})
    if 'trace_index_ref' in spec:
        index=c.read(root,spec['trace_index_ref']); rt.shape(index,['traces'],label='trace index')
        rt.need(isinstance(index['traces'],list) and len(index['traces'])<=1000,'Invalid trace index')
        inputs.append(spec['trace_index_ref'])
        for ref in index['traces']:
            t=c.read(root,ref); inputs.append(ref)
            rt.shape(t,['case_id','attempt','definition_id','instance_id','activities','edges','evidence_refs'],['scope'],label='activity trace')
            rt.need(t['case_id'] in known and t['case_id'] in p['cases'],'Trace case not selected')
            rt.need(t['definition_id']==graph['definition']['id'],'Trace definition mismatch','DEFINITION_MISMATCH')
            rt.need(isinstance(t['instance_id'],str) and t['instance_id'] and isinstance(t['attempt'],str) and t['attempt'],'Missing instance/attempt')
            rt.need(isinstance(t['activities'],list) and all(x in nodes for x in t['activities']) and isinstance(t['edges'],list) and all(x in edges for x in t['edges']),'Unknown trace activity/edge')
            rt.need(isinstance(t['evidence_refs'],list) and t['evidence_refs'],'Observed trace requires evidence references')
            for evidence in t['evidence_refs']: inputs.append(evidence); c.hash_file(root,evidence)
            # Explicit transitions must be supported by activity anchors. Raw observations remain local provenance.
            rt.need(all(edges[x]['source'] in t['activities'] and edges[x]['target'] in t['activities'] for x in t['edges']),'Observed edge lacks node anchors')
            mapped.append({'case_id':t['case_id'],'attempt':t['attempt'],'instance_id':t['instance_id'],'basis':'observed',
                           'nodes':t['activities'],'edges':t['edges'],'evidence_ref':ref,'evidence_refs':t['evidence_refs']})
            # Missing transition between adjacent anchors is inference, not observed evidence.
            inferred=[]
            for start,end in zip(t['activities'],t['activities'][1:]):
                candidates=[];search_truncated=[False]
                def search(node,route,visited):
                    if len(candidates)>1:return
                    if len(route)>32:search_truncated[0]=True;return
                    if node==end:candidates.append(route);return
                    if nodes[node]['type']=='parallelGateway' or nodes[node]['opaque']:return
                    for e in outgoing[node]:
                        if e['target'] not in visited:search(e['target'],route+[e['id']],visited|{e['target']})
                search(start,[],{start})
                if len(candidates)==1 and not search_truncated[0]: inferred+=candidates[0]
                elif search_truncated[0]:issues.append({'case_id':t['case_id'],'kind':'connection_search_truncated','from':start,'to':end})
                elif len(candidates)>1: issues.append({'case_id':t['case_id'],'kind':'ambiguous_connection','from':start,'to':end})
            if inferred:
                mapped.append({'case_id':t['case_id'],'attempt':t['attempt'],'basis':'derived','nodes':sorted({edges[x]['source'] for x in inferred}|{edges[x]['target'] for x in inferred}),
                               'edges':sorted(set(inferred)-set(t['edges'])),'evidence_ref':ref,
                               'assumption':'Unique simple connecting paths within 32 edges; loop counts/causality are not proven.'})
    if 'aligned_trace_ref' in spec:
        manifest,base=c.artifact(root,args['project'],'trace')
        rt.need(spec['aligned_trace_ref']==base+'/manifest.json','Use current validated aligned trace manifest')
        inputs += [base+'/manifest.json']+list(manifest['inputs'])+[base+'/'+name for name in manifest['products']]
        anchors=c.read(root,base+'/activity-anchors.json')
        for anchor in anchors:
            if not anchor['case_id']:issues.append({'kind':'unassigned_trace_anchor','http':anchor['http']});continue
            rt.need(anchor['case_id'] in known and anchor['definition_id']==graph['definition']['id'],'Aligned activity definition/case mismatch')
            rt.need(all(x in nodes for x in anchor['activities']),'Unknown aligned activity')
            if anchor['status']=='candidate':
                mapped.append({'case_id':anchor['case_id'],'attempt':anchor['attempt'],'basis':'derived','nodes':anchor['activities'],
                               'edges':[],'evidence_ref':base+'/activity-anchors.json','reason':anchor['reason']})
            else:issues.append({'kind':'ambiguous_activity_anchor','http':anchor['http']})
    obligation_file=c.read(root,spec['obligations_ref'])
    rt.shape(obligation_file,['definition_id','obligations'],label='path obligations')
    rt.need(obligation_file['definition_id']==graph['definition']['id'],'Obligation definition mismatch','DEFINITION_MISMATCH')
    obligations=obligation_file['obligations']
    rt.need(isinstance(obligations,list) and len(obligations)<=1000,'Invalid obligation list')
    for o in obligations:
        rt.shape(o,['id','activities_in_order','source_refs'],['edges_in_order'],label='obligation')
        rt.ident(o['id'],'obligation id')
        rt.need(isinstance(o['activities_in_order'],list) and o['activities_in_order'] and all(x in nodes for x in o['activities_in_order']),'Invalid obligation activities')
        rt.need(isinstance(o['source_refs'],list) and o['source_refs'],'Obligation needs independent source')
        rt.need(isinstance(o.get('edges_in_order',[]),list) and all(x in edges for x in o.get('edges_in_order',[])),'Invalid obligation edges')
        inputs+=o['source_refs']
    rt.need(len({o['id'] for o in obligations})==len(obligations),'Duplicate obligation IDs')
    # Active DSL requirements augment independent obligations; they do not redefine graph denominators.
    active=rules.active(root,args['project'])
    if active:
        _,directory=c.project(root,args['project']); inputs.append(c.relative(root,directory/'runtime/active-rules.json'))
        pointer=c.read(root,inputs[-1]); manifest=c.read(root,pointer['manifest']);base=pointer['manifest'].rsplit('/',1)[0]
        inputs += [pointer['manifest']]+list(manifest['inputs'])+[base+'/'+name for name in manifest['products']]
    for r in active:
        if r['kind']!='coverage_obligation':continue
        rt.need(not r['scope'].get('process_key') or r['scope']['process_key']==graph['definition']['key'],'Rule process mismatch')
        if r['scope'].get('definition_ref'):
            scoped,scoped_inputs=flow_model.load(root,r['scope']['definition_ref']);inputs+=scoped_inputs
            rt.need(scoped['definition']==graph['definition'],'Rule definition/version mismatch','DEFINITION_MISMATCH')
        acts=r['require']['activities_in_order']
        rt.need(all(x in nodes for x in acts),'Rule references unknown activity')
        applicable=[]
        for cid in p['cases']:
            if not rules.applies(r,cid):continue
            case=__import__('file_workflow').Composer(root).file(p['cases'][cid])
            if r['scope'].get('operations') and not any(step['operation'] in r['scope']['operations'] for step in case['steps']):continue
            when=rules.evaluate(r['when'],case['vars'])
            rt.need(when is rules.UNKNOWN or type(when) is bool,'Coverage rule condition must be boolean','RULE_TYPE_ERROR')
            if when is True:applicable.append(cid)
            elif when is rules.UNKNOWN:issues.append({'rule_id':r['id'],'case_id':cid,'kind':'rule_condition_unresolved'})
        if applicable:
            expected_edges=r['require'].get('edges_in_order',[])
            rt.need(all(x in edges for x in expected_edges),'Rule references unknown edge')
            obligations.append({'id':r['id'],'activities_in_order':acts,'edges_in_order':expected_edges,'source_refs':r['source_refs'],'case_ids':applicable})
    rt.need(len({o['id'] for o in obligations})==len(obligations),'DSL and declared obligation IDs collide')
    gateway_exits={e['id'] for e in graph['edges'] if nodes[e['source']]['type'] in ('exclusiveGateway','inclusiveGateway','eventBasedGateway')}
    parallel_exits={e['id'] for e in graph['edges'] if nodes[e['source']]['type']=='parallelGateway'}
    coverage={}
    def metric(covered,total,available=True):
        return {'covered':len(covered),'total':len(total),'ratio':len(covered)/len(total) if total and available else None,
                'uncovered':sorted(total-covered),'reason':None if total and available else 'no_evidence' if not available else 'empty_denominator'}
    for basis in ('observed','derived','planned'):
        records=[x for x in mapped if x['basis']==basis]
        ns={n for x in records for n in x['nodes']}; es={e for x in records for e in x['edges']}
        os=set()
        for o in obligations:
            if basis!='derived' and any((not o.get('case_ids') or row['case_id'] in o['case_ids']) and
                subsequence(o['activities_in_order'],row['nodes']) and subsequence(o.get('edges_in_order',[]),row['edges']) for row in records):os.add(o['id'])
        available=bool(records)
        coverage[basis]={'nodes':metric(ns,set(nodes),available),'edges':metric(es,set(edges),available),
                         'decision_exits':metric(es&gateway_exits,gateway_exits,available),
                         'parallel_exits':metric(es&parallel_exits,parallel_exits,available),
                         'path_obligations':metric(os,{o['id'] for o in obligations},available)}
    enumerated=flow_model.paths(graph,spec.get('coverage_policy',{}))
    enumerated['planned_path_ratio']=None
    if enumerated['complete'] and enumerated['paths']:
        matched={path['id'] for path in enumerated['paths'] if any(row['basis']=='planned' and row['edges']==path['edges'] for row in mapped)}
        enumerated['planned_path_ratio']=len(matched)/len(enumerated['paths'])
    digest={'definition':graph['definition'],'metrics':coverage,'path_enumeration':{k:v for k,v in enumerated.items() if k!='paths'},
            'scope':'All nodes/sequence flows in selected process snapshot; no silent exclusion.',
            'opaque_nodes':graph['opaque_nodes'],'claim':'Observed = imported evidence; derived/planned are separate. No new business execution.'}
    lines=['# 静态流程覆盖报告','',f'定义：{graph["definition"]["id"]}','',
           '| 证据基础 | 节点 | 边 | 决策出口 | 路径义务 |','|---|---|---|---|---|']
    for basis,v in coverage.items():
        lines.append('| '+basis+' | '+' | '.join(f'{v[k]["covered"]}/{v[k]["total"]}; ratio={v[k]["ratio"]}' for k in ('nodes','edges','decision_exits','path_obligations'))+' |')
    lines+=['','路径枚举：'+str(enumerated['reason'])+'；条件可行性未证明。','不透明节点：'+str(graph['opaque_nodes'])]
    # Mermaid uses opaque aliases; untrusted display names never become syntax.
    alias={nid:'N'+str(i) for i,nid in enumerate(nodes)}
    def label(value):return re.sub(r'[^a-zA-Z0-9_\u4e00-\u9fff .-]','',str(value))[:100]
    node_cases={nid:{basis:sorted({row['case_id'] for row in mapped if row['basis']==basis and nid in row['nodes']}) for basis in coverage} for nid in nodes}
    edge_cases={eid:{basis:sorted({row['case_id'] for row in mapped if row['basis']==basis and eid in row['edges']}) for basis in coverage} for eid in edges}
    mermaid=['flowchart TD']+[f'  {alias[nid]}["{label(nid+" "+n["name"])} P={len(node_cases[nid]["planned"])} O={len(node_cases[nid]["observed"])}"]' for nid,n in nodes.items()]
    mermaid += [f'  {alias[e["source"]]} -->|"{label(e["id"])} P={len(edge_cases[e["id"]]["planned"])} O={len(edge_cases[e["id"]]["observed"])}"| {alias[e["target"]]}' for e in graph['edges']]
    return c.publish(root,args['project'],'flow',args['out'],{'graph.json':graph,'case-path-index.json':mapped,
        'coverage.json':digest,'coverage.md':'\n'.join(lines)+'\n','graph.mmd':'\n'.join(mermaid)+'\n',
        'graph-labels.json':{alias[nid]:{'node':nodes[nid],'cases':node_cases[nid]} for nid in nodes},
        'edge-cases.json':edge_cases,'paths.json':enumerated,'issues.json':issues},inputs)
