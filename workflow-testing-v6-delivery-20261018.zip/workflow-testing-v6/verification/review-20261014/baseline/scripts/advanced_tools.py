"""Registered static tools and bounded project queries."""
import json
import http_runner as rt
import v5_common as c
import freshness
import rules_codegen
import flow_analysis
import trace_align

TOOLS={
    'runtime_init':(['project','out'],[]),
    'context_refresh':(['project','case_id','out'],['phase','plan']),
    'rules_codegen':(['project','spec','out'],[]),
    'project_tool_invoke':(['project','tool_ref','input_ref','out'],[]),
    'flow_analysis':(['project','spec','out'],[]),
    'trace_align':(['project','spec','out'],[]),
    'artifact_query':(['project','query','out'],[]),
    'knowledge_record':(['project','spec','out'],[]),
}

def query(root,args):
    spec=c.read(root,args['query'])
    rt.shape(spec,['kind'],['case_id','id','offset','limit'],label='artifact query')
    offset,limit=spec.get('offset',0),spec.get('limit',10)
    rt.need(type(offset) is int and offset>=0 and type(limit) is int and 1<=limit<=100,'Invalid query bounds')
    kind=spec['kind']
    if kind in ('case_paths','uncovered_edges','coverage','graph_nodes'):
        _,base=c.artifact(root,args['project'],'flow')
        if kind=='case_paths':
            rows=c.read(root,base+'/case-path-index.json')
            if 'case_id' in spec:rows=[x for x in rows if x['case_id']==spec['case_id']]
        elif kind=='coverage': rows=[c.read(root,base+'/coverage.json')]
        elif kind=='graph_nodes':rows=c.read(root,base+'/graph.json')['nodes']
        else:
            coverage=c.read(root,base+'/coverage.json')
            rows=[{'id':x,'basis':basis} for basis,data in coverage['metrics'].items() for x in data['edges']['uncovered']]
    elif kind in ('rules','tools'):
        _,base=c.artifact(root,args['project'],'rules')
        rows=c.read(root,base+('/rules.index.json' if kind=='rules' else '/tools.json'))
    elif kind=='trace_matches':
        _,base=c.artifact(root,args['project'],'trace');rows=c.read(root,base+'/alignment.json')
    elif kind=='lessons':
        p,d=c.project(root,args['project']);rows=[]
        directory=rt.workspace_path(root,c.relative(root,d/'knowledge'))
        if directory.exists():
            for path in sorted(directory.glob('*.json')):
                n=c.read(root,c.relative(root,path))
                if spec.get('case_id') and n['case_id'] not in ('*',spec['case_id']):continue
                stale=any(not rt.workspace_path(root,r).exists() or c.hash_file(root,r)!=h for r,h in n['applicability'].items())
                evidence_changed=any(not rt.workspace_path(root,r).exists() or c.hash_file(root,r)!=h for r,h in n['evidence_hashes'].items())
                rows.append({'id':path.stem,'case_id':n['case_id'],'kind':n['kind'],'summary':n['summary'],
                             'next_action':n['next_action'],'status':'evidence_changed' if evidence_changed else 'superseded' if stale else n['kind'],'ref':c.relative(root,path)})
    else:raise rt.ToolError('UNKNOWN_QUERY','Only registered named queries are allowed')
    if 'id' in spec:rows=[x for x in rows if x.get('id')==spec['id']]
    selected=[]
    for row in rows[offset:offset+limit]:
        if len(json.dumps(selected+[row],ensure_ascii=False).encode('utf-8'))>32768:
            rt.need(selected,'Single result exceeds query budget; inspect artifact by file pointer','QUERY_TOO_LARGE')
            break
        selected.append(row)
    result={'kind':kind,'total':len(rows),'offset':offset,'rows':selected,
            'next_offset':offset+len(selected) if offset+len(selected)<len(rows) else None}
    c.write(root,args['out'],result)
    return {'result':args['out'],'total':len(rows),'returned':len(selected),'next_offset':result['next_offset'],'network_executed':False}

def knowledge(root,args):
    _,d=c.project(root,args['project'])
    note=c.read(root,args['spec'])
    rt.shape(note,['case_id','kind','summary','next_action','evidence_refs','applies_to'],['supersedes'],label='knowledge record')
    rt.need(note['kind'] in ('candidate','confirmed'),'Knowledge kind must be candidate/confirmed')
    for field in ('summary','next_action'):rt.need(isinstance(note[field],str) and 1<=len(note[field])<=1000,'Knowledge text length limit')
    p,_=c.project(root,args['project']);rt.need(note['case_id']=='*' or note['case_id'] in p['cases'],'Unknown knowledge case')
    rt.need(isinstance(note['evidence_refs'],list) and note['evidence_refs'] and isinstance(note['applies_to'],list) and note['applies_to'],'Knowledge requires evidence and applicability refs')
    payload={**note,'evidence_hashes':{ref:c.hash_file(root,ref) for ref in note['evidence_refs']},
             'applicability':{ref:c.hash_file(root,ref) for ref in note['applies_to']},'created_at':rt.utc_now()}
    target=rt.workspace_path(root,args['out'])
    intended=rt.workspace_path(root,c.relative(root,d/'knowledge'))
    rt.need(intended in target.parents,'Knowledge output must stay in project knowledge directory')
    c.write(root,args['out'],payload)
    return {'knowledge':args['out'],'network_executed':False}

def dispatch(root,tool,args):
    with c.capture():
        return _dispatch(root,tool,args)

def _dispatch(root,tool,args):
    if tool=='runtime_init':return freshness.init(root,args)
    if tool=='context_refresh':return freshness.refresh(root,args)
    if tool=='rules_codegen':return rules_codegen.generate(root,args)
    if tool=='project_tool_invoke':return rules_codegen.invoke(root,args)
    if tool=='flow_analysis':return flow_analysis.analyze(root,args)
    if tool=='trace_align':return trace_align.align(root,args)
    if tool=='artifact_query':return query(root,args)
    if tool=='knowledge_record':return knowledge(root,args)
    raise rt.ToolError('INVALID_INPUT','Unknown advanced tool')
