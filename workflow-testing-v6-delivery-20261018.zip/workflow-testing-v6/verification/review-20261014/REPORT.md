# v5 维护复查：20261014-control

实现已完成，保持 **v5 / runner 3.0.0 / protocol 1.0**。新增能力没有第三方依赖，现有 HTTP/刷新/不重发语义保持兼容。没有接入公司环境；独立复核 pending。

## 复查发现与修改

| 原问题 | 已实施修改 | 可验证结果 |
|---|---|---|
| brief 提示读取整份回执，排查容易加载业务正文 | 可选 --control / PowerShell -Control，只输出动作与引用 | 上限 4096 UTF-8 字节，允许名单投影，完整回执仍落文件 |
| 失败后的检查粒度过大 | flow_diagnose | 状态/断言 ID/证据指针；不输出 actual、expected、context、异常消息 |
| 忘记参数便加载整个 describe | tool_help(name) | 从同一注册表返回当前工具的精确 schema、参数、模板和副作用 |
| 查看局部响应仍要读大文件 | evidence_query | 默认只查类型/大小；显式标量值查询；哈希可通过文件指针引用 |
| 静态与执行边界主要靠文档 | 副作用表 + ContextVar + 执行器/传输检查 | 静态工具及嵌套 run 被 EFFECT_DENIED 拦截，无运行目录/网络副作用 |
| 公共代码边界无法持续验证 | AST 架构检查及行为测试 | 检查 5 个静态模块、40 个注册工具；发现并改掉 2 处动态导入 |

诊断≤8192 字节；字段查询默认≤2048 字节、可设 512..8192。超限拒绝，避免通过自动截断掩盖实际值。所有预算由程序执行；不是只在 Skill 中提醒模型。

## 测试证据

- **155 项测试全部通过**，其中原有 129 项、本轮新增 26 项。实际耗时 21.717 秒，详见 [regression.stderr.log](regression.stderr.log)。覆盖未知字段、预算、哈希漂移、未封存证据、静态嵌套调用、CLI、PowerShell，以及原有真实回环 HTTP 测试。
- [架构检查](boundaries.stdout.log)：ok=true，5 个静态模块，40 个工具，无违反项。
- [Skill 校验](skill.stdout.log)：Skill is valid。
- [全部验证命令和退出码](validation.json)：4 条验证命令全部退出 0；另有 5 次独立 CLI 诊断演示调用。
- 原有 [60-case 静态演示](static-demo/metrics.json) 通过；没有 HTTP 业务调用或浏览器回放。60 个 case 是输入规模，不代表执行了 60 个业务测试。

## 大证据文件排查演示

这是程序生成的合成 FAIL 证据，不是实际业务执行，也不是真实缺陷。输入模拟大 actual/expected/context/error.message，检验它们不会进入控制摘要。

| 指标 | 实测字节 |
|---|---:|
| 完整证据文件 | 2,881,060 |
| 诊断文件 | 1,698 |
| 两字段结构查询结果 | 625 |
| 5 次工具调用的终端输出合计 | 1,227 |
| 单次终端输出最大值 | 321 |

[指标](diagnostic-demo/metrics.json)、[命令记录](diagnostic-demo/commands.json)、[诊断结果](diagnostic-demo/project/inspect/diagnosis.json)、[查询结果](diagnostic-demo/project/inspect/shape.json) 均落盘。业务 HTTP 调用 0。这里测量 UTF-8 输出量，不把压缩比例等同于实际模型 token 计费节省。

## 架构依据与边界

采用了 [Playwright fixtures](https://playwright.dev/docs/test-fixtures) 的用例隔离、[Trace Viewer](https://playwright.dev/docs/trace-viewer) 的按步骤查证据、[pytest fixtures](https://docs.pytest.org/en/stable/how-to/fixtures.html) 的显式依赖、[Pact](https://docs.pact.io/getting_started/how_pact_works) 的契约与验证结果分离，以及 [ArchUnit](https://www.archunit.org/userguide/html/000_Index.html) 的可测试依赖边界。落实到现有标准库工具，不增加这些框架的运行依赖，也没有宣称已实现它们的集成。

执行能力限制覆盖注册入口与合作代码；保留历史直接 Python API 兼容，不是操作系统沙箱，不保护任意恶意改代码/绕过入口的进程。字段敏感键遮盖不等于自动识别所有未知秘密。知识推广仍需来源和适用版本；没有让一次失败自动修改全局规则。

升级时保留 workspace/runs，不覆盖证据；刷新上下文并重建代码摘要已变化的生成物。常规使用入口见 [START_HERE](../../START_HERE.md)，具体规约见 [diagnostics.md](../../workflow-testing/references/diagnostics.md)。

## 接力与回退

实际代码和声明修改清单在本目录 change-request.json；已有文件基线在 baseline，交付说明旧版在 baseline-delivery。修订历史与旧验证证据保留。回退恢复声明基线并移除本轮新代码，不删除任何测试证据，不移除项目严格策略以绕过刷新。

下一步是公司环境用脱敏 fixture 验证实际接口、Flowable 导出形式与权限配置。独立审查和公司业务验收均未代为完成。维护租约状态以本目录 release.json 和根 handoff.json 为准。
