"""Reproducible local validation; no company service calls."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
delivery = here.parents[1]
skill = delivery / 'workflow-testing'
sys.path.insert(0,str(skill/'scripts'))
from demo_support import make_assets


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write('\n')


def command(label, args, cwd=skill):
    with (here/(label+'.stdout.log')).open('x',encoding='utf-8') as out, \
         (here/(label+'.stderr.log')).open('x',encoding='utf-8') as err:
        p = subprocess.run(args,cwd=cwd,stdout=out,stderr=err,encoding='utf-8',timeout=120)
    result = {'label':label,'command':args,'exit_code':p.returncode,
              'stdout':label+'.stdout.log','stderr':label+'.stderr.log'}
    if p.returncode:
        raise RuntimeError('Validation failed; inspect '+str(here/(label+'.stderr.log')))
    return result


def diagnostic_demo():
    root = here / 'diagnostic-demo'
    root.mkdir(exist_ok=False)
    calls = []
    def call(label, tool, **args):
        req = {'protocol_version':'1.0','tool':tool,'arguments':args}
        save(root/('calls/'+label+'.json'),req)
        p = subprocess.run([sys.executable,'-X','utf8',str(skill/'scripts/toolchain.py'),
                            '--workspace',str(root),'--request',str(root/('calls/'+label+'.json')),
                            '--response-file','replies/'+label+'.json','--control'],
                           capture_output=True,encoding='utf-8',timeout=30)
        (root/(label+'.stdout.log')).write_text(p.stdout,encoding='utf-8')
        (root/(label+'.stderr.log')).write_text(p.stderr,encoding='utf-8')
        assert p.returncode == 0, p.stderr or p.stdout
        assert 'PRIVATE-FIXTURE-CANARY' not in p.stdout
        calls.append({'label':label,'exit_code':p.returncode,'stdout_bytes':len(p.stdout.encode('utf-8'))})
        return json.loads((root/('replies/'+label+'.json')).read_text(encoding='utf-8'))['data']

    suite, adapter, plan = make_assets(19001)
    for ref, data in [('suite.json',suite),('adapter.json',adapter),('plan.json',plan),
                      ('session.json',{'suite':'suite.json','adapter':'adapter.json','plan':'plan.json'})]:
        save(root/ref,data)
    call('init','flow_init',spec='session.json',out='project')
    call('prepare','flow_prepare',project='project/project.json',case_id='TC-DEMO-1')
    meta = json.loads((root/'project/attempts/TC-DEMO-1/0001/meta.json').read_text(encoding='utf-8'))
    payload = 'PRIVATE-FIXTURE-CANARY' + '业务数据' * 60000
    case = {'case_id':'TC-DEMO-1','execution_status':'FAIL','gate':'BLOCKED','steps':[],
            'failures':[{'step_id':'S1','check_id':'C1','assertion_id':'A1','actual':payload,
                         'expected':payload+'-expected','status':'FAIL','pointer':'/json/details'}],
            'unexecuted_steps':['S2'],'context':{'fixture_data':payload},
            'error':{'code':'SYNTHETIC_DIAGNOSTIC_FIXTURE','message':payload}}
    result = {'result_version':'1.0','run_id':meta['run_id'],'fingerprint':meta['fingerprint'],
              'finished_at':'2026-10-14T00:00:00Z','status':'FAIL','gate':'BLOCKED','cases':[case],
              'evidence_origin':'SYNTHETIC: generated for projection test; no workflow executed.'}
    result_path = root/('runs/'+meta['run_id']+'/results.json')
    save(result_path,result)
    result_path.with_suffix('.sha256').write_text(hashlib.sha256(result_path.read_bytes()).hexdigest(),encoding='ascii')
    call('diagnose','flow_diagnose',project='project/project.json',case_id='TC-DEMO-1',out='project/inspect/diagnosis.json')
    save(root/'query.json',{'artifact':'results','sha256':{'$file':'project/inspect/diagnosis.json','pointer':'/artifacts/results/sha256'},
                          'pointers':['/cases/0/failures/0/actual','/cases/0/failures/0/expected']})
    call('query','evidence_query',project='project/project.json',case_id='TC-DEMO-1',query='query.json',out='project/inspect/shape.json')
    call('help','tool_help',name='evidence_query')
    for ref in ('project/inspect/diagnosis.json','project/inspect/shape.json'):
        assert 'PRIVATE-FIXTURE-CANARY' not in (root/ref).read_text(encoding='utf-8')
    metrics = {'scope':'Synthetic failure projection, not actual business execution or token-billing measurement',
               'business_http_calls':0,'fresh_process_calls':len(calls),
               'raw_evidence_bytes':result_path.stat().st_size,
               'diagnostic_bytes':(root/'project/inspect/diagnosis.json').stat().st_size,
               'query_bytes':(root/'project/inspect/shape.json').stat().st_size,
               'stdout_total_bytes':sum(x['stdout_bytes'] for x in calls),
               'stdout_max_bytes':max(x['stdout_bytes'] for x in calls)}
    save(root/'commands.json',calls)
    save(root/'metrics.json',metrics)
    return metrics


if __name__ == '__main__':
    validations = []
    validations.append(command('regression',[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-v']))
    validations.append(command('boundaries',[sys.executable,'-X','utf8','scripts/check_boundaries.py']))
    validator = Path(r'C:\Users\jing\.codex\skills\.system\skill-creator\scripts\quick_validate.py')
    validations.append(command('skill',[sys.executable,'-X','utf8',str(validator),str(skill)]))
    validations.append(command('static-demo',[sys.executable,'-X','utf8','scripts/demo_v5.py','--out',str(here/'static-demo')]))
    metrics = diagnostic_demo()
    save(here/'validation.json',{'commands':validations,'diagnostic_demo':metrics})
    print(json.dumps({'checks':len(validations),'diagnostic_demo':metrics},ensure_ascii=False))
