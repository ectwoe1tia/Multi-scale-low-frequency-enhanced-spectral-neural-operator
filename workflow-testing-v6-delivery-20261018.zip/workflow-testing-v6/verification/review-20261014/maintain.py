import hashlib
import json
import shutil
import sys
from pathlib import Path

delivery = Path(__file__).resolve().parents[2]
skill = delivery / 'workflow-testing'
here = Path(__file__).resolve().parent
sys.path.insert(0, str(skill / 'scripts'))
import toolchain

changed = ['SKILL.md', 'scripts/toolchain.py', 'scripts/http_runner.py',
           'scripts/advanced_tools.py', 'scripts/v5_schema.py',
           'references/v5.md', 'references/extensions.md', 'references/toolchain.md',
           'assets/v5.schema.json', 'assets/tool-request.schema.json']
added = ['scripts/execution_boundary.py', 'scripts/inspection.py',
         'scripts/tool_contracts.py', 'scripts/check_boundaries.py',
         'tests/test_inspection.py', 'references/diagnostics.md',
         'assets/flow-diagnose.request.example.json',
         'assets/evidence-query.request.example.json', 'assets/evidence-query.example.json',
         'assets/tool-help.request.example.json']

def call(tool, **arguments):
    return toolchain.dispatch(skill, {'protocol_version': '1.0', 'tool': tool, 'arguments': arguments})

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as out:
        json.dump(value, out, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    hashes = call('snapshot', files=changed)['data']['base_hashes']
    for ref in changed:
        target = here / 'baseline' / ref
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(skill / ref, target)
    save(here / 'baseline-manifest.json', {
        p.relative_to(skill).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in skill.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.coordination' not in p.parts})
    change = dict(change_id='CHANGE-V5-DIAGNOSTIC-BOUNDARIES', owner='codex-maintainer-20261014',
                  role='maintainer', status='implementing', base_version='v5 / 3.0.0',
                  purpose='用户授权复查并保留 v5：小型排查输出、文件证据查询、确定性工具边界。',
                  base_hashes=hashes, changed_files=changed, new_files=added,
                  compatibility='保留 v5 与 runner 3.0.0；新增具名工具与可选 CLI 输出模式。旧 JSON 请求兼容。',
                  business_expectations_changed=False, review={'status':'pending','reviewer':''},
                  rollback='从本目录 baseline 恢复声明文件，移除本次新增代码；保留所有历史证据。')
    save(here / 'change-request.json', change)
    lease = call('claim', owner=change['owner'], change_id=change['change_id'], base_hashes=hashes)
    save(here / 'lease.json', lease)
    print(json.dumps({'claimed': True, 'existing_files': len(changed), 'new_files': len(added)}))
