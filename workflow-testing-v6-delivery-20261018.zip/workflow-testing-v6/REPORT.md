# Workflow Testing v6 实现与验证报告 · 20261018

本次按用户最新要求升级为 **v6 / runner 6.0.0**，日期 **20261018**。请求协议及数据版本保持 1.0；旧 v5 目录与已发布包逐文件核对一致，原 v4 源文件哈希也未变。当前 Skill 未自动安装。

## 本次修复

| 问题 | 实现与验证 |
|---|---|
| PowerShell 拼接/格式错误 | 新 Invoke-WorkflowSession.ps1 仅收 Session/Action/CaseId 等固定参数；参数数组传 Python，不拼 JSON；中文、空格路径、动作大小写、缺 Session 已验证 |
| 请求与 token 挤占上下文 | session-spec.json 引用 suite/adapter/plan/tokens；脚本生成请求与回执；实际 execute 内只读一次凭据并恢复进程环境；静态动作与已完成重复调用不读 token |
| 自定义业务头缺入口 | adapter → actor → operation → case → step；字符串或 env 引用；大小写无关覆盖；禁止保留头、重复键、CR/LF、未知变量；真实回环验证发送结果 |
| 报告无法解释失败 | 展示编号、标题、分类、优先级、设计与执行状态、PASS/FAIL 原因、期望/实际、msg/message，以及每步方法、路径、响应码和检查结果 |
| 模型跳过刷新/文件入口 | file_only 初始化绑定会话；固定动作链自动刷新与诊断；有效 receipt 也不能从旧入口直接执行该项目；execute 必须已有准备状态 |
| 重复调用与接力 | 完成 attempt 只复用封存证据；不确定结果必须核对；日志/回执/报告保存引用，模型只获取短控制输出 |

可直接查看 [实际生成的报告](verification/review-20261018/final/SAMPLE-REPORT.md)。示例 TC-001 为 PASS，TC-002 为有意制造的 FAIL：POST /documents 期望 201、实际 400，服务端 msg 为“文档编号不能为空”。这条失败用来验证报告与退出码，不是回归失败。

## 最终验证

- **182 项自动化测试全部通过**，包含原有 155 项与新增 27 项行为测试。
- 静态代码边界检查与 Skill 格式校验通过；40 个注册工具，8 个静态模块接受边界检查。
- 真实 PowerShell 文件入口演示：2 个用例、7 次调用、4 次本地回环 HTTP；重复 execute 未重发。
- 这 7 次调用 stdout 合计 **2900 字节**，单次最大 **496 字节**；完整人类报告 **4933 字节**，保存在文件。
- 演示凭据未出现在报告或生成证据中；凭据只使用合成本地值。
- 60 用例静态演示继续通过；HAR 3966026 字节，业务 HTTP 调用 0。这并不表示 60 个业务用例已实际执行。

[验证命令与结果](verification/review-20261018/final/validation.json)、[全量测试日志](verification/review-20261018/final/regression.stderr.log)、[PowerShell 逐次命令](verification/review-20261018/final/session-demo/commands.json)、[输出测量](verification/review-20261018/final/session-demo/metrics.json) 可用于接力复验。字节数是实测输出量，不等于 token 计费或模型遵循率测量。

## 公司接续与限制

从 [START_HERE](START_HERE.md) 和 [文件会话契约](workflow-testing/references/managed-session.md) 接入。已有项目显式 init 迁移；未决 PREPARED/UNKNOWN/INCOMPLETE 先完成或核对，保留旧证据。代码升级后重新刷新并生成依赖代码摘要的产物。沿用 v5_schema 等接口名称，不代表发布版本仍是 v5。

强制入口只约束已初始化的受支持执行代码，不是 OS 沙箱；未迁移旧项目保留兼容入口。报告的服务端消息取响应顶层 msg/message；完整结构可通过证据查询。旧证据缺少元数据时仅在准备来源哈希一致时补充显示，否则标明未知，不改写证据。报告单元格有明确截短标记，完整值见证据。

独立评审仍为 **pending**；公司业务验收 **not_executed**。没有请求公司接口、读取公司凭据或修改宿主 PowerShell 策略。
