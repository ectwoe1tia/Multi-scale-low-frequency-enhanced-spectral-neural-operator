# Workflow Testing v5 扩展设计草案

状态：仅设计，尚未实现或测试。基线：workflow-testing v4 / runner 2.2.0。日期：2026-10-13。

本轮不修改 v4 程序、不运行公司流程、不重放浏览器、不访问公司 Flowable 服务。本文中的工具名和参数是拟定契约，尚未注册，不能当作现有可调用工具。

## 1. 目标与实施次序

将工作分为“确定性运行内核、项目声明与生成物、短上下文”三个部分。模型选择目标并处理歧义；程序读取文件、查询索引、验证规则和计算覆盖率。使用已有证据分析已发生行为，不通过再次操作业务系统补证据。

| 阶段 | 内容 | 交付目标 |
|---|---|---|
| P0-A | staleness 强制刷新 | 过期摘要、规则、接口契约、用例状态不能继续驱动执行 |
| P0-B | rules_codegen + 有限 DSL | 同一份声明生成校验器输入、工具契约、请求模板、规则摘要与溯源；规则增长不再堆进 SKILL |
| P1-A | flow_analysis | 读取 BPMN/已导出的 REST 定义，输出 case—路径映射和口径明确的覆盖率 |
| P1-B | Recorder + HAR 对齐 | 生成可追溯测试轨迹；不确定关联保留为候选，不伪装成已发生流程路径 |

基础 flow_analysis 不依赖双输入自动对齐：第一阶段可以使用已有 case 显式绑定和导出的引擎历史。trace_align 后续补充证据，提高映射率。各阶段都有独立验收点，额度耗尽后可单独接续。

## 2. 现有 v4 的可复用部分与缺口

- file_workflow.py 已有逐 case 文件、来源哈希、prepare/execute、稳定 attempt、独占 intent、UNKNOWN 阻断、笔记和摘要。
- flow_execute 已校验 prepared plan 与来源哈希，但 flow_status/focus 的刷新不是后续工作的强制门槛；规则说明、工具契约、相关经验版本尚未统一绑定。
- trace_tools.py 已支持 HAR 或 Recorder 单独导入、匹配注册 HTTP operation、显式绑定后生成计划。
- 当前 Recorder 导入只保留动作次序等结构信息；HAR 导入没有保留本次对齐所需的时序字段；trace 1.0 不能原地塞入新字段，否则会破坏严格 schema 校验。
- 当前包未包含完整的 rules_codegen / DSL 实现。以下将 DSL 明确定义为新的设计契约，不能声称既有版本已经提供它。

## 3. 总体结构

```text
项目原始资料 ──> 规范化器 ──> 版本化中间表示/索引
  BPMN/REST快照               FlowGraph
  Recorder/HAR               TraceIR
  需求/规约                   RuleDSL → RuleIR
                                   │
                  ┌────────────────┼────────────────┐
                  ▼                ▼                ▼
             rules_codegen     trace_align      flow_analysis
                  │                │                │
          项目工具描述/模板     证据关联图       覆盖报告/流程图
                  └────────────────┼────────────────┘
                                   ▼
                       文件引用 + 有界查询 + 当前摘要
                                   │
                              模型处理当前问题
```

每个产物都记录输入引用与 SHA-256、schema/生成器版本、依赖和适用范围。源码、规范化数据、派生报告、上下文摘要分开，避免“生成的结果反过来成为事实来源”。

## 4. P0-A：staleness 必须落在程序入口

### 4.1 新增 context_refresh

拟定请求：

```json
{
  "protocol_version": "1.0",
  "tool": "context_refresh",
  "arguments": {
    "project": "projects/order/project.json",
    "case_id": "TC-001",
    "out": "projects/order/context/snapshots/CX-001"
  }
}
```

输出目录包含 `focus.json`、`receipt.json`、`changes.json` 和当前可用动作的请求文件。focus 只包含当前状态、相关核心规则、最多三条适用经验、下一步和文件引用。目标大小为 4 KiB；过多条目进入按需查询索引，不静默截掉必需约束。

receipt 至少绑定：project/case、操作阶段、当前 case 状态版本、相关业务基线与计划片段哈希、adapter 及其来源、有效 RuleIR、工具 schema、核心指引、相关经验索引、生成器版本、签发时间和有效期。不是把全部内容复制到 receipt，只记录必要依赖及哈希。

后续 `flow_prepare`、`flow_execute` 和会产生新运行尝试的入口使用 `context_receipt` 文件引用。自动生成的请求负责填入引用，模型不手抄版本或摘要。

### 4.2 强制校验

统一在 dispatch/运行内核中校验，不只改 CLI 或 SKILL：

1. 缺 receipt：返回 CONTEXT_REQUIRED，并生成刷新请求引用。
2. receipt 不属于当前 project/case/动作阶段：拒绝。
3. 必需依赖哈希、规则版本、case 状态变化：返回 CONTEXT_STALE 和变更文件清单。
4. 超过有效期：要求刷新。有效期可配置，初始建议 10 分钟；时间只是补充，不能替代内容哈希。
5. 校验成功后才继续原有 plan/actor/guard/intent 流程。

prepare 会产生新的状态，因此 prepare 完成后为 execute 生成绑定“准备完成状态”的 receipt 和请求。execute 提交前重新检查，不能复用准备前的 receipt。已完成 attempt 的重复查询继续返回旧证据，不因为刷新而创建新 attempt。

报告/静态分析可以自动重建纯派生产物，但不能因此自动发业务请求。旧报告可以按原快照查看，必须标记 as-of；不能冒充当前分析结果。

### 4.3 必须防止旧入口绕过

项目/工作区启用严格模式后，旧 `run` 入口也必须检查相同上下文与规则绑定；不能只保护 flow_execute。旧 v4 项目通过显式迁移启用，不静默给旧请求“补一个总是有效”的 receipt。内部 Python 调用与动态项目工具也走同一内核。

P0 第一刀可以是较小的 gate + receipt 校验补丁，但完整交付还需覆盖依赖发现、状态竞争、旧入口与恢复测试，不能把全部工作估为几十行。

边界：程序能够阻止使用过期状态/契约继续执行，不能证明模型真的阅读或理解了文字，也不能自动识别宿主何时压缩了对话。每次交接仍从刷新入口开始，机器可执行约束由 DSL/现有校验器落实。

## 5. P0-B：rules_codegen 与有限 DSL

### 5.1 四种规则必须区分

| 类别 | 真正来源 | 放在哪里 | 如何生效 |
|---|---|---|---|
| 工具内核约束 | 维护代码/版本契约 | 公共内核 | 不允许项目覆盖 |
| 项目权限和数据边界 | 已有 policy/adapter | 项目受限能力 | 保留 deny 优先、角色交集、guards；DSL 只能进一步约束 |
| 业务规则/预期 | 明确需求或确认记录 | 项目 RuleDSL | 编译为校验输入、路径义务和必要请求模板 |
| 操作经验 | 已有执行证据与分析 | knowledge | 用于提醒和检索；假设不自动变成强制规则 |

已经存在的 request_guards、checks 不重写成另一套相互冲突的执行引擎。编译器优先生成这些成熟契约；确实没有对应能力时形成 unsupported 诊断，不能生成任意 Python 代替。

### 5.2 DSL v1 示例

以下是拟定 DSL 内容，不是已经支持的输入。规则依据必须来自业务需求，而非仅从 BPMN 实现反推验收标准。

```json
{
  "dsl_version": "1.0",
  "id": "R-LARGE-AMOUNT",
  "kind": "coverage_obligation",
  "scope": {"process_key": "expense", "definition_ref": "definitions/expense.bundle.json"},
  "when": {
    "op": "gt",
    "left": {"case_var": "amount"},
    "right": {"literal": 10000}
  },
  "require": {"activities_in_order": ["managerReview", "directorReview"]},
  "status": "confirmed",
  "source_refs": ["requirements/REQ-008.json"]
}
```

允许的表达式为受限 JSON AST：布尔组合、比较、集合包含、存在性、类型检查、已定义字段引用。禁止 eval/exec、函数调用、模块导入、任意属性访问、网络和 shell。第一版不自动执行 BPMN 的 Java/UEL/脚本表达式；无法规范化的表达式保存原文引用，结果为 UNKNOWN。

语义必须固定：缺字段不等于 null，bool 不当数值，金额采用约定小数表示，时间带时区；比较类型不兼容报诊断；when 为 UNKNOWN 时形成 unresolved，不当作 false 跳过义务。AST 深度、规则数量、输入和结果大小均受限。

DSL 分文件维护：每规则一个文件，index 只保存 id、作用域、来源和哈希。修改规则使其依赖的生成物失效，不能重新生成一份文件却保留旧 hash。

### 5.3 编译产物与动态工具

`rules_codegen(project, spec, out)` 拟生成：

- `rules.ir.json`：经过类型和引用检查的中间表示。
- `rules.index.json`：按 case、operation、activity、阶段检索的索引。
- `tools/<id>/descriptor.json`：名称、输入/输出 schema、能力范围、纯度、版本和溯源。
- `requests/*.request.json`：调用文件模板。
- `context/rules.digest.json`：当前范围的小摘要。
- `diagnostics.json`：冲突、缺事实、暂不支持项。
- `manifest.json`：输入/产物哈希与生成器版本。

动态工具第一版是“项目私有的声明式配方”，由固定 `project_tool_invoke` 分派，不动态 import 项目 Python，不把几十个工具的描述全部注入模型工具列表。公共入口稳定，模型只检索当前需要的 descriptor。

配方仅组合白名单操作，例如字段选择、类型检查、记录关联、路径查询、报告格式化。递归和无界循环禁止；每一步数据仅保存在当前 Python 调用的数据结构中，终端只返回产物引用。动态工具本身不执行业务 HTTP；任何以后允许的执行能力仍必须经过原有受限执行入口。

确有重复模板需求时再添加 `tool_codegen`：元模板 + 项目 schema → descriptor/IR/请求模板。生成器本身是公共受测代码，项目生成物是数据，不能无限递归生成/执行代码。

生成的 expected 不得使用 recorded response 作为唯一依据。生成的测试用例不能同时作为规则正确性的唯一验证依据，必须有独立维护的正反例 fixture。

### 5.4 规则演进

candidate → 有证据的 confirmed → 编译验证 → 在项目版本中启用；冲突/缺来源则保留 draft。已有用户业务确认可直接引用，不重复索要同一授权。业务预期变化必须形成新基线，不能在失败后自动改 expected。解释能力有限的复杂业务继续留给人工/模型分析，并显式列为 unresolved。

## 6. P1-A：flow_analysis

### 6.1 输入范围和无副作用边界

工具拟定为 `flow_analysis(project, spec, out)`。业务侧零写入、零回放；本地只读输入并生成分析文件。

支持三种定义来源：

1. 本地 BPMN XML。
2. Flowable REST `/resourcedata` 的已导出 XML + 定义元数据快照。
3. Flowable REST `/model` 的已导出 JSON + 导出版本/能力信息，通过版本化适配器转换。

Flowable 官方同时提供 `GET repository/process-definitions/{processDefinitionId}/resourcedata` 与 `/model`。普通 process definition 元数据对象不足以推导完整流程图。[官方 REST 文档](https://www.flowable.com/open-source/docs/bpmn/ch14-REST)

为严格满足纯静态，flow_analysis **不接受 URL 并隐式联网**。第一版读取导出快照。如果以后需要在线只读拉取，单独设计受限 `definition_snapshot` 工具；采集与分析解耦，快照固定后再算覆盖。本轮及第一版分析不执行该采集动作。

还可以输入：case 基线与计划、显式 activity/operation 绑定、已有 run 结果、Recorder/HAR 对齐轨迹、导出的 Flowable 活动/任务/流程实例历史。所有轨迹按 definition ID/版本、实例 ID、case ID、attempt 和执行作用域分组，禁止混淆不同部署版本或不同运行。

### 6.2 规范化图

FlowGraph 记录 process/scope、node ID/type、sequenceFlow ID/source/target/default/condition、lane/角色注释、子流程与调用定义引用、源文件位置。

XML 解析禁止 DTD、外部实体和外部资源加载，并设置大小/节点深度限制。子流程保留作用域；没有定义快照的 callActivity 标为 opaque。messageFlow 不计作本进程 sequenceFlow。多流程 XML 必须选定 process，不能混成一张图。

第一版精确覆盖：顺序节点、开始/结束、用户/服务任务、排他分支、结构明确的并行分支、显式作用域内 sequenceFlow。并行网关表示所有分支的并发与汇合，不能当作任选一条分支；无需枚举并发执行顺序的所有排列。[Flowable 网关语义](https://www.flowable.com/open-source/docs/bpmn/ch07b-BPMN-Constructs#parallel-gateway)

包容/事件网关、非结构化并行、多实例、补偿、边界中断和动态调用第一版保留结构与可直接证明的节点/边覆盖，但不能完整推演其可行路径。报告必须列 unsupported/opaque 数量、受影响范围及理由。

### 6.3 case 到路径的映射与证据等级

```text
case/attempt → trace events → business instance/activity events → BPMN nodes/sequence flows
```

| 等级 | 依据 | 允许结论 |
|---|---|---|
| observed | 可追溯的活动/迁移记录，定义、实例、作用域匹配 | 记录证明的节点或边确实发生 |
| derived | 基于观测锚点及图约束推得的唯一/候选连接 | 在明确假设下可推断；不混入直接观察覆盖 |
| planned | case 计划、数据与确认规则推导 | 测试设计计划覆盖该路径，尚不能说实际走过 |
| ambiguous / unmapped | 多个匹配或没有证据 | 列出候选/缺口，不能强制选一条 |

两条相邻活动记录不一定唯一确定一条 sequenceFlow；网关、循环或中断可能留下多条候选。即使能唯一推导，也保留 derived 与依据。只有 Recorder 点击或 HTTP 200，通常无法证明内部 BPMN 分支。没有真实轨迹时输出 planned coverage 和 observed coverage=null/insufficient_evidence，不能填“实际覆盖 100%”。

### 6.4 覆盖率不能只有一个不明分母的百分比

默认报告四类指标：

- 节点覆盖：可证明到达的节点 / 明确定义的分析范围内节点。
- 边覆盖：可证明经过的 sequenceFlow / 分析范围内 sequenceFlow。
- 决策分支覆盖：覆盖的决策网关出口 / 分析范围内决策出口；并行分支义务单独统计。
- 路径义务覆盖：覆盖的、预先定义且版本固定的路径义务 / 全部同范围路径义务。

每类分别显示 observed、derived、planned；同时给出分子、分母、未知数、排除项与定义版本。默认分母不能因当前用例覆盖不足而缩小；无法证明不可达的元素不能悄悄排除。分母为零或证据不足时为 null，并给 reason。

示例：确认的路径义务共有 6 条，计划覆盖 5 条、直接证据满足 3 条，则设计路径义务覆盖为 5/6，已观测义务覆盖为 3/6。它不等同“流程所有可能路径的覆盖率”。

循环可能形成无限路径，并发排列会膨胀。无环、受支持且可枚举完的范围可以输出完整有限路径覆盖；其他情况采用显式 `loop_bound`、`max_depth`、`max_paths` 和规范化并发块，输出 bounded-path coverage，并记录限制。枚举中途截断时不输出貌似完整的精确百分比，只报告已分析数量、下界或 null，保留 truncation 原因。

路径义务来自独立于测试结果的业务规则/显式义务清单，或由定义静态生成并版本固定；若清单本身不完整，必须标 scope，不能称全路径。避免“仅从现有 case 生成路径再宣布全部覆盖”的循环证明。

未知条件表达式按 UNKNOWN 处理，不执行 Flowable UEL/Java bean/脚本，不声称证明了一般条件的可满足性。

### 6.5 输出

```text
analysis/<input-fingerprint>/
  manifest.json
  graph.json
  case-path-index.json
  cases/TC-001.paths.json
  coverage.json
  coverage.md
  graph.mmd
  issues.json
  summary.json
```

graph 使用稳定 BPMN ID，节点/边附 case 引用；大模型从 case 或未覆盖边查询，不读整个 graph。Mermaid 用于可检查的静态可视化，不能因名称相同合并节点。case-path 记录 step/event/证据文件位置、置信分类和候选路径，不只给一句自然语言结论。

## 7. P1-B：Recorder 与 HAR 双输入对齐

### 7.1 新建 TraceIR 2.0，不破坏旧输入

保留 trace 1.0 的原始解析与验真路径；新增独立 `trace_align(project,spec,out)` 和版本化适配器。旧生成物不能由新规则重新解释后仍声称 hash 未变化。

Recorder JSON 提供动作结构与顺序；其标准 schema 没有可以普遍依赖的逐步绝对时间戳，不能把 timeout 当作发生时间。[官方 Recorder 文档](https://developer.chrome.com/docs/devtools/recorder/reference/)；[维护方 Schema.ts](https://github.com/puppeteer/replay/blob/main/src/Schema.ts)。

HAR 保留 startedDateTime、duration、page 引用、method/归一化 URL、允许的请求结构和响应状态；需要业务证据时仅按项目 allowlist 提取 activityId、processInstanceId 等字段，原响应正文保持文件引用。Chrome 提供 sanitized HAR，但业务字段仍需项目脱敏，不默认其完全无敏感信息。[Chrome Network 文档](https://developer.chrome.com/docs/devtools/network/reference/)

### 7.2 对齐步骤

1. 校验录制范围：同一次业务会话、环境、来源哈希和已知定义版本。无法确认则先列问题，不自动拼接。
2. 分别规范化 UI 动作与网络事件，按页签/页面/实例标识分组。HAR 私有字段只能在存在时利用，不能当作标准必填字段。
3. 优先使用显式 `alignment.json`：Recorder step → 一组 HAR event 的人工确认绑定；支持一个动作发多个请求、后台无 UI 请求、UI 无 HTTP 请求。
4. 自动候选结合导航锚点、事件顺序、允许 operation、输入形状、业务实例 ID 和可选外部时间锚点。没有统一时间基准时不做绝对时间硬匹配。
5. 采用允许空匹配/多匹配的有界序列关联，保留候选理由；轮询、加载、遥测分类但不丢原始证据。
6. 输出 confirmed / candidate / ambiguous / unmatched。算法评分只是排序信号，不当作真实概率或事实确认。

同一路径多次点击、并发 XHR、分页、轮询、重试、异步后台任务都不能用简单“第 n 次点击 = 第 n 个请求”配对。响应时间的先后也不等于因果关系。

### 7.3 测试轨迹与测试计划分离

拟生成 `test-trace.jsonl` 与索引：每个事件含 case/attempt 绑定、UI 引用、HTTP 引用、operation、实例/活动锚点、偏序关系和证据等级。

三种输入模式都可用：Recorder-only 生成 UI 观察轨迹；HAR-only 生成 HTTP 观察轨迹；双输入生成关联轨迹。没有 case 映射时保持 unassigned，不猜测属于哪个测试用例。

这些是观察轨迹，不是自动通过的测试结果。后续从轨迹生成计划时仍用明确业务 expected、新数据与角色映射，不复制历史 token/实例 ID，也不触发浏览器或 HTTP 回放。本版 flow_analysis 仅消费这些已生成轨迹。

## 8. 运行环境与查询：数据留在程序里

拟定 `runtime_init(project,out)` 检查已有 Python/curl 能力、创建项目 runtime 目录和工具版本锁定记录，不自动安装依赖、启动浏览器或常驻服务。静态工具不依赖 curl 可用；环境报告分别标记 static_ready 和 execution_ready，不能因公司禁用网络就阻断纯静态分析。

第一版使用短生命周期 CLI，内部 Python dict/dataclass 保存 FlowGraph、RuleIR、TraceIndex；不会把这些对象 dump 到 stdout。**每个 CLI 子进程结束后临时变量就消失**，因此跨调用复用依靠文件化产物与内容寻址缓存，不能把内存变量当作额度耗尽后的持久状态。

数据量增加时使用标准库 sqlite3 存放可重建查询索引，JSON/JSONL 仍为可追溯事实文件。缓存键包含源哈希、schema、规则和编译器版本；丢失缓存只影响速度，不影响正确性。索引不得作为副本去改写原证据。首版无需常驻 Python 服务或 pgSQL；未来确有性能证据再评估长驻进程。

固定 `artifact_query(project, query, out)` 只接受具名查询：case_paths、uncovered_edges、rule_by_id、trace_matches、relevant_lessons 等；没有任意 SQL/Python/JMESPath 执行。分页、条数和输出字节数受限；超量结果落文件并返回 cursor/ref。普通回执目标 <= 2 KiB，当前上下文目标 <= 4 KiB；超出时返回索引，不静默丢必需信息。

## 9. 生成物分级与知识沉淀

```text
projects/order/
  project.json
  sources/                  # 原文、BPMN、REST 导出、Recorder/HAR：受控原始输入
  contracts/                # 项目规约、业务 DSL、绑定、路径义务清单
  normalized/               # TraceIR/FlowGraph 等版本化中间表示
  generated/<fingerprint>/  # RuleIR、工具描述、请求模板：可再生
  analysis/<fingerprint>/   # 路径映射、覆盖、诊断：可再生
  attempts/                 # 运行/核对/重试历史：不可覆盖
  knowledge/
    index.json              # 小索引，按 case/operation/activity 检索
    candidates/             # 一次问题形成的假设/经验
    confirmed/              # 已有真实依据、带适用范围的经验
    superseded/             # 过期但保留来源的历史结论
  context/                  # 当前工作快照、refresh receipt；只装必要摘要
  runtime/                  # 版本锁定、可重建 cache/index
  calls/ replies/           # 项目专属工具请求与完整回执
```

区分两个维度：

- 可信度：source、confirmed、candidate、unresolved、superseded。
- 可再生性：原始资料/运行证据不可覆盖；中间表示、索引、报告可按指纹重建；上下文摘要可刷新。

知识条目保存适用 definition/rule/adapter 版本、case/operation/activity、现象、原因是否证实、解决动作、反例、证据引用、失效条件和 supersedes。经验跨版本变化后先重新验证；不能仅因重复出现次数多就从假设升级成事实。

单次问题先留原始证据，再提炼项目经验；可复用的操作模式变为项目配方；跨项目稳定规律才走共享 Skill 的维护流程。不能把所有项目经验持续追加进 SKILL.md。生成后的动态工具也有适用版本与生命周期，依赖改变即 STALE，重新编译后产生新指纹，历史版本仍可解释历史运行。

## 10. 拟定工具表

| 工具 | arguments | 网络/业务副作用 | 返回内容 |
|---|---|---|---|
| runtime_init | project,out | 无 | 能力检查与初始化清单引用 |
| context_refresh | project,case_id,out | 无 | 小摘要、receipt、下一动作请求引用 |
| rules_codegen | project,spec,out | 无 | IR/索引/工具描述/模板 manifest |
| project_tool_invoke | project,tool_ref,input_ref,out | 第一版无 | 受限配方结果引用 |
| trace_align | project,spec,out | 无 | 测试轨迹、对齐表与未决候选 |
| flow_analysis | project,spec,out | 无 | case 路径、覆盖、图和诊断 |
| artifact_query | project,query,out | 无 | 有界查询结果或分页引用 |

flow_analysis spec 示例：

```json
{
  "schema_version": "1.0",
  "definition_ref": "projects/order/sources/definition.bundle.json",
  "suite_ref": "inputs/suite.json",
  "case_binding_ref": "projects/order/contracts/case-flow-bindings.json",
  "trace_index_ref": "projects/order/normalized/traces/index.json",
  "obligations_ref": "projects/order/contracts/path-obligations.json",
  "coverage_policy": {
    "reported_basis": ["observed", "derived", "planned"],
    "loop_bound": 1,
    "max_paths": 5000,
    "max_depth": 200
  }
}
```

没有 trace 时 trace_index_ref 可省略，只计算设计覆盖；数量限制是待 fixture 验证的初始值，不承诺这些参数能完整枚举任意业务流程。

## 11. 实施拆分与验收

| 交接单元 | 实现位置建议 | 必须通过的验收 |
|---|---|---|
| A. freshness gate | 新 freshness.py + toolchain/file_workflow 接入 | 修改规则/契约/状态后旧 receipt 拒绝；旧 run 不绕过；同一次已完成执行查询仍不重发；准备与执行间变化被发现 |
| B. DSL 编译 | rules_schema.py、rules_codegen.py、固定解释器 | 同输入语义哈希稳定；未知字段/调用/深度超限拒绝；缺值 UNKNOWN；业务冲突不能生成有效规则；generated 工具不扩权 |
| C. BPMN 图 | flow_model.py + 版本化输入适配 | XML 与对应 REST 快照得到等价图；定义版本不混；作用域与默认流保留；XXE/深度超限拒绝 |
| D. 静态覆盖 | flow_analysis.py | 顺序/XOR/并行/循环 fixture 有人工预设期望；无证据不冒充 observed；截断不冒充完整；分母稳定；未知结构可见 |
| E. trace 对齐 | TraceIR 2.0 + trace_align.py | 单 UI 多请求、无网络 UI、轮询、并发、跨页签、无时间戳、不同会话均有反例；含糊关联不自动确认 |
| F. 分层查询/接续 | artifact_query.py + 项目索引 | 大输入不进入 stdout；缓存删后可重建；换进程恢复；经验过期不自动适用；原记录不覆盖 |

所有新增工具的单测应禁止真实 socket/HTTP 调用，证明纯静态分析不因缺资料自动联网。输入用合成 fixture 或公司明确授权且脱敏的样本。覆盖指标必须与人工构造的小图黄金结果比较，不能仅靠“工具能生成 JSON”验收。

性能实验拟使用几十至上百 case、较大 HAR、循环/并行 BPMN；记录真实耗时、峰值内存、stdout 字节数、缓存命中和跨进程恢复结果。具体阈值由公司环境测定，不在设计阶段伪造性能数字或测试通过报告。

保留原有 94 项回归，新增正反例；独立评审另行真实开展。第一阶段严格模式和后续 TraceIR 2.0 涉及契约变化，版本与迁移说明必须同步，不能用 minor 升级名义静默改变老项目行为。

## 12. 后续接手入口

本文件是设计事实来源。下一轮首先完成 A 的协议/schema、gate 与测试，再完成 B；不先铺开全部工具骨架。每个单元完成后保存变更单、实际命令、日志、未决项和下一步，继续沿用现有维护租约协议。

首轮需要冻结的约定：严格模式覆盖哪些执行入口、receipt 的有效期与依赖范围、DSL v1 操作符、路径义务分母、公司 Flowable 版本与可导出证据。没有公司版本和样本时可以先做合成 fixture，不自行推断公司接口字段。

当前状态：设计已落盘；没有实现新增工具，没有运行新增测试，没有修改现有 v4。
