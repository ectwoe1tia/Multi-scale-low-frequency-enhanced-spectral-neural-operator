# Workflow Testing v6 使用入口 · 20261018

Skill 位于 `workflow-testing/`，runner **6.0.0**，协议 **1.0**。本次发布 v6，旧 v5 保留；历史契约文件名继续兼容。先看 [本次报告](REPORT.md)，需要参数时只读 [文件会话入口](workflow-testing/references/managed-session.md)。

## 首次接入

1. 将 suite.json、adapter.json、plan.json 和 session-spec.json 放到项目 workspace；session-spec 放根目录，内部路径均相对根目录。
2. 参考 assets/managed-session.example.json 配置 project_dir、credentials_file 和 execution_mode=file_only。真实 tokens.json 放在生成目录之外，由本机填写；模型不读取、不粘贴到聊天或命令。
3. 使用下列固定入口依次 init → prepare → execute。新入口不要混用 Invoke-WorkflowTool.ps1 的参数。

```powershell
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action init
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action prepare -CaseId TC-001
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action execute -CaseId TC-001
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action report
```

把示例路径换成本机实际路径。接手已初始化项目先用 `-Action status`；失败先 `-Action diagnose -CaseId TC-001`。脚本保存完整回执和报告，终端仅返回状态、动作及文件引用。prepare/execute 自动刷新和诊断；不确定写结果不能直接重发。

已有项目先阅读 [v6 迁移契约](workflow-testing/references/v6.md)，显式 init 登记 file_only；复制包本身不会迁移项目。生成 adapter 的业务头写入来源 policy，避免直接修改生成文件破坏溯源。

## 文件分层与接力

- 常驻上下文：SKILL.md、当前动作、状态码、少量相关经验与文件引用。
- 按需查询：tool_help、flow_diagnose、evidence_query、artifact_query；完整参数 schema 保存文件。
- 项目沉淀：sources/contracts/normalized/generated/analysis/knowledge/context；请求回执在 .session-calls/.session-replies，封存证据与报告单独保存。
- 静态规则、BPMN/Flowable 定义快照、Recorder/HAR 分析沿用注册工具文件入口，不执行业务请求。详见 [沿用契约](workflow-testing/references/v5.md)。

换模型只交接 workspace、v6/6.0.0/20261018、session-spec 路径、最近回执引用、当前 case 和未决项。不要复制业务大文件、凭据或完整报告进交接上下文。

## 本地复验

在 workflow-testing 目录运行：

```powershell
python -X utf8 -m unittest discover -s tests -v
python -X utf8 scripts/check_boundaries.py
```

完整回归与演示可从交付根目录运行 `python -X utf8 verification/review-20261018/verify.py <全新输出目录>`。测试 HTTP 只访问自带回环服务器。实际结果见 REPORT.md；独立评审和公司业务验收尚未完成。
