# 演示文稿设计基板

这套基板将演示的内容、设计规则和最终渲染分开保存。主题 token 描述颜色与字体；`design-language.json` 保存构图、视觉引导、图像论证角色与失败模式；Vue 运行时负责将结构化内容放入布局组件。

## 在 Windows 上启动

需要 Python 3.9+、Node 22+。本地预览和原生 PPTX 生成需要 Pillow；安装命令为 `python -m pip install -r requirements.txt`。基板内附 Vue 2.6.12 离线运行时；在联网环境运行 `npm install` 会改用锁定的 Vue 3.5.13。

```powershell
python tools/pipeline.py rebuild styles/baseline decks/demo.json examples/demo
python tools/pipeline.py check examples/demo/index.html examples/demo-checks --engine native
python tools/pipeline.py export examples/demo/index.html examples/demo.pptx --engine native
```

默认基板含 cover、split、metrics、timeline、comparison、closing 六种组件布局。用已有风格包时，将路径替换为 `styles/source-1`。选项以 `layouts.json` 中的 ID 为准；不支持的布局和超容量内容会在构建时失败。

实际内容契约见 `decks/demo.json`。插图路径需相对于 deck JSON，限定 PNG/JPEG 且不超过 5 MB。图表示例用编辑器友好的形状组成，不会声称是有数据结构的 PowerPoint 原生图表。

## 导出与检查边界

`--engine native` 用系统中文字体度量文本并生成离线预览，适用于本受限环境；PPTX 由文字框、矩形和图片组成，非整页截图。这个排版器按布局契约生成场景；它不是 Chrome 的 CSS 渲染，不应声称与浏览器像素一致。`--engine browser` 用本地 Chrome/Edge 读取真实 Vue DOM、检查内容区并按测得文字行导出；需要允许启动无头浏览器的主机。PPTX 中每行文字为独立文字框，图表仍是形状，字体可能在其他电脑替换。

独立 OOXML 检查和 14 项自动化回归覆盖关系路径、组合坐标、图片/文字 ID、容量校验、导出关系和包的完整性；没有宣称已用 PowerPoint/LibreOffice 独立打开验证。样本 PPT 的结构提取通过；源文件缩略图上的风格观察见 `styles/source-1/visual-review.json`，它只代表所列六页，颜色为近似值。

## 素材复用

`tools/pipeline.py extract <PPTX或目录> <本地输出目录>` 读取原稿，不把源文件复制到风格包。只全页位图的幻灯片会清楚标记；需要视觉审阅/OCR才能推断内部布局。要显式生成最多六张低清源图缩略图，加 `--references`。跨电脑打包依照白名单，不携带源稿、`.git`、`.env`、缓存或原始素材目录。

```powershell
python tools/pipeline.py pack E:/AI/presentation-design-system E:/AI/delivery
python tools/pipeline.py verify-pack E:/AI/delivery
```

`skills/` 下的两个 Skill 分别用于源风格提炼和新 deck 重建；PPTWork 的 MIT 许可参数解析函数单独收录于 `vendor/pptwork/`，并带原许可。其 HTML/PPTX 转换器未被复制或冒充已验证的上游依赖。

## 本机素材库的分组结果

以用户指定的微信文件目录为只读输入，已对目录中 68 份 PPTX 全量提取，结构分析成功率 100%。索引与可移植风格包见 `styles/corpus/INDEX.md` 和 `styles/corpus/aesthetic-*/`；全量匿名哈希与统计报告见 `reports/corpus-curation.json`，原文件名及绝对路径只在 `.local/corpus/` 供本机对应查找。重新扫描命令：

```powershell
python tools/curate_corpus.py "E:/MyFile/文档/WeChat Files/wxid_7lozgok3qlk322/FileStorage/MsgAttach/d5b8310aa4a51f3fb7358166de6d183f/File/2023-06"
```

分组使用可解析的背景明暗、主题色、文字/图片比、图片主导页比例和文本密度，不声称视觉模型看过 2,425 页。所有组都标记 `requiresVisualReview`；艺术风格规则是有证据的候选而非视觉终审。交付包不包含原始 PPT、原始图片或源文件名。
