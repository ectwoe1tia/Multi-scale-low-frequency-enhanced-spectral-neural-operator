"""Extract the PPT corpus, group by measured visual constraints, and write art direction."""
import argparse
from collections import Counter
import colorsys
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from extract import extract,dump
from rebuild import DEFAULT_LAYOUTS,theme_css

ROOT=Path(__file__).resolve().parents[1]


def rgb(hexcolor):
    try:return tuple(int(hexcolor[i:i+2],16)/255 for i in (1,3,5))
    except (ValueError,IndexError,TypeError):return (0.09,.27,.39)


def features(evidence):
    pages=evidence['pages'];objects=[o for p in pages for o in p['objects']]
    fill=Counter(o['fill'] for o in objects if o['fill']);primary=fill.most_common(1)[0][0] if fill else '#174B63'
    backgrounds=Counter(p['background'] for p in pages if p['background']);background=backgrounds.most_common(1)[0][0] if backgrounds else '#FFFFFF'
    images=sum(o['type']=='image' for o in objects);texts=sum(o['type']=='text' for o in objects)
    raster=sum(p['rasterPage'] for p in pages)/max(1,len(pages));hue,sat,val=colorsys.rgb_to_hsv(*rgb(primary));luma=sum(a*b for a,b in zip(rgb(background),(.2126,.7152,.0722)))
    tone='dark' if luma<.20 or raster>.45 else 'light'
    palette='blue-cyan' if .48<=hue<.67 else 'green-teal' if .30<=hue<.50 else 'red-orange' if hue<.12 or hue>.93 else 'warm-gold' if .08<=hue<.20 else 'violet' if .67<=hue<.84 else 'neutral'
    density=texts/max(1,len(pages));densityBand='dense' if density>20 else 'medium' if density>7 else 'visual-led'
    media=images/max(1,images+texts)
    imageMode='image-led' if media>.58 or raster>.45 else 'balanced' if media>.2 else 'text-led'
    return {'primary':primary,'background':background,'tone':tone,'paletteFamily':palette,'density':densityBand,'imageMode':imageMode,'rasterShare':round(raster,3),'textPerSlide':round(density,1),'imagePerSlide':round(images/max(1,len(pages)),1),'font':Counter(r['font'] for o in objects for r in o['runs'] if r.get('font')).most_common(1)[0][0] if any(r.get('font') for o in objects for r in o['runs']) else 'unspecified'}


def distance(a,b):
    ca,cb=rgb(a['primary']),rgb(b['primary']);color=sum((x-y)**2 for x,y in zip(ca,cb))**.5*2.4
    return color+(0 if a['tone']==b['tone'] else 2)+(0 if a['density']==b['density'] else .35)+(0 if a['imageMode']==b['imageMode'] else .5)+(0 if a['paletteFamily']==b['paletteFamily'] else .45)


def assign(items,threshold=1.05):
    groups=[]
    for item in sorted(items,key=lambda v:v['features']['tone']+v['features']['paletteFamily']+v['sha256']):
        candidates=[(distance(item['features'],g['centroid']),i) for i,g in enumerate(groups) if g['tone']==item['features']['tone']]
        if candidates and min(candidates)[0]<threshold:
            d,i=min(candidates);g=groups[i];g['items'].append(item);g['_distance'].append(d)
            fs=[v['features'] for v in g['items']]
            g['centroid']['primary']=max(Counter(v['primary'] for v in fs).items(),key=lambda x:x[1])[0]
            for k in ('paletteFamily','density','imageMode','font'):
                g['centroid'][k]=Counter(v[k] for v in fs).most_common(1)[0][0]
        else:groups.append({'tone':item['features']['tone'],'centroid':dict(item['features']),'items':[item],'_distance':[]})
    return groups


def guide(g,index):
    fs=[x['features'] for x in g['items']];f=g['centroid'];count=len(fs);mean=sum(v['textPerSlide'] for v in fs)/count
    if f['tone']=='dark':
        contrast='Use a restrained dark field for a clear focal area. Reserve the brightest accent for one claim or a data marker; keep paragraph backgrounds quiet.'
        rationale='Dark field separates product imagery or technical diagrams from surrounding copy and concentrates attention.'
    else:
        contrast='Keep broad content areas light, set a stable alignment edge, and use the strongest color for headings or one emphasized result.'
        rationale='Light space supports document evidence, readable explanations, and labels without competing with small visuals.'
    if f['imageMode']=='image-led':
        pairing='Let one large visual carry context, then pair it with a short explicit claim. For a full-page bitmap, treat this as a visual reference only; do not infer its internal layout.'
        avoid='Do not place a small new title over a dense screenshot or treat a complete source slide image as an editable picture layout.'
    elif f['imageMode']=='balanced':
        pairing='Assign each visual one role: explain a mechanism, prove a result, compare alternatives, or establish context. Put its label adjacent to the relevant image.'
        avoid='Avoid an image gallery without a shared question and captions that state no relationship to the main claim.'
    else:
        pairing='Use diagrams, metrics, and short text blocks as evidence. Add imagery only when it clarifies a point or supplies provenance.'
        avoid='Do not add stock imagery just to fill whitespace; preserve deliberate empty space around the conclusion.'
    layouts=Counter(x['shape'] for item in g['items'] for x in item['layoutKinds']); common=layouts.most_common(4)
    layout_notes=[{'kind':k,'slides':n} for k,n in common]
    return {'schemaVersion':'2.0','groupId':'aesthetic-%02d'%index,'status':'structure-derived; visual review needed','groupEvidence':{'presentationCount':count,'meanObjectsPerSlide':round(mean,1),'tone':f['tone'],'paletteFamily':f['paletteFamily'],'dominantFills':Counter(v['primary'] for v in fs).most_common(5),'imageMode':f['imageMode'],'densityBands':dict(Counter(v['density'] for v in fs)),'dominantObservedFont':f['font'],'commonPageStructures':layout_notes},'designIntent':rationale,'compositionRules':[contrast,pairing,'Begin each slide with its claim; decide whether an image is context, evidence, explanation, comparison, or appendix material before selecting a layout.'],'assetClaimMapping':{'context':'use low contrast; never present it as evidence','evidence':'caption with what it proves and cite source/date','explanation':'diagram the mechanism; keep labels adjacent to the step','comparison':'match crop, scale, and visual hierarchy for each alternative','appendix':'retain source identity and privacy controls; link to original file'},'attentionPath':'headline / claim → primary visual or metric → brief evidence label → takeaway/source','aestheticConstraints':{'fontFallback':'Use observed font only if installed; otherwise select and test one CJK fallback consistently.','accentUse':'One high-priority accent per slide; defer low-priority labels to muted color.','negativeSpace':'Keep open space around the dominant focal point. At high text density, reduce copy or split the slide before shrinking type.','imageCrop':'Keep the subject and evidence legible; align crop ratios for peer images.','avoid':avoid},'recommendedLayoutFamilies':[k for k,_ in common],'doNotReuseOriginalTextOrAssets':True}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('source',type=Path);ap.add_argument('--threshold',type=float,default=1.05);args=ap.parse_args()
    source=args.source.resolve();files=sorted(source.glob('*.pptx'))
    if not files:raise ValueError('No PPTX files in '+str(source))
    local=ROOT/'.local/corpus';items=[];failures=[]
    for n,ppt in enumerate(files,1):
        sha=hashlib.sha256(ppt.read_bytes()).hexdigest();folder=local/sha[:16]
        try:
            report=extract(ppt,folder,False);e=json.loads((folder/'evidence.json').read_text(encoding='utf-8'));f=features(e)
            layout=Counter()
            for page in e['pages']:
                im=sum(o['type']=='image' for o in page['objects']);tx=sum(o['type']=='text' for o in page['objects'])
                layout['visual-led' if not tx and im else 'image-text' if im and tx else 'text-led' if tx else 'shape-led']+=1
            items.append({'sha256':sha,'sourceName':ppt.name,'relativeSource':ppt.name,'pages':report['pages'],'objects':report['objects'],'features':f,'layoutKinds':[{'shape':k,'pages':v} for k,v in layout.most_common(4)],'localEvidence':str(folder.relative_to(ROOT))})
        except Exception as ex:failures.append({'file':ppt.name,'error':str(ex)})
        if n%10==0:print('Processed %d / %d presentations'%(n,len(files)),flush=True)
    groups=assign(items,args.threshold);out=ROOT/'styles/corpus';out.mkdir(parents=True,exist_ok=True);summary=[];index_rows=[]
    for index,g in enumerate(groups,1):
        slug='aesthetic-%02d'%index;folder=out/slug;folder.mkdir(parents=True,exist_ok=True);f=g['centroid'];art=guide(g,index)
        fills=Counter(v['primary'] for v in [x['features'] for x in g['items']]);primary=fills.most_common(1)[0][0]
        theme={'schemaVersion':'2.0','id':slug,'colors':{'primary':primary,'accent':'#D7AD45' if f['tone']=='light' else '#2EC7D6','background':'#111C32' if f['tone']=='dark' else '#F7F9FC','surface':'#1D2B46' if f['tone']=='dark' else '#FFFFFF','text':'#F2F6FB' if f['tone']=='dark' else '#172B3A','muted':'#B5C4D9' if f['tone']=='dark' else '#536777'},'fonts':{'body':f['font'] if f['font']!='unspecified' else 'Microsoft YaHei','fallback':'Arial'},'typography':{'title':44,'body':25,'caption':17},'provenance':{'palette':'frequency from parsed slide-shape fills; adjusted for stated aesthetic family','background':'structure-derived dark/light classification; review needed','font':'most frequent explicit/resolved run font, not proof it exists on destination system'},'canvas':[1280,720]}
        dump(folder/'theme.json',theme);(folder/'theme.css').write_text(theme_css(theme),encoding='utf-8')
        layouts=json.loads(json.dumps(DEFAULT_LAYOUTS));layouts['layouts'].append({'id':'corpus-split','kind':'split','visualSide':'right','visualFraction':.55 if f['imageMode']=='image-led' else .46 if f['imageMode']=='balanced' else .38,'maxBodyItems':4,'purpose':'主张加图像或证据','assetRoles':art['assetClaimMapping'],'compositionRule':art['compositionRules'][1],'attentionPath':art['attentionPath'],'avoid':art['aestheticConstraints']['avoid'],'status':'measured-group-candidate'})
        dump(folder/'layouts.json',layouts);dump(folder/'design-language.json',art);dump(folder/'recipes.json',{'schemaVersion':'2.0','rules':art['compositionRules'],'assetRoles':art['assetClaimMapping'],'attentionPath':art['attentionPath']})
        files_out=[{'sourceSha256':x['sha256'],'pageCount':x['pages'],'objectCount':x['objects'],'features':x['features'],'localEvidence':x['localEvidence']} for x in g['items']]
        dump(folder/'provenance.json',files_out)
        dump(folder/'manifest.json',{'schemaVersion':'2.0','version':'0.3.0','id':slug,'groupStatus':art['status'],'sourceCount':len(g['items']),'visualReview':'pending','requiresVisualReview':True,'sourceNamesOmittedFromPortablePack':True})
        (folder/'style.md').write_text('# '+slug+' · '+f['tone']+' / '+f['paletteFamily']+'\n\n'+art['designIntent']+'\n\n## 内容与展示的搭配\n\n'+art['compositionRules'][1]+'\n\n## 审美约束与反例\n\n'+art['aestheticConstraints']['avoid']+'\n\n## 审阅状态\n\n本组来自结构统计，风格属性尚未对本组每份演示逐页人工审阅。确认布局用途、素材语义和受众适配后，才能将待审规则标为成熟规范。详见 design-language.json 和 provenance.json。\n',encoding='utf-8')
        summary.append({'id':slug,'count':len(g['items']),'tone':f['tone'],'paletteFamily':f['paletteFamily'],'imageMode':f['imageMode'],'commonPageStructures':art['recommendedLayoutFamilies'],'stylePath':'styles/corpus/'+slug})
        label={'dark':'深色','light':'浅色'}[f['tone']]+'·'+{'blue-cyan':'蓝青科技','green-teal':'绿青自然','red-orange':'红橙强调','warm-gold':'暖金商务','violet':'紫色表现','neutral':'中性'}[f['paletteFamily']]+'·'+{'image-led':'图片主导','balanced':'图文平衡','text-led':'文字主导'}[f['imageMode']]
        index_rows.append('| %s | %d | %s | %s | %s | `%s` |'%(slug,len(g['items']),f['tone'],f['paletteFamily'],f['imageMode'],label))
    public=[{'sha256':x['sha256'],'pages':x['pages'],'objects':x['objects'],'features':x['features'],'group':next('aesthetic-%02d'%(i+1) for i,g in enumerate(groups) if x in g['items'])} for x in items]
    dump(ROOT/'reports/corpus-curation.json',{'sourceDirectoryName':source.name,'pptxCount':len(files),'processedCount':len(items),'failedCount':len(failures),'groups':summary,'presentations':public,'failures':[{'error':x['error']} for x in failures]})
    dump(ROOT/'.local/corpus/failures.json',failures)
    (out/'INDEX.md').write_text('# 68 份 PPT 的设计风格分组\n\n按底色明暗、主色系、图文比例和信息密度得到 '+str(len(groups))+' 个结构候选，失败 '+str(len(failures))+' 份。小样本组属于风格候选，适合作为局部灵感；不能当作验证充分的通用规范。源文件名和绝对路径只保存在本机 `.local/corpus` 中。\n\n| 组 | 文件数 | 明暗 | 色系 | 图文分布 | 浏览标签 |\n| --- | ---: | --- | --- | --- | --- |\n'+'\n'.join(index_rows)+'\n\n## 排版与内容的搭配\n\n- 图片主导：让一张主视觉建立语境，邻近文字明确说出图片在解释、举证还是对比。整页位图只能做视觉参考，不能据此恢复内部文字。\n- 图文平衡：素材必须有明确论证角色，图注与其支持的主张相邻；同类图片才使用等高图片组。\n- 文字主导：用留白划分结论与证据，信息超过布局容量时拆分页面。\n- 深色底用亮色强调一个重点；浅色底靠稳定的对齐边和单一强调色分层。色彩是结构派生的候选值，需按企业品牌和投影效果校正。\n- 各组 `design-language.json` 记录视线路径、素材论证角色、适用条件和失败模式；`layouts.json` 提供一个 `corpus-split` 可调用布局。\n\n自动分类没有逐页理解图片内涵。每个组需要审阅代表页后，才能从候选规则升级为公司规范。\n',encoding='utf-8')
    print(json.dumps({'presentations':len(items),'groups':len(groups),'failures':len(failures),'groupsSummary':summary},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
