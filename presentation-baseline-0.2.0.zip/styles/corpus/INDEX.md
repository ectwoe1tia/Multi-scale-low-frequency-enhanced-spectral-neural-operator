# 68 份 PPT 的设计风格分组

按底色明暗、主色系、图文比例和信息密度得到 12 个结构候选，失败 0 份。小样本组属于风格候选，适合作为局部灵感；不能当作验证充分的通用规范。源文件名和绝对路径只保存在本机 `.local/corpus` 中。

| 组 | 文件数 | 明暗 | 色系 | 图文分布 | 浏览标签 |
| --- | ---: | --- | --- | --- | --- |
| aesthetic-01 | 38 | dark | blue-cyan | image-led | `深色·蓝青科技·图片主导` |
| aesthetic-02 | 1 | dark | blue-cyan | balanced | `深色·蓝青科技·图文平衡` |
| aesthetic-03 | 3 | dark | red-orange | balanced | `深色·红橙强调·图文平衡` |
| aesthetic-04 | 1 | dark | red-orange | image-led | `深色·红橙强调·图片主导` |
| aesthetic-05 | 10 | light | blue-cyan | text-led | `浅色·蓝青科技·文字主导` |
| aesthetic-06 | 5 | light | blue-cyan | balanced | `浅色·蓝青科技·图文平衡` |
| aesthetic-07 | 1 | light | blue-cyan | balanced | `浅色·蓝青科技·图文平衡` |
| aesthetic-08 | 1 | light | blue-cyan | balanced | `浅色·蓝青科技·图文平衡` |
| aesthetic-09 | 5 | light | red-orange | balanced | `浅色·红橙强调·图文平衡` |
| aesthetic-10 | 1 | light | red-orange | balanced | `浅色·红橙强调·图文平衡` |
| aesthetic-11 | 1 | light | red-orange | balanced | `浅色·红橙强调·图文平衡` |
| aesthetic-12 | 1 | light | violet | balanced | `浅色·紫色表现·图文平衡` |

## 排版与内容的搭配

- 图片主导：让一张主视觉建立语境，邻近文字明确说出图片在解释、举证还是对比。整页位图只能做视觉参考，不能据此恢复内部文字。
- 图文平衡：素材必须有明确论证角色，图注与其支持的主张相邻；同类图片才使用等高图片组。
- 文字主导：用留白划分结论与证据，信息超过布局容量时拆分页面。
- 深色底用亮色强调一个重点；浅色底靠稳定的对齐边和单一强调色分层。色彩是结构派生的候选值，需按企业品牌和投影效果校正。
- 各组 `design-language.json` 记录视线路径、素材论证角色、适用条件和失败模式；`layouts.json` 提供一个 `corpus-split` 可调用布局。

自动分类没有逐页理解图片内涵。每个组需要审阅代表页后，才能从候选规则升级为公司规范。
