# aesthetic-04 · dark / red-orange

Dark field separates product imagery or technical diagrams from surrounding copy and concentrates attention.

## 内容与展示的搭配

Let one large visual carry context, then pair it with a short explicit claim. For a full-page bitmap, treat this as a visual reference only; do not infer its internal layout.

## 审美约束与反例

Do not place a small new title over a dense screenshot or treat a complete source slide image as an editable picture layout.

## 审阅状态

本组来自结构统计，风格属性尚未对本组每份演示逐页人工审阅。确认布局用途、素材语义和受众适配后，才能将待审规则标为成熟规范。详见 design-language.json 和 provenance.json。
