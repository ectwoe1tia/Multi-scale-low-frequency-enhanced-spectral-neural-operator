# aesthetic-06 · light / blue-cyan

Light space supports document evidence, readable explanations, and labels without competing with small visuals.

## 内容与展示的搭配

Assign each visual one role: explain a mechanism, prove a result, compare alternatives, or establish context. Put its label adjacent to the relevant image.

## 审美约束与反例

Avoid an image gallery without a shared question and captions that state no relationship to the main claim.

## 审阅状态

本组来自结构统计，风格属性尚未对本组每份演示逐页人工审阅。确认布局用途、素材语义和受众适配后，才能将待审规则标为成熟规范。详见 design-language.json 和 provenance.json。
