---
name: presentation-rebuild
description: Rebuild an HTML presentation from a portable PPT style pack and structured content; prepare a PPTX export through an editable HTML exporter.
---

# Presentation rebuild

Read the pack's `design-language.json` before choosing a layout. Choose it by communication goal and audience, not by page appearance alone. State which material supports the page's claim, which role it plays, and the intended attention path. Follow the layout's required slots and failure modes. Use `python tools/pipeline.py rebuild <style-dir> <deck.json> <output-dir>`; the runtime composes Vue components using the chosen layout parameters and emits HTML. Run `python tools/pipeline.py export <html> <file.pptx> --engine native` for a deterministic editable subset, or `--engine browser` on a host that permits Chrome/Edge. The bundled runtime is Vue 2.6.12 for offline operation; `npm install` installs Vue 3.5.13. Check the report for the exact renderer. Browser-measured export represents text by measured lines. Labels, bars, rectangles, and images are editable objects; charts are not yet native data charts. Use PPTWork visual-review/export guidance as a workflow reference; this package does not vendor its private exporter.
