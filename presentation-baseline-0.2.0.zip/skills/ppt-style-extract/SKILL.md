---
name: ppt-style-extract
description: Extract reusable layout, theme, and image-text relationships from local PPTX examples into a compact portable style pack.
---

# PPT style extraction

Use `python tools/pipeline.py extract <source.pptx|directory> <output-dir>` from project root. Source is read only. It writes local OOXML evidence and a portable candidate pack. The extractor classifies image area and nearby text only: retain that as geometry evidence, never as an interpretation of meaning. Review representative pages, then record each asset's rhetorical role, claim supported, attention path, crop, replacement guidance, failure modes, and evidence slide in `design-language.json` and `visual-review.json`. Turn repeated compositions into layout grammar: when to use them, how the eye moves, required slots, and when not to use them. Preserve uncertainty, source hashes, and evidence links. Keep original artwork and private text local unless selected for transfer. See `ARCHITECTURE.md` for parsing limits.

Inspired by [PPTWork](https://github.com/JunfengRan/PPTWork) for HTML-first delivery and [python-pptx](https://python-pptx.readthedocs.io/en/latest/) for structural extraction. This first implementation uses Python's standard-library OOXML parser and is not a full PowerPoint renderer.
