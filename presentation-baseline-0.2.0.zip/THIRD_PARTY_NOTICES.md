# Third-party notices

- Vue 2.6.12 offline production runtime, `vendor/vue/vue.min.js`: MIT, © 2014–2020 Evan You; license at `vendor/vue/LICENSE.txt`. It is retained only for offline compatibility. `package.json` installs Vue 3.5.13 for the modern runtime.
- PPTWork `parseArgs` function adaptation, `vendor/pptwork/parse-args.mjs`: MIT, © 2026 Junfeng Ran; source workflow https://github.com/JunfengRan/PPTWork; license at `vendor/pptwork/LICENSE.txt`.
- System fonts are referenced by family name and are not redistributed.
- Source PPT images are not included in portable style packs. `visual-review.json` records design observations and source-page evidence.
