# 严格扩展规定

## 版本

发布版本 runtime.VERSION 当前 2.2.0；工具协议、adapter、plan、result 均 1.0；suite 沿用 1.0。资料接入契约见 intake.md，文件会话契约见 file-workflow.md，版本均 1.0。既有手工 adapter 仍支持；provenance 与 operation.request_guards 为可选扩展。

- 不改变外部契约的修复升 patch；兼容的新能力升 minor。
- 字段、默认值、断言语义、退出码、重试语义的破坏性变化必须升主版本/协议，提供迁移和旧输入拒绝行为。
- 未知字段/工具/操作符始终拒绝。新增项同时更新运行时校验、describe Schema（涉及工具参数时）、文档、例子、测试。
- 项目 Skill 复制确定版本，不自动追随主 Skill。升级比较差异，保留项目基线与妥协，重新验证，不覆盖整个旧目录。

## 扩展位置

| 需求 | 首选位置 | 必须证明 |
|---|---|---|
| 新平台 HTTP 接入 | adapter + plan | 真实端点、角色、正反例、业务与目标节点断言 |
| 接口文档格式 | capabilities.py 的发现层 | 原始方法/路径/位置、稳定 ID、不支持格式可见，不执行示例 |
| 项目规约 | policy + capabilities.py | deny 优先、角色交集、所有约束累积、来源漂移和动态变量无法绕过 |
| Word/PDF 等资料 | intake.py | 提取位置、缺口、冲突、不可读页，不将观察当作预期 |
| 开发者工具记录 | trace_tools.py | 凭据处理、同源匹配、显式新数据和断言、历史 ID 不隐式重放 |
| 新认证 | 独立认证适配逻辑 | 秘密不进 argv/报告，刷新失败可见，不重放写请求 |
| 新断言 | 具名确定性操作符 | 缺失/null/类型和反例；不允许 eval 或任意表达式 |
| 浏览器 | 独立受限 adapter，沿用结果契约 | 真实定位器、身份隔离、证据、有界等待 |
| Flowable 模型测试 | 固定版本 JVM 桥接或业务 API | 并行/多实例/子流程/异步，不绕过应用权限冒充端到端 |
| 局部节点准备 | 单独 fixture 工具与结果模式 | 与 replay 分开，不计前序覆盖，不直接改引擎表 |
| MCP | 调用同一个 dispatch 的薄封装 | 相同 schema/错误/工作区限制，无任意 shell |

没有 run_shell、动态 Python/PowerShell、直接 SQL、任意 curl options 或任意 URL 执行工具。确需能力就增加具名动作及验证，不建立万能执行口。

## 扩展完成条件

1. 变更单说明触发需求、证据、范围、契约、兼容性、回滚。
2. 获得租约，保留业务断言和历史记录。
3. 添加正例、相关反例和副作用边界测试；HTTP 变化需实际 loopback 测试，不仅 mock。
4. 原有测试通过：`python -X utf8 -m unittest discover -s tests -v`。有可用 Skill 校验器则运行；没有则明确未做。
5. 文档、示例、导出 Schema 与程序同步；生成项目 Skill 包含运行依赖。
6. 至少一次本地 demo，或用证据说明该变化不影响执行链。演示通过不算真实平台验证。
7. 检查脱敏、输出范围、拒绝覆盖、无隐式写重试、原始失败不变。不得修改宿主 sandbox 或全局执行策略。
8. 交接实际日志、版本、完成与未完成项；独立复核缺失时保持 pending。

资料接入的新输入契约同时导出 describe.data.intake_schema 与 assets/intake.schema.json。变更字段须同步 intake_schema.py、运行时、例子与行为测试。文件会话的命名输入模式独立导出 describe.data.file_workflow_schema 与 assets/file-workflow.schema.json，保留资料接入契约不变。Apifox 新布局先提供 fixture，不退化成任意文本 URL 扫描。不得为兼容 HAR 自行加入 Cookie/JS/shell 执行入口。fixture 使用合成或已授权且脱敏的资料，不提交真实账号和客户记录。

这些条件用于修改共享 Skill/执行器，不要求普通需求分析反复审批。已有授权不重复确认，业务歧义与环境权限问题分开说明。

## MCP 实现纲要

本包未实现 MCP server。若宿主只支持 MCP，使用其支持版本的官方 SDK，把固定工具映射到同一个 toolchain.dispatch；工作区在启动时固定，模型不能扩大。stdout 只走协议，错误保持结构化 code 与证据路径。分别标注只读工具与 run/claim/release 的副作用。

不要在 MCP 内复制业务判定，不把调用失败当作请求未提交。测试初始化、schema、错误、取消、进程中断、重复调用。固定协议版本并与宿主测试，不能将某版最小 stdio 实现宣称支持所有客户端。
