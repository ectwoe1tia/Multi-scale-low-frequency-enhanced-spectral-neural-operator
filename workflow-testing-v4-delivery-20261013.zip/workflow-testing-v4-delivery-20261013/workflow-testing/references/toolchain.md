# 固定工具调用协议 1.0

## 入口

本版采用 Skill + PowerShell + Python + curl CLI。HTTP、DOCX 和 Markdown 工具只用标准库；PDF 提取需 pypdf 或已有 PyPDF2。模型只写 JSON 数据；PowerShell 只传递路径，Python 验证后通过参数数组调用真实 curl.exe（Windows）或 curl。没有 MCP 服务进程；后续可按扩展文档增加薄封装。

在项目工作区保存 `requests/doctor.json`：

```json
{"protocol_version":"1.0","tool":"doctor","arguments":{}}
```

Windows 固定命令，只替换路径：

```powershell
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "C:\path\workflow-testing\scripts\Invoke-WorkflowTool.ps1" -Workspace "C:\path\my-project" -Request "C:\path\my-project\requests\doctor.json"
```

RemoteSigned 仅针对本次进程，不修改全局策略，不提升账户权限；组织策略仍可能阻止执行。直接 Python 等效入口：

```powershell
python -X utf8 "C:\path\workflow-testing\scripts\toolchain.py" --workspace "C:\path\my-project" --request "C:\path\my-project\requests\doctor.json"
```

请求文件须在工作区内。JSON 文件参数全为 Workspace 相对路径；不允许越界路径、重复 JSON 键、未知工具/字段。不在 JSON 中填写密码、令牌或 shell 命令。

## 工具目录

| tool | arguments 必填项 | 作用 |
|---|---|---|
| describe | 无 | 返回本版本工具 JSON Schema、顺序和退出码 |
| doctor | 无 | 验证 Python/curl/目录写入，不测试远端网络 |
| api_discover | source, out | 从 Apifox Markdown 识别能力及来源，不联网 |
| adapter_build | catalog, policy, out | 生成受项目规约约束的 adapter 与筛选明细 |
| document_import | source, out | 导入 DOCX/PDF/Markdown/TXT 证据 |
| cases_build | manifest, out | 汇总已写用例、缺口和同名冲突；模型继续语义分析 |
| trace_import | source, out | 导入 HAR/Recorder 观察记录 |
| trace_match | trace, adapter, out | 匹配同源且已允许的 HTTP 能力 |
| plan_from_trace | suite, adapter, trace, binding, out | 结合文档预期与新数据生成执行计划 |
| suite_validate | suite | 校验需求资产，不执行测试 |
| suite_render | suite, out | 在新目录导出设计报告和 CSV |
| skill_build | suite, out, name | 生成自包含项目 Skill |
| plan_validate | suite, adapter, plan | 校验配置、角色、变量和断言，不联网 |
| plan_preview | suite, adapter, plan | 返回步骤摘要及 fingerprint，不联网 |
| run | suite, adapter, plan, expected_fingerprint, run_id | 执行预览过的 HTTP 测试 |
| report | run_id, out | 从完整且校验和一致的结果导出 Markdown |
| snapshot | files | 返回文件 SHA-256 基线 |
| claim | owner, change_id, base_hashes | 取得唯一编辑租约 |
| release | lease_token | 仅正确令牌持有者释放租约 |

无可选扩展参数。describe 的输出是机器契约，`assets/tool-request.schema.json` 是由程序导出的副本。Schema 不能替代跨文件引用检查。

资料接入契约和逐步说明见 [intake.md](intake.md)。`describe.data.intake_schema` 同步导出为 `assets/intake.schema.json`。自动生成 adapter 后，不直接编辑生成物：修改来源或 policy，再生成到新目录。

预览请求：

```json
{"protocol_version":"1.0","tool":"plan_preview","arguments":{"suite":"suite.json","adapter":"adapter.json","plan":"plan.json"}}
```

取返回的 data.fingerprint，生成执行请求：

```json
{"protocol_version":"1.0","tool":"run","arguments":{"suite":"suite.json","adapter":"adapter.json","plan":"plan.json","expected_fingerprint":"替换为预览返回的64位哈希","run_id":"RUN-20261007-001"}}
```

fingerprint 不是批准或权限凭据；它证明 suite/adapter/plan 和执行器版本与预览一致。输入变化必须重新预览。

## 返回与后续动作

stdout 只有一个 JSON 对象：protocol_version、tool、ok、code、message、data。读取 `$LASTEXITCODE` 或 returncode，同时检查 code/data。不要从自然语言猜状态。

| code | 退出码 | 下一步 |
|---|---|---|
| OK | 0 | 读 data 后进入下一步；资产检查 OK 不等于业务通过 |
| TEST_FAILED | 10 | 报告失败，不改断言、不自动重跑 |
| EXECUTION_ERROR | 11 | 可能已提交副作用，核对证据及服务端状态，不自动重发 |
| ENVIRONMENT_ERROR / PERMISSION_DENIED | 12 | 说明环境缺口；执行模型不自行改权限或绕过限制 |
| CHANGE_CONFLICT | 20 | 重读基线并重做变更，不覆盖他人修改 |
| LEASE_BUSY | 21 | 等持有者释放，不删锁或冒用令牌 |
| RUN_EXISTS | 22 | 读旧结果，不仅改运行 ID 来绕过保护 |
| STALE_PLAN | 2 | 尚未联网，重新预览 |
| STALE_SOURCE | 2 | 原始文档、catalog 或 policy 变化；重新导入/生成 |
| POLICY_DENIED | 2 或 run 内 11 | 查输入及证据；较早步骤可能已提交，不能放宽约束绕过 |
| NO_CAPABILITIES / CAPABILITY_MISMATCH | 2 | 查文档识别、规约筛选、origin 与端点匹配 |
| DEPENDENCY_MISSING | 2 | doctor 查看 PDF 后端；补项目依赖或继续其他格式 |
| UNSUPPORTED_FORMAT / DOCUMENT_READ_ERROR / DOCUMENT_LOCKED / UNSUPPORTED_TRACE_ENTRY | 2 | 处理格式、解锁副本或未支持记录；不假称已读取 |
| NEEDS_CLARIFICATION | 2 | 澄清业务，继续设计无关场景 |
| INVALID_INPUT / OUTPUT_EXISTS | 2 | 修正数据或新建输出位置，不改验证器 |
| EVIDENCE_CHANGED | 2 | 结果变动或运行未完成，保留证据并调查 |

status 是原始 PASS/FAIL/ERROR，gate 是 PASS/ALLOWED_WITH_GAPS/BLOCKED。有效豁免不会把原始 FAIL 改为 PASS，也不会使退出码自动变零。CI 如需依据 gate 决策，须显式读取；不得把所有 exit 10 放行。

## 证据和边界

`runs/<run_id>/results.json` 保存时间、环境、指纹、发送意图、响应、断言、失败特征、变量、未执行步骤和未选用例。完成时生成 results.sha256。SENDING 残留意味着结果未知，不能推定请求未提交。

常规执行输入和单响应上限 1 MiB，运行证据上限 16 MiB；新文档/HAR 输入 32 MiB，Markdown 能力文档 8 MiB，中间 JSON 最大 16 MiB，PDF 最多 500 页。生成的 suite/adapter/plan 仍须满足执行输入限制，超限按模块拆分。超限停止，保留此前检查点。认证从环境变量取值，经 curl stdin 传入；不放入进程参数。按秘密字段名和已知值脱敏仍不能识别所有业务敏感信息，接口应减少无关返回内容。

curl 调用设置超时、禁用默认配置、禁用跳转，不自动重试写请求，不自动使用环境代理。企业代理、证书、上传、OAuth 刷新要经扩展流程实现，不能临时加 flags。参照 [curl 官方文档](https://curl.se/docs/manpage.html)。

## v4 文件会话扩展

runner 2.2.0 保留原工具，新增注册工具 request_compose、flow_init/prepare/execute/status/focus/note/reconcile/cancel/report。详细参数与文件契约见 [file-workflow.md](file-workflow.md)。CLI 新增 --response-file 和 --brief；建议把完整 describe/schema 保存文件，按需读取。新版 schema 同步导出至 assets/tool-request.schema.json。
