"""Published JSON schemas for new author-written intake contracts."""


def schema():
    text = {'type': 'string', 'minLength': 1}
    strings = {'type': 'array', 'minItems': 1, 'uniqueItems': True, 'items': text}
    def obj(properties, optional=()):
        return {'type': 'object', 'additionalProperties': False,
                'required': [key for key in properties if key not in optional], 'properties': properties}
    def arr(items, minimum=0, maximum=10000):
        return {'type': 'array', 'minItems': minimum, 'maxItems': maximum, 'items': items}
    guard_base = {'target': {'enum': ['params', 'query', 'body']}, 'pointer': {'type': 'string', 'pattern': r'^(?:/(?:[^~]|~[01])*)?$'}}
    guard = {'oneOf': [obj({**guard_base, 'op': {'const': 'eq'}, 'expected': {}}),
                       obj({**guard_base, 'op': {'const': 'in'}, 'expected': arr({}, 1)}),
                       obj({**guard_base, 'op': {'enum': ['exists', 'not_exists']}})]}
    selector = {'methods': {'type': 'array', 'minItems': 1, 'uniqueItems': True, 'items': {'enum': ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'TRACE', 'CONNECT']}},
                'path_prefix': {'type': 'string', 'pattern': '^/'}}
    actor = obj({'bearer_token_env': {'type': 'string', 'pattern': r'^(?:[A-Za-z_][A-Za-z0-9_]*)?$'}})
    policy = obj({'policy_version': {'const': '1.0'}, 'adapter_id': text, 'platform': {'enum': ['lowcode', 'flowable', 'custom']},
                  'base_url': text, 'environment': obj({'name': text, 'kind': {'enum': ['local', 'test', 'uat']}, 'release': text}),
                  'allow_mutations': {'type': 'boolean'}, 'timeout_seconds': {'type': 'number', 'minimum': 1, 'maximum': 30},
                  'max_duration_seconds': {'type': 'number', 'minimum': 1, 'maximum': 300},
                  'actors': {'type': 'object', 'minProperties': 1, 'additionalProperties': actor},
                  'allow': arr(obj({**selector, 'actors': strings, 'request_guards': arr(guard, 0, 100)}), 1),
                  'deny': arr(obj(selector)), 'idempotency_header': text}, ['idempotency_header'])
    check = obj({'id': text, 'pointer': {'type': 'string'}, 'op': {'enum': ['eq', 'ne', 'contains', 'exists', 'not_exists', 'gt', 'gte', 'lt', 'lte']},
                 'expected': {}, 'assertion_id': text}, ['expected', 'assertion_id'])
    step = obj({'entry_id': text, 'actor': text, 'params': {'type': 'object'}, 'query': {'type': 'object'}, 'body': {},
                'capture': {'type': 'object', 'additionalProperties': {'type': 'string'}}, 'checks': arr(check, 1),
                'operation': text, 'poll': obj({'attempts': {'type': 'integer', 'minimum': 1, 'maximum': 20},
                                             'interval_seconds': {'type': 'number', 'minimum': 0.05, 'maximum': 5}})}, ['operation', 'poll'])
    binding = obj({'binding_version': {'const': '1.0'}, 'plan_id': text,
                   'cases': arr(obj({'case_id': text, 'vars': {'type': 'object'}, 'steps': arr(step, 1, 40)}), 1, 100)})
    manifest = obj({'project': text, 'platform': {'enum': ['unknown', 'mixed', 'lowcode', 'flowable', 'custom']},
                    'documents': arr(obj({'document': text, 'role': {'enum': ['requirements', 'test_cases']}}), 1, 30)})
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema',
            '$comment': 'Select #/$defs/policy, manifest or binding. Runtime additionally checks sources, origins, references, guards, variables and assertions.',
            '$defs': {'policy': policy, 'manifest': manifest, 'binding': binding}}
