"""Apifox Markdown discovery and deterministic project capability compilation."""
import hashlib
import re
from pathlib import Path
from urllib.parse import urlsplit

import http_runner as rt

METHODS = ('GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'TRACE', 'CONNECT')
METHOD_RE = '|'.join(METHODS)


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    path = Path(path)
    encoded = rt.canonical(value)
    rt.need(len(encoded.encode('utf-8')) <= 16 * rt.MAX_BYTES, 'Generated document exceeds 16 MiB')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as handle:
        import json
        handle.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def operation_id(method, path):
    slug = re.sub(r'[^a-z0-9]+', '_', path.lower()).strip('_')[:42] or 'root'
    return method.lower() + '_' + slug + '_' + rt.digest([method, path])[:10]


def check_path(path):
    rt.text(path, 'path')
    rt.need(path.startswith('/') and not path.startswith('//'), 'Path must be relative to an origin')
    rt.need(not any(c in path for c in ('?', '#', '\\', '%')) and not any(c.isspace() or ord(c) < 32 for c in path), 'Unsupported path characters')
    rt.need('..' not in path.split('/'), 'Parent path components are forbidden')
    names = re.findall(r'\{([A-Za-z][A-Za-z0-9_-]*)\}', path)
    rest = re.sub(r'\{[A-Za-z][A-Za-z0-9_-]*\}', '', path)
    rt.need('{' not in rest and '}' not in rest and len(names) == len(set(names)), 'Unsupported path parameters')
    return path


def endpoint(method, target):
    target = target.strip().strip('`')
    parsed = urlsplit(target)
    if parsed.scheme:
        rt.need(parsed.scheme in ('http', 'https') and parsed.hostname and not parsed.username and not parsed.password, 'Invalid absolute endpoint')
        path, origin = parsed.path or '/', parsed.scheme + '://' + parsed.netloc
    else:
        path, origin = target.split('?', 1)[0].split('#', 1)[0], ''
    check_path(path)
    rt.need(method in METHODS, 'Unknown HTTP method')
    return path, origin


def discover(markdown, relative):
    path = Path(markdown)
    rt.need(path.stat().st_size <= 8 * rt.MAX_BYTES, 'Markdown exceeds 8 MiB')
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    operations, issues = {}, []
    heading, pending_method, pending_path, fence = '', None, None, None
    active, section = None, ''
    # Deliberately ignore code samples. They describe examples, not declarations.
    for lineno, raw in enumerate(lines, 1):
        stripped = raw.strip()
        if re.match(r'^(`{3,}|~{3,})', stripped):
            marker = stripped[0]
            if fence is None:
                fence = marker
            elif fence == marker:
                fence = None
            continue
        if fence:
            continue
        text = re.sub(r'[*`]', '', stripped).lstrip('> ').strip()
        header = re.match(r'^(#{1,6})\s+(.+)', text)
        if header:
            section = header[2]
            subsection = re.search(r'请求参数|返回结果|响应参数|请求体|响应体|返回数据|请求示例|响应示例|Request|Response|Parameters', header[2], re.I)
            if len(header[1]) <= 2 and not subsection:
                heading = header[2]
                active = None
                pending_method = pending_path = None
            text = header[2]
        # Common Apifox export: '# POST title' then a separate 'POST /path'.
        direct = re.match(r'^(' + METHOD_RE + r')\s+((?:https?://|/)[^\s]+)(?:\s+HTTP/\d(?:\.\d)?)?$', text, re.I)
        method_line = re.match(r'^(?:请求方式|请求方法|请求类型|Method)\s*[:：]\s*(' + METHOD_RE + r')$', text, re.I)
        path_line = re.match(r'^(?:请求地址|请求路径|接口地址|URL|Path)\s*[:：]\s*(\S+)$', text, re.I)
        if text.startswith('|'):
            cells = [c.strip() for c in text.strip('|').split('|')]
            if len(cells) == 2:
                method_line = method_line or re.match(r'^(?:请求方式|请求方法|请求类型|Method)\s*[:：]\s*(' + METHOD_RE + r')$', cells[0] + ':' + cells[1], re.I)
                path_line = path_line or re.match(r'^(?:请求地址|请求路径|接口地址|URL|Path)\s*[:：]\s*(\S+)$', cells[0] + ':' + cells[1], re.I)
        if method_line:
            pending_method = (method_line[1].upper(), lineno)
        if path_line:
            pending_path = (path_line[1], lineno)
        pair = None
        if direct:
            pair = (direct[1].upper(), direct[2], lineno)
        elif pending_method and pending_path:
            pair = (pending_method[0], pending_path[0], min(pending_method[1], pending_path[1]))
            pending_method = pending_path = None
        if pair:
            method, target, start = pair
            try:
                urlpath, origin = endpoint(method, target)
            except (rt.ToolError, ValueError):
                issues.append({'code': 'UNSUPPORTED_ENDPOINT', 'line': start, 'message': 'Endpoint could not be normalized; inspect source line'})
                active = None
                continue
            oid = operation_id(method, urlpath)
            evidence = {'source': relative, 'line': start, 'text': method + ' ' + urlpath}
            if oid not in operations:
                operations[oid] = {'id': oid, 'method': method, 'path': urlpath, 'title': heading or method + ' ' + urlpath,
                                   'origins': [], 'evidence': [], 'parameters': [], 'response_statuses': [],
                                   'status': 'discovered' if method not in ('OPTIONS', 'TRACE', 'CONNECT') else 'unsupported'}
            active = operations[oid]
            if origin and origin not in active['origins']:
                active['origins'].append(origin)
            active['evidence'].append(evidence)
            continue
        if active:
            status = re.search(r'(?:HTTP\s*状态码|状态码|Status(?:\s*Code)?)\s*[:：]?\s*([1-5]\d\d)', text, re.I)
            if status and int(status[1]) not in active['response_statuses']:
                active['response_statuses'].append(int(status[1]))
            if text.startswith('|'):
                cells = [c.strip() for c in text.strip('|').split('|')]
                if len(cells) >= 4 and cells[1].lower() in ('path', 'query', 'body', 'header', 'cookie'):
                    active['parameters'].append({'name': cells[0], 'in': cells[1].lower(), 'type': cells[2],
                                                 'required': cells[3].lower() in ('是', 'true', 'yes', 'required'), 'line': lineno})
    if pending_method or pending_path:
        issues.append({'code': 'INCOMPLETE_ENDPOINT', 'message': 'Method or URL is missing at end of document'})
    rt.need(operations, 'No declared endpoints recognized; inspect the export format', 'NO_CAPABILITIES')
    return {'catalog_version': '1.0', 'source': relative, 'source_sha256': file_hash(path),
            'operations': sorted(operations.values(), key=lambda x: x['id']), 'issues': issues,
            'semantics': 'Declared HTTP capabilities only; examples and observed responses are not business acceptance criteria.'}


def string_list(value, label, nonempty=True):
    rt.need(isinstance(value, list) and (bool(value) or not nonempty) and all(isinstance(v, str) and v for v in value), label + ': string array required')
    rt.need(len(value) == len(set(value)), label + ': duplicates')


def validate_guards(guards):
    rt.need(isinstance(guards, list) and len(guards) <= 100, 'request_guards: array of at most 100 rules required')
    for guard in guards:
        rt.shape(guard, ['target', 'pointer', 'op'], ['expected'], 'request guard')
        rt.need(guard['target'] in ('params', 'query', 'body'), 'Unknown guard target')
        ptr = guard['pointer']
        rt.need(isinstance(ptr, str) and (ptr == '' or ptr.startswith('/')) and not re.search(r'~(?![01])', ptr), 'Invalid guard pointer')
        rt.need(guard['op'] in ('eq', 'in', 'exists', 'not_exists'), 'Unsupported guard operator')
        if guard['op'] in ('eq', 'in'):
            rt.need('expected' in guard and not rt.refs(guard['expected']), 'Guard needs literal expected value')
            if guard['op'] == 'in':
                rt.need(isinstance(guard['expected'], list) and guard['expected'], 'in guard requires nonempty array')
        else:
            rt.need('expected' not in guard, 'Existence guard cannot have expected')


def enforce_guards(op, request, deferred=False):
    """Validate constants at preview and all substituted values immediately before transport."""
    for guard in op.get('request_guards', []):
        target = request[guard['target']]
        actual = rt.json_pointer(target, guard['pointer'])
        if deferred and ((actual is not rt.MISSING and rt.refs(actual)) or (actual is rt.MISSING and isinstance(target, str) and rt.refs(target))):
            continue
        operator = guard['op']
        if operator == 'in':
            ok = actual is not rt.MISSING and any(rt.canonical(actual) == rt.canonical(x) for x in guard['expected'])
        elif operator == 'eq':
            ok = actual is not rt.MISSING and rt.canonical(actual) == rt.canonical(guard['expected'])
        else:
            ok = (actual is not rt.MISSING) if operator == 'exists' else (actual is rt.MISSING)
        rt.need(ok, 'Project request guard rejected ' + guard['target'] + guard['pointer'], 'POLICY_DENIED')


def validate_catalog(catalog):
    rt.shape(catalog, ['catalog_version', 'source', 'source_sha256', 'operations', 'issues', 'semantics'], label='catalog')
    rt.need(catalog['catalog_version'] == '1.0', 'Unsupported catalog version')
    rt.need(isinstance(catalog['operations'], list) and 1 <= len(catalog['operations']) <= 10000, 'Invalid catalog operations')
    seen = set()
    for op in catalog['operations']:
        rt.shape(op, ['id', 'method', 'path', 'title', 'origins', 'evidence', 'parameters', 'response_statuses', 'status'], label='catalog operation')
        rt.need(op['method'] in METHODS, 'Invalid catalog method')
        check_path(op['path'])
        rt.need(op['id'] == operation_id(op['method'], op['path']) and op['id'] not in seen, 'Catalog ID mismatch or duplicate')
        seen.add(op['id'])
        rt.need(op['status'] in ('discovered', 'unsupported'), 'Invalid catalog status')


def validate_policy(policy):
    rt.shape(policy, ['policy_version', 'adapter_id', 'platform', 'base_url', 'environment', 'allow_mutations',
                      'timeout_seconds', 'max_duration_seconds', 'actors', 'allow', 'deny'], ['idempotency_header'], 'project policy')
    rt.need(policy['policy_version'] == '1.0', 'Unsupported policy version')
    rt.need(isinstance(policy['actors'], dict) and policy['actors'], 'Policy actors required')
    for kind in ('allow', 'deny'):
        rt.need(isinstance(policy[kind], list) and (policy[kind] or kind == 'deny'), kind + ': rules array required')
        for rule in policy[kind]:
            required = ['methods', 'path_prefix', 'actors', 'request_guards'] if kind == 'allow' else ['methods', 'path_prefix']
            rt.shape(rule, required, label=kind + ' rule')
            string_list(rule['methods'], 'rule.methods')
            rt.need(set(rule['methods']) <= set(METHODS), 'Unknown rule method')
            check_path(rule['path_prefix'])
            rt.need('{' not in rule['path_prefix'], 'Use literal path segment prefixes in policy')
            if kind == 'allow':
                string_list(rule['actors'], 'rule.actors')
                rt.need(set(rule['actors']) <= policy['actors'].keys(), 'Policy rule references an unknown actor')
                validate_guards(rule['request_guards'])


def matches(rule, op):
    prefix = rule['path_prefix'].rstrip('/')
    return op['method'] in rule['methods'] and (not prefix or op['path'] == prefix or op['path'].startswith(prefix + '/'))


def compile_adapter(catalog, policy):
    validate_catalog(catalog)
    validate_policy(policy)
    adapter = {k: v for k, v in policy.items() if k not in ('policy_version', 'allow', 'deny')}
    adapter['schema_version'] = '1.0'
    adapter['operations'] = {}
    decisions = []
    for op in catalog['operations']:
        allowed = [rule for rule in policy['allow'] if matches(rule, op)]
        denied = any(matches(rule, op) for rule in policy['deny'])
        reason = 'allowed'
        if op['status'] != 'discovered':
            reason = 'unsupported_method'
        elif denied:
            reason = 'denied_by_policy'
        elif not allowed:
            reason = 'outside_allow_rules'
        elif op['method'] not in rt.READ_METHODS and not policy['allow_mutations']:
            reason = 'mutations_disabled'
        if reason == 'allowed':
            # Overlapping rules only narrow: actor intersection, every guard applies.
            actors = set(allowed[0]['actors'])
            guards = []
            for rule in allowed:
                actors.intersection_update(rule['actors'])
                for guard in rule['request_guards']:
                    if guard not in guards:
                        guards.append(guard)
            if not actors:
                reason = 'empty_actor_intersection'
            else:
                adapter['operations'][op['id']] = {'method': op['method'], 'path': op['path'], 'actors': sorted(actors), 'request_guards': guards}
        decisions.append({'operation': op['id'], 'method': op['method'], 'path': op['path'], 'decision': reason, 'evidence': op['evidence']})
    rt.need(adapter['operations'], 'Policy leaves no executable capabilities', 'NO_CAPABILITIES')
    rt.validate_adapter(adapter)
    return adapter, decisions


def build_adapter(root, catalog_name, policy_name, out):
    catalog_path = rt.workspace_path(root, catalog_name, existing=True)
    policy_path = rt.workspace_path(root, policy_name, existing=True)
    catalog, policy = rt.read_json(catalog_path, 16 * rt.MAX_BYTES), rt.read_json(policy_path)
    verify_source(root, catalog)
    adapter, decisions = compile_adapter(catalog, policy)
    adapter['provenance'] = {'catalog': catalog_name, 'catalog_sha256': file_hash(catalog_path),
                             'policy': policy_name, 'policy_sha256': file_hash(policy_path)}
    target = rt.workspace_path(root, out)
    target.mkdir(parents=True, exist_ok=False)
    write_new(target / 'adapter.json', adapter)
    write_new(target / 'capability-decisions.json', {'decisions': decisions, 'network_executed': False})
    return {'adapter': out.replace('\\', '/').rstrip('/') + '/adapter.json', 'enabled': len(adapter['operations']),
            'excluded': len(decisions) - len(adapter['operations']), 'decisions': out.replace('\\', '/').rstrip('/') + '/capability-decisions.json'}


def verify_source(root, catalog):
    validate_catalog(catalog)
    source = rt.workspace_path(root, catalog['source'], existing=True)
    rt.need(file_hash(source) == catalog['source_sha256'], 'API Markdown changed; discover and build again', 'STALE_SOURCE')
    rt.need(rt.canonical(discover(source, catalog['source'])) == rt.canonical(catalog), 'Catalog differs from its source; rediscover', 'EVIDENCE_CHANGED')


def load_adapter(root, path):
    adapter = rt.read_json(path)
    if 'provenance' in adapter:
        provenance = adapter['provenance']
        rt.shape(provenance, ['catalog', 'catalog_sha256', 'policy', 'policy_sha256'], label='provenance')
        inputs = {}
        for key in ('catalog', 'policy'):
            source = rt.workspace_path(root, provenance[key], existing=True)
            rt.need(file_hash(source) == provenance[key + '_sha256'], key + ' changed; rebuild adapter', 'STALE_SOURCE')
            inputs[key] = rt.read_json(source, 16 * rt.MAX_BYTES)
        verify_source(root, inputs['catalog'])
        rebuilt, _ = compile_adapter(inputs['catalog'], inputs['policy'])
        rebuilt['provenance'] = provenance
        rt.need(rt.canonical(adapter) == rt.canonical(rebuilt), 'Generated adapter was edited outside the project policy; rebuild', 'POLICY_DENIED')
    rt.validate_adapter(adapter)
    return adapter
