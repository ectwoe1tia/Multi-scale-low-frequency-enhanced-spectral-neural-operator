# Workflow Testing v4：文件引用与可接续测试交付报告

本次在 2026-10-08 的 v3 工具包基础上独立实现 v4 交付，执行器版本为 **2.2.0**。原 v3 目录保留。目标是减少大模型在测试中搬运参数、读取大结果和依赖会话记忆的工作，保留已有业务断言、权限规约与执行保护。

## 实际完成

| 问题 | 实现 | 入口 |
|---|---|---|
| 参数/接口文档太大，反复粘贴 | `$file` 多级 JSON/文本引用、JSON Pointer 定位，由程序确定性展开 | request_compose；flow_prepare 内置展开 |
| 一次加载几十个 case | 初始计划拆成逐 case 文件，只准备当前 case；项目 Skill 生成小索引和单用例资料 | flow_init、flow_focus、skill_build |
| 工具全量返回占上下文 | 完整返回写文件，终端只显示结果码和路径；错误退出码保留 | `--response-file … --brief`，PowerShell 同等参数 |
| 反复执行造成重复审批 | 稳定 attempt/run_id、独占 intent、完成证据复用；不确定时阻断 | flow_execute、flow_reconcile |
| 已预览参数需要修正 | 仅取消未发送计划；取消与发送竞争同一独占槽位 | flow_cancel，再用明确 retry_note 准备新 attempt |
| 重复犯错、交接忘记下一步 | 经验摘要/下一步/证据引用，区分事实与假设；最多三条相关经验进入焦点 | flow_note、FOCUS.json |
| 额度耗尽或换模型 | 从真实证据重建统计和下一用例，不依赖旧聊天总结 | requests/status.json → NEXT.json / outline.json |
| 缺少历史报告 | 每个 attempt 独立保存，会话报告包含历次状态；旧失败不会改为通过 | flow_report |

实现位于 `workflow-testing/scripts/file_workflow.py`，复用原 `http_runner.py` 执行语义，未增加任意脚本执行、URL 访问或数据库写入通道。新增运行能力没有引入第三方 Python 依赖。工具请求与文件内容 schema、示例、文档均已导出。

## 分层方案

1. **L0：常驻指引**——SKILL.md，只放路由、恢复入口与核心约束。
2. **L1：项目摘要**——NEXT.json，当前统计、下一用例和路径；outline.json 按需查看。
3. **L2：当前用例**——FOCUS.json、当前 case、最多三条相关经验。
4. **L3：程序输入**——参数片段、完整基线/adapter、请求文件，由脚本加载。
5. **L4：原始证据**——展开计划、intent、响应、哈希、每次重试依据，仅诊断时读取。

旧 SKILL 中完整任务规则保留在 references/v3-routing.md 并通过路由按需加载。生成项目 Skill 不再要求模型先读取整个 project-suite.json。分层设计全文见 [context-design.md](workflow-testing/references/context-design.md)。

## 实测结果

最终回归 **94 项全部通过**：原有 77 项与新增 17 项。新增覆盖文件递归引用、中文文本、路径/循环/大小/重复键拒绝、来源漂移、断言不可绕过、实际 HTTP、重复调用、跨进程恢复、写入中断、显式重试、未发送取消及竞争、历史报告、经验范围、schema 同步和 PowerShell 简短回执。

- [最终回归日志](verification/regression-final.stderr.log)
- [真实命令与退出码](verification/validation.json)
- [Skill 校验日志](verification/skill-validation.stdout.log)：通过。

30 用例规模实验使用自带回环 HTTP 服务，调用入口均为真实 Python 子进程；未连接公司系统。

| 实测项 | 结果 |
|---|---:|
| 用例数 / 最终通过数 | 30 / 30 |
| 实际 HTTP 请求数 | 105 |
| 重复调用完成 attempt 新增请求数 | 0 |
| 独立进程工具调用数 | 66 |
| 展开计划合计 | 4,010,130 字节 |
| 保存的运行结果合计 | 208,796 字节 |
| 全部简短 stdout 合计 | 15,165 字节 |
| 单次 stdout 最大值 | 239 字节 |
| 完成时 NEXT.json | 348 字节 |

第 15 个用例完成后，在新进程恢复得到 PASS=15、TODO=15，并继续完成其余用例。大请求片段通过文件读取，没有作为工具回执输出。[中途检查点](verification/volume-final/halfway-checkpoint.json)、[指标](verification/volume-final/metrics.json)、[逐次调用记录](verification/volume-final/commands.json)、[会话报告](verification/volume-final/session-report.md) 均保留。

这些是文件和终端输出的实际字节数，**不是 token 费用、模型记忆准确率或线上端到端能力的测量**。实际节省取决于调用者是否遵循按需读取，而不是随后又把所有文件读入上下文。

开发过程中曾由原有回归发现工具请求 schema 未同步；已更新导出 schema，随后全量通过。未通过削弱断言或跳过旧测试处理该失败。

## 公司接续方式

先看 [接续路线](workflow-testing/references/v4-handoff.md) 和 [调用/文件契约](workflow-testing/references/file-workflow.md)。固定 workspace，保留当前 Skill 版本，将公司 suite/adapter/plan 放入 inputs，参照 assets/session-spec.example.json 与 flow-init.request.json 建立会话。之后直接引用工具生成的 prepare/execute/status 请求文件。

中断交接只需记录 workspace、版本、status 请求路径、当前未决事项；不必复述全部测试内容。每次开始先调用 status，根据 NEXT.json 接续。需修改公共实现时继续执行现有单写者租约与真实验证协议。

## 边界和尚未验证

- 不会主动删除宿主历史对话，也不能保证模型永不遗忘；程序将关键校验、进度和重复调用判断落实到文件。
- UNKNOWN/INCOMPLETE 需要真实核对。程序校验记录形状和证据哈希，不能证明人工填写的授权/远端副作用结论真实；必须确认旧执行者停止。
- 重试从用例首步开始，不是自动续跑某个写步骤；原生 HTTP 响应仍限制 1 MiB、运行结果 16 MiB。
- 本地文件和哈希不是对抗恶意本地写者的签名系统；未实现分布式调度、浏览器执行、公司生产系统连接。
- 已在当前 Windows/Python 3.9.9 环境验证；其他系统及公司代理/证书/权限环境须由接手团队验证。
- **独立评审 pending**；未声称存在第二评审者。本地演示通过不等同公司业务验收。
