# 从这里开始

交付的 Skill 在 `workflow-testing/`，runner 版本 2.2.0；`verification/` 是合成测试证据，不需要全部加载或复制进项目上下文。原 v3 目录未替换。本交付生成不等于自动安装。

1. 先读 [报告](REPORT.md)，确认完成范围和实测结果。
2. 执行使用 [SKILL.md](workflow-testing/SKILL.md) 和 [文件调用契约](workflow-testing/references/file-workflow.md)。
3. 公司开发接力使用 [接续路线](workflow-testing/references/v4-handoff.md)，需要设计理由时读 [分层设计](workflow-testing/references/context-design.md)。

自己复验本地演示：

```powershell
Set-Location E:\AI\demo\workflow-testing-v4-delivery-20261013\workflow-testing
python -X utf8 -m unittest discover -s tests -v
python -X utf8 scripts/demo_file_workflow.py --out E:\AI\workflow-demo-new
```

演示输出目录必须尚不存在；程序只启动回环服务，不连接公司业务接口。实际公司调用需替换 workspace 和文件路径，按现有接入规约提供真实 adapter，不把演示端口/角色当成公司配置。

日常默认入口：

```powershell
python -X utf8 <skill路径>\scripts\toolchain.py --workspace <公司workspace> --request <workspace中的请求文件绝对路径> --response-file replies/<本次唯一名字>.json --brief
```

恢复时直接调用项目生成的 `requests/status.json`；只读生成的 NEXT.json 和当前用例相关文件。完整 schema 和原始证据留在文件中按需定位。
