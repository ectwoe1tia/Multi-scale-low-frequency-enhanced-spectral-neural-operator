from pathlib import Path
import json, subprocess, sys, datetime
delivery = Path(r'E:\AI\demo\workflow-testing-v4-delivery-20261013')
skill = delivery / 'workflow-testing'
out = delivery / 'verification'
out.mkdir(exist_ok=True)
commands = [
    ('regression', [sys.executable, '-X', 'utf8', '-m', 'unittest', 'discover', '-s', 'tests', '-v']),
    ('skill-validation', [sys.executable, '-X', 'utf8', r'C:\Users\jing\.codex\skills\.system\skill-creator\scripts\quick_validate.py', str(skill)]),
    ('volume-final', [sys.executable, '-X', 'utf8', 'scripts/demo_file_workflow.py', '--out', str(out / 'volume-final')]),
]
rows = []
for label, cmd in commands:
    result = subprocess.run(cmd, cwd=skill, capture_output=True, encoding='utf-8', timeout=180)
    (out / (label + '.stdout.log')).write_text(result.stdout, encoding='utf-8')
    (out / (label + '.stderr.log')).write_text(result.stderr, encoding='utf-8')
    row = {'label':label,'command':cmd,'cwd':str(skill),'exit_code':result.returncode,'stdout':f'verification/{label}.stdout.log','stderr':f'verification/{label}.stderr.log'}
    rows.append(row)
    (out / 'validation.json').write_text(json.dumps({'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':rows}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'label':label,'exit_code':result.returncode,'tail':(result.stdout+result.stderr)[-500:]}, ensure_ascii=False), flush=True)
    if result.returncode:
        sys.exit(result.returncode)
