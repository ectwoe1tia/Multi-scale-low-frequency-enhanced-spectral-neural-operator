from pathlib import Path
import json, sys
root = Path(r'E:\AI\demo\workflow-testing-v4-delivery-20261013\workflow-testing')
sys.path.insert(0, str(root / 'scripts'))
import toolchain, file_workflow
def save(name, data):
    (root / 'assets' / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
save('tool-request.schema.json', toolchain.protocol_schema())
save('session-spec.example.json', {'suite':'inputs/suite.json','adapter':'inputs/adapter.json','plan':'inputs/plan.json'})
for name, tool, args in [
    ('flow-init', 'flow_init', {'spec':'session-spec.json','out':'projects/order'}),
    ('flow-status', 'flow_status', {'project':'projects/order/project.json'}),
    ('flow-prepare', 'flow_prepare', {'project':'projects/order/project.json','case_id':'TC-DEMO-1'}),
    ('flow-execute', 'flow_execute', {'project':'projects/order/project.json','case_id':'TC-DEMO-1','attempt':'0001'}),
    ('flow-focus', 'flow_focus', {'project':'projects/order/project.json','case_id':'TC-DEMO-1'}),
    ('flow-note', 'flow_note', {'project':'projects/order/project.json','note':'notes/new-note.json'}),
    ('flow-cancel', 'flow_cancel', {'project':'projects/order/project.json','case_id':'TC-DEMO-1','attempt':'0001','reason':'修正尚未发送的参数'}),
    ('flow-report', 'flow_report', {'project':'projects/order/project.json','out':'reports/session-001.md'}),
    ('flow-reconcile', 'flow_reconcile', {'project':'projects/order/project.json','record':'notes/reconcile.json'}),
    ('request-compose', 'request_compose', {'spec':'payloads/spec.json','out':'prepared/payload.json'})
]:
    save(name + '.request.json', file_workflow.request(tool, **args))
save('file-note.example.json', {'case_id':'TC-DEMO-1','kind':'hypothesis','summary':'疑似角色映射不一致；示例不是公司事实','next_action':'核对当前任务办理人和 adapter 映射','evidence':['checks/role-review.json']})
save('retry-note.example.json', {'case_id':'TC-DEMO-1','previous_attempt':'0001','reason':'填写实际原因','change':'填写实际修正','side_effects':'填写上次提交和新夹具情况','authorization':'填写已有授权的真实来源','evidence':['checks/retry-review.json']})
save('reconcile.example.json', {'case_id':'TC-DEMO-1','attempt':'0001','reason':'填写实际中断原因','side_effects':'填写业务侧查询与清理情况','authorization':'填写真实授权来源','writer_stopped':'confirmed','evidence':['checks/reconciliation.json']})
p = root / 'references/file-workflow.md'
s = p.read_text(encoding='utf-8').replace('| flow_reconcile |', '| flow_cancel | project, case_id, attempt, reason | 仅取消尚未发送的 PREPARED；与发送竞争同一个独占 intent，保留 CANCELLED 记录 |\n| flow_report | project, out | 生成 Markdown 会话报告，逐项保留所有 attempt 历史，输出不能覆盖 |\n| flow_reconcile |')
s = s.replace('前一次必须已为 PASS/FAIL/ERROR/ABANDONED；', '前一次必须已为 PASS/FAIL/ERROR/ABANDONED/CANCELLED；')
s = s.replace('若 prepared 输入变了而尚未发送，修复到原快照或建立新项目；本版未提供取消 PREPARED 工具，不能删除 intent/attempt 来绕过保护。', '若 prepared 输入变了而尚未发送，使用 flow_cancel 记录原因，再提供 retry_note 准备新 attempt。cancel 和 execute 使用同一个独占 intent 槽位，两者只能一个成功；已经开始发送的请求不能取消，也不能删除 intent/attempt 绕过保护。')
s = s.replace('终态 → 明确的 retry_note', 'PREPARED → flow_cancel（仅未发送）→ CANCELLED\n终态 → 明确的 retry_note')
p.write_text(s, encoding='utf-8')
p = root / 'references/v4-handoff.md'
s = p.read_text(encoding='utf-8').replace('| P1 | PREPARED 取消/替换工具 | 仅未有 intent 的 attempt；明确归档取消事件，竞态下不能和发送并行 |\n', '')
p.write_text(s, encoding='utf-8')
for name, text in [
    ('toolchain.md', '\n## v4 文件会话扩展\n\nrunner 2.2.0 保留原工具，新增注册工具 request_compose、flow_init/prepare/execute/status/focus/note/reconcile/cancel/report。详细参数与文件契约见 [file-workflow.md](file-workflow.md)。CLI 新增 --response-file 和 --brief；建议把完整 describe/schema 保存文件，按需读取。新版 schema 同步导出至 assets/tool-request.schema.json。\n'),
    ('implementation.md', '\n## v4 已实现扩展（runner 2.2.0）\n\n多级文件引用、逐用例会话、固定请求生成、简短回执、稳定 attempt 与不确定执行阻断、显式重试/核对、未发送取消、分层经验、会话报告及项目 Skill 小索引已实现。接续文档见 [v4-handoff.md](v4-handoff.md)，实际验证报告位于交付根目录 REPORT.md；旧内容中的 v3 状态为历史范围，不表示新增能力缺失。\n')
]:
    p = root / 'references' / name
    p.write_text(p.read_text(encoding='utf-8') + text, encoding='utf-8')
