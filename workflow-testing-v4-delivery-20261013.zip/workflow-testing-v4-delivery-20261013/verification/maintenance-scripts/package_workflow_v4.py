from pathlib import Path
import hashlib, json, sys, zipfile
d = Path(r'E:\AI\demo\workflow-testing-v4-delivery-20261013')
s = d / 'workflow-testing'
sys.path.insert(0, str(s / 'scripts'))
import toolchain
def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
baseline = json.loads((d / 'source-manifest.json').read_text(encoding='utf-8'))
source = Path(baseline['source'])
unchanged = all((source / ref).is_file() and digest(source / ref) == expected for ref, expected in baseline['files'].items())
assert unchanged, 'Source v3 unexpectedly changed'
changed, added = [], []
for p in s.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or '.coordination' in p.parts or p.name == 'change-request.json':
        continue
    ref = p.relative_to(s).as_posix()
    if ref not in baseline['files']:
        added.append(ref)
    elif digest(p) != baseline['files'][ref]:
        changed.append(ref)
validation = json.loads((d / 'verification/validation.json').read_text(encoding='utf-8'))
assert all(c['exit_code'] == 0 for c in validation['commands'])
req = json.loads((s / 'change-request.json').read_text(encoding='utf-8'))
req.update(status='implemented', changed_files=sorted(changed), new_files=sorted(added),
           contract_changes=['runner 2.2.0; protocol 1.0 unchanged', 'Registered file composition/session tools and named input schemas', 'Optional response-file/brief CLI; original CLI remains compatible', 'Generated project skill uses progressive baseline indexes'],
           compatibility='Old tools, guards, business assertions and raw failure semantics retained. File workflow is opt-in. No company integration claimed.',
           validation={'status':'passed','commands':[c['command'] for c in validation['commands']], 'exit_codes':[c['exit_code'] for c in validation['commands']], 'evidence':['../verification/validation.json','../verification/regression-final.stderr.log','../verification/volume-final/metrics.json']},
           review={'status':'pending','reviewer':'','notes':['No independent reviewer performed this review.']},
           rollback='Original v3 source preserved and hashes verified unchanged. Switch skill version; preserve all project evidence. Re-prepare plans after runner changes.',
           open_questions=['Company endpoint/auth/fixtures and operating environment acceptance remain with project owner.'],
           next_action='Read v4-handoff.md and REPORT.md; integrate company assets and perform authorized business acceptance.')
save(s / 'change-request.json', req)
lease = json.loads((d / 'maintenance-lease.json').read_text(encoding='utf-8'))
released = toolchain.dispatch(s, {'protocol_version':'1.0','tool':'release','arguments':{'lease_token':lease['data']['lease_token']}})
save(d / 'verification/lease-release.json', released)
save(d / 'handoff.json', {'delivery':'workflow-testing-v4','runner_version':'2.2.0','protocol_version':'1.0',
     'status':'implemented_and_locally_verified','source_v3_unchanged':unchanged,'maintenance_lease_released':released['ok'],
     'regression':{'passed':94,'failed':0},'local_volume_demo':json.loads((d/'verification/volume-final/metrics.json').read_text(encoding='utf-8')),
     'entry':'START_HERE.md','report':'REPORT.md','company_handoff':'workflow-testing/references/v4-handoff.md',
     'independent_review':'pending','company_business_acceptance':'not_executed',
     'resume':'For each project invoke its generated requests/status.json using toolchain --response-file --brief.'})
# Preserve implementation helpers as historical maintenance evidence, outside the installable Skill.
history = d / 'verification/maintenance-scripts'
history.mkdir(exist_ok=True)
for name in ('setup_workflow_v4.py','maintain_workflow_v4.py','finish_workflow_assets.py','verify_workflow_v4.py','package_workflow_v4.py'):
    p = Path(r'E:\AI') / name
    if p.is_file():
        p.rename(history / name)
files = [p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.coordination' not in p.parts and p.name not in ('maintenance-lease.json','MANIFEST.sha256.json')]
save(d / 'MANIFEST.sha256.json', {p.relative_to(d).as_posix():digest(p) for p in sorted(files)})
files.append(d / 'MANIFEST.sha256.json')
archive = d.with_suffix('.zip')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, d.name + '/' + p.relative_to(d).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'sha256':digest(archive),'files':len(files),'changed':len(changed),'added':len(added),'lease_released':released['ok'],'v3_unchanged':unchanged}, ensure_ascii=False))
