import sys, shutil, json, hashlib
from pathlib import Path
source = Path(r'E:\AI\demo\workflow-testing-v3-delivery-20261008\workflow-testing')
delivery = Path(r'E:\AI\demo\workflow-testing-v4-delivery-20261013')
target = delivery / 'workflow-testing'
target.mkdir(parents=True, exist_ok=False)
for folder in ('scripts', 'references', 'assets', 'tests', 'agents'):
    shutil.copytree(source / folder, target / folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
for name in ('AGENTS.md', 'SKILL.md'):
    shutil.copyfile(source / name, target / name)
sys.path.insert(0, str(target / 'scripts'))
import toolchain
changed = ['SKILL.md', 'scripts/toolchain.py', 'scripts/http_runner.py', 'scripts/suite.py', 'scripts/Invoke-WorkflowTool.ps1', 'references/toolchain.md', 'references/implementation.md', 'assets/tool-request.schema.json']
changed = [f for f in changed if (target / f).exists()]
req = json.loads((target / 'assets/change-request.template.json').read_text(encoding='utf-8-sig'))
req.update(change_id='CHANGE-FILE-CONTEXT-V4', owner='codex-maintainer', purpose='用户要求：文件引用、分层上下文、重复执行记录、额度耗尽接续；基于 v3 独立交付。', base_version='2.1.0', changed_files=changed, status='implementing', next_action='Implement and validate')
def call(tool, **args):
    return toolchain.dispatch(target, {'protocol_version':'1.0','tool':tool,'arguments':args})
snapshot = call('snapshot', files=changed)
req['base_hashes'] = snapshot['data']['base_hashes']
(target / 'change-request.json').write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding='utf-8')
lease = call('claim', owner=req['owner'], change_id=req['change_id'], base_hashes=req['base_hashes'])
(delivery / 'maintenance-lease.json').write_text(json.dumps(lease, indent=2), encoding='utf-8')
(delivery / 'source-manifest.json').write_text(json.dumps({'source': str(source), 'files': {str(p.relative_to(source)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file() and '.coordination' not in p.parts and '__pycache__' not in p.parts}}, ensure_ascii=False, indent=2), encoding='utf-8')
print(target)
