# 文件会话测试报告

只统计本会话选中用例；不是发布许可。历史失败不会因后次通过而消失。

最新状态统计：`{"PASS": 30}`

| Case | Attempt | 原始/观察状态 | 处置 | 证据 |
|---|---|---|---|---|
| TC-VOLUME-001 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-f28a5851b308-0001/results.json |
| TC-VOLUME-002 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-bc1f84c55ff1-0001/results.json |
| TC-VOLUME-003 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-d66b24a1ff6a-0001/results.json |
| TC-VOLUME-004 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-945879e57bee-0001/results.json |
| TC-VOLUME-005 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-fac3ddc6569b-0001/results.json |
| TC-VOLUME-006 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-02ff192d1a27-0001/results.json |
| TC-VOLUME-007 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-6c136eb46c58-0001/results.json |
| TC-VOLUME-008 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-403af5b56c8c-0001/results.json |
| TC-VOLUME-009 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-c2ce394e7366-0001/results.json |
| TC-VOLUME-010 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-07f4a62c3d10-0001/results.json |
| TC-VOLUME-011 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-39156fe4eeb6-0001/results.json |
| TC-VOLUME-012 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-0d9dcdef28d2-0001/results.json |
| TC-VOLUME-013 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-e162e26dea4b-0001/results.json |
| TC-VOLUME-014 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-0d24b20a60e1-0001/results.json |
| TC-VOLUME-015 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-54e706d5c734-0001/results.json |
| TC-VOLUME-016 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-452efefa4171-0001/results.json |
| TC-VOLUME-017 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-c699377c1196-0001/results.json |
| TC-VOLUME-018 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-f7ac0b66e776-0001/results.json |
| TC-VOLUME-019 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-c36d6c21785a-0001/results.json |
| TC-VOLUME-020 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-a6343d5ccc48-0001/results.json |
| TC-VOLUME-021 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-e353b9159237-0001/results.json |
| TC-VOLUME-022 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-2443d85524e2-0001/results.json |
| TC-VOLUME-023 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-79df6f600435-0001/results.json |
| TC-VOLUME-024 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-ed3be9f70060-0001/results.json |
| TC-VOLUME-025 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-727b787d9e10-0001/results.json |
| TC-VOLUME-026 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-d84c6b26a6c0-0001/results.json |
| TC-VOLUME-027 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-3515379f12f1-0001/results.json |
| TC-VOLUME-028 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-a0b3bb0f8211-0001/results.json |
| TC-VOLUME-029 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-b216b28125b8-0001/results.json |
| TC-VOLUME-030 | 0001 | PASS | PASS | runs/Sf1f4ca1c7d97436e-31a48356b747-0001/results.json |

基线：suite.json
项目大纲：project/outline.json
经验记录：project/notes

未选中范围见原基线与各 run 的 not_selected_cases。
