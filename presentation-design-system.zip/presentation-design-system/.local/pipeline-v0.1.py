"""Portable PPTX style extraction, deck rebuilding, and 15 MB packaging."""
import argparse
from collections import Counter
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import statistics
import xml.etree.ElementTree as ET
import zipfile

P = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PR = 'http://schemas.openxmlformats.org/package/2006/relationships'
NS = {'p': P, 'a': A, 'r': R}


def xml(z, name):
    return ET.fromstring(z.read(name))


def slug(name):
    return re.sub('[^a-z0-9]+', '-', name.lower()).strip('-')[:48] or 'style'


def rgb(node):
    if node is None:
        return None
    n = node.find('.//a:srgbClr', NS)
    if n is not None:
        return '#' + n.get('val', '000000').upper()
    n = node.find('.//a:schemeClr', NS)
    return 'theme:' + n.get('val') if n is not None else None


def bbox(shape, width, height):
    xfrm = shape.find('.//a:xfrm', NS)
    if xfrm is None:
        return None
    off, ext = xfrm.find('a:off', NS), xfrm.find('a:ext', NS)
    if off is None or ext is None:
        return None
    return [round(int(off.get('x', 0))/width, 4), round(int(off.get('y', 0))/height, 4), round(int(ext.get('cx', 0))/width, 4), round(int(ext.get('cy', 0))/height, 4)]


def extract(path, out):
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        pres = xml(z, 'ppt/presentation.xml')
        size = pres.find('p:sldSz', NS)
        w, h = int(size.get('cx')), int(size.get('cy'))
        rels = {}
        for rel in xml(z, 'ppt/_rels/presentation.xml.rels'):
            rels[rel.get('Id')] = rel.get('Target')
        order = []
        for item in pres.findall('.//p:sldId', NS):
            target = rels.get(item.get('{%s}id' % R), '')
            if target:
                order.append('ppt/' + target.lstrip('/').replace('../', ''))
        if not order:
            order = sorted((n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)), key=lambda n:int(re.search(r'\d+', n).group()))
        pages = []
        colors = Counter()
        fonts = Counter()
        for n, member in enumerate(order, 1):
            if member not in z.namelist():
                continue
            root = xml(z, member)
            shapes = []
            for sh in root.findall('.//p:spTree/p:sp', NS) + root.findall('.//p:spTree/p:pic', NS):
                box = bbox(sh, w, h)
                if not box:
                    continue
                text = ''.join(t.text or '' for t in sh.findall('.//a:t', NS)).strip()
                typ = 'image' if sh.tag.endswith('pic') else 'text' if text else 'shape'
                color = rgb(sh.find('.//a:solidFill', NS))
                if color and color.startswith('#'):
                    colors[color] += 1
                for latin in sh.findall('.//a:latin', NS):
                    if latin.get('typeface'):
                        fonts[latin.get('typeface')] += 1
                pr = sh.find('./p:nvSpPr/p:cNvPr', NS) or sh.find('./p:nvPicPr/p:cNvPr', NS)
                shapes.append({'id':pr.get('id') if pr is not None else None,'type':typ,'box':box,'color':color,'text':text[:120] if text else None})
            # Image role depends on position and neighboring text, not just the media file.
            images = []
            texts = [s for s in shapes if s['type'] == 'text' and s['text']]
            for s in [s for s in shapes if s['type'] == 'image']:
                x,y,bw,bh = s['box']
                area = bw*bh
                if area > .60:
                    role = 'background-or-hero'
                elif area > .22:
                    role = 'hero-or-evidence'
                elif area < .035:
                    role = 'icon-or-decoration'
                else:
                    role = 'supporting-visual'
                cx,cy=x+bw/2,y+bh/2
                nearest = sorted(texts,key=lambda t:abs(t['box'][0]+t['box'][2]/2-cx)+abs(t['box'][1]+t['box'][3]/2-cy))[:2]
                images.append({'shapeId':s['id'],'roleHypothesis':role,'areaRatio':round(area,4),'nearestTextShapeIds':[t['id'] for t in nearest],'relationship':'visual near text; inspect rendering to classify illustration, evidence, metaphor, or decoration','confidence':'low'})
            pages.append({'slide':n,'shapes':shapes,'imageRelationships':images,'layoutFeatures':{'imageArea':round(sum(s['box'][2]*s['box'][3] for s in shapes if s['type']=='image'),3),'textCount':len(texts)}})
    evidence={'schemaVersion':'1.0','sourceSha256':sha,'sourceFile':path.name,'canvasEmu':[w,h],'pages':pages,'topColors':colors.most_common(12),'topFonts':fonts.most_common(8),'visualAnalysis':'pending-render-review'}
    out.mkdir(parents=True,exist_ok=True)
    (out/'evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
    selected = sorted(pages,key=lambda p:(abs(p['layoutFeatures']['imageArea']-.28),-p['layoutFeatures']['textCount']))[:5]
    selected = sorted(selected,key=lambda p:p['slide'])
    sid=slug(path.stem.encode('utf-8').hex()[:16])
    style=out/'style';style.mkdir(exist_ok=True)
    theme={'schemaVersion':'1.0','id':sid,'colors':{'primary':colors.most_common(1)[0][0] if colors else '#244263','accent':colors.most_common(2)[-1][0] if colors else '#D58B42','background':'#FFFFFF','text':'#1D2430'},'fonts':{'body':fonts.most_common(1)[0][0] if fonts else 'Arial','fallback':'Arial'},'canvas':[1280,720]}
    (style/'theme.json').write_text(json.dumps(theme,ensure_ascii=False,indent=2),encoding='utf-8')
    (style/'theme.css').write_text(':root{--color-primary:%s;--color-accent:%s;--color-bg:%s;--color-text:%s;--font-body:"%s",Arial,sans-serif}\n'%(theme['colors']['primary'],theme['colors']['accent'],theme['colors']['background'],theme['colors']['text'],theme['fonts']['body']),encoding='utf-8')
    layouts=[]
    for page in selected:
        boxes=[{'role':s['type'],'box':s['box']} for s in page['shapes'] if s['type'] in ('text','image')]
        layouts.append({'id':'source-slide-%d'%page['slide'],'sourceSlide':page['slide'],'observedBoxes':boxes,'status':'observed-layout-requires-curation'})
    (style/'layouts.json').write_text(json.dumps(layouts,ensure_ascii=False,indent=2),encoding='utf-8')
    (style/'style.md').write_text('# 风格观察\n\n结构已提取；艺术气质、视觉重心和图像隐喻需结合渲染图人工或视觉模型确认。不要把位置推断写成确定的艺术规则。\n',encoding='utf-8')
    (style/'image-relations.json').write_text(json.dumps([{'slide':p['slide'],'relationships':p['imageRelationships']} for p in selected],ensure_ascii=False,indent=2),encoding='utf-8')
    (style/'manifest.json').write_text(json.dumps({'schemaVersion':'1.0','styleVersion':'0.1.0','id':sid,'sourceSha256':sha,'visualReview':'pending','selectedSlides':[p['slide'] for p in selected]},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'source':path.name,'slides':len(pages),'selected':[p['slide'] for p in selected],'style':str(style)},ensure_ascii=False))


def rebuild(style, deck_file, out):
    theme=json.loads((style/'theme.json').read_text(encoding='utf-8'))
    deck=json.loads(deck_file.read_text(encoding='utf-8'))
    out.mkdir(parents=True,exist_ok=True)
    slides=[]
    for i,page in enumerate(deck['slides'],1):
        title=html.escape(page.get('title',''))
        body=''.join('<p>'+html.escape(str(t))+'</p>' for t in page.get('body',[]))
        slides.append('<section class="slide"><div class="accent"></div><header>%02d / %s</header><h1>%s</h1><main>%s</main></section>'%(i,html.escape(deck.get('name','Deck')),title,body))
    css='@page{size:13.333in 7.5in;margin:0}body{margin:0;background:#ddd;font-family:var(--font-body)}.slide{width:1280px;height:720px;box-sizing:border-box;position:relative;overflow:hidden;margin:20px auto;padding:75px 100px;background:var(--color-bg);color:var(--color-text)}.accent{width:140px;height:9px;background:var(--color-accent)}header{margin-top:18px;color:var(--color-primary)}h1{font-size:52px;line-height:1.2;max-width:1020px}main{font-size:30px;line-height:1.5;max-height:390px;overflow:hidden}@media print{body{background:white}.slide{margin:0;break-after:page}}'
    doc='<!doctype html><html lang="zh"><meta charset="utf-8"><title>%s</title><style>%s%s</style>%s</html>'%(html.escape(deck.get('name','Deck')),(style/'theme.css').read_text(encoding='utf-8'),css,''.join(slides))
    (out/'index.html').write_text(doc,encoding='utf-8')
    (out/'rebuild-report.json').write_text(json.dumps({'slides':len(slides),'html':'index.html','pptx':'requires configured PPTWork/html2pptx-pro exporter','style':theme['id']},ensure_ascii=False,indent=2),encoding='utf-8')
    print(out/'index.html')


def pack(source, dest, max_bytes=15_000_000):
    paths=[p for p in source.rglob('*') if p.is_file() and '.local' not in p.parts and '__pycache__' not in p.parts and p.suffix.lower() not in {'.pptx','.ppt','.pdf','.zip','.pyc'}]
    dest.mkdir(parents=True,exist_ok=True)
    groups=[];group=[];size=0
    for p in paths:
        if p.stat().st_size>max_bytes:
            raise ValueError('single file exceeds 15 MB: '+str(p))
        if group and size+p.stat().st_size>max_bytes*.8:
            groups.append(group);group=[];size=0
        group.append(p);size+=p.stat().st_size
    if group: groups.append(group)
    outputs=[]
    for i,group in enumerate(groups,1):
        target=dest/('presentation-design-system.zip' if len(groups)==1 else 'presentation-design-system-%02d.zip'%i)
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in group: z.write(p,p.relative_to(source))
        if target.stat().st_size>max_bytes: raise ValueError('package exceeds 15 MB')
        outputs.append({'file':str(target),'bytes':target.stat().st_size})
    print(json.dumps(outputs,ensure_ascii=False,indent=2))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='cmd',required=True)
    ex=sub.add_parser('extract');ex.add_argument('pptx',type=Path);ex.add_argument('output',type=Path)
    rb=sub.add_parser('rebuild');rb.add_argument('style',type=Path);rb.add_argument('deck',type=Path);rb.add_argument('output',type=Path)
    pk=sub.add_parser('pack');pk.add_argument('source',type=Path);pk.add_argument('output',type=Path)
    a=ap.parse_args()
    if a.cmd=='extract': extract(a.pptx,a.output)
    elif a.cmd=='rebuild': rebuild(a.style,a.deck,a.output)
    else: pack(a.source,a.output)


if __name__=='__main__': main()
