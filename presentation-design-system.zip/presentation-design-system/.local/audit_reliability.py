"""Non-mutating audit of the delivered implementation; fixtures stay under .local."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('pipeline', BASE/'tools/pipeline.py')
pipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pipe)
SOURCE = Path(r'E:\MyFile\文档\WeChat Files\wxid_7lozgok3qlk322\FileStorage\MsgAttach\d5b8310aa4a51f3fb7358166de6d183f\File\2023-06')
report = {'samples': [], 'checks': {}}
for folder in sorted((BASE/'.local').glob('validation-*')):
    ev=json.loads((folder/'evidence.json').read_text(encoding='utf-8'))
    shapes=[s for p in ev['pages'] for s in p['shapes']]
    paths=list(SOURCE.rglob(ev['sourceFile']))
    raw={'sp':0,'pic':0,'grpSp':0,'graphicFrame':0,'cxnSp':0}
    if paths:
        with zipfile.ZipFile(paths[0]) as z:
            import re
            for name in z.namelist():
                if re.fullmatch(r'ppt/slides/slide\d+\.xml',name):
                    root=ET.fromstring(z.read(name))
                    for tag in raw:
                        raw[tag]+=len(root.findall('.//p:'+tag,pipe.NS))
    refs=[x for p in ev['pages'] for rel in p['imageRelationships'] for x in rel['nearestTextShapeIds']]
    report['samples'].append({'name':ev['sourceFile'],'pages':len(ev['pages']),'rawSlideObjects':raw,'extractedShapes':len(shapes),'extractedText':sum(s['type']=='text' for s in shapes),'nullIds':sum(s['id'] is None for s in shapes),'nearestTextReferences':len(refs),'nullTextReferences':sum(x is None for x in refs),'topColors':ev['topColors'],'topFonts':ev['topFonts']})
with tempfile.TemporaryDirectory(dir=BASE,prefix='audit-') as temp:
    tmp=Path(temp)
    st=tmp/'style';shutil.copytree(BASE/'styles/validation-2',st)
    with contextlib.redirect_stdout(io.StringIO()):
        pipe.rebuild(st,BASE/'decks/example.json',tmp/'before')
        (st/'layouts.json').write_text('THIS IS INVALID JSON',encoding='utf-8')
        pipe.rebuild(st,BASE/'decks/example.json',tmp/'after')
    report['checks']['invalidLayoutsIgnoredAndIdenticalOutput']=(tmp/'before/index.html').read_bytes()==(tmp/'after/index.html').read_bytes()
    ppt=tmp/'absolute-target.pptx'
    slide='<p:sld xmlns:p="'+pipe.P+'" xmlns:a="'+pipe.A+'"><p:cSld><p:spTree><p:sp><p:nvSpPr><p:cNvPr id="2" name="Title"/></p:nvSpPr><p:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="100" cy="100"/></a:xfrm></p:spPr><p:txBody><a:p><a:r><a:t>Title</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>'
    with zipfile.ZipFile(ppt,'w') as z:
        z.writestr('ppt/presentation.xml','<p:presentation xmlns:p="'+pipe.P+'" xmlns:r="'+pipe.R+'"><p:sldIdLst><p:sldId id="256" r:id="rId1"/></p:sldIdLst><p:sldSz cx="1280" cy="720"/></p:presentation>')
        z.writestr('ppt/_rels/presentation.xml.rels','<Relationships xmlns="'+pipe.PR+'"><Relationship Id="rId1" Type="'+pipe.R+'/slide" Target="/ppt/slides/slide1.xml"/></Relationships>')
        z.writestr('ppt/slides/slide1.xml',slide)
    with contextlib.redirect_stdout(io.StringIO()):
        pipe.extract(ppt,tmp/'absolute')
    absolute=json.loads((tmp/'absolute/evidence.json').read_text(encoding='utf-8'))
    report['checks']['absoluteTargetExpectedPages']=1
    report['checks']['absoluteTargetActualPages']=len(absolute['pages'])
    # Equivalent relative target must retain the text ID used in image relationships.
    with zipfile.ZipFile(ppt) as z: entries={n:z.read(n) for n in z.namelist()}
    entries['ppt/_rels/presentation.xml.rels']=entries['ppt/_rels/presentation.xml.rels'].replace(b'/ppt/slides/slide1.xml',b'slides/slide1.xml')
    relative=tmp/'relative-target.pptx'
    with zipfile.ZipFile(relative,'w') as z:
        for n,b in entries.items():z.writestr(n,b)
    with contextlib.redirect_stdout(io.StringIO()):pipe.extract(relative,tmp/'relative')
    ev=json.loads((tmp/'relative/evidence.json').read_text(encoding='utf-8'))
    report['checks']['textIdExpected']='2'
    report['checks']['textIdActual']=ev['pages'][0]['shapes'][0]['id']
    # Test portable pack contents in an isolated fixture, without exposing any real credentials.
    source=tmp/'pack-source';source.mkdir()
    (source/'.env').write_text('AUDIT_FIXTURE=not-a-real-secret')
    (source/'.git').mkdir();(source/'.git/config').write_text('audit fixture')
    with contextlib.redirect_stdout(io.StringIO()):pipe.pack(source,tmp/'packed')
    with zipfile.ZipFile(tmp/'packed/presentation-design-system.zip') as z:
        report['checks']['packIncludesDotEnvAndGit']=z.namelist()
delivery=BASE.parent/'delivery/presentation-design-system.zip'
with zipfile.ZipFile(delivery) as z:
    report['delivery']={'bytes':delivery.stat().st_size,'under15MB':delivery.stat().st_size<15000000,'crcError':z.testzip(),'fileCount':len(z.namelist()),'pptxCount':sum(n.endswith('.pptx') for n in z.namelist()),'vueFileCount':sum(n.endswith('.vue') for n in z.namelist()),'packageJsonPresent':'package.json' in z.namelist()}
(BASE/'.local/reliability-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
