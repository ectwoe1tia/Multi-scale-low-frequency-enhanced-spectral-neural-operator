"""Deterministic layout fallback for hosts that cannot launch a browser.

Uses the same content/layout/theme contracts; reports that browser fidelity is
not verified. Pillow provides real font measurement and an inspectable preview.
"""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

FONTS=[Path('C:/Windows/Fonts/msyh.ttc'),Path('C:/Windows/Fonts/msyh.ttf'),Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]


def native_scene(html_path,output):
    folder=Path(html_path).parent;output=Path(output);output.mkdir(parents=True,exist_ok=True)
    raw=(folder/'data.js').read_text(encoding='utf-8').strip()
    data=json.loads(raw.removeprefix('window.PRESENTATION = ').removesuffix(';'))
    deck=data['deck'];theme=data['theme'];registry={l['id']:l for l in data['layouts']};colors=theme['colors']
    font_path=next((p for p in FONTS if p.exists()),None)
    if not font_path:raise ValueError('Native layout requires a font; edit FONTS in tools/native_layout.py for this host')
    scene={'schemaVersion':'2.0','canvas':[1280,720],'engine':'native-baseline','fontFile':font_path.name,'browserFidelity':'not-verified','slides':[],'issues':[]}
    font_cache={}
    def font(size):
        size=round(size)
        if size not in font_cache:font_cache[size]=ImageFont.truetype(str(font_path),size)
        return font_cache[size]
    measure=ImageDraw.Draw(Image.new('RGB',(1,1)))
    for number,slide in enumerate(deck['slides'],1):
        layout=registry[slide['layout']];kind=layout['kind'];objects=[]
        def rect(x,y,w,h,fill):objects.append({'type':'rect','x':x,'y':y,'w':w,'h':h,'fill':fill.lstrip('#'),'alpha':1})
        def text(value,x,y,w,size=25,color=None,bold=False,maxh=500):
            value=str(value);color=color or colors['text'];lines=[];line=''
            for ch in value:
                if ch=='\n':lines.append(line);line='';continue
                if line and measure.textlength(line+ch,font=font(size))>w:lines.append(line);line=ch
                else:line+=ch
            if line:lines.append(line)
            lh=round(size*1.45,2)
            if len(lines)*lh>maxh:scene['issues'].append({'slide':number,'code':'text-overflow','text':value[:60]})
            for i,line in enumerate(lines):
                objects.append({'type':'text','x':x,'y':y+i*lh,'w':max(1,measure.textlength(line,font=font(size))+2),'h':lh,'text':line,'font':theme['fonts']['body'],'size':size,'bold':bold,'color':color.lstrip('#')})
            return len(lines)*lh
        rect(72,0,116,7,colors['accent'])
        text(slide.get('eyebrow','DESIGN SYSTEM / 演示基板'),72,46,920,14,colors['muted'])
        text('%02d / %02d'%(number,len(deck['slides'])),1130,46,78,14,colors['muted'])
        if kind in ('cover','closing'):
            rect(1028,200,180,260,colors['primary']);rect(1000,420,110,110,colors['accent'])
            text('让设计持续复用' if kind=='cover' else '下一步，开始你的演示',72,170,830,20,colors['primary'])
            h=text(slide['title'],72,225,830,60,bold=True,maxh=230)
            y=225+h+32
            for line in slide.get('body',[]):y+=text(line,72,y,830,25,maxh=640-y)+12
        else:
            text(slide['title'],72,104,1136,theme['typography']['title'],bold=True,maxh=110)
            if kind=='split':
                fraction=layout.get('visualFraction',.46);gap=48;usable=1136-gap;vw=usable*fraction;tw=usable-vw
                vx=72 if layout.get('visualSide')=='left' else 72+tw+gap;tx=72+vw+gap if layout.get('visualSide')=='left' else 72
                y=242
                for line in slide.get('body',[]):y+=text(line,tx,y,tw,theme['typography']['body'],maxh=610-y)+24
                visual=slide.get('visual',{'kind':'diagram','items':[{'label':'内容'},{'label':'布局'},{'label':'交付'}]});y=235
                if visual['kind']=='image':
                    import base64,io
                    src=visual['src'];image=Image.open(io.BytesIO(base64.b64decode(src.split(',')[1])));ratio=min(vw/image.width,325/image.height)
                    iw,ih=image.width*ratio,image.height*ratio;objects.append({'type':'image','x':vx+(vw-iw)/2,'y':y,'w':iw,'h':ih,'src':src});y+=ih+20
                elif visual['kind']=='bars':
                    for item in visual['items']:
                        text(item['label'],vx,y,110,18);rect(vx+120,y+7,vw-190,14,'#E2E9EF');rect(vx+120,y+7,(vw-190)*item['value']/100,14,colors['accent']);text(str(item['value'])+'%',vx+vw-60,y,60,18);y+=74
                else:
                    for i,item in enumerate(visual['items'],1):
                        rect(vx,y,vw,80,colors['surface']);text('0'+str(i),vx+26,y+25,40,18,colors['accent'],True);text(item['label'],vx+80,y+22,vw-105,25,colors['primary'],maxh=50);y+=96
                text(visual.get('caption','从设计规则到可复用页面'),vx,y+5,vw,17,colors['muted'],maxh=650-y)
            elif kind=='metrics':
                items=slide.get('metrics',[]);cw=(1136-24*(len(items)-1))/max(1,len(items))
                for i,m in enumerate(items):
                    x=72+i*(cw+24);rect(x,255,cw,320,colors['surface']);text(m['value'],x+28,295,cw-56,58,colors['primary'],True,maxh=90);text(m['label'],x+28,408,cw-56,25,maxh=70);text(m.get('detail',''),x+28,487,cw-56,17,colors['muted'],maxh=60)
            elif kind=='timeline':
                items=slide.get('steps',[]);cw=(1136-22*(len(items)-1))/max(1,len(items))
                for i,m in enumerate(items):
                    x=72+i*(cw+22);rect(x,240,cw,350,colors['surface']);text('0'+str(i+1),x+24,270,cw-48,35,colors['accent'],True);text(m['title'],x+24,345,cw-48,28,bold=True,maxh=75);text(m['detail'],x+24,421,cw-48,21,maxh=155)
            elif kind=='comparison':
                for i,col in enumerate(slide.get('columns',[])):
                    x=72+i*584;rect(x,225,552,385,colors['surface']);text(col['title'],x+34,259,484,28,colors['primary'],True);y=330
                    for t in col['items']:y+=text(t,x+34,y,484,24,maxh=590-y)+22
        text(slide.get('footer','内容与风格分离 · HTML 与 PPTX 双格式'),72,667,730,13,colors['muted'])
        text(slide.get('tag','PRESENTATION BASELINE'),987,667,221,13,colors['muted'])
        for obj in objects:
            if obj['x']<0 or obj['y']<0 or obj['x']+obj['w']>1281 or obj['y']+obj['h']>721:scene['issues'].append({'slide':number,'code':'outside-slide','type':obj['type']})
        scene['slides'].append({'id':slide['id'],'layout':slide['layout'],'background':colors['background'].lstrip('#'),'objects':objects})
        canvas=Image.new('RGB',(1280,720),colors['background']);draw=ImageDraw.Draw(canvas)
        for o in objects:
            if o['type']=='rect':draw.rectangle((o['x'],o['y'],o['x']+o['w'],o['y']+o['h']),fill='#'+o['fill'])
            elif o['type']=='text':draw.text((o['x'],o['y']),o['text'],font=font(o['size']),fill='#'+o['color'],anchor='lt',stroke_width=0)
            else:
                import base64,io
                im=Image.open(io.BytesIO(base64.b64decode(o['src'].split(',')[1]))).convert('RGB').resize((max(1,round(o['w'])),max(1,round(o['h']))))
                canvas.paste(im,(round(o['x']),round(o['y'])))
        canvas.save(output/('slide-%02d.png'%number))
    (output/'scene.json').write_text(json.dumps(scene,ensure_ascii=False,indent=2),encoding='utf-8')
    report={'engine':'native-baseline','status':'failed' if scene['issues'] else 'passed','slides':len(scene['slides']),'issues':scene['issues'],'browserFidelity':'not-verified','fontFile':font_path.name}
    (output/'check-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    if scene['issues']:raise ValueError('Native layout overflow; see '+str(output/'check-report.json'))
    return scene
