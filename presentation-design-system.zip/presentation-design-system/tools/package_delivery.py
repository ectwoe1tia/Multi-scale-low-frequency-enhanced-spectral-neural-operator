"""Allowlisted delivery archives, each strictly below 15,000,000 bytes."""
import hashlib
import io
import json
from pathlib import Path
import zipfile

LIMIT=15_000_000
DIRS={'tools','runtime','skills','styles','decks','tests','vendor','examples','docs','reports'}
ROOT_FILES={'README.md','ARCHITECTURE.md','RELIABILITY_REVIEW.md','THIRD_PARTY_NOTICES.md','package.json','package-lock.json','.gitignore','requirements.txt','run-demo.cmd'}
DENY={'.git','.local','node_modules','__pycache__','sources','.pytest_cache'}
EXTS={'.py','.mjs','.js','.css','.html','.json','.md','.txt','.svg','.webp','.png','.jpg','.jpeg','.pptx','.cmd','.yaml','.yml'}


def archive(files):
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in files:
            info=zipfile.ZipInfo(name,(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data)
    return buf.getvalue()


def pack(source,destination):
    source=Path(source).resolve();destination=Path(destination).resolve()
    if destination==source or source in destination.parents:raise ValueError('Delivery directory must be outside source tree')
    files=[]
    for p in sorted(source.rglob('*')):
        if not p.is_file() or p.is_symlink():continue
        rel=p.relative_to(source)
        if any(part in DENY or part.startswith('.env') for part in rel.parts):continue
        if len(rel.parts)==1:
            if rel.name not in ROOT_FILES:continue
        elif rel.parts[0] not in DIRS or p.suffix.lower() not in EXTS:continue
        # Original decks are never included; only generated demo PPTX artifacts.
        if p.suffix.lower()=='.pptx' and rel.parts[0]!='examples':continue
        files.append((rel.as_posix(),p.read_bytes()))
    if not files:raise ValueError('No allowlisted files')
    manifest={'version':'0.2.0','files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in files]}
    files.append(('DELIVERY_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')))
    groups=[files]
    while True:
        expanded=[];split=False
        for group in groups:
            if len(archive(group))<LIMIT:expanded.append(group)
            elif len(group)==1:raise ValueError('Single file cannot fit under 15 MB: '+group[0][0])
            else:
                mid=len(group)//2;expanded.extend([group[:mid],group[mid:]]);split=True
        groups=expanded
        if not split:break
    destination.mkdir(parents=True,exist_ok=True);result=[]
    for i,group in enumerate(groups,1):
        name='presentation-baseline-0.2.0'+('' if len(groups)==1 else '-%02d'%i)+'.zip'
        content=archive(group);target=destination/name;temp=target.with_suffix('.tmp');temp.write_bytes(content);temp.replace(target)
        result.append({'file':name,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
    (destination/'PACKAGES.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result


def verify(folder):
    folder=Path(folder);packages=json.loads((folder/'PACKAGES.json').read_text(encoding='utf-8'));data={}
    for p in packages:
        raw=(folder/p['file']).read_bytes()
        if len(raw)>=LIMIT or len(raw)!=p['bytes'] or hashlib.sha256(raw).hexdigest()!=p['sha256']:raise ValueError('Package size/hash mismatch')
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            if z.testzip():raise ValueError('ZIP CRC error')
            for n in z.namelist():
                if n.startswith('/') or '..' in Path(n).parts or n in data:raise ValueError('Unsafe or duplicate entry')
                data[n]=z.read(n)
    manifest=json.loads(data.pop('DELIVERY_MANIFEST.json'))
    expected={f['path'] for f in manifest['files']}
    if set(data)!=expected:raise ValueError('Manifest file set mismatch')
    for f in manifest['files']:
        b=data[f['path']]
        if len(b)!=f['bytes'] or hashlib.sha256(b).hexdigest()!=f['sha256']:raise ValueError('File integrity mismatch')
    return {'status':'passed','packages':len(packages),'files':len(expected),'totalBytes':sum(p['bytes'] for p in packages)}
