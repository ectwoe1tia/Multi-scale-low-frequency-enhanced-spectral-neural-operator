"""OOXML structure and image/text proximity. Visual semantics require review."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import posixpath
import re
import xml.etree.ElementTree as ET
import zipfile

NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
R='{'+NS['r']+'}'
I=[1,0,0,1,0,0]


def readable(color_value, background='#F7F9FC', minimum=4.5):
    def luminance(c):
        vals=[int(c[i:i+2],16)/255 for i in (1,3,5)]
        vals=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in vals]
        return sum(a*b for a,b in zip(vals,[.2126,.7152,.0722]))
    result=color_value
    for _ in range(30):
        a,b=sorted([luminance(result),luminance(background)])
        if (b+.05)/(a+.05)>=minimum:return result
        result='#'+''.join('%02X'%round(int(result[i:i+2],16)*.9) for i in (1,3,5))
    return result


def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def target_path(part,target):
    value=posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join(posixpath.dirname(part),target))
    if value=='..' or value.startswith('../'):raise ValueError('Relationship escapes package')
    return value


def relationships(z,part):
    folder,name=posixpath.split(part);rel=posixpath.join(folder,'_rels',name+'.rels')
    if rel not in z.namelist():return {}
    return {e.get('Id'):{'type':e.get('Type','').rsplit('/',1)[-1],'target':target_path(part,e.get('Target',''))} for e in ET.fromstring(z.read(rel)) if e.get('TargetMode')!='External'}


def linked(z,part,kind):
    return next((v['target'] for v in relationships(z,part).values() if v['type']==kind),None) if part else None


def first(nodes,xpath):
    for node in nodes:
        if node is not None:
            found=node.find(xpath,NS)
            if found is not None:return found
    return None


def color(el,theme,cmap):
    if el is None:return None
    n=next((n for n in el.iter() if n.tag.rsplit('}',1)[-1] in ('srgbClr','schemeClr','sysClr')),None)
    if n is None:return None
    typ=n.tag.rsplit('}',1)[-1]
    v=n.get('val') if typ=='srgbClr' else n.get('lastClr') if typ=='sysClr' else theme.get(cmap.get(n.get('val'),n.get('val')))
    if not v or not re.fullmatch('[0-9A-Fa-f]{6}',v):return None
    rgb=[int(v[i:i+2],16)/255 for i in (0,2,4)]
    for t in n:
        k=t.tag.rsplit('}',1)[-1];v=int(t.get('val',0))/100000
        if k=='tint':rgb=[c+(1-c)*v for c in rgb]
        elif k in ('shade','lumMod'):rgb=[c*v for c in rgb]
        elif k=='lumOff':rgb=[c+v for c in rgb]
    return '#'+''.join('%02X'%round(max(0,min(1,c))*255) for c in rgb)


def mult(a,b):
    return [a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]]


def xform(x,group=False):
    if x is None:return None
    off=x.find('a:off',NS);ext=x.find('a:ext',NS)
    if off is None or ext is None:return None
    ox,oy=int(off.get('x',0)),int(off.get('y',0));w,h=int(ext.get('cx',0)),int(ext.get('cy',0))
    r=int(x.get('rot',0))/60000*math.pi/180;c,s=math.cos(r),math.sin(r)
    fx=-1 if x.get('flipH')=='1' else 1;fy=-1 if x.get('flipV')=='1' else 1
    m=mult([1,0,0,1,ox+w/2,oy+h/2],mult([c,s,-s,c,0,0],[fx,0,0,fy,0,0]))
    m=mult(m,[1,0,0,1,-w/2,-h/2])
    if group:
        ch=x.find('a:chOff',NS);ce=x.find('a:chExt',NS)
        if ch is not None and ce is not None:
            cw,hh=int(ce.get('cx',0)),int(ce.get('cy',0))
            if not cw or not hh:return None
            m=mult(m,[w/cw,0,0,h/hh,-int(ch.get('x',0))*w/cw,-int(ch.get('y',0))*h/hh])
    return m,w,h


def placeholder(sh,root):
    ph=sh.find('.//p:ph',NS)
    if ph is None or root is None:return None
    for c in root.findall('.//p:sp',NS):
        p=c.find('.//p:ph',NS)
        if p is not None and p.get('idx','0')==ph.get('idx','0'):return c
    return None


def extract(path,out,include_references=False):
    path=Path(path);out=Path(out);digest=hashlib.sha256(path.read_bytes()).hexdigest()
    warnings=[];pages=[];fills=Counter();fonts=Counter()
    with zipfile.ZipFile(path) as z:
        pres=ET.fromstring(z.read('ppt/presentation.xml'));sz=pres.find('p:sldSz',NS)
        width,height=int(sz.get('cx')),int(sz.get('cy'));rels=relationships(z,'ppt/presentation.xml');ids=pres.findall('p:sldIdLst/p:sldId',NS)
        if not ids:raise ValueError('Presentation has no slides')
        for num,item in enumerate(ids,1):
            rel=rels.get(item.get(R+'id'))
            if not rel or rel['target'] not in z.namelist():raise ValueError('Missing slide at page '+str(num))
            part=rel['target'];root=ET.fromstring(z.read(part));sr=relationships(z,part)
            lp=linked(z,part,'slideLayout');mp=linked(z,lp,'slideMaster');tp=linked(z,mp,'theme')
            layout=ET.fromstring(z.read(lp)) if lp else None;master=ET.fromstring(z.read(mp)) if mp else None
            theme={};themefonts={};cmap={'tx1':'dk1','tx2':'dk2','bg1':'lt1','bg2':'lt2'}
            if tp:
                tr=ET.fromstring(z.read(tp))
                for n in tr.findall('.//a:clrScheme/*',NS):
                    if len(n):theme[n.tag.rsplit('}',1)[-1]]=n[0].get('val') if n[0].tag.endswith('srgbClr') else n[0].get('lastClr')
                for family in ('major','minor'):
                    fn=tr.find('.//a:'+family+'Font',NS)
                    if fn is not None:
                        for k in ('latin','ea'):
                            n=fn.find('a:'+k,NS);themefonts[family+'-'+k]=n.get('typeface') if n is not None else None
                        if not themefonts.get(family+'-ea'):themefonts[family+'-ea']=next((n.get('typeface') for n in fn.findall('a:font',NS) if n.get('script')=='Hans'),None)
            cm=first([master],'p:clrMap')
            if cm is not None:cmap.update(cm.attrib)
            cm=first([root,layout],'p:clrMapOvr/a:overrideClrMapping')
            if cm is not None:cmap.update(cm.attrib)
            background=color(first([root,layout,master],'p:cSld/p:bg'),theme,cmap)
            objects=[];unsupported=Counter();groupcount=0
            def walk(tree,parent=I,depth=0):
                nonlocal groupcount
                for sh in tree:
                    tag=sh.tag.rsplit('}',1)[-1]
                    if tag=='grpSp':
                        groupcount+=1;xf=xform(sh.find('p:grpSpPr/a:xfrm',NS),True)
                        if xf is None:unsupported['group-missing-transform']+=1;continue
                        walk(sh,mult(parent,xf[0]),depth+1);continue
                    if tag not in ('sp','pic','graphicFrame','cxnSp'):continue
                    ls=placeholder(sh,layout);ms=placeholder(ls if ls is not None else sh,master);chain=[sh,ls,ms]
                    x=first(chain,'p:spPr/a:xfrm') if tag!='graphicFrame' else sh.find('p:xfrm',NS)
                    xf=xform(x)
                    if xf is None:unsupported[tag+'-missing-geometry']+=1;continue
                    mat=mult(parent,xf[0]);w,h=xf[1:]
                    corners=[[mat[0]*px+mat[2]*py+mat[4],mat[1]*px+mat[3]*py+mat[5]] for px,py in ((0,0),(w,0),(w,h),(0,h))]
                    xs=[p[0] for p in corners];ys=[p[1] for p in corners];box=[min(xs)/width,min(ys)/height,(max(xs)-min(xs))/width,(max(ys)-min(ys))/height]
                    pr=sh.find('.//p:cNvPr',NS);sid=pr.get('id') if pr is not None else None
                    if sid is None:raise ValueError('Shape missing id')
                    txt='\n'.join(''.join(t.text or '' for t in p.findall('.//a:t',NS)) for p in sh.findall('.//a:p',NS)).strip()
                    typ='image' if tag=='pic' else 'table' if sh.find('.//a:tbl',NS) is not None else 'chart' if sh.find('.//{http://schemas.openxmlformats.org/drawingml/2006/chart}chart') is not None else 'graphicFrame' if tag=='graphicFrame' else 'line' if tag=='cxnSp' else 'text' if txt else 'shape'
                    fill=color(first(chain,'p:spPr/a:solidFill'),theme,cmap)
                    if fill:fills[fill]+=1
                    runs=[]
                    for run in sh.findall('.//a:r',NS):
                        rp=run.find('a:rPr',NS);t=run.find('a:t',NS);font=None
                        if rp is not None:
                            ea=rp.find('a:ea',NS);latin=rp.find('a:latin',NS);chosen=ea if ea is not None and ea.get('typeface') else latin
                            font=chosen.get('typeface') if chosen is not None else None
                        if font and font.startswith('+'):font=themefonts.get(('major' if font.startswith('+mj') else 'minor')+('-ea' if font.endswith('ea') else '-latin'))
                        fallback=not font
                        if not font:font=themefonts.get('minor-ea') or themefonts.get('minor-latin')
                        if font:fonts[font]+=1
                        runs.append({'text':(t.text or '') if t is not None else '', 'font':font,'themeFallback':fallback,'sizePt':float(rp.get('sz'))/100 if rp is not None and rp.get('sz') else None})
                    o={'id':sid,'type':typ,'z':len(objects),'groupDepth':depth,'box':[round(v,5) for v in box],'text':txt or None,'fill':fill,'runs':runs}
                    if typ=='image':
                        blip=sh.find('.//a:blip',NS);r=sr.get(blip.get(R+'embed')) if blip is not None else None;o['mediaPart']=r['target'] if r else None
                        crop=sh.find('.//a:srcRect',NS);o['crop']=dict(crop.attrib) if crop is not None else {}
                    if typ in ('chart','table','graphicFrame'):unsupported[typ+'-semantic-rebuild']+=1
                    objects.append(o)
            tree=root.find('p:cSld/p:spTree',NS)
            if tree is not None:walk(tree)
            texts=[o for o in objects if o['type']=='text'];images=[o for o in objects if o['type']=='image'];relations=[]
            for im in images:
                x,y,w,h=im['box'];area=w*h
                near=sorted(texts,key=lambda o:math.hypot(o['box'][0]+o['box'][2]/2-x-w/2,o['box'][1]+o['box'][3]/2-y-h/2))[:2]
                relations.append({'imageId':im['id'],'textIds':[o['id'] for o in near],'roleHypothesis':'background-or-composite-page' if area>.75 else 'main-visual' if area>.2 else 'supporting-visual' if area>.035 else 'icon-or-decoration','areaRatio':round(area,4),'basis':'geometry-only','confidence':'low','semanticRole':'unreviewed'})
            raster=not texts and any(o['box'][2]*o['box'][3]>.75 for o in images)
            if raster:warnings.append({'slide':num,'code':'raster-page','message':'Internal typography and layout require visual analysis/OCR.'})
            pages.append({'slide':num,'background':background,'objects':objects,'imageRelationships':relations,'rasterPage':raster,'groups':groupcount,'unsupported':dict(unsupported)})
        evidence={'schemaVersion':'2.0','sourceSha256':digest,'sourceFile':path.name,'canvasEmu':[width,height],'pages':pages,'warnings':warnings,'limitations':['Master/layout decorations are not flattened.','Paragraph style inheritance is partial; missing size remains null.','Geometry roles need visual review.']}
        dump(out/'evidence.json',evidence);style=out/'style';style.mkdir(exist_ok=True)
        selected=[];seen=set()
        for p in pages:
            sig=(p['rasterPage'],min(6,sum(o['type']=='text' for o in p['objects'])),min(4,sum(o['type']=='image' for o in p['objects'])),p['background'])
            if sig not in seen:seen.add(sig);selected.append(p)
            if len(selected)==6:break
        for idx in sorted(set(round(i*(len(pages)-1)/5) for i in range(6))):
            if len(selected)>=6:break
            if pages[idx] not in selected:selected.append(pages[idx])
        selected.sort(key=lambda p:p['slide'])
        palette=[c for c,_ in fills.most_common() if max(int(c[i:i+2],16) for i in (1,3,5))-min(int(c[i:i+2],16) for i in (1,3,5))>35]
        theme={'schemaVersion':'2.0','id':'style-'+digest[:12],'colors':{'primary':palette[0] if palette else '#174B63','accent':palette[1] if len(palette)>1 else '#19A897','background':'#F7F9FC','surface':'#FFFFFF','text':'#172B3A','muted':'#536777'},'fonts':{'body':fonts.most_common(1)[0][0] if fonts else 'Microsoft YaHei','fallback':'Arial'},'typography':{'title':44,'body':25,'caption':17},'provenance':{'palette':'observed-fills' if palette else 'baseline-default','font':'observed-or-theme-fallback' if fonts else 'baseline-default','background':'baseline-default'},'canvas':[1280,720]}
        theme['observedPalette']=palette[:12]
        for key in ('primary','accent'):
            original=theme['colors'][key];theme['colors'][key]=readable(original)
            if original!=theme['colors'][key]:theme['provenance'][key]='contrast-adjusted from '+original
        dump(style/'theme.json',theme)
        from rebuild import theme_css, DEFAULT_LAYOUTS
        (style/'theme.css').write_text(theme_css(theme),encoding='utf-8');layouts=json.loads(json.dumps(DEFAULT_LAYOUTS));observed=[]
        for p in selected:
            observed.append({'sourceSlide':p['slide'],'rasterPage':p['rasterPage'],'boxes':[{'role':o['type'],'box':o['box']} for o in p['objects']],'imageRelationships':p['imageRelationships']})
            ims=[o for o in p['objects'] if o['type']=='image' and .12<o['box'][2]*o['box'][3]<.7]
            if ims and any(o['type']=='text' for o in p['objects']):
                im=max(ims,key=lambda o:o['box'][2]*o['box'][3]);side='left' if im['box'][0]+im['box'][2]/2<.5 else 'right'
                layouts['layouts'].append({'id':'observed-'+str(p['slide']),'kind':'split','visualSide':side,'visualFraction':round(max(.35,min(.6,im['box'][2])),3),'sourceSlide':p['slide'],'status':'geometry-derived','maxBodyItems':4})
            refs=style/'references';refs.mkdir(exist_ok=True)
            rects=''.join('<rect x="%s" y="%s" width="%s" height="%s" fill="%s" fill-opacity=".22" stroke="#456DB0"/>'%(o['box'][0]*960,o['box'][1]*540,o['box'][2]*960,o['box'][3]*540,'#179A89' if o['type']=='image' else '#456DB0') for o in p['objects'])
            (refs/('slide-%03d.svg'%p['slide'])).write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 540"><rect width="960" height="540" fill="white"/>'+rects+'</svg>',encoding='utf-8')
            if include_references:
                try:
                    from PIL import Image
                    import io
                    ims=[o for o in p['objects'] if o['type']=='image' and o.get('mediaPart')]
                    if ims:
                        im=max(ims,key=lambda o:o['box'][2]*o['box'][3])
                        with Image.open(io.BytesIO(z.read(im['mediaPart']))) as pic:
                            pic.thumbnail((640,360));pic.convert('RGB').save(refs/('source-image-%03d.webp'%p['slide']),'WEBP',quality=65)
                except (ImportError,OSError,KeyError):warnings.append({'slide':p['slide'],'code':'preview-unavailable'})
        dump(style/'layouts.json',layouts);dump(style/'observed-layouts.json',observed)
        dump(style/'image-relations.json',[{'slide':p['slide'],'relations':p['imageRelationships']} for p in selected])
        dump(style/'manifest.json',{'schemaVersion':'2.0','version':'0.2.0','id':theme['id'],'sourceSha256':digest,'visualReview':'pending','status':'candidate','selectedSlides':[p['slide'] for p in selected],'rasterPages':sum(p['rasterPage'] for p in pages)})
        (style/'style.md').write_text('# 风格候选\n\n基础版式用于承载新内容。observed-* 的方向和图像比例来自源页，尚需视觉审阅。\n\n图片关系是几何推断；未确认素材是在举证、说明流程、营造气氛或装饰。整页位图的内部布局需要视觉模型或 OCR。\n\n审阅时记录：图片支持的观点、主体位置、裁剪、留白、可替代素材类型、误用场景及证据页码。\n',encoding='utf-8')
        report={'source':path.name,'pages':len(pages),'objects':sum(len(p['objects']) for p in pages),'rasterPages':sum(p['rasterPage'] for p in pages),'groups':sum(p['groups'] for p in pages),'warnings':warnings,'style':str(style)}
        dump(out/'extract-report.json',report);return report
