"""Validate data and compose an offline Vue presentation."""
import base64
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT=Path(__file__).resolve().parents[1]
DEFAULT_LAYOUTS={'schemaVersion':'2.0','layouts':[
    {'id':'cover','kind':'cover','maxBodyItems':2},
    {'id':'split','kind':'split','visualSide':'right','visualFraction':0.46,'maxBodyItems':4},
    {'id':'metrics','kind':'metrics','maxBodyItems':3},
    {'id':'timeline','kind':'timeline','maxBodyItems':4},
    {'id':'comparison','kind':'comparison','maxBodyItems':4},
    {'id':'closing','kind':'closing','maxBodyItems':3}]}


def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def theme_css(theme):
    colors=theme['colors'];fonts=theme['fonts'];sizes=theme['typography']
    for key in ('primary','accent','background','surface','text','muted'):
        if not re.fullmatch('#[a-fA-F0-9]{6}',colors.get(key,'')):raise ValueError('Invalid color '+key)
    for value in fonts.values():
        if not isinstance(value,str) or re.search(r'[<>;{}\\\n\r"]',value):raise ValueError('Invalid font name')
    for key in ('title','body','caption'):
        if not isinstance(sizes.get(key),(int,float)) or not 10<=sizes[key]<=80:raise ValueError('Invalid typography '+key)
    return ':root{'+''.join('--'+k+':'+v+';' for k,v in colors.items())+'--font:"'+fonts['body']+'","'+fonts['fallback']+'",sans-serif;'+''.join('--size-'+k+':'+str(v)+'px;' for k,v in sizes.items())+'}\n'


def validate(style,deck):
    theme=read(style/'theme.json');layouts=read(style/'layouts.json');manifest=read(style/'manifest.json')
    if theme.get('schemaVersion')!='2.0' or layouts.get('schemaVersion')!='2.0':raise ValueError('Expected schemaVersion 2.0')
    theme_css(theme)
    if not isinstance(layouts.get('layouts'),list):raise ValueError('layouts must be an array')
    known={}
    for layout in layouts['layouts']:
        if layout.get('kind') not in ('cover','split','metrics','timeline','comparison','closing'):raise ValueError('Unsupported layout kind')
        if layout['id'] in known:raise ValueError('Duplicate layout id')
        if layout['kind']=='split':
            if layout.get('visualSide','right') not in ('left','right') or not .25<=layout.get('visualFraction',.46)<=.7:raise ValueError('Invalid split proportions')
        known[layout['id']]=layout
    if deck.get('schemaVersion')!='2.0':raise ValueError('Deck schemaVersion must be 2.0')
    if not isinstance(deck.get('slides'),list) or not 1<=len(deck['slides'])<=200:raise ValueError('Deck requires 1..200 slides')
    seen=set()
    for s in deck['slides']:
        if s.get('id') in seen or not isinstance(s.get('id'),str):raise ValueError('Slide id missing or duplicate')
        seen.add(s['id'])
        if s.get('layout') not in known:raise ValueError('Unknown layout: '+str(s.get('layout')))
        if not isinstance(s.get('title'),str) or not s['title'].strip() or len(s['title'])>70:raise ValueError('Title must have 1..70 characters')
        body=s.get('body',[])
        if not isinstance(body,list) or len(body)>known[s['layout']].get('maxBodyItems',4) or any(not isinstance(t,str) or len(t)>100 for t in body):raise ValueError('Body exceeds layout capacity')
        kind=known[s['layout']]['kind']
        required={'metrics':'metrics','timeline':'steps','comparison':'columns'}.get(kind)
        if required and required not in s:raise ValueError('Layout requires '+required)
        for field in ('eyebrow','footer','tag'):
            if field in s and (not isinstance(s[field],str) or len(s[field])>55):raise ValueError('Invalid '+field)
        for field in ('metrics','steps','columns'):
            if field in s and (not isinstance(s[field],list) or not 1<=len(s[field])<=4):raise ValueError('Invalid '+field+' count')
        if 'metrics' in s:
            for m in s['metrics']:
                if not isinstance(m.get('value'),str) or len(m['value'])>12 or not isinstance(m.get('label'),str) or len(m['label'])>25:raise ValueError('Metric exceeds capacity')
        if 'steps' in s:
            for m in s['steps']:
                if not isinstance(m.get('title'),str) or len(m['title'])>18 or not isinstance(m.get('detail'),str) or len(m['detail'])>55:raise ValueError('Step exceeds capacity')
        if 'columns' in s:
            if len(s['columns'])!=2:raise ValueError('Comparison needs two columns')
            for c in s['columns']:
                if not isinstance(c.get('title'),str) or len(c['title'])>25 or not isinstance(c.get('items'),list) or len(c['items'])>4 or any(not isinstance(t,str) or len(t)>60 for t in c['items']):raise ValueError('Invalid comparison content')
        if 'visual' in s:
            v=s['visual']
            if 'caption' in v and (not isinstance(v['caption'],str) or len(v['caption'])>90):raise ValueError('Visual caption too long')
            if v.get('kind') not in ('diagram','image','bars'):raise ValueError('Unknown visual kind')
            if v['kind']=='image' and not isinstance(v.get('path'),str):raise ValueError('Image path missing')
            if v['kind'] in ('diagram','bars'):
                if not isinstance(v.get('items'),list) or not 1<=len(v['items'])<=4:raise ValueError('Visual requires 1..4 items')
                for i in v['items']:
                    if not isinstance(i.get('label'),str) or len(i['label'])>20:raise ValueError('Visual label too long')
                    if v['kind']=='bars' and (not isinstance(i.get('value'),(int,float)) or not 0<=i['value']<=100):raise ValueError('Bar value must be 0..100')
    return theme,layouts,manifest


def rebuild(style,deck_path,out):
    style=Path(style);deck_path=Path(deck_path);out=Path(out)
    deck=read(deck_path);theme,layouts,manifest=validate(style,deck)
    for s in deck['slides']:
        visual=s.get('visual',{})
        if visual.get('kind')=='image':
            path=(deck_path.parent/visual['path']).resolve();base=deck_path.parent.resolve()
            if base not in path.parents:raise ValueError('Image must be under deck directory')
            suffix=path.suffix.lower()
            if suffix not in ('.png','.jpg','.jpeg'):raise ValueError('Baseline accepts PNG/JPEG images')
            if path.stat().st_size>5_000_000:raise ValueError('Image exceeds 5 MB')
            visual['src']='data:image/'+('png' if suffix=='.png' else 'jpeg')+';base64,'+base64.b64encode(path.read_bytes()).decode()
    out.mkdir(parents=True,exist_ok=True)
    runtime=ROOT/'runtime'
    for name in ('index.html','app.js','base.css'):
        shutil.copyfile(runtime/name,out/name)
    vue3=ROOT/'node_modules/vue/dist/vue.global.prod.js'
    vue=vue3 if vue3.exists() else ROOT/'vendor/vue/vue.min.js'
    if not vue.exists():raise ValueError('Vue runtime missing; run npm install or restore vendor runtime')
    shutil.copyfile(vue,out/'vue.js')
    (out/'theme.css').write_text(theme_css(theme),encoding='utf-8')
    payload=json.dumps({'deck':deck,'theme':theme,'layouts':layouts['layouts'],'manifest':manifest},ensure_ascii=False).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    (out/'data.js').write_text('window.PRESENTATION = '+payload+';\n',encoding='utf-8')
    report={'schemaVersion':'2.0','slides':len(deck['slides']),'themeId':theme['id'],'visualReview':manifest.get('visualReview'),'runtime':'Vue 3 (npm)' if vue3.exists() else 'Vue 2.6.12 offline compatibility','layoutIds':[s['layout'] for s in deck['slides']],'html':'index.html','browserCheck':'not-run'}
    (out/'build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return out/'index.html'
