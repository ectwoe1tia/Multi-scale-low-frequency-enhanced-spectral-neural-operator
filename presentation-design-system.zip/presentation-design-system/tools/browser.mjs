// Browser-first inspection, following PPTWork's ready -> screenshot -> export flow.
// Node built-ins avoid a Playwright installation for the portable baseline.
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {parseArgs} from '../vendor/pptwork/parse-args.mjs';

const {positional} = parseArgs(process.argv.slice(2));
const [htmlPath, outputPath] = positional;
if (!htmlPath || !outputPath) throw new Error('Usage: node tools/browser.mjs <index.html> <output>');
const candidates=[process.env.PPT_BROWSER_EXECUTABLE,'C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe','/usr/bin/chromium','/usr/bin/google-chrome','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'];
let executable;
for(const p of candidates.filter(Boolean)){try{await fs.access(p);executable=p;break;}catch{}}
if(!executable)throw new Error('Install Chrome/Edge or set PPT_BROWSER_EXECUTABLE');
const profile=await fs.mkdtemp(path.join(os.tmpdir(),'presentation-cdp-'));
const child=spawn(executable,['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--remote-debugging-port=0',`--user-data-dir=${profile}`,'about:blank'],{windowsHide:true,stdio:['ignore','pipe','pipe']});
let ws,seq=0,session;const waiting=new Map();
try{
  const endpoint=await new Promise((resolve,reject)=>{
    let log='';const timer=setTimeout(()=>reject(new Error('Browser did not expose DevTools within 25 seconds: '+log.slice(-800))),25000);
    child.once('error',e=>{clearTimeout(timer);reject(e)});
    child.once('exit',code=>{clearTimeout(timer);reject(new Error('Browser exited '+code+': '+log.slice(-800)))});
    child.stderr.on('data',chunk=>{log+=chunk;const m=log.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});
  });
  ws=new WebSocket(endpoint);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
  ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id&&waiting.has(m.id)){const {resolve,reject,timer}=waiting.get(m.id);waiting.delete(m.id);clearTimeout(timer);m.error?reject(new Error(JSON.stringify(m.error))):resolve(m.result)}});
  const send=(method,params={},sess=session)=>new Promise((resolve,reject)=>{const id=++seq;const timer=setTimeout(()=>{waiting.delete(id);reject(new Error('CDP timeout '+method))},30000);waiting.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params,...(sess?{sessionId:sess}:{})}))});
  const target=await send('Target.createTarget',{url:'about:blank'},null);session=(await send('Target.attachToTarget',{targetId:target.targetId,flatten:true},null)).sessionId;
  await send('Page.enable');await send('Runtime.enable');await send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
  await send('Page.navigate',{url:pathToFileURL(path.resolve(htmlPath)).href});
  async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
  let ready=false;
  for(let i=0;i<100;i++){if(await evaluate('window.__PPT_READY__ === true')){ready=true;break}await new Promise(r=>setTimeout(r,100));}
  if(!ready)throw new Error('Vue did not finish rendering; inspect HTML scripts and dependencies');
  const scene=await evaluate(`(() => {
    const issues=[]; const slides=[];
    const rgb=(s)=>{const a=s.match(/[\\d.]+/g);return a?{hex:a.slice(0,3).map(x=>Math.round(Number(x)).toString(16).padStart(2,'0')).join('').toUpperCase(),alpha:a.length>3?Number(a[3]):1}:{hex:'000000',alpha:1}};
    for(const [index,slide] of [...document.querySelectorAll('.slide')].entries()){
      const box=slide.getBoundingClientRect();const objects=[];
      for(const el of slide.querySelectorAll('[data-pptx]')){
        const r=el.getBoundingClientRect(),css=getComputedStyle(el),type=el.dataset.pptx;
        if(!r.width||!r.height||css.display==='none')continue;
        const x=r.left-box.left,y=r.top-box.top;
        if(x<-.5||y<-.5||x+r.width>1280.5||y+r.height>720.5)issues.push({slide:index+1,code:'outside-slide',text:el.textContent.slice(0,60)});
        const bounds=el.parentElement.closest('[data-bound]');
        if(bounds){const b=bounds.getBoundingClientRect();if(r.left<b.left-1||r.top<b.top-1||r.right>b.right+1||r.bottom>b.bottom+1)issues.push({slide:index+1,code:'outside-content-region',text:el.textContent.slice(0,60)})}
        if(el.clientWidth>0 && (el.scrollWidth>el.clientWidth+2||el.scrollHeight>el.clientHeight+2))issues.push({slide:index+1,code:'overflow',text:el.textContent.slice(0,60)});
        const common={type,x,y,w:r.width,h:r.height};
        if(type==='rect'){
          const fill=rgb(css.backgroundColor);if(fill.alpha>0)objects.push({...common,fill:fill.hex,alpha:fill.alpha});
        }else if(type==='image'){
          if(!el.complete||!el.naturalWidth){issues.push({slide:index+1,code:'image-not-loaded'});continue;}
          objects.push({...common,src:el.src,alt:el.alt});
        }else if(type==='text'){
          if(el.children.length)issues.push({slide:index+1,code:'nested-text-not-supported',text:el.textContent.slice(0,60)});
          // Measure individual characters so Chinese and Latin wrapping follows the browser.
          const lines=[];const walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let node;
          while(node=walker.nextNode()){
            for(let n=0;n<node.length;){const cp=node.textContent.codePointAt(n);const length=cp>65535?2:1;const range=document.createRange();range.setStart(node,n);range.setEnd(node,n+length);const q=range.getBoundingClientRect();const text=node.textContent.slice(n,n+length);n+=length;if(!q.height)continue;
              let line=lines.find(l=>Math.abs(l.top-q.top)<2);if(!line){line={top:q.top,left:q.left,right:q.right,height:q.height,text:''};lines.push(line)}line.text+=text;line.left=Math.min(line.left,q.left);line.right=Math.max(line.right,q.right);line.height=Math.max(line.height,q.height);
            }
          }
          for(const l of lines){if(!l.text.trim())continue;objects.push({type:'text',x:l.left-box.left,y:l.top-box.top,w:l.right-l.left,h:l.height,text:l.text,font:css.fontFamily.split(',')[0].replace(/["]/g,''),size:parseFloat(css.fontSize),bold:Number(css.fontWeight)>=600,color:rgb(css.color).hex});}
        }else issues.push({slide:index+1,code:'unknown-element-type',type});
      }
      slides.push({id:slide.dataset.slideId,layout:slide.dataset.layout,background:rgb(getComputedStyle(slide).backgroundColor).hex,objects,clip:{x:box.left+scrollX,y:box.top+scrollY,width:1280,height:720,scale:1}});
    }
    return {schemaVersion:'2.0',canvas:[1280,720],vueVersion:window.__VUE_VERSION__,slides,issues};
  })()`);
  if(!scene.slides.length)throw new Error('No slides rendered');
  await fs.mkdir(outputPath,{recursive:true});
  for(let i=0;i<scene.slides.length;i++){
    const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:scene.slides[i].clip});
    await fs.writeFile(path.join(outputPath,`slide-${String(i+1).padStart(2,'0')}.png`),Buffer.from(shot.data,'base64'));
  }
  await fs.writeFile(path.join(outputPath,'scene.json'),JSON.stringify(scene,null,2));
  const result={slides:scene.slides.length,vueVersion:scene.vueVersion,issues:scene.issues,status:scene.issues.length?'failed':'passed',editableTextObjects:scene.slides.reduce((n,s)=>n+s.objects.filter(o=>o.type==='text').length,0)};
  await fs.writeFile(path.join(outputPath,'check-report.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify(result));
  if(scene.issues.length)process.exitCode=2;
  await send('Browser.close',{},null).catch(()=>{});
}finally{
  for(const {timer} of waiting.values())clearTimeout(timer);
  if(ws)ws.close();
  child.kill();
  // Only remove the task-owned temporary browser profile; never touch a user profile.
  await new Promise(r=>setTimeout(r,300));
  await fs.rm(profile,{recursive:true,force:true,maxRetries:3,retryDelay:200}).catch(()=>{});
}
