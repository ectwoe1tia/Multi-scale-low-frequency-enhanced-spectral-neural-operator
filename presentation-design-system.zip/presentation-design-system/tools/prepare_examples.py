# -*- coding: utf-8 -*-
"""Build portable neutral-content examples and the reviewed dark-tech variant."""
import json
from pathlib import Path
from extract import dump
from rebuild import rebuild,theme_css
from native_layout import native_scene
from pptx_writer import write_pptx

ROOT=Path(__file__).resolve().parents[1]


def main():
    style=ROOT/'styles/source-1'
    manifest=json.loads((style/'manifest.json').read_text(encoding='utf-8'))
    review=json.loads((style/'visual-review.json').read_text(encoding='utf-8'))
    review['sourceSha256']=manifest['sourceSha256'];dump(style/'visual-review.json',review)
    manifest['visualReview']='selected-pages-reviewed';manifest['status']='reviewed-candidate';dump(style/'manifest.json',manifest)
    theme=json.loads((style/'theme.json').read_text(encoding='utf-8'))
    theme['colors']={'primary':'#34C6F3','accent':'#F4CD3F','background':'#111C32','surface':'#1D2B46','text':'#F2F6FB','muted':'#B5C4D9'}
    theme['provenance']={'palette':'AI visual approximation from selected source thumbnails','font':'baseline replacement; font cannot be inferred reliably from raster','background':'AI visual approximation'}
    dump(style/'theme.json',theme);(style/'theme.css').write_text(theme_css(theme),encoding='utf-8')
    (style/'style.md').write_text('# 深蓝科技风格：选页视觉审阅\n\n观察页为 1、8、15、21、28、35。深蓝色承担背景，青色用于章节和技术关键词，黄色用于重要数据与证据标注，正文保持浅色。这里的颜色是视觉近似值，不是精确取色。\n\n首页用低对比电路或设备意象建立行业语境。功能页使用成对界面截图举证；案例页使用文件/奖项与指标的左右组合；工作页使用等高照片组；附录使用同宽扫描件及标签。\n\n把素材按作用选择：概念背景负责氛围，产品界面负责能力证明，现场照片负责真实经历，合同和证书负责佐证。不可用无关素材代替事实证据。\n\n详见 visual-review.json。便携包不附带原始品牌、联系方式和完整业务材料；references 中保留结构线框。新样张使用原创中性内容与图形。\n',encoding='utf-8')
    dump(style/'recipes.json',{'schemaVersion':'2.0','sequences':[{'purpose':'技术方案介绍','layouts':['cover','split','comparison','metrics','closing'],'guidance':'先明确方案，再用界面/图解解释能力，用真实材料支持指标。'}]})
    reports=[]
    for name,stylepath in [('demo',ROOT/'styles/baseline'),('tech-dark',style),('source-layout',ROOT/'styles/source-3')]:
        deck=json.loads((ROOT/'decks/demo.json').read_text(encoding='utf-8'))
        if name!='demo':deck['slides']=deck['slides'][:2]+deck['slides'][-1:]
        if name=='source-layout':
            layouts=json.loads((stylepath/'layouts.json').read_text(encoding='utf-8'))['layouts']
            observed=next((l for l in layouts if l['id'].startswith('observed-')),None)
            if observed:deck['slides'][1]['layout']=observed['id']
        deckpath=ROOT/'decks'/(name+'.json');dump(deckpath,deck)
        out=ROOT/'examples'/name;rebuild(stylepath,deckpath,out)
        native_scene(out/'index.html',ROOT/'examples'/(name+'-checks'))
        reports.append(write_pptx(ROOT/'examples'/(name+'-checks')/'scene.json',ROOT/'examples'/(name+'.pptx')))
    dump(ROOT/'reports/example-validation.json',reports)
    from PIL import Image
    files=sorted((ROOT/'examples/demo-checks').glob('slide-*.png'))
    canvas=Image.new('RGB',(960,270*((len(files)+1)//2)),'#dfe5ea')
    for i,p in enumerate(files):
        with Image.open(p) as image:
            image.thumbnail((480,270));canvas.paste(image,((i%2)*480,(i//2)*270))
    canvas.save(ROOT/'examples/preview.png')
    print('Built three HTML/PPTX examples, 13 total slides')


if __name__=='__main__':main()
