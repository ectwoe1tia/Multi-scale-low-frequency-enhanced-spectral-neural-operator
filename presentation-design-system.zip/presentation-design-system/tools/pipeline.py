"""Presentation baseline: extract, rebuild, check, export, pack, verify-pack."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    from extract import extract
    from rebuild import rebuild
    from package_delivery import pack, verify
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='cmd', required=True)
    s = sub.add_parser('extract'); s.add_argument('source', type=Path); s.add_argument('output', type=Path)
    s.add_argument('--references', action='store_true')
    s = sub.add_parser('rebuild'); s.add_argument('style', type=Path); s.add_argument('deck', type=Path); s.add_argument('output', type=Path)
    for cmd in ('check','export'):
        s = sub.add_parser(cmd); s.add_argument('html', type=Path); s.add_argument('output', type=Path)
        s.add_argument('--engine',choices=['browser','native'],default='browser')
    s = sub.add_parser('pack'); s.add_argument('source', type=Path); s.add_argument('output', type=Path)
    s = sub.add_parser('verify-pack'); s.add_argument('folder', type=Path)
    a = p.parse_args()
    if a.cmd == 'extract':
        files = sorted(a.source.rglob('*.pptx')) if a.source.is_dir() else [a.source]
        for f in files: print(json.dumps(extract(f, a.output/f.stem if a.source.is_dir() else a.output, a.references), ensure_ascii=False))
    elif a.cmd == 'rebuild': print(rebuild(a.style, a.deck, a.output))
    elif a.cmd in ('check','export'):
        target = a.output if a.cmd == 'check' else a.output.parent/(a.output.stem+'-checks')
        if a.engine=='native':
            from native_layout import native_scene
            native_scene(a.html,target)
        else:
            subprocess.run(['node',str(ROOT/'tools/browser.mjs'),str(a.html.resolve()),str(target.resolve())],check=True)
        if a.cmd == 'export':
            from pptx_writer import write_pptx
            print(json.dumps(write_pptx(target/'scene.json',a.output),ensure_ascii=False))
    elif a.cmd == 'pack': print(json.dumps(pack(a.source,a.output),ensure_ascii=False,indent=2))
    else: print(json.dumps(verify(a.folder),indent=2))


if __name__ == '__main__':
    try: main()
    except (ValueError,OSError,KeyError,subprocess.CalledProcessError) as e:
        print('ERROR: '+str(e),file=sys.stderr);sys.exit(1)
