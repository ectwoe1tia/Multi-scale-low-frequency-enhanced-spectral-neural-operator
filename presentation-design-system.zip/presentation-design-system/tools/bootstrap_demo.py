"""Create the neutral demo style; never label it as extracted from a source deck."""
from pathlib import Path
import json
from rebuild import DEFAULT_LAYOUTS,theme_css
from extract import dump

root=Path(__file__).resolve().parents[1];style=root/'styles/baseline'
theme={'schemaVersion':'2.0','id':'baseline-teal','colors':{'primary':'#174B63','accent':'#19A897','background':'#F7F9FC','surface':'#FFFFFF','text':'#172B3A','muted':'#536777'},'fonts':{'body':'Microsoft YaHei','fallback':'Arial'},'typography':{'title':44,'body':25,'caption':17},'provenance':{'kind':'original-baseline-design'},'canvas':[1280,720]}
dump(style/'theme.json',theme);dump(style/'layouts.json',DEFAULT_LAYOUTS);dump(style/'manifest.json',{'schemaVersion':'2.0','id':'baseline-teal','version':'0.2.0','visualReview':'baseline-design','source':'original'})
(style/'theme.css').write_text(theme_css(theme),encoding='utf-8')
(style/'style.md').write_text('# 基础青蓝风格\n\n浅灰背景承托白色内容卡片，青蓝用于标题，青绿标示流程和重点。单页保留一个主要结论。图像和正文分区，避免在复杂背景上叠加大段文字。\n\n这是原创基板样式，不是从源 PPT 自动提取的艺术结论。\n',encoding='utf-8')
