"""Native editable text/rect/image PPTX adapter for the measured DOM subset."""
import base64
import hashlib
import json
from pathlib import Path
import re
from xml.sax.saxutils import escape, quoteattr
import xml.etree.ElementTree as ET
import zipfile

P='http://schemas.openxmlformats.org/presentationml/2006/main'
A='http://schemas.openxmlformats.org/drawingml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
HEADER='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
EMU=9525


def relation(items):
    return HEADER+'<Relationships xmlns="'+REL+'">'+''.join('<Relationship Id="rId%d" Type="%s/%s" Target=%s/>'%(i,R,k,quoteattr(t)) for i,k,t in items)+'</Relationships>'


def transform(o):
    return '<a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'%(round(o['x']*EMU),round(o['y']*EMU),max(1,round(o['w']*EMU)),max(1,round(o['h']*EMU)))


def solid(color,alpha=1):
    if not re.fullmatch('[0-9A-Fa-f]{6}',color):raise ValueError('Invalid scene color')
    return '<a:solidFill><a:srgbClr val="'+color+'"><a:alpha val="'+str(round(alpha*100000))+'"/></a:srgbClr></a:solidFill>'


def write_pptx(scene_path,output):
    scene=json.loads(Path(scene_path).read_text(encoding='utf-8'))
    if scene.get('issues'):raise ValueError('Browser check failed; refusing PPTX export')
    if scene.get('canvas')!=[1280,720] or not scene.get('slides'):raise ValueError('Expected measured 1280x720 slides')
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    media={};slides=[];reports=[]
    rootattrs=' xmlns:p="'+P+'" xmlns:a="'+A+'" xmlns:r="'+R+'"'
    for n,s in enumerate(scene['slides'],1):
        shapes=[];rels=[(1,'slideLayout','../slideLayouts/slideLayout1.xml')];counts={'text':0,'rect':0,'image':0}
        for sid,o in enumerate(s['objects'],2):
            typ=o['type']
            if typ not in counts:raise ValueError('Unsupported scene object '+typ)
            counts[typ]+=1
            nv='<p:cNvPr id="%d" name="%s %d"/>'%(sid,typ,sid)
            if typ=='image':
                m=re.fullmatch(r'data:image/(png|jpeg);base64,(.+)',o['src'],re.S)
                if not m:raise ValueError('Image must be embedded PNG/JPEG')
                data=base64.b64decode(m[2],validate=True);ext='png' if m[1]=='png' else 'jpg';name=hashlib.sha256(data).hexdigest()[:20]+'.'+ext;media[name]=data
                rid=len(rels)+1;rels.append((rid,'image','../media/'+name))
                shapes.append('<p:pic><p:nvPicPr>'+nv+'<p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rId%d"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr>'%rid+transform(o)+'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>');continue
            sp='<p:sp><p:nvSpPr>'+nv+'<p:cNvSpPr txBox="'+('1' if typ=='text' else '0')+'"/><p:nvPr/></p:nvSpPr><p:spPr>'+transform(o)+'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
            sp+=(solid(o['fill'],o.get('alpha',1)) if typ=='rect' else '<a:noFill/>')+'<a:ln><a:noFill/></a:ln></p:spPr>'
            if typ=='text':
                size=round(o['size']*.75*100)
                # Each browser-measured line is one editable PowerPoint textbox.
                sp+='<p:txBody><a:bodyPr wrap="none" lIns="0" tIns="0" rIns="0" bIns="0" anchor="ctr"><a:noAutofit/></a:bodyPr><a:lstStyle/><a:p><a:pPr algn="l" marL="0" indent="0"><a:spcBef><a:spcPts val="0"/></a:spcBef><a:spcAft><a:spcPts val="0"/></a:spcAft></a:pPr><a:r><a:rPr lang="zh-CN" sz="%d" b="%d">'%(size,bool(o.get('bold')))+solid(o['color'])+'<a:latin typeface='+quoteattr(o['font'])+'/><a:ea typeface='+quoteattr(o['font'])+'/></a:rPr><a:t xml:space="preserve">'+escape(o['text'])+'</a:t></a:r><a:endParaRPr lang="zh-CN" sz="%d"/></a:p></p:txBody>'%size
            shapes.append(sp+'</p:sp>')
        tree='<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
        doc=HEADER+'<p:sld'+rootattrs+'><p:cSld><p:bg><p:bgPr>'+solid(s['background'])+'<a:effectLst/></p:bgPr></p:bg><p:spTree>'+tree+''.join(shapes)+'</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'
        slides.append((doc,relation(rels)));reports.append({'slide':n,**counts})
    base_tree='<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>'
    cmap='<p:clrMap accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" bg1="lt1" bg2="lt2" folHlink="folHlink" hlink="hlink" tx1="dk1" tx2="dk2"/>'
    theme=HEADER+'<a:theme xmlns:a="'+A+'" name="Baseline"><a:themeElements><a:clrScheme name="Baseline">'+''.join('<a:'+k+'><a:srgbClr val="'+v+'"/></a:'+k+'>' for k,v in [('dk1','172B3A'),('lt1','FFFFFF'),('dk2','174B63'),('lt2','F7F9FC'),('accent1','174B63'),('accent2','19A897'),('accent3','E6B55A'),('accent4','647B91'),('accent5','8EB8B0'),('accent6','A7B8CD'),('hlink','0563C1'),('folHlink','954F72')])+'</a:clrScheme><a:fontScheme name="Baseline"><a:majorFont><a:latin typeface="Arial"/><a:ea typeface="Microsoft YaHei"/><a:cs typeface="Arial"/></a:majorFont><a:minorFont><a:latin typeface="Arial"/><a:ea typeface="Microsoft YaHei"/><a:cs typeface="Arial"/></a:minorFont></a:fontScheme><a:fmtScheme name="Baseline"><a:fillStyleLst>'+('<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'*3)+'</a:fillStyleLst><a:lnStyleLst>'+('<a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>'*3)+'</a:lnStyleLst><a:effectStyleLst>'+('<a:effectStyle><a:effectLst/></a:effectStyle>'*3)+'</a:effectStyleLst><a:bgFillStyleLst>'+('<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'*3)+'</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>'
    files={
      '_rels/.rels':relation([(1,'officeDocument','ppt/presentation.xml')]),
      'ppt/presentation.xml':HEADER+'<p:presentation'+rootattrs+'><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>'+''.join('<p:sldId id="%d" r:id="rId%d"/>'%(255+n,n+1) for n in range(1,len(slides)+1))+'</p:sldIdLst><p:sldSz cx="12192000" cy="6858000" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>',
      'ppt/_rels/presentation.xml.rels':relation([(1,'slideMaster','slideMasters/slideMaster1.xml')]+[(n+1,'slide','slides/slide%d.xml'%n) for n in range(1,len(slides)+1)]),
      'ppt/slideMasters/slideMaster1.xml':HEADER+'<p:sldMaster'+rootattrs+'>'+base_tree+cmap+'<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles></p:sldMaster>',
      'ppt/slideMasters/_rels/slideMaster1.xml.rels':relation([(1,'slideLayout','../slideLayouts/slideLayout1.xml'),(2,'theme','../theme/theme1.xml')]),
      'ppt/slideLayouts/slideLayout1.xml':HEADER+'<p:sldLayout'+rootattrs+' type="blank" preserve="1">'+base_tree+'<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>',
      'ppt/slideLayouts/_rels/slideLayout1.xml.rels':relation([(1,'slideMaster','../slideMasters/slideMaster1.xml')]),
      'ppt/theme/theme1.xml':theme}
    overrides=[('ppt/presentation.xml','presentation'),('ppt/slideMasters/slideMaster1.xml','slideMaster'),('ppt/slideLayouts/slideLayout1.xml','slideLayout')]
    for i,(doc,rels) in enumerate(slides,1):
        files['ppt/slides/slide%d.xml'%i]=doc;files['ppt/slides/_rels/slide%d.xml.rels'%i]=rels;overrides.append(('ppt/slides/slide%d.xml'%i,'slide'))
    files['[Content_Types].xml']=HEADER+'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpg" ContentType="image/jpeg"/>'+''.join('<Override PartName="/'+p+'" ContentType="application/vnd.openxmlformats-officedocument.presentationml.'+t+('.main+xml' if t=='presentation' else '+xml')+'"/>' for p,t in overrides)+'<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/></Types>'
    for value in files.values():ET.fromstring(value)
    temp=output.with_suffix('.tmp')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
        for name,doc in files.items():z.writestr(name,doc.encode('utf-8'))
        for name,data in media.items():z.writestr('ppt/media/'+name,data)
    temp.replace(output)
    report={'status':'exported','adapter':'native-scene-subset-1','layoutEngine':scene.get('engine','browser'),'browserFidelity':scene.get('browserFidelity','browser-measured; PowerPoint appearance needs verification'),'slides':reports,'rasterizedSlides':0,'limitations':['Text is editable per measured line, not as one paragraph.','Bars/diagrams are editable shapes, not native chart data.','Font substitution may change appearance on another computer.'],'bytes':output.stat().st_size}
    output.with_suffix('.report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');return report
