"""Read PPTX ZIP directories without extracting or modifying source files."""
import argparse
import collections
import json
from pathlib import Path
import re
import zipfile
import xml.etree.ElementTree as ET


def scan(root):
    rows = []
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.suffix.lower() != '.pptx':
            continue
        row = {'file': str(path.relative_to(root)), 'bytes': path.stat().st_size}
        try:
            with zipfile.ZipFile(path) as archive:
                items = archive.infolist()
                row['slides'] = sum(bool(re.fullmatch(r'ppt/slides/slide\d+\.xml', i.filename)) for i in items)
                row['mediaCompressedBytes'] = sum(i.compress_size for i in items if i.filename.startswith('ppt/media/'))
                row['hasThumbnail'] = any(i.filename.startswith('docProps/thumbnail.') for i in items)
                node = ET.fromstring(archive.read('ppt/presentation.xml')).find('{http://schemas.openxmlformats.org/presentationml/2006/main}sldSz')
                if node is not None:
                    row['canvasEmu'] = [int(node.get('cx')), int(node.get('cy'))]
        except (OSError, zipfile.BadZipFile, KeyError, ET.ParseError, TypeError, ValueError) as exc:
            row['error'] = str(exc)
        rows.append(row)
    valid = [row for row in rows if 'error' not in row]
    total = sum(row['bytes'] for row in rows)
    media = sum(row['mediaCompressedBytes'] for row in valid)
    return {
        'scanKind': 'ZIP directory and presentation size only; no visual analysis',
        'summary': {
            'files': len(rows), 'errors': len(rows) - len(valid),
            'slides': sum(row['slides'] for row in valid),
            'totalMiB': round(total / 1048576, 1),
            'mediaCompressedMiB': round(media / 1048576, 1),
            'mediaSharePercent': round(media / total * 100, 1) if total else 0,
            'filesWithThumbnail': sum(row['hasThumbnail'] for row in valid),
            'canvasCounts': dict(collections.Counter('x'.join(map(str, row.get('canvasEmu', []))) for row in valid)),
        },
        'files': rows,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if not args.source.is_dir():
        parser.error('source must be an existing directory')
    report = scan(args.source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report['summary'], ensure_ascii=False, indent=2))
