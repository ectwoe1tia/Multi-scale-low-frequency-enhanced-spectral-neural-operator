"""Re-run three source decks and publish compact, content-neutral sample reports."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET
import zipfile
from extract import extract, dump, NS

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);a=p.parse_args()
    files=sorted(a.source.glob('*.pptx'),key=lambda p:p.stat().st_size)
    if len(files)<3:raise ValueError('Need at least three sample decks')
    selected=[files[0],files[len(files)//2],files[-1]];results=[]
    for i,f in enumerate(selected,1):
        out=ROOT/'.local'/('verified-'+str(i));result=extract(f,out,True)
        e=json.loads((out/'evidence.json').read_text(encoding='utf-8'));raw=Counter()
        with zipfile.ZipFile(f) as z:
            for name in z.namelist():
                if re.fullmatch(r'ppt/slides/slide\d+\.xml',name):
                    root=ET.fromstring(z.read(name))
                    for tag in ('sp','pic','cxnSp','graphicFrame'):raw[tag]+=len(root.findall('.//p:'+tag,NS))
        refs=0
        for page in e['pages']:
            ids=[o['id'] for o in page['objects']]
            if None in ids or len(set(ids))!=len(ids):raise ValueError('Missing/duplicate shape ids')
            for relation in page['imageRelationships']:
                if relation['imageId'] not in ids or any(t not in ids for t in relation['textIds']):raise ValueError('Broken image/text reference')
                refs+=len(relation['textIds'])
        if sum(raw.values())!=result['objects']:raise ValueError('Source object count mismatch; inspect unsupported report')
        destination=ROOT/'styles'/('source-'+str(i))
        shutil.copytree(out/'style',destination,dirs_exist_ok=True,ignore=shutil.ignore_patterns('source-image-*'))
        results.append({'sample':i,'sourceSha256':e['sourceSha256'],'pages':result['pages'],'rawObjects':dict(raw),'extractedObjects':result['objects'],'groups':result['groups'],'rasterPages':result['rasterPages'],'validImageTextReferences':refs,'nullIds':0,'status':'structural-check-passed','visualReview':'pending'})
    dump(ROOT/'reports/source-validation.json',results)
    print(json.dumps(results,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
