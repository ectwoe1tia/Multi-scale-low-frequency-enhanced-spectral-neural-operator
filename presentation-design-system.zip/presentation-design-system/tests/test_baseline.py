import contextlib
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from extract import extract, target_path, xform, mult, dump, NS
from rebuild import rebuild, DEFAULT_LAYOUTS
from package_delivery import pack, verify
from native_layout import native_scene
from pptx_writer import write_pptx


def make_ppt(path,target='slides/slide1.xml',group=False,missing=False):
    shape='<p:sp><p:nvSpPr><p:cNvPr id="2" name="Text"/></p:nvSpPr><p:spPr><a:xfrm><a:off x="10" y="20"/><a:ext cx="100" cy="40"/></a:xfrm></p:spPr><p:txBody><a:p><a:r><a:t>Hello</a:t></a:r></a:p></p:txBody></p:sp>'
    if group:shape='<p:grpSp><p:grpSpPr><a:xfrm><a:off x="100" y="200"/><a:ext cx="400" cy="200"/><a:chOff x="0" y="0"/><a:chExt cx="200" cy="100"/></a:xfrm></p:grpSpPr>'+shape+'</p:grpSp>'
    slide='<p:sld xmlns:p="'+NS['p']+'" xmlns:a="'+NS['a']+'"><p:cSld><p:spTree>'+shape+'</p:spTree></p:cSld></p:sld>'
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('ppt/presentation.xml','<p:presentation xmlns:p="'+NS['p']+'" xmlns:r="'+NS['r']+'"><p:sldIdLst><p:sldId id="256" r:id="rId1"/></p:sldIdLst><p:sldSz cx="1280" cy="720"/></p:presentation>')
        z.writestr('ppt/_rels/presentation.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+NS['r']+'/slide" Target="'+target+'"/></Relationships>')
        if not missing:z.writestr('ppt/slides/slide1.xml',slide)


class Baseline(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_absolute_relationship_and_text_id(self):
        make_ppt(self.d/'a.pptx','/ppt/slides/slide1.xml');extract(self.d/'a.pptx',self.d/'out')
        e=json.loads((self.d/'out/evidence.json').read_text(encoding='utf-8'))
        self.assertEqual(len(e['pages']),1);self.assertEqual(e['pages'][0]['objects'][0]['id'],'2')
    def test_relative_relationship(self):
        self.assertEqual(target_path('ppt/slides/slide1.xml','../media/image1.png'),'ppt/media/image1.png')
        with self.assertRaises(ValueError):target_path('ppt/presentation.xml','../../bad.xml')
    def test_missing_slide_fails(self):
        make_ppt(self.d/'a.pptx',missing=True)
        with self.assertRaises(ValueError):extract(self.d/'a.pptx',self.d/'out')
    def test_group_transform_is_composed(self):
        make_ppt(self.d/'a.pptx',group=True);extract(self.d/'a.pptx',self.d/'out')
        e=json.loads((self.d/'out/evidence.json').read_text(encoding='utf-8'));o=e['pages'][0]['objects'][0]
        self.assertEqual(o['groupDepth'],1);self.assertAlmostEqual(o['box'][0],120/1280,places=4);self.assertAlmostEqual(o['box'][1],240/720,places=4);self.assertAlmostEqual(o['box'][2],200/1280,places=4)
    def test_invalid_layout_rejected(self):
        shutil.copytree(ROOT/'styles/baseline',self.d/'style');(self.d/'style/layouts.json').write_text('invalid')
        with self.assertRaises(ValueError):rebuild(self.d/'style',ROOT/'decks/demo.json',self.d/'out')
    def test_unknown_layout_rejected(self):
        d=json.loads((ROOT/'decks/demo.json').read_text(encoding='utf-8'));d['slides'][0]['layout']='missing';dump(self.d/'deck.json',d)
        with self.assertRaises(ValueError):rebuild(ROOT/'styles/baseline',self.d/'deck.json',self.d/'out')
    def test_native_uses_layout_side(self):
        shutil.copytree(ROOT/'styles/baseline',self.d/'style')
        rebuild(self.d/'style',ROOT/'decks/demo.json',self.d/'before');a=native_scene(self.d/'before/index.html',self.d/'a')
        p=self.d/'style/layouts.json';layouts=json.loads(p.read_text());layouts['layouts'][1]['visualSide']='left';dump(p,layouts)
        rebuild(self.d/'style',ROOT/'decks/demo.json',self.d/'after');b=native_scene(self.d/'after/index.html',self.d/'b')
        def pos(scene):return next(o['x'] for o in scene['slides'][1]['objects'] if o.get('text','').startswith('解释'))
        self.assertGreater(pos(b),pos(a))
    def test_capacity_rejected(self):
        d=json.loads((ROOT/'decks/demo.json').read_text(encoding='utf-8'));d['slides'][1]['body']=['x']*20;dump(self.d/'deck.json',d)
        with self.assertRaises(ValueError):rebuild(ROOT/'styles/baseline',self.d/'deck.json',self.d/'out')
    def test_source_fonts_css_injection_rejected(self):
        shutil.copytree(ROOT/'styles/baseline',self.d/'style');p=self.d/'style/theme.json';t=json.loads(p.read_text());t['fonts']['body']='x";body{display:none}';dump(p,t)
        with self.assertRaises(ValueError):rebuild(self.d/'style',ROOT/'decks/demo.json',self.d/'out')
    def test_native_export_and_relationship_integrity(self):
        rebuild(ROOT/'styles/baseline',ROOT/'decks/demo.json',self.d/'html');scene=native_scene(self.d/'html/index.html',self.d/'scene');report=write_pptx(self.d/'scene/scene.json',self.d/'demo.pptx')
        self.assertEqual(len(report['slides']),7);self.assertGreater(sum(s['text'] for s in report['slides']),70);self.assertEqual(report['rasterizedSlides'],0)
        with zipfile.ZipFile(self.d/'demo.pptx') as z:
            names=set(z.namelist());self.assertIsNone(z.testzip())
            for name in names:
                if name.endswith('.xml') or name.endswith('.rels'):ET.fromstring(z.read(name))
                if name.endswith('.rels'):
                    part='' if name=='_rels/.rels' else name.replace('/_rels/','/').removesuffix('.rels')
                    for r in ET.fromstring(z.read(name)):
                        self.assertIn(target_path(part,r.get('Target')),names)
            text=''.join(z.read('ppt/slides/slide%d.xml'%i).decode() for i in range(1,8))
            self.assertIn('设计',text);self.assertNotIn('<p:pic>',text)
    def test_pack_excludes_private_and_checks_manifest(self):
        source=self.d/'source';(source/'tools').mkdir(parents=True);(source/'.git').mkdir();(source/'.local').mkdir()
        (source/'tools/tool.py').write_text('print(1)');(source/'.env').write_text('fixture');(source/'.git/config').write_text('fixture');(source/'.local/cache.json').write_text('{}')
        outputs=pack(source,self.d/'delivery');self.assertEqual(len(outputs),1);self.assertLess(outputs[0]['bytes'],15_000_000)
        with zipfile.ZipFile(self.d/'delivery'/outputs[0]['file']) as z:self.assertEqual(set(z.namelist()),{'tools/tool.py','DELIVERY_MANIFEST.json'})
        self.assertEqual(verify(self.d/'delivery')['status'],'passed')
    def test_pack_source_inside_local_is_not_empty(self):
        source=self.d/'.local/project';(source/'tools').mkdir(parents=True);(source/'tools/tool.py').write_text('print(1)')
        self.assertEqual(len(pack(source,self.d/'delivery')),1)
    def test_pack_tampering_detected(self):
        source=self.d/'source';source.mkdir();(source/'README.md').write_text('hello');r=pack(source,self.d/'delivery');p=self.d/'delivery'/r[0]['file'];p.write_bytes(p.read_bytes()+b'bad')
        with self.assertRaises(ValueError):verify(self.d/'delivery')
    def test_pack_output_inside_source_rejected(self):
        with self.assertRaises(ValueError):pack(self.d,self.d/'delivery')


if __name__=='__main__':unittest.main()
