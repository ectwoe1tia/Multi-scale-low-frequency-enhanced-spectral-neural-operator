---
name: ppt-style-extract
description: Extract reusable layout, theme, and image-text relationships from local PPTX examples into a compact portable style pack.
---

# PPT style extraction

Use `python tools/pipeline.py extract <source.pptx> <output-dir>` from the project root. The source is read only. The result separates local evidence.json from portable style/. Run on a small, diverse set first. Review selected pages visually before changing `visualReview` from pending or claiming a visual style was learned. An image's role is a hypothesis based on area and proximity, and `nearestTextShapeIds` only identifies nearby text. Inspect the rendered slide to decide whether the image illustrates a claim, supplies evidence, acts as metaphor, or decorates. Do not copy original images or business text into the portable pack by default. See `ARCHITECTURE.md` for the format contract and limitations.

Inspired by [PPTWork](https://github.com/JunfengRan/PPTWork) for HTML-first delivery and [python-pptx](https://python-pptx.readthedocs.io/en/latest/) for structural extraction. This first implementation uses Python's standard-library OOXML parser and is not a full PowerPoint renderer.
