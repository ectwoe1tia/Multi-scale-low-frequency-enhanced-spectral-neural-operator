---
name: presentation-rebuild
description: Rebuild an HTML presentation from a portable PPT style pack and structured content; prepare a PPTX export through an editable HTML exporter.
---

# Presentation rebuild

Read a style pack's `manifest.json`, `theme.json`, `layouts.json`, `style.md`, and image relationship notes. Verify the requested style is visually reviewed before describing a deck as faithful to it. Use `python tools/pipeline.py rebuild <style-dir> <deck.json> <output-dir>` for a deterministic offline HTML baseline. For full Vue authoring, apply the architecture's component model and place content in Deck IR. Inspect HTML at 1280×720 for overflow. PPTX export is a separate adapter step; use [PPTWork](https://github.com/JunfengRan/PPTWork)'s `html2pptx-pro` flow only after dependency installation and a local editable-output check. Never describe rasterized elements as editable. Preserve the source pack and commit reusable component/style changes rather than generated HTML.
