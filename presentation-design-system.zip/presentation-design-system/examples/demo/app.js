/* Options API works with Vue 3 and the bundled offline compatibility runtime. */
(() => {
  const {deck, theme, layouts} = window.PRESENTATION;
  const registry = Object.fromEntries(layouts.map(l => [l.id, l]));
  const Visual = {
    props:['visual'],
    template:`<div class="visual-panel" data-bound>
      <template v-if="visual && visual.kind==='image'"><img data-pptx="image" :src="visual.src" :alt="visual.alt || '演示配图'" class="visual-image"><p data-pptx="text" class="caption">{{visual.caption || ''}}</p></template>
      <template v-else-if="visual && visual.kind==='bars'"><div class="bar-row" v-for="(item,i) in visual.items" :key="i"><p data-pptx="text" class="bar-label">{{item.label}}</p><div class="bar-track" data-pptx="rect"><div class="bar-fill" data-pptx="rect" :style="{width:item.value+'%'}"></div></div><p data-pptx="text" class="bar-value">{{item.value}}%</p></div><p data-pptx="text" class="caption">{{visual.caption || '示例数据，仅用于布局验证'}}</p></template>
      <template v-else><div class="diagram-node" data-pptx="rect" v-for="(item,i) in (visual && visual.items || [{label:'内容'},{label:'布局'},{label:'交付'}])" :key="i"><span data-pptx="text" class="node-index">0{{i+1}}</span><span data-pptx="text" class="node-label">{{item.label}}</span></div><p data-pptx="text" class="caption">{{visual && visual.caption || '从设计规则到可复用页面'}}</p></template>
    </div>`
  };
  const Slide = {
    props:['slide','number','total','layout'],components:{'slide-visual':Visual},
    computed:{
      kind(){return this.layout.kind},
      splitStyle(){const f=this.layout.visualFraction || .46;return {gridTemplateColumns:this.layout.visualSide==='left'?`${f}fr ${1-f}fr`:`${1-f}fr ${f}fr`}},
      reversed(){return this.layout.visualSide==='left'}
    },
    template:`<section class="slide" :class="'layout-'+kind" :data-slide-id="slide.id" :data-layout="layout.id">
      <div class="top-accent" data-pptx="rect"></div>
      <header><span class="eyebrow" data-pptx="text">{{slide.eyebrow || 'DESIGN SYSTEM / 演示基板'}}</span><span class="folio" data-pptx="text">{{String(number).padStart(2,'0')}} / {{String(total).padStart(2,'0')}}</span></header>
      <template v-if="kind==='cover' || kind==='closing'"><div class="hero" data-bound><p class="hero-kicker" data-pptx="text">{{kind==='cover'?'让设计持续复用':'下一步，开始你的演示'}}</p><h1 data-pptx="text">{{slide.title}}</h1><p class="hero-body" v-for="(line,i) in slide.body" :key="i" data-pptx="text">{{line}}</p></div><div class="hero-mark" data-pptx="rect"></div><div class="hero-mark small" data-pptx="rect"></div></template>
      <template v-else><h1 data-pptx="text">{{slide.title}}</h1>
        <div v-if="kind==='split'" class="split-grid" :style="splitStyle" data-bound><div class="body-list" :style="{order:reversed?2:1}" data-bound><p v-for="(line,i) in slide.body" :key="i" data-pptx="text">{{line}}</p></div><div :style="{order:reversed?1:2}" data-bound><slide-visual :visual="slide.visual"></slide-visual></div></div>
        <div v-else-if="kind==='metrics'" class="metrics-grid" data-bound><div v-for="(m,i) in slide.metrics" :key="i" class="metric-card" data-pptx="rect"><p class="metric-number" data-pptx="text">{{m.value}}</p><p class="metric-label" data-pptx="text">{{m.label}}</p><p class="caption" data-pptx="text">{{m.detail || ''}}</p></div></div>
        <div v-else-if="kind==='timeline'" class="timeline-grid" data-bound><div v-for="(step,i) in slide.steps" :key="i" class="step-card" data-pptx="rect"><p class="step-number" data-pptx="text">0{{i+1}}</p><h2 data-pptx="text">{{step.title}}</h2><p class="step-detail" data-pptx="text">{{step.detail}}</p></div></div>
        <div v-else-if="kind==='comparison'" class="compare-grid" data-bound><div v-for="(col,i) in slide.columns" :key="i" class="compare-card" data-pptx="rect"><h2 data-pptx="text">{{col.title}}</h2><p v-for="(line,j) in col.items" :key="j" data-pptx="text">{{line}}</p></div></div>
      </template>
      <footer><span data-pptx="text">{{slide.footer || '内容与风格分离 · HTML 与 PPTX 双格式'}}</span><span data-pptx="text">{{slide.tag || 'PRESENTATION BASELINE'}}</span></footer>
    </section>`
  };
  const app={components:{'deck-slide':Slide},data(){return {deck,registry}},template:`<main class="deck"><deck-slide v-for="(s,i) in deck.slides" :key="s.id" :slide="s" :number="i+1" :total="deck.slides.length" :layout="registry[s.layout]"></deck-slide></main>`,async mounted(){await document.fonts.ready;await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})));window.__PPT_READY__=true;document.title=deck.name;window.__VUE_VERSION__=Vue.version;}};
  if(Vue.createApp) Vue.createApp(app).mount('#app'); else new Vue(app).$mount('#app');
})();
