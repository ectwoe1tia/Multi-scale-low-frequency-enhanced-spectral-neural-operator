# PPT 风格提取与 Vue 演示文稿设计系统

状态：架构草案，2026-11-15。当前交付是架构与只读盘点工具；风格提取、视觉分析、Vue 渲染和导出 Skill 尚未实现。文中的接口、目录及数据示例均为拟议契约，示例颜色不代表已从素材提取的结果。

本机目录盘点：68 份 PPTX，共 2,425 页，总大小 1,080.3 MiB；ZIP 内媒体压缩体积 1,034.7 MiB，占文件总体积约 95.8%。68 份均成功读取 ZIP 目录及 presentation.xml；这不等于完整内容校验。55 份包含内嵌封面缩略图，至少一份为 4:3。另有 29 份 PDF、5 份 DOCX，当前不纳入提取范围。盘点明细保存在 `.local/inventory.json`，其中源文件名不纳入 Git。

本机能力检查：Python、Node 可用；当前 Python 环境未发现 python-pptx/lxml；soffice 未在 PATH 中发现，尚未确认 PowerPoint 是否可用于渲染。当前盘点脚本仅用 Python 标准库，不安装依赖、不修改源文件。

## 1. 核心决策

采用 Vue 3 + TypeScript + Vite，遵循 HTML-first 渲染路径。Git 中的权威来源是主题、布局、Vue 组件、内容数据和局部定制源码；HTML 是可检查的渲染产物，PPTX 是交付产物。

以 PPTWork 的浏览器预览、检查、导出流程作为参考，不直接继承其“每页 HTML 是唯一源文件”的存储方式。导出器以适配器隔离，候选 html2pptx-pro；同名 html2pptx 项目不能视为同一依赖，实际选型必须固定仓库、包名、版本及许可。

本项目优先学习设计规律，不迁移原始图库，不承诺原稿像素级复刻，不承诺 PPTX 修改自动回流 Vue。公司电脑只需获得轻量风格包和一次安装的运行时，不必获得原 PPT。

## 2. 数据流

```mermaid
flowchart TD
  A[本机 PPTX 素材库] --> B[结构解析：OOXML 与主题继承]
  A --> C[本地渲染与代表页筛选]
  B --> D[本地提取记录 Evidence IR]
  C --> D
  D --> E[视觉归纳与版式聚类]
  E --> F[可移植 Style Pack]
  F --> G[Git 或离线 ZIP / bundle]
  G --> H[公司电脑：重建 Skill]
  I[业务内容 Deck IR] --> H
  H --> J[Vue 组件与主题]
  J --> K[浏览器 DOM 与布局检查]
  K --> L[HTML 演示文稿]
  K --> M[PPTX 导出适配器]
  M --> N[可编辑性与视觉检查报告]
```

## 3. 三种中间数据，避免把所有东西塞进一个 JSON

### Evidence IR：本机提取证据

保存在 `.local/`，不随风格包搬运。包含源文件哈希、页码、shapeId、源尺寸、主题与母版引用、形状类型、文本样式区间、变换、层级、边界、裁剪、渐变与解析状态。源文件名及实际文字默认只留本地。

保留 source/derived/unknown 状态：解析得到的事实、计算得到的几何量、模型推断的语义不能混为一谈。颜色同时保存 scheme token 和解析后的值；字体区分 East Asian/Latin、主题引用和本机实际替代字体。

显式属性不等于最终外观。实现时追踪 slide → layout → master → theme，并处理 color map、占位符样式、段落层级、局部覆盖、tint/shade/alpha 与组变换。复杂图形、SmartArt、OLE、未解析效果记录 unsupported，不能静默丢弃。python-pptx 提供方便的对象访问，OOXML 补足它未覆盖的部分。

实际字形、字体替换、阴影合成及渲染留白需要渲染校验，不能称为“全部精确提取”。图片主导的页面只能提取构图、颜色和视觉参考，无法从位图可靠恢复原始编辑结构。

### Style Pack：Git 管理的设计规则

```text
styles/<style-id>/
  manifest.json       # schemaVersion、风格版本、运行时兼容范围、依赖及哈希
  theme.json          # 语义配色、字体回退、字号层级、间距、线条与阴影
  theme.css           # 从 theme.json 生成，可提交用于直接复用
  layouts.json        # 角色、插槽、相对区域、对齐关系、容量、变体及组合建议
  style.md            # 视觉重心、节奏、留白、装饰规律与适用场景
  recipes.json        # 故事结构及跨页组合规则
  references/         # 少量代表页 WebP 与内容中性的 SVG 线框
  provenance.json     # 源哈希、页码、规则证据、置信度、提取器版本
```

`theme.json` 是设计 token 的唯一来源；`theme.css` 标记 generated，并通过 CI 检查是否同步。自由 CSS 规则存放在组件或单独的 overrides.css，不回写生成文件。主题作用域使用 `[data-theme="style-id"]`，避免风格之间污染。

`layouts.json` 保存“标题+左文右图”等角色关系，原始绝对坐标只保留在 Evidence IR。复用层使用 0..1 的比例和明确的内容插槽，适配不同业务内容；不要把一页几十个文本框直接硬编码成永久组件。

`style.md` 每条规则应包含：适用条件、具体做法、反例/限制、证据页、推断置信度。例如“单页只保留一个强调数字；放在右侧主区域；其余指标降低对比度”，比“高级、科技、简约”更可执行。

参考图不是纯装饰：它们弥补 JSON/CSS 无法完整表达的艺术判断。但原始预览可能包含业务文字或 Logo，默认本地保留；便携包优先用重建的中性样张与线框，允许明确选择少量原图参考。

### Deck IR：新内容

```json
{
  "schemaVersion": "1.0",
  "style": {"id": "sample-tech", "version": "1.0.0"},
  "canvas": {"width": 1280, "height": 720},
  "slides": [{
    "id": "market",
    "layout": "split-evidence",
    "slots": {
      "title": "示例市场机会",
      "body": ["核心判断", "支持证据"],
      "visual": {"type": "chart", "kind": "bar", "dataRef": "data/market.json"}
    },
    "notes": "可选讲稿"
  }]
}
```

实际契约使用 JSON Schema 版本化，验证布局是否存在、插槽类型、资产路径、数据引用、字符/项目容量及运行时兼容性。JSON 仅存数据，不执行表达式或动态 Vue 模板。

## 4. 从大量 PPT 中提炼少量风格

1. **便宜的全量扫描**：先统计页数、画布、媒体占比，再按文件哈希去重；主题和页面结构做二级去重。只读原文件，失败单独报告并继续其他文件。
2. **结构特征**：提取色彩角色、文字层级、形状/图片比例、对象分布、留白估计、重复标题和页脚。按版式和主题分组；默认以文件内部连贯风格为起点，再合并相近设计。
3. **本地渲染**：使用实际可用的 PowerPoint 或 LibreOffice；记录渲染器与字体清单。二者呈现可能不同。文件内 docProps 缩略图通常只代表封面，不能代替逐页渲染。未检测到渲染器时可以完成结构解析，艺术归纳标记 pending，不能假装已经看过页面。
4. **筛选代表页**：每个候选风格初始选择 6–12 页，覆盖封面、章节、正文、数据、流程、结束页；页数可按多样性调整。用布局特征与图像相似性去重，并保留少见但有用的版式。
5. **视觉归纳**：结合代表页和结构事实，归纳主次对比、视觉重心、留白、图文搭配、装饰及跨页节奏。区分“图片内容造成的配色”与“主题设计配色”；不能把不同文件的颜色平均成一个主题。
6. **重建验证**：用与原稿无关的中性内容重建 3–6 页，再评价风格规则是否可执行；只能在同内容复刻测试中使用像素差作为指标，换内容后应检查对齐、比例和规则一致性。
7. **轻量打包**：仅输出主题、布局、规则、必要矢量装饰和少量预览。源媒体、业务文字、完整原文件均不默认导出。

初始体积预算（目标，不是保证）：每个风格包约 0.5–3 MB，参考图 6–12 张、单张约 50–200 KB；预算超限先减少相似参考页。公共 Vue 运行时只搬运一次。无需把所有素材放 Git LFS 才能复用风格。

## 5. 两个 Skill 与一套共享运行时

### `ppt-style-extract`

输入：文件/目录、抽样策略、输出目录、参考图策略。

职责：盘点、解析、渲染筛选、视觉归纳、风格包生成及验证。支持 scan / extract / distill / pack 阶段和断点继续。昂贵结果按 sourceHash + parserVersion + rendererVersion + fontFingerprint 缓存。

输出：Style Pack、提取报告、未覆盖功能清单。可以只输出结构草稿，但必须声明视觉分析是否完成。不要求公司电脑具备此 Skill。

### `presentation-rebuild`

输入：Style Pack + 业务内容/Deck IR + 目标输出格式。

职责：选布局、生成内容、复用 Vue 组件、浏览器检查、按需导出 HTML/PPTX、输出质量报告。只有现有布局无法承载内容时才增加局部 Vue 组件。

输出：deck.json、少量新增组件/样式、HTML、PPTX、导出报告。参考图只作为视觉依据，不能把参考图整页贴入 PPTX 并声称可编辑。

两个 Skill 的 SKILL.md 只负责入口、关键约束和路由；格式规范、视觉分析提示、导出能力矩阵放 references，确定性逻辑放 scripts。导出是共享运行时能力，不必独立成第三个 Skill。

## 6. Vue 组件与构建

```text
packages/
  contracts/          # Style Pack / Deck IR / Evidence IR 的 schema 与迁移
  slide-runtime/      # Vue 播放、分页、主题加载、离线资源
  slide-components/   # Title、Metric、Quote、ImageFrame、Diagram 等
  slide-layouts/      # Cover、Split、Comparison、Timeline、Dashboard 等
  export-adapters/    # PPTX 引擎接口、版本锁定、能力报告
styles/               # 多个独立风格包
decks/                # deck.json、数据、局部组件
skills/               # 提取与重建 Skill
.local/               # 本地证据、原始截图、源路径索引；不入 Git
```

业务内容通过 props/slots 进入组件，组件通过 CSS 变量取得主题。页面布局以 Grid/Flex 为主，标题区/装饰等可局部定位；浏览器输出测量后再生成 PPT 坐标。源画布可能不是 16:9：提取保留源比例，重建时明确采用 1280×720 的 16:9，并重新排版，不能直接拉伸。

编辑修改优先落在 deck.json、theme.json、Vue/CSS 源码。AI 可以检查导出的 HTML/DOM；若直接改了构建产物，必须把改动回写源文件，否则下一次构建会丢失。交互层可响应窗口缩放，但导出画布尺寸保持固定。

导出前等待 Vue 完成、document.fonts.ready、图片 decode 和图表数据就绪，关闭动画，固定浏览器 viewport/deviceScaleFactor。浏览器端验证字体真实加载，避免“导出成功但字体替换”。长中文标题、英文长词、数字表格必须作为容量样例。

## 7. 可编辑 PPTX 的能力边界

适配器概念接口：`exportDeck(renderedSlides, options) -> {pptxPath, report}`。report 至少记录引擎版本、字体替换、逐页不支持元素、栅格化对象、可编辑性等级和失败原因。

| 元素 | 目标 | 降级策略 |
| --- | --- | --- |
| 普通 DOM 文字 | 原生文本框 | 失败时修复/报错，不静默整页截图 |
| 基础形状、线条、表格 | 原生可编辑对象 | 由实际引擎能力验证 |
| SVG | 保留矢量视觉 | SVG 图片不等于原生形状可编辑，报告区分 |
| 图表 | 有数据时走原生图表适配器 | 只有 SVG 则是矢量图，不承诺编辑数据 |
| 图片 | 可替换图片对象 | 原图内容本身不可编辑 |
| 复杂滤镜、遮罩、Canvas | 默认在组件中避免 | 可显式栅格化局部装饰并报告 |

浏览器支持 Flex/Grid 不意味着导出器支持所有 CSS；导出读取计算后的布局，仍需测试多行文本、背景、层叠、变换与 SVG。保留 HTML 可视效果和 PPTX 可编辑性两个验收维度，不以文件生成成功代替验收。

候选引擎先以 6 页能力样例评估：长中文标题、左右图文、表格、SVG 流程、数据图表、渐变装饰。对比原生文字数量、图表结构、元素越界及实际 PPT 渲染。PPTWork 默认引擎可优先验证，但不绑定其私有内部实现。

## 8. Git 与公司电脑复用

Git 保存 schema、主题、布局、组件、Deck IR、生成脚本、锁文件及少量中性预览。原 PPT、原图全集、原业务内容、绝对路径、缓存和默认导出产物不进入仓库。`.gitignore` 是便利措施，打包程序还应通过显式文件清单选择输出。

风格包使用 schemaVersion 与 styleVersion 两种版本；deck 固定风格版本和组件运行时版本。便携包 manifest 记录文件哈希、必要组件 ID、字体及回退策略、最低运行时版本。字体文件只有明确需要且允许分发时才随包提供。

迁移方式：可访问 Git 时 clone/pull；不能访问时使用带 manifest 的 ZIP，或用 git bundle 保留历史。包内只使用相对路径。轻量风格包本身不需要运行 Node；要重新生成内容需公司电脑预置 Node/Vue 运行时、浏览器及导出依赖。完全离线时另备经过验证的运行环境包，体积不计入风格包。

公司电脑流程：导入 → 校验 schema/哈希/组件依赖 → 预览中性样张 → 提供业务内容 → 生成 Vue 页面 → 浏览器检查 → 导出 HTML/PPTX。可交付离线静态 HTML 目录（HTML/JS/CSS/assets），不强制每页保存成单独 HTML。

## 9. 分阶段验收

阶段 0：完成素材盘点及架构；当前阶段。

阶段 1：选择 3 份差异较大的模板，提取结构并完成代表页视觉检查，产生 2–3 套候选风格。暂不全量精细分析 68 份 PPT。

阶段 2：完成 schemas、两个 Skill 和最小 Vue 运行时；使用不同内容生成至少 6 页，覆盖主要版式。风格包能在不含原 PPT 的干净目录工作。

阶段 3：比较导出器的可编辑性，固定版本；检验文字、形状、图表可编辑范围，并生成逐页降级报告。

阶段 4：全量聚类去重、增量扫描、Git 工作流、离线公司电脑验收。修改主题 token 后多页一致更新；重建结果无缺失资产，无阻断性溢出，且报告反映真实限制。

## 10. 核实过的参考资料

- PPTWork：https://github.com/JunfengRan/PPTWork 。参考 HTML-first 预览和导出工作流；其文档列出 html2pptx-pro 作为默认可编辑引擎，PPTX 为单向构建产物。
- python-pptx：https://python-pptx.readthedocs.io/en/latest/ 。结构解析候选；官方明确有尚未支持的 PPT 特性，因此不能依赖单一高层库完整恢复外观。
- 同名导出项目示例：https://github.com/junyuaini/html2pptx 。需和 html2pptx-pro 区分，不能仅凭名称替换。

以上是文档核查，尚未安装或运行这些转换器，也尚未读取源 PPT 的视觉页面。本方案中的艺术规则将在后续渲染与视觉验证后形成。
