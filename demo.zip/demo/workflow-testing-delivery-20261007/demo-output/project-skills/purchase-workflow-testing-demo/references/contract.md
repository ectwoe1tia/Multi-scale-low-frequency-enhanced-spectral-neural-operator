# 测试资产契约与脚本

## 文件与状态

`suite.json` 使用 UTF-8，`schema_version` 固定为 `1.0`。可以添加项目自定义字段，脚本校验核心字段与引用。完整示例在主 Skill 的 `assets/example-suite.json`；项目生成物保留自己的 `references/project-suite.json`。

| 顶层字段 | 内容 |
|---|---|
| project | 非空项目名 |
| platform | unknown / lowcode / flowable / custom / mixed |
| sources | `{id, location, excerpt}`；定位到原文件、页码、段落或用户确认记录 |
| requirements | `{id, text, status, source_ids}`；状态见需求分析方法 |
| questions | `{id, text, requirement_ids, status, options, answer}`；open / resolved，resolved 必须有 answer |
| cases | 下方用例字段 |
| deviations | 下方妥协字段，可以为空 |

用例必填字段：

```text
id, title, requirement_ids, category, priority: P0/P1/P2/P3,
status: ready/needs_clarification,
question_ids, preconditions, actors, data, steps,
assertions: [{id, expected, status: defined/pending}],
automation: {status: unbound/manual/implemented, reason, artifact}
```

- `preconditions`、`actors`、`steps` 为非空文本数组，`data` 为对象；不适用的前置条件明确写“无额外前置条件”。
- `category` 是 requirements.md 中的分类标识。
- `ready` 必须仅引用 explicit/confirmed 规则，全部断言 defined，不能引用未解决问题。
- `needs_clarification` 必须关联至少一个未解决问题，且问题涉及该例的规则；预期选项写在问题 `options`，断言可写“待 Q-001 确认阈值后判定”。
- `automation.status=implemented` 必须有真实脚本路径 `artifact`，且用例 ready；脚本不检查外部脚本是否可执行，报告中不得将此状态当成已运行。
- `automation.status=unbound` 是尚未接入；`manual` 表示选择人工验证。两者均需要说明原因。
- 缺失/推测/冲突规则必须关联 open 问题。每条规则应关联用例；未覆盖时校验报告警告。

妥协字段：

```text
id, case_id, assertion_id, reason, owner, issue,
status: proposed/accepted/closed,
failure_signature, scope: {release, environment},
accepted_by, accepted_at, expires_on
```

`accepted` 要有真实接受人、接受日期及失效日期（ISO YYYY-MM-DD）。日期过期时脚本发出警告；它不会判定本次运行放行。`failure_signature` 应精确描述已知失败，不能写“任意错误”。scope 不使用通配符；多个版本/环境分别登记。`proposed` 允许接受字段为空。不要使用演示数据编造用户批准。

## 命令

在 Skill 目录执行，或把脚本改为绝对路径。路径带空格时加引号。`init` 输出空的可编辑结构，之后由 AI 根据原文填入，不会自动解析文档。

```powershell
python scripts/suite.py init --out ./test-output/suite.json --project "采购审批" --platform unknown
python scripts/suite.py validate ./test-output/suite.json
python scripts/suite.py render ./test-output/suite.json --out ./test-output/report
python scripts/suite.py build-skill ./test-output/suite.json --out ./project-skills --name purchase-workflow-testing
```

`validate`：结构/引用错误返回退出码 1；只有覆盖/过期等警告返回 0，并打印警告。合法文件不等于语义正确或覆盖完整。`render`、`build-skill` 在结构校验失败时不创建结果。

`render` 在新目录生成 `report.md`、`cases.csv`、`traceability.csv`、`questions.csv`、`deviations.csv`。CSV 使用带 BOM 的 UTF-8，适合 Excel；对可能解释为公式的单元格做文本处理。报告不生成任何虚构的 PASS。

`build-skill` 在输出父目录创建指定名称的新文件夹，复制经过校验的 suite、通用核心工作指引、三份引用说明和辅助脚本，生成独立 SKILL.md 与 agents/openai.yaml。不复制凭据、不自动安装、不联网。未接入状态继续保留；仅生成可复用工作说明，不伪造适配器。

所有输出都拒绝覆盖已存在的目标。重新生成使用新目录；更新现有项目资产先比较变化并保留 ID/批准记录，不直接删目录重建。
