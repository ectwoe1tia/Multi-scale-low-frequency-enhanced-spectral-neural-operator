[CmdletBinding()]
param(
    [string]$TargetPath = 'C:\Users\jing\workflow-testing',
    [switch]$Apply,
    [switch]$GrantSandboxModify
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding

try {
    $sourceRoot = [IO.Path]::GetFullPath($PSScriptRoot)
    $target = [IO.Path]::GetFullPath($TargetPath).TrimEnd('\')
    $allowedParent = [IO.Path]::GetFullPath('C:\Users\jing').TrimEnd('\')
    if ([IO.Path]::GetDirectoryName($target) -ine $allowedParent -or [IO.Path]::GetFileName($target) -ine 'workflow-testing') {
        throw 'This repair is scoped to the new C:\Users\jing\workflow-testing directory only.'
    }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    if (-not $Apply) {
        @{
            mode = 'preview'; identity = $identity; source = $sourceRoot; target = $target
            grants = $(if ($GrantSandboxModify) { 'Local CodexSandboxUsers: Modify on this directory and its children only' } else { 'No ACL changes' })
            next = 'Run this script from the real user PowerShell with -Apply; reopen the new directory as the application workspace.'
        } | ConvertTo-Json -Depth 8
        exit 0
    }
    if ($identity -match '\\CodexSandbox[^\\]*$') {
        throw 'Cannot repair from the restricted sandbox account. Run this command in the real user PowerShell. No elevation is attempted.'
    }
    if (Test-Path -LiteralPath $target) {
        throw 'Target already exists. Refusing to overwrite files or change permissions on an existing project.'
    }
    $manifestFile = Join-Path $sourceRoot 'package-manifest.json'
    $manifest = Get-Content -Raw -Encoding UTF8 -LiteralPath $manifestFile | ConvertFrom-Json
    $payloadFiles = @($manifest.files | Where-Object { $_.path.StartsWith('workflow-testing/') })
    if ($payloadFiles.Count -eq 0) { throw 'No verified skill payload in manifest.' }
    # Verify every source path and checksum before creating or granting anything.
    foreach ($entry in $payloadFiles) {
        $relative = $entry.path.Substring('workflow-testing/'.Length).Replace('/', '\')
        $source = [IO.Path]::GetFullPath((Join-Path $sourceRoot $entry.path))
        $destination = [IO.Path]::GetFullPath((Join-Path $target $relative))
        if (-not $source.StartsWith(($sourceRoot + '\'), [StringComparison]::OrdinalIgnoreCase) -or
            -not $destination.StartsWith(($target + '\'), [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Manifest path leaves its allowed root.'
        }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
            throw ('Package checksum mismatch: ' + $entry.path)
        }
    }
    $sandboxSid = $null
    if ($GrantSandboxModify) {
        $sandboxAccount = New-Object Security.Principal.NTAccount($env:COMPUTERNAME, 'CodexSandboxUsers')
        $sandboxSid = $sandboxAccount.Translate([Security.Principal.SecurityIdentifier])
    }
    New-Item -ItemType Directory -Path $target -ErrorAction Stop | Out-Null
    $originalAcl = Get-Acl -LiteralPath $target
    [IO.File]::WriteAllText((Join-Path $target 'workspace-acl-before.sddl'), $originalAcl.Sddl)
    foreach ($entry in $payloadFiles) {
        $relative = $entry.path.Substring('workflow-testing/'.Length).Replace('/', '\')
        $source = [IO.Path]::GetFullPath((Join-Path $sourceRoot $entry.path))
        $destination = [IO.Path]::GetFullPath((Join-Path $target $relative))
        $parent = [IO.Path]::GetDirectoryName($destination)
        [IO.Directory]::CreateDirectory($parent) | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -ErrorAction Stop
    }
    if ($GrantSandboxModify) {
        $access = [Security.AccessControl.FileSystemRights]::Modify
        $inheritance = [Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'
        $propagation = [Security.AccessControl.PropagationFlags]::None
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sandboxSid, $access, $inheritance, $propagation, 'Allow')
        $updatedAcl = Get-Acl -LiteralPath $target
        $updatedAcl.AddAccessRule($rule)
        Set-Acl -LiteralPath $target -AclObject $updatedAcl
    }
    $probe = Join-Path $target ('.host-write-probe-' + [Guid]::NewGuid().ToString('N'))
    [IO.File]::WriteAllText($probe, 'write verified')
    Remove-Item -LiteralPath $probe -ErrorAction Stop
    @{
        mode = 'applied'; target = $target; files_copied = $payloadFiles.Count
        host_write_verified = $true; scoped_acl_grant_applied = [bool]$GrantSandboxModify
        sandbox_write_verified = $false
        next = 'Reopen this directory as the workspace and call doctor from the model. Host verification does not prove sandbox access.'
    } | ConvertTo-Json -Depth 8
    exit 0
}
catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
