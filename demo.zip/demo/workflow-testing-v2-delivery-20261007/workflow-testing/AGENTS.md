# Shared workflow testing package

Use `SKILL.md` and the versioned contracts under `references/`. This file applies to maintenance of this package and its generated project copies.

- Execution role: use only registered JSON tools through `scripts/toolchain.py` or `scripts/Invoke-WorkflowTool.ps1`. Do not invent tools, raw curl flags, shell actions or selectors. Reading input and evidence files is allowed.
- A test failure is a product/test finding, not permission to weaken assertions, expand waivers or edit the runner. Preserve raw results.
- Before modifying shared maintained files, read `references/collaboration.md` and `references/extensions.md`, record a change request, snapshot the affected existing files and acquire the single-writer claim. Only the owner writes shared files; readers may review concurrently.
- Do not delete another writer's lease. An interrupted lease requires the project owner to confirm the old writer has stopped before archiving it.
- Update contracts, examples, exported schemas and behavior tests together. Run `python -X utf8 -m unittest discover -s tests -v`; new runtime behavior must have observable positive and negative coverage.
- Do not overwrite `runs/` evidence. Generated reports and new independent test runs are normal tool operations and do not require a maintenance lease.
- Keep business facts sourced, unresolved questions explicit, and credentials outside artifacts. Document actual implementation limits.
- Do not modify unrelated files, host sandbox settings or global PowerShell policy. The separate host workspace repair script is an explicit one-time user maintenance operation, not a model execution tool.
- Generated project Skills must include their runtime, references, assets and tests. Do not claim auto-installation, an MCP server, browser execution or real Flowable integration without implementation and evidence.
- Report missing independent review as pending; do not invent a second reviewer.
