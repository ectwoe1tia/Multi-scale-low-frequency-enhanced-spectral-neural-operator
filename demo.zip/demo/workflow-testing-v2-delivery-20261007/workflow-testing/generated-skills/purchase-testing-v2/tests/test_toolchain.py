"""Observable HTTP behavior and cross-model contract invariants."""
import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import http_runner as runtime
import toolchain
from demo_support import DemoServer, make_assets

AUTH = {'WF_DEMO_APPLICANT': 'demo-applicant', 'WF_DEMO_MANAGER': 'demo-manager', 'WF_DEMO_DIRECTOR': 'demo-director'}


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.suite, self.adapter, self.plan = make_assets(8765)

    def validate(self):
        return runtime.validate_bundle(self.suite, self.adapter, self.plan)

    def test_unknown_keys_are_rejected(self):
        self.plan['cases'][0]['steps'][0]['shell'] = 'anything'
        with self.assertRaises(runtime.ToolError):
            self.validate()

    def test_all_business_assertions_must_be_mapped(self):
        del self.plan['cases'][0]['steps'][-1]['checks'][1]['assertion_id']
        with self.assertRaises(runtime.ToolError):
            self.validate()

    def test_mutating_poll_is_rejected(self):
        self.plan['cases'][0]['steps'][0]['poll'] = {'attempts': 2, 'interval_seconds': 0.05}
        with self.assertRaises(runtime.ToolError):
            self.validate()

    def test_actor_binding_and_auth_required(self):
        self.plan['cases'][0]['steps'][0]['actor'] = 'manager'
        with self.assertRaises(runtime.ToolError):
            self.validate()

    def test_no_unknown_or_overwritten_variables(self):
        self.plan['cases'][0]['steps'][0]['capture']['amount'] = '/body/amount'
        with self.assertRaises(runtime.ToolError):
            self.validate()

    def test_plan_fingerprint_changes_with_business_baseline(self):
        before = self.validate()['fingerprint']
        self.suite['requirements'][0]['text'] += ' revised'
        self.assertNotEqual(before, self.validate()['fingerprint'])

    def test_ambiguous_suite_cannot_run(self):
        self.suite['requirements'][0]['status'] = 'missing'
        self.suite['questions'] = [{'id': 'Q-DEMO', 'text': 'Which path?', 'status': 'open',
                                    'requirement_ids': ['REQ-DEMO-1'], 'options': [], 'answer': ''}]
        case = self.suite['cases'][0]
        case.update(status='needs_clarification', question_ids=['Q-DEMO'], automation={'status': 'unbound', 'reason': 'unknown'})
        with self.assertRaises(runtime.ToolError) as raised:
            self.validate()
        self.assertEqual(raised.exception.code, 'NEEDS_CLARIFICATION')

    def test_pointer_missing_is_not_null_or_false(self):
        self.assertFalse(runtime.compare(runtime.MISSING, 'eq', None))
        self.assertFalse(runtime.compare(True, 'eq', 1))
        self.assertFalse(runtime.compare(runtime.MISSING, 'ne', 'manager'))
        self.assertTrue(runtime.compare(runtime.json_pointer({'a/b': [None]}, '/a~1b/0'), 'exists'))

    def test_plain_remote_http_and_production_blocked(self):
        self.adapter['base_url'] = 'http://example.invalid'
        self.adapter['environment']['kind'] = 'test'
        with self.assertRaises(runtime.ToolError):
            self.validate()
        self.adapter['base_url'] = 'https://example.invalid'
        self.adapter['environment']['kind'] = 'production'
        with self.assertRaises(runtime.ToolError):
            self.validate()

    def test_absolute_endpoint_and_traversal_rejected(self):
        self.adapter['operations']['create']['path'] = '//example.invalid'
        with self.assertRaises(runtime.ToolError):
            self.validate()
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(runtime.ToolError):
                runtime.workspace_path(folder, '../outside.json')

    def test_unknown_tool_has_no_execution_path(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(runtime.ToolError):
                toolchain.dispatch(folder, {'protocol_version': '1.0', 'tool': 'shell', 'arguments': {}})

    def test_duplicate_json_key_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder) / 'duplicate.json'
            file.write_text('{"tool":"run","tool":"doctor"}', encoding='utf-8')
            with self.assertRaises(runtime.ToolError):
                runtime.read_json(file)


class HttpExecutionTests(unittest.TestCase):
    def setUp(self):
        self.workspace = tempfile.TemporaryDirectory(prefix='workflow-runtime-tests-')
        self.root = Path(self.workspace.name)
        self.server = DemoServer().__enter__()
        self.suite, self.adapter, self.plan = make_assets(self.server.server_port)
        self.env = patch.dict(os.environ, AUTH)
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self.server.__exit__(None, None, None)
        self.workspace.cleanup()

    def run_plan(self, run_id='RUN-ONE'):
        preview = runtime.validate_bundle(self.suite, self.adapter, self.plan)
        return runtime.run_plan(self.root, self.suite, self.adapter, self.plan, preview, run_id)

    def test_real_http_paths_roles_and_redaction(self):
        result = self.run_plan()
        self.assertEqual(result['summary'], {'PASS': 2, 'FAIL': 0, 'ERROR': 0})
        self.assertEqual(len(self.server.calls), 7)
        self.assertEqual(self.server.instances['instance-1']['state'], 'finance')
        self.assertEqual(self.server.instances['instance-2']['state'], 'manager')
        saved = (self.root / 'runs/RUN-ONE/results.json').read_text(encoding='utf-8')
        self.assertNotIn('response-secret-canary', saved)
        self.assertNotIn('demo-applicant', saved)

    def test_same_run_id_never_resends_mutations(self):
        self.run_plan()
        count = len(self.server.calls)
        with self.assertRaises(runtime.ToolError) as raised:
            self.run_plan()
        self.assertEqual(raised.exception.code, 'RUN_EXISTS')
        self.assertEqual(len(self.server.calls), count)

    def test_assertion_failure_stays_raw_failure_with_exact_waiver(self):
        self.plan['cases'] = self.plan['cases'][:1]
        self.plan['cases'][0]['steps'][-1]['checks'][1]['expected'] = 'unexpected-node'
        result = self.run_plan()
        case = result['cases'][0]
        self.assertEqual(case['execution_status'], 'FAIL')
        self.assertEqual(case['gate'], 'BLOCKED')
        failure = case['failures'][0]
        today = date.today().isoformat()
        self.suite['deviations'] = [{'id': 'GAP-DEMO', 'case_id': 'TC-DEMO-1', 'assertion_id': 'A-RESULT',
                                     'reason': 'test fixture only', 'owner': 'test', 'issue': 'TEST-1', 'status': 'accepted',
                                     'failure_signature': failure['failure_signature'],
                                     'scope': {'release': 'demo-v2', 'environment': 'local-demo'},
                                     'accepted_by': 'test fixture', 'accepted_at': today, 'expires_on': today}]
        self.assertEqual(runtime.assess_case(case, self.suite, self.adapter['environment'])[0], 'ALLOWED_WITH_GAPS')
        changed = copy.deepcopy(case)
        changed['failures'][0]['failure_signature'] = 'different-actual-error'
        self.assertEqual(runtime.assess_case(changed, self.suite, self.adapter['environment'])[0], 'BLOCKED')
        changed = copy.deepcopy(case)
        changed['unexecuted_steps'] = ['downstream-not-tested']
        self.assertEqual(runtime.assess_case(changed, self.suite, self.adapter['environment'])[0], 'BLOCKED')

    def test_transport_uncertainty_does_not_retry(self):
        self.plan['cases'] = self.plan['cases'][:1]
        self.adapter['operations']['create']['path'] = '/commit-then-drop'
        result = self.run_plan()
        self.assertEqual(result['status'], 'ERROR')
        self.assertEqual(self.server.calls, [('POST', '/commit-then-drop')])
        self.assertEqual(result['cases'][0]['steps'][0]['request_state'], 'SENDING')

    def test_safe_read_poll_eventually_passes(self):
        self.plan['cases'] = self.plan['cases'][:1]
        self.adapter['operations']['poll'] = {'method': 'GET', 'path': '/unstable', 'actors': ['applicant']}
        self.plan['cases'][0]['steps'] = [{'id': 'poll-ready', 'operation': 'poll', 'actor': 'applicant', 'params': {},
                                          'query': {}, 'body': None, 'capture': {}, 'poll': {'attempts': 3, 'interval_seconds': 0.05},
                                          'checks': [{'id': 'status', 'pointer': '/status_code', 'op': 'eq', 'expected': 200},
                                                     {'id': 'ready', 'pointer': '/body/ready', 'op': 'eq', 'expected': True, 'assertion_id': 'A-RESULT'}]}]
        result = self.run_plan()
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(self.server.poll_count, 2)

    def test_redirect_not_followed(self):
        operation = {'method': 'GET', 'path': '/redirect', 'actors': ['applicant']}
        response = runtime.curl_request(self.adapter, operation, 'applicant', {}, {}, None, 'x', 3, [])
        self.assertEqual(response['status_code'], 302)
        self.assertEqual(self.server.calls, [('GET', '/redirect')])

    def test_streaming_response_limit(self):
        operation = {'method': 'GET', 'path': '/large', 'actors': ['applicant']}
        with self.assertRaises(runtime.ToolError) as raised:
            runtime.curl_request(self.adapter, operation, 'applicant', {}, {}, None, 'x', 3, [])
        self.assertEqual(raised.exception.code, 'TRANSPORT_ERROR')

    def test_stale_preview_rejected_before_network(self):
        inputs = {}
        for name, value in [('suite', self.suite), ('adapter', self.adapter), ('plan', self.plan)]:
            (self.root / (name + '.json')).write_text(json.dumps(value), encoding='utf-8')
            inputs[name] = name + '.json'
        with self.assertRaises(runtime.ToolError) as raised:
            toolchain.dispatch(self.root, {'protocol_version': '1.0', 'tool': 'run',
                                           'arguments': {**inputs, 'expected_fingerprint': 'wrong', 'run_id': 'STALE'}})
        self.assertEqual(raised.exception.code, 'STALE_PLAN')
        self.assertEqual(self.server.calls, [])
        self.assertFalse((self.root / 'runs/STALE').exists())

    def test_missing_actor_secret_is_detected_before_any_mutation(self):
        with patch.dict(os.environ, {'WF_DEMO_DIRECTOR': ''}):
            with self.assertRaises(runtime.ToolError) as raised:
                self.run_plan()
        self.assertEqual(raised.exception.code, 'ENVIRONMENT_ERROR')
        self.assertEqual(self.server.calls, [])
        self.assertFalse((self.root / 'runs/RUN-ONE').exists())

    def test_results_tampering_is_detected_and_original_report_is_preserved(self):
        inputs = {}
        for name, value in [('suite', self.suite), ('adapter', self.adapter), ('plan', self.plan)]:
            (self.root / (name + '.json')).write_text(json.dumps(value), encoding='utf-8')
            inputs[name] = name + '.json'
        preview = runtime.validate_bundle(self.suite, self.adapter, self.plan)
        run = toolchain.dispatch(self.root, {'protocol_version': '1.0', 'tool': 'run', 'arguments': {
            **inputs, 'run_id': 'INTEGRITY', 'expected_fingerprint': preview['fingerprint']}})
        self.assertTrue(run['ok'])
        request = {'protocol_version': '1.0', 'tool': 'report', 'arguments': {'run_id': 'INTEGRITY', 'out': 'report.md'}}
        self.assertTrue(toolchain.dispatch(self.root, request)['ok'])
        original = (self.root / 'report.md').read_bytes()
        with self.assertRaises(FileExistsError):
            toolchain.dispatch(self.root, request)
        self.assertEqual(original, (self.root / 'report.md').read_bytes())
        result_file = self.root / 'runs/INTEGRITY/results.json'
        result_file.write_text(result_file.read_text(encoding='utf-8') + ' ', encoding='utf-8')
        with self.assertRaises(runtime.ToolError) as raised:
            toolchain.dispatch(self.root, request)
        self.assertEqual(raised.exception.code, 'EVIDENCE_CHANGED')

    def test_cli_preserves_failure_exit_code(self):
        self.plan['cases'] = self.plan['cases'][:1]
        self.plan['cases'][0]['steps'][-1]['checks'][1]['expected'] = 'wrong'
        inputs = {}
        for name, value in [('suite', self.suite), ('adapter', self.adapter), ('plan', self.plan)]:
            (self.root / (name + '.json')).write_text(json.dumps(value), encoding='utf-8')
            inputs[name] = name + '.json'
        preview = runtime.validate_bundle(self.suite, self.adapter, self.plan)
        request_file = self.root / 'request.json'
        request_file.write_text(json.dumps({'protocol_version': '1.0', 'tool': 'run', 'arguments': {
            **inputs, 'run_id': 'FAILURE', 'expected_fingerprint': preview['fingerprint']}}), encoding='utf-8')
        run = subprocess.run([sys.executable, '-X', 'utf8', str(ROOT / 'scripts/toolchain.py'),
                              '--workspace', str(self.root), '--request', str(request_file)],
                             capture_output=True, encoding='utf-8')
        self.assertEqual(run.returncode, 10, run.stdout + run.stderr)
        response = json.loads(run.stdout)
        self.assertEqual(response['code'], 'TEST_FAILED')
        self.assertEqual(response['data']['status'], 'FAIL')


class CollaborationAndShellTests(unittest.TestCase):
    def test_only_one_writer_and_stale_base_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            target = root / 'file.md'
            target.write_text('v1', encoding='utf-8')
            hashes = toolchain.snapshots(root, ['file.md'])
            request = {'protocol_version': '1.0', 'tool': 'claim', 'arguments': {'owner': 'model-a', 'change_id': 'CHANGE-1', 'base_hashes': hashes}}
            lease = toolchain.dispatch(root, request)['data']
            with self.assertRaises(runtime.ToolError) as raised:
                toolchain.dispatch(root, request)
            self.assertEqual(raised.exception.code, 'LEASE_BUSY')
            target.write_text('v2', encoding='utf-8')
            with self.assertRaises(runtime.ToolError):
                toolchain.dispatch(root, {'protocol_version': '1.0', 'tool': 'release', 'arguments': {'lease_token': 'wrong'}})
            toolchain.dispatch(root, {'protocol_version': '1.0', 'tool': 'release', 'arguments': {'lease_token': lease['lease_token']}})
            with self.assertRaises(runtime.ToolError) as raised:
                toolchain.dispatch(root, request)
            self.assertEqual(raised.exception.code, 'CHANGE_CONFLICT')

    @unittest.skipUnless(os.name == 'nt', 'PowerShell wrapper requires Windows')
    def test_powershell_json_entry_handles_spaces_and_cjk_paths(self):
        with tempfile.TemporaryDirectory(prefix='workflow 中文 space ') as folder:
            request = Path(folder) / 'doctor request.json'
            request.write_text(json.dumps({'protocol_version': '1.0', 'tool': 'doctor', 'arguments': {}}), encoding='utf-8')
            run = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'RemoteSigned', '-File', str(ROOT / 'scripts/Invoke-WorkflowTool.ps1'),
                                  '-Workspace', folder, '-Request', str(request)], capture_output=True, encoding='utf-8')
            self.assertEqual(run.returncode, 0, run.stderr)
            response = json.loads(run.stdout)
            self.assertTrue(response['ok'])
            self.assertTrue(response['data']['writable'])


if __name__ == '__main__':
    unittest.main()
