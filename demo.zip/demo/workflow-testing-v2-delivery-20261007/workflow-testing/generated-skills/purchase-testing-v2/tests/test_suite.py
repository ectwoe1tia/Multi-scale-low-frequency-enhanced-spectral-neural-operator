"""Behavior checks for traceability, ambiguity, deviations and generated artifacts."""
import copy
import csv
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('suite_tool', ROOT / 'scripts/suite.py')
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)


class SuiteTests(unittest.TestCase):
    def setUp(self):
        self.suite = tool.read_suite(ROOT / 'assets/example-suite.json')

    def test_example_preserves_uncertainty(self):
        errors, warnings = tool.validate(self.suite)
        self.assertEqual(errors, [])
        self.assertTrue(warnings)
        blocked = [c for c in self.suite['cases'] if c['status'] == 'needs_clarification']
        self.assertEqual({c['id'] for c in blocked}, {'TC-007', 'TC-009'})
        self.assertFalse(any(d['status'] == 'accepted' for d in self.suite['deviations']))

    def test_empty_scaffold_is_not_valid_design(self):
        for key in ('sources', 'requirements', 'questions', 'cases', 'deviations'):
            self.suite[key] = []
        errors, _ = tool.validate(self.suite)
        self.assertTrue(any('空模板' in e for e in errors))

    def test_orphan_reference_is_rejected(self):
        self.suite['cases'][0]['requirement_ids'] = ['REQ-NOT-FOUND']
        self.assertTrue(tool.validate(self.suite)[0])

    def test_conflict_cannot_be_marked_ready(self):
        case = self.suite['cases'][6]
        case['status'] = 'ready'
        case['question_ids'] = []
        case['assertions'][0].update(status='defined', expected='直接进入财务')
        errors, _ = tool.validate(self.suite)
        self.assertTrue(any('不能标为 ready' in e for e in errors))

    def test_pending_assertion_blocks_ready(self):
        self.suite['cases'][0]['assertions'][0]['status'] = 'pending'
        self.assertTrue(tool.validate(self.suite)[0])

    def test_resolved_question_without_answer_rejected(self):
        self.suite['questions'][0]['status'] = 'resolved'
        self.assertTrue(any('.answer' in e for e in tool.validate(self.suite)[0]))

    def test_unrelated_question_cannot_satisfy_blocked_case(self):
        self.suite['cases'][6]['question_ids'] = ['Q-002']
        self.assertTrue(any('无关' in e for e in tool.validate(self.suite)[0]))

    def test_implemented_requires_ready_and_artifact(self):
        self.suite['cases'][6]['automation'] = {'status': 'implemented', 'artifact': ''}
        errors, _ = tool.validate(self.suite)
        self.assertTrue(any('artifact' in e for e in errors))
        self.assertTrue(any('implemented' in e for e in errors))

    def test_duplicate_ids_rejected(self):
        self.suite['cases'].append(copy.deepcopy(self.suite['cases'][0]))
        self.assertTrue(any('ID 重复' in e for e in tool.validate(self.suite)[0]))

    def test_deviation_cannot_reference_other_assertion(self):
        self.suite['deviations'][0]['assertion_id'] = 'A-404'
        self.assertTrue(any('assertion_id' in e for e in tool.validate(self.suite)[0]))

    def test_acceptance_requires_evidence_fields(self):
        self.suite['deviations'][0]['status'] = 'accepted'
        errors, _ = tool.validate(self.suite)
        self.assertTrue(any('accepted_by' in e for e in errors))
        self.assertTrue(any('expires_on' in e for e in errors))

    def test_expired_deviation_is_not_silent(self):
        self.suite['deviations'][0].update(status='accepted', accepted_by='测试角色',
                                         accepted_at='2026-01-01', expires_on='2026-02-01')
        errors, warnings = tool.validate(self.suite, today=date(2026, 10, 7))
        self.assertEqual(errors, [])
        self.assertTrue(any('妥协已过期' in w for w in warnings))

    def test_wildcard_waiver_scope_rejected(self):
        self.suite['deviations'][0]['scope']['release'] = '*'
        self.assertTrue(any('通配符' in e for e in tool.validate(self.suite)[0]))

    def test_malformed_types_return_errors_not_crashes(self):
        for key, value in [('cases', [None]), ('requirements', {}), ('sources', None)]:
            candidate = copy.deepcopy(self.suite)
            candidate[key] = value
            self.assertTrue(tool.validate(candidate)[0])
        candidate = copy.deepcopy(self.suite)
        candidate['requirements'][0]['status'] = []
        candidate['cases'][0]['automation'] = None
        candidate['deviations'][0]['case_id'] = {}
        self.assertTrue(tool.validate(candidate)[0])

    def test_report_preserves_cases_and_csv_is_safe(self):
        self.suite['cases'][0]['title'] = '=HYPERLINK("https://example.invalid")'
        with tempfile.TemporaryDirectory(prefix='workflow-skill-test-') as folder:
            target = Path(folder) / 'report'
            tool.render(self.suite, target, tool.validate(self.suite)[1])
            with (target / 'cases.csv').open(encoding='utf-8-sig', newline='') as handle:
                rows = list(csv.reader(handle))
            self.assertEqual(len(rows), len(self.suite['cases']) + 1)
            self.assertTrue(rows[1][1].startswith("'="))
            self.assertIn('needs_clarification', (target / 'report.md').read_text(encoding='utf-8'))
            before = (target / 'cases.csv').read_bytes()
            with self.assertRaises(FileExistsError):
                tool.render(self.suite, target, [])
            self.assertEqual(before, (target / 'cases.csv').read_bytes())

    def test_project_skill_is_self_contained_and_preserves_uncertainty(self):
        with tempfile.TemporaryDirectory(prefix='workflow-skill-test-') as folder:
            target = tool.build_skill(self.suite, folder, 'purchase-workflow-testing')
            baseline = target / 'references/project-suite.json'
            self.assertEqual(tool.read_suite(baseline), self.suite)
            for path in ('SKILL.md', 'agents/openai.yaml', 'references/requirements.md',
                         'references/contract.md', 'references/automation.md', 'scripts/suite.py',
                         'scripts/toolchain.py', 'scripts/http_runner.py', 'scripts/Invoke-WorkflowTool.ps1',
                         'references/toolchain.md', 'references/collaboration.md', 'references/extensions.md'):
                self.assertTrue((target / path).is_file(), path)
            run = subprocess.run([sys.executable, '-X', 'utf8', str(target / 'scripts/suite.py'),
                                  'validate', str(baseline)], capture_output=True, encoding='utf-8')
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            discovery = subprocess.run([sys.executable, '-X', 'utf8', str(target / 'scripts/toolchain.py'),
                                        '--workspace', str(target), '--describe'], capture_output=True, encoding='utf-8')
            self.assertEqual(discovery.returncode, 0, discovery.stdout + discovery.stderr)
            self.assertTrue(json.loads(discovery.stdout)['ok'])
            with self.assertRaises(FileExistsError):
                tool.build_skill(self.suite, folder, 'purchase-workflow-testing')
            with self.assertRaises(ValueError):
                tool.build_skill(self.suite, folder, '../escape')

    def test_cli_rejects_invalid_suite_without_outputs(self):
        with tempfile.TemporaryDirectory(prefix='workflow-skill-test-') as folder:
            source = Path(folder) / 'bad.json'
            source.write_text(json.dumps({'schema_version': '1.0'}), encoding='utf-8')
            target = Path(folder) / 'report'
            run = subprocess.run([sys.executable, '-X', 'utf8', str(ROOT / 'scripts/suite.py'),
                                  'render', str(source), '--out', str(target)],
                                 capture_output=True, encoding='utf-8')
            self.assertEqual(run.returncode, 1)
            self.assertFalse(target.exists())


if __name__ == '__main__':
    unittest.main()
