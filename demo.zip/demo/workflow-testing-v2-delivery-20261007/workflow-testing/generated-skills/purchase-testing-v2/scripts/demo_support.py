"""Loopback-only illustrative application and assets for real HTTP execution tests."""
import json
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class DemoServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self):
        super().__init__(('127.0.0.1', 0), DemoHandler)
        self.instances = {}
        self.calls = []
        self.poll_count = 0
        self.thread = threading.Thread(target=self.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.shutdown()
        self.server_close()
        self.thread.join(timeout=3)


class DemoHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send_json(self, status, body, headers=None):
        data = json.dumps(body).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def do_GET(self):
        self.server.calls.append(('GET', self.path))
        if self.path.startswith('/instances/'):
            item = self.server.instances.get(self.path.rsplit('/', 1)[-1])
            self.send_json(200 if item else 404, item or {'error': 'not_found'})
        elif self.path == '/unstable':
            self.server.poll_count += 1
            self.send_json(200, {'ready': self.server.poll_count >= 2})
        elif self.path == '/redirect':
            self.send_json(302, {'redirect': True}, {'Location': '/redirect-target'})
        elif self.path == '/large':
            self.send_json(200, {'payload': 'x' * (1024 * 1024 + 200)})
        else:
            self.send_json(404, {'error': 'not_found'})

    def do_POST(self):
        self.server.calls.append(('POST', self.path))
        try:
            data = json.loads(self.rfile.read(int(self.headers.get('Content-Length', '0'))) or b'{}')
        except ValueError:
            self.send_json(400, {'error': 'invalid_json'})
            return
        actor = self.headers.get('Authorization', '').replace('Bearer demo-', '')
        if self.path == '/instances':
            if actor != 'applicant':
                self.send_json(403, {'error': 'forbidden'})
                return
            if type(data.get('amount')) not in (int, float) or data['amount'] <= 0:
                self.send_json(400, {'error': 'invalid_amount'})
                return
            iid = 'instance-' + str(len(self.server.instances) + 1)
            item = {'id': iid, 'amount': data['amount'], 'state': 'manager', 'task_id': iid + '-manager',
                    'history': ['submitted'], 'access_token': 'response-secret-canary'}
            self.server.instances[iid] = item
            self.send_json(201, item)
        elif self.path == '/commit-then-drop':
            self.connection.shutdown(socket.SHUT_RDWR)
            self.connection.close()
        elif self.path.startswith('/tasks/') and self.path.endswith('/complete'):
            task = self.path.split('/')[2]
            item = next((v for v in self.server.instances.values() if v['task_id'] == task), None)
            if not item:
                self.send_json(404, {'error': 'task_not_found'})
            elif actor != item['state']:
                self.send_json(403, {'error': 'forbidden'})
            else:
                old = item['state']
                item['history'].append(old + '-approved')
                item['state'] = 'director' if old == 'manager' and item['amount'] > 10000 else 'finance'
                item['task_id'] = item['id'] + '-' + item['state']
                self.send_json(200, item)
        else:
            self.send_json(404, {'error': 'not_found'})


def make_assets(port):
    """Demo data only. Does not represent any user's Flowable or low-code API."""
    suite = {
        'schema_version': '1.0', 'project': '本地HTTP流程工具链演示', 'platform': 'custom',
        'sources': [{'id': 'SRC-DEMO', 'location': 'demo_support.py / local demo contract',
                     'excerpt': '金额大于10000经过主管和总监后到财务；非任务办理人审批返回403且状态不变。'}],
        'requirements': [
            {'id': 'REQ-DEMO-1', 'text': '12000元申请经过主管和总监后停在财务。', 'status': 'explicit', 'source_ids': ['SRC-DEMO']},
            {'id': 'REQ-DEMO-2', 'text': '申请人不能办理主管任务，拒绝后任务仍在主管。', 'status': 'explicit', 'source_ids': ['SRC-DEMO']}],
        'questions': [], 'cases': [], 'deviations': []}
    for n, title, category, amount in [(1, '推进到财务待办', 'happy_path', 12000), (2, '验证错误角色审批被拒绝', 'permission', 8000)]:
        suite['cases'].append({'id': f'TC-DEMO-{n}', 'title': title, 'requirement_ids': [f'REQ-DEMO-{n}'],
                               'category': category, 'priority': 'P0', 'status': 'ready', 'question_ids': [],
                               'preconditions': ['本地演示服务运行中'], 'actors': ['applicant', 'manager', 'director'],
                               'data': {'amount': amount}, 'steps': [title],
                               'assertions': [{'id': 'A-RESULT', 'expected': suite['requirements'][n-1]['text'], 'status': 'defined'}],
                               'automation': {'status': 'implemented', 'artifact': 'plan.json', 'reason': '本地演示接口映射'}})
    adapter = {
        'schema_version': '1.0', 'adapter_id': 'local-demo', 'platform': 'custom',
        'base_url': f'http://127.0.0.1:{port}', 'environment': {'name': 'local-demo', 'kind': 'local', 'release': 'demo-v2'},
        'allow_mutations': True, 'timeout_seconds': 3, 'max_duration_seconds': 30,
        'idempotency_header': 'Idempotency-Key',
        'actors': {role: {'bearer_token_env': 'WF_DEMO_' + role.upper()} for role in ('applicant', 'manager', 'director')},
        'operations': {
            'create': {'method': 'POST', 'path': '/instances', 'actors': ['applicant']},
            'complete': {'method': 'POST', 'path': '/tasks/{task_id}/complete', 'actors': ['applicant', 'manager', 'director']},
            'state': {'method': 'GET', 'path': '/instances/{instance_id}', 'actors': ['applicant', 'manager', 'director']}}}

    def step(sid, operation, actor, params=None, body=None, capture=None, status=200, checks=None):
        return {'id': sid, 'operation': operation, 'actor': actor, 'params': params or {}, 'query': {},
                'body': body, 'capture': capture or {},
                'checks': [{'id': sid + '-http', 'pointer': '/status_code', 'op': 'eq', 'expected': status}] + (checks or [])}

    def create():
        return step('create', 'create', 'applicant', body={'amount': '${amount}'}, status=201,
                    capture={'instance_id': '/body/id', 'manager_task_id': '/body/task_id'})

    plan = {'schema_version': '1.0', 'plan_id': 'local-demo-plan', 'adapter_id': 'local-demo', 'cases': [
        {'case_id': 'TC-DEMO-1', 'vars': {'amount': 12000}, 'steps': [create(),
            step('manager', 'complete', 'manager', {'task_id': '${manager_task_id}'}, {'decision': 'approve'},
                 {'director_task_id': '/body/task_id'}, checks=[{'id': 'director-waiting', 'pointer': '/body/state', 'op': 'eq', 'expected': 'director'}]),
            step('director', 'complete', 'director', {'task_id': '${director_task_id}'}, {'decision': 'approve'}),
            step('finance', 'state', 'applicant', {'instance_id': '${instance_id}'}, checks=[
                {'id': 'finance-waiting', 'pointer': '/body/state', 'op': 'eq', 'expected': 'finance', 'assertion_id': 'A-RESULT'},
                {'id': 'history', 'pointer': '/body/history', 'op': 'eq', 'expected': ['submitted', 'manager-approved', 'director-approved']}])]},
        {'case_id': 'TC-DEMO-2', 'vars': {'amount': 8000}, 'steps': [create(),
            step('unauthorized', 'complete', 'applicant', {'task_id': '${manager_task_id}'}, {'decision': 'approve'}, status=403),
            step('unchanged', 'state', 'applicant', {'instance_id': '${instance_id}'}, checks=[
                {'id': 'still-manager', 'pointer': '/body/state', 'op': 'eq', 'expected': 'manager', 'assertion_id': 'A-RESULT'}])]}]}
    return suite, adapter, plan
