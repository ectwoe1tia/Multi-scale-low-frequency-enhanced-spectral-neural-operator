[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Workspace,
    [Parameter(Mandatory = $true)][string]$Request,
    [string]$Python = 'python'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
try {
    $workspacePath = (Resolve-Path -LiteralPath $Workspace -ErrorAction Stop).Path
    $requestPath = (Resolve-Path -LiteralPath $Request -ErrorAction Stop).Path
    $pythonCommand = Get-Command -Name $Python -CommandType Application -ErrorAction Stop | Select-Object -First 1
    $entry = Join-Path $PSScriptRoot 'toolchain.py'
    # Argument array; no Invoke-Expression, curl alias, interpolated shell or JSON command text.
    & $pythonCommand.Source -X utf8 $entry --workspace $workspacePath --request $requestPath
    exit $LASTEXITCODE
}
catch {
    $result = @{
        protocol_version = '1.0'; tool = 'unknown'; ok = $false
        code = 'ENVIRONMENT_ERROR'; message = 'Cannot locate Python, workspace or request file.'; data = @{}
    }
    [Console]::Out.WriteLine(($result | ConvertTo-Json -Compress -Depth 10))
    exit 12
}
