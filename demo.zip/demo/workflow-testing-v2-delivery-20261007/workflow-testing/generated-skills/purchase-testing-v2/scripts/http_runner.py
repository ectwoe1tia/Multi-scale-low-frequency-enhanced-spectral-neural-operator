"""Version 1 HTTP workflow contract and deterministic curl execution.

Only registered operations are executable. No shell strings, eval, browser or SQL.
"""
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import time
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.parse import urlencode, urlsplit

import suite as suite_tools

VERSION = '2.0.0'
PROTOCOL = '1.0'
MAX_BYTES = 1024 * 1024
MISSING = object()
SECRET_KEYS = re.compile(r'password|passwd|secret|token|authorization|cookie|api.?key', re.I)
IDENT = re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,79}$')
READ_METHODS = {'GET', 'HEAD'}
OPERATORS = {'eq', 'ne', 'contains', 'exists', 'not_exists', 'gt', 'gte', 'lt', 'lte'}


class ToolError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def need(condition, message, code='INVALID_INPUT'):
    if not condition:
        raise ToolError(code, message)


def shape(value, required, optional=(), label='object'):
    need(isinstance(value, dict), f'{label}: object required')
    need(set(required) <= value.keys(), f'{label}: missing keys {sorted(set(required) - value.keys())}')
    need(value.keys() <= set(required) | set(optional), f'{label}: unknown keys {sorted(value.keys() - set(required) - set(optional))}')


def text(value, label):
    need(isinstance(value, str) and bool(value.strip()), f'{label}: nonempty string required')
    return value


def ident(value, label):
    need(isinstance(value, str) and bool(IDENT.fullmatch(value)), f'{label}: invalid identifier')
    return value


def number(value, low, high, label):
    need(type(value) in (int, float) and math.isfinite(value) and low <= value <= high,
         f'{label}: number between {low} and {high} required')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def read_json(path, max_bytes=MAX_BYTES):
    path = Path(path)
    need(path.stat().st_size <= max_bytes, 'JSON document exceeds size limit')
    def pairs(items):
        obj = {}
        for key, value in items:
            need(key not in obj, f'Duplicate JSON key: {key}')
            obj[key] = value
        return obj
    def constant(value):
        raise ToolError('INVALID_INPUT', f'Non-JSON numeric value: {value}')
    try:
        return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ToolError('INVALID_INPUT', 'Invalid UTF-8 JSON document') from exc


def workspace_path(root, relative, existing=False):
    root = Path(root).resolve()
    text(relative, 'relative path')
    need(not Path(relative).is_absolute() and not re.match(r'^[A-Za-z]:', relative), 'Use workspace-relative paths')
    target = (root / relative).resolve()
    need(target != root and root in target.parents, 'Path leaves workspace')
    if existing:
        need(target.is_file(), f'Input file missing: {relative}')
    return target


def redact(value, secrets=()):
    if value is MISSING:
        return {'missing': True}
    if isinstance(value, dict):
        return {key: '[REDACTED]' if SECRET_KEYS.search(key) else redact(item, secrets) for key, item in value.items()}
    if isinstance(value, list):
        return [redact(item, secrets) for item in value]
    if isinstance(value, str):
        for secret in sorted((s for s in secrets if s), key=len, reverse=True):
            value = value.replace(secret, '[REDACTED]')
    return value


def json_pointer(document, pointer):
    need(isinstance(pointer, str) and (pointer == '' or pointer.startswith('/')), 'Invalid JSON pointer')
    current = document
    for part in pointer.split('/')[1:] if pointer else []:
        part = part.replace('~1', '/').replace('~0', '~')
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list) and re.fullmatch(r'0|[1-9][0-9]*', part) and int(part) < len(current):
            current = current[int(part)]
        else:
            return MISSING
    return current


def refs(value):
    if isinstance(value, str):
        match = re.fullmatch(r'\$\{([A-Za-z][A-Za-z0-9_-]*)\}', value)
        if match:
            return {match.group(1)}
        need('${' not in value, 'Variables must occupy the entire value, e.g. ${instance_id}')
    if isinstance(value, dict):
        return set().union(*(refs(v) for v in value.values())) if value else set()
    if isinstance(value, list):
        return set().union(*(refs(v) for v in value)) if value else set()
    return set()


def substitute(value, context):
    if isinstance(value, str) and re.fullmatch(r'\$\{([A-Za-z][A-Za-z0-9_-]*)\}', value):
        return context[value[2:-1]]
    if isinstance(value, dict):
        return {k: substitute(v, context) for k, v in value.items()}
    if isinstance(value, list):
        return [substitute(v, context) for v in value]
    return value


def validate_bundle(suite, adapter, plan):
    errors, warnings = suite_tools.validate(suite)
    need(not errors, 'Suite invalid: ' + '; '.join(errors))
    shape(adapter, ['schema_version', 'adapter_id', 'platform', 'base_url', 'environment', 'allow_mutations',
                    'timeout_seconds', 'max_duration_seconds', 'actors', 'operations'], ['idempotency_header'], 'adapter')
    need(adapter['schema_version'] == PROTOCOL, 'Unsupported adapter schema_version')
    ident(adapter['adapter_id'], 'adapter_id')
    need(adapter['platform'] in ('lowcode', 'flowable', 'custom'), 'Unknown adapter platform')
    need(suite['platform'] in ('unknown', 'mixed', adapter['platform']), 'Suite/adapter platform mismatch')
    text(adapter['base_url'], 'base_url')
    origin = urlsplit(adapter['base_url'])
    need(origin.scheme in ('http', 'https') and origin.hostname and not origin.username and not origin.password,
         'base_url must be an HTTP(S) origin without credentials')
    need(origin.path in ('', '/') and not origin.query and not origin.fragment, 'base_url must contain only origin')
    try:
        origin.port
    except ValueError as exc:
        raise ToolError('INVALID_INPUT', 'Invalid origin port') from exc
    shape(adapter['environment'], ['name', 'kind', 'release'], label='environment')
    env = adapter['environment']
    for key in ('name', 'release'):
        text(env[key], 'environment.' + key)
        need('*' not in env[key], 'Environment and release cannot be wildcards')
    need(env['kind'] in ('local', 'test', 'uat'), 'Production environments are not supported by this runner')
    loopback = origin.hostname in ('localhost', '127.0.0.1', '::1')
    need(origin.scheme == 'https' or loopback, 'Plain HTTP is supported only for local loopback')
    need(env['kind'] != 'local' or loopback, 'local environment must use loopback')
    need(type(adapter['allow_mutations']) is bool, 'allow_mutations must be boolean')
    number(adapter['timeout_seconds'], 1, 30, 'timeout_seconds')
    number(adapter['max_duration_seconds'], 1, 300, 'max_duration_seconds')
    header = adapter.get('idempotency_header')
    if header is not None:
        need(isinstance(header, str) and bool(re.fullmatch(r'[A-Za-z][A-Za-z0-9-]*', header)), 'Invalid idempotency_header')
        need(header.lower() not in {'authorization', 'host', 'cookie', 'content-type', 'content-length'}, 'Reserved idempotency header')
    actors = adapter['actors']
    need(isinstance(actors, dict) and actors, 'At least one actor is required')
    for actor, auth in actors.items():
        ident(actor, 'actor')
        shape(auth, ['bearer_token_env'], label='actor auth')
        token_env = auth['bearer_token_env']
        need(isinstance(token_env, str), 'bearer_token_env must be string')
        need(token_env == '' or bool(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', token_env)), 'Invalid token environment name')
        need(token_env != '' or (loopback and env['kind'] == 'local'), 'Authentication-free actors are local-demo-only')
    operations = adapter['operations']
    need(isinstance(operations, dict) and operations, 'operations must be nonempty object')
    for oid, op in operations.items():
        ident(oid, 'operation')
        shape(op, ['method', 'path', 'actors'], label='operation ' + oid)
        need(op['method'] in ('GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'), 'Unsupported HTTP method')
        path = text(op['path'], 'operation.path')
        need(path.startswith('/') and not path.startswith('//') and not any(c in path for c in ('?', '#', '\\', '%')),
             'Operation path must be a literal relative HTTP path without query, escapes or fragment')
        need(not any(c.isspace() or ord(c) < 32 for c in path) and '..' not in path.split('/'), 'Invalid operation path')
        placeholders = re.findall(r'\{([A-Za-z][A-Za-z0-9_-]*)\}', path)
        remainder = re.sub(r'\{[A-Za-z][A-Za-z0-9_-]*\}', '', path)
        need('{' not in remainder and '}' not in remainder, 'Invalid path placeholder')
        need(len(placeholders) == len(set(placeholders)), 'Repeated path placeholders')
        need(isinstance(op['actors'], list) and op['actors'] and all(isinstance(a, str) and a in actors for a in op['actors']), 'Invalid operation actors')

    shape(plan, ['schema_version', 'plan_id', 'adapter_id', 'cases'], label='plan')
    need(plan['schema_version'] == PROTOCOL, 'Unsupported plan schema_version')
    ident(plan['plan_id'], 'plan_id')
    need(plan['adapter_id'] == adapter['adapter_id'], 'Wrong adapter binding')
    need(isinstance(plan['cases'], list) and 1 <= len(plan['cases']) <= 100, 'Plan must contain 1..100 cases')
    indexed = {case['id']: case for case in suite['cases']}
    seen_cases = set()
    preview = []
    for case in plan['cases']:
        shape(case, ['case_id', 'vars', 'steps'], label='plan case')
        cid = ident(case['case_id'], 'case_id')
        need(cid in indexed and cid not in seen_cases, 'Unknown or duplicated case_id: ' + cid)
        seen_cases.add(cid)
        need(indexed[cid]['status'] == 'ready', cid + ': unresolved cases cannot run', 'NEEDS_CLARIFICATION')
        need(isinstance(case['vars'], dict), 'vars must be an object')
        for name in case['vars']:
            ident(name, 'variable')
        need(not {'run_id', 'case_id'} & case['vars'].keys(), 'Reserved initial variable')
        need(not refs(case['vars']), 'Initial vars must be literals')
        known = set(case['vars']) | {'run_id', 'case_id'}
        need(isinstance(case['steps'], list) and 1 <= len(case['steps']) <= 40, 'Case must have 1..40 steps')
        step_ids, check_ids, mapped = set(), set(), set()
        required = {a['id'] for a in indexed[cid]['assertions']}
        for step in case['steps']:
            shape(step, ['id', 'operation', 'actor', 'params', 'query', 'body', 'capture', 'checks'], ['poll'], 'step')
            sid = ident(step['id'], 'step id')
            need(sid not in step_ids, 'Duplicate step id')
            step_ids.add(sid)
            operation = step['operation']
            need(isinstance(operation, str) and operation in operations, 'Unregistered operation')
            op = operations[operation]
            need(step['actor'] in op['actors'], 'Actor not allowed for operation')
            if op['method'] not in READ_METHODS:
                need(adapter['allow_mutations'], 'Mutation disabled in adapter', 'MUTATION_DISABLED')
            for key in ('params', 'query', 'capture'):
                need(isinstance(step[key], dict), key + ' must be object')
            placeholders = set(re.findall(r'\{([A-Za-z][A-Za-z0-9_-]*)\}', op['path']))
            need(set(step['params']) == placeholders, 'Path parameters do not match registered operation')
            need(not any(SECRET_KEYS.search(k) for k in step['query']), 'Credentials cannot be passed through query strings')
            if op['method'] in READ_METHODS:
                need(step['body'] is None, 'GET/HEAD cannot carry a body')
            used = refs({k: step[k] for k in ('params', 'query', 'body', 'checks')})
            need(used <= known, 'Unknown variables: ' + ', '.join(sorted(used - known)))
            need(isinstance(step['checks'], list) and step['checks'], 'Every step needs observable checks')
            has_status_check = False
            for check in step['checks']:
                shape(check, ['id', 'pointer', 'op'], ['expected', 'assertion_id'], 'check')
                check_id = ident(check['id'], 'check id')
                need(check_id not in check_ids, 'Duplicate check id within case')
                check_ids.add(check_id)
                need(isinstance(check['op'], str) and check['op'] in OPERATORS, 'Unsupported check operator')
                pointer = text(check['pointer'], 'pointer')
                need(pointer.startswith('/') and not re.search(r'~(?![01])', pointer), 'Use valid JSON pointers')
                if check['op'] in ('exists', 'not_exists'):
                    need('expected' not in check, 'exists/not_exists cannot have expected')
                else:
                    need('expected' in check, 'Comparison needs expected value')
                if pointer == '/status_code' and check['op'] == 'eq':
                    expected = check.get('expected')
                    need(type(expected) is int and 100 <= expected <= 599, 'HTTP status check needs integer literal')
                    has_status_check = True
                aid = check.get('assertion_id')
                if aid is not None:
                    need(isinstance(aid, str) and aid in required and aid not in mapped, 'Unknown or duplicated business assertion mapping')
                    mapped.add(aid)
            need(has_status_check, 'Each step must explicitly assert expected HTTP status_code with eq')
            if 'poll' in step:
                shape(step['poll'], ['attempts', 'interval_seconds'], label='poll')
                need(op['method'] in READ_METHODS, 'Polling/retry of mutating operation is prohibited')
                attempts = step['poll']['attempts']
                need(type(attempts) is int and 1 <= attempts <= 20, 'poll.attempts must be 1..20')
                number(step['poll']['interval_seconds'], 0.05, 5, 'poll.interval_seconds')
            for name, pointer in step['capture'].items():
                ident(name, 'capture name')
                need(name not in known, 'Captured variable cannot overwrite an earlier value')
                need(isinstance(pointer, str) and pointer.startswith('/') and not re.search(r'~(?![01])', pointer), 'Invalid capture JSON pointer')
                known.add(name)
            preview.append({'case_id': cid, 'step_id': sid, 'operation': operation,
                            'method': op['method'], 'path_template': op['path'], 'actor': step['actor'],
                            'mutates': op['method'] not in READ_METHODS, 'checks': len(step['checks'])})
        need(mapped == required, cid + ': every business assertion must be mapped exactly once')
    fingerprint = digest({'suite': suite, 'adapter': adapter, 'plan': plan, 'runner_version': VERSION})
    return {'fingerprint': fingerprint, 'warnings': warnings, 'steps': preview,
            'selected_cases': sorted(seen_cases), 'not_selected_cases': sorted(indexed.keys() - seen_cases)}


def compare(actual, op, expected=MISSING):
    if op == 'exists':
        return actual is not MISSING
    if op == 'not_exists':
        return actual is MISSING
    if actual is MISSING:
        return False
    if op in ('eq', 'ne'):
        equal = canonical(actual) == canonical(expected)
        return equal if op == 'eq' else not equal
    if op == 'contains':
        if isinstance(actual, list):
            return any(canonical(item) == canonical(expected) for item in actual)
        return isinstance(actual, str) and isinstance(expected, str) and expected in actual
    if type(actual) not in (int, float) or type(expected) not in (int, float):
        return False
    return {'gt': actual > expected, 'gte': actual >= expected, 'lt': actual < expected, 'lte': actual <= expected}[op]


def curl_request(adapter, op, actor, params, query, body, key, timeout, secrets):
    curl = shutil.which('curl.exe') or shutil.which('curl')
    need(curl is not None, 'curl executable not found', 'ENVIRONMENT_ERROR')
    path = op['path']
    for name, value in params.items():
        need(type(value) in (str, int) and bool(re.fullmatch(r'[A-Za-z0-9_.:-]+', str(value))) and str(value) not in ('.', '..'),
             'Path parameter is not a safe identifier')
        path = path.replace('{' + name + '}', str(value))
    for name, value in query.items():
        need(type(value) in (str, int, float, bool), 'Query values must be scalars')
    url = adapter['base_url'].rstrip('/') + path
    if query:
        url += '?' + urlencode(query)
    headers = ['Content-Type: application/json', 'Accept: application/json']
    token_env = adapter['actors'][actor]['bearer_token_env']
    if token_env:
        token = os.environ.get(token_env, '')
        need(bool(token) and '\n' not in token and '\r' not in token, 'Missing/invalid actor token environment variable', 'ENVIRONMENT_ERROR')
        headers.append('Authorization: Bearer ' + token)
    if adapter.get('idempotency_header') and op['method'] not in READ_METHODS:
        headers.append(adapter['idempotency_header'] + ': ' + key)
    # curl config goes to stdin, so bearer tokens are absent from process arguments and files.
    config = ''.join('header = "' + h.replace('\\', '\\\\').replace('"', '\\"') + '"\n' for h in headers)
    with tempfile.TemporaryDirectory(prefix='workflow-http-') as folder:
        args = [curl, '--disable', '--silent', '--show-error', '--globoff', '--proto', '=http,https',
                '--noproxy', '*', '--connect-timeout', str(min(timeout, 5)), '--max-time', str(timeout),
                '--max-redirs', '0', '--request', op['method'], '--config', '-',
                '--write-out', '\n__WF_HTTP_STATUS__:%{http_code}', '--url', url]
        if body is not None:
            request_file = Path(folder) / 'body.json'
            request_file.write_text(canonical(body), encoding='utf-8')
            args.extend(['--data-binary', '@' + str(request_file)])
        if op['method'] == 'HEAD':
            args.append('--head')
        process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, shell=False)
        received = bytearray()
        try:
            process.stdin.write(config.encode('utf-8'))
            process.stdin.close()
            while True:
                block = process.stdout.read(65536)
                if not block:
                    break
                received.extend(block)
                need(len(received) <= MAX_BYTES + 100, 'HTTP response exceeds 1 MiB', 'TRANSPORT_ERROR')
            return_code = process.wait(timeout=timeout + 2)
            need(return_code == 0, f'curl transport failed with exit code {return_code}; action may already have committed', 'TRANSPORT_ERROR')
        finally:
            if process.poll() is None:
                process.kill()
            process.wait()
            process.stdout.close()
            if not process.stdin.closed:
                process.stdin.close()
        marker = b'\n__WF_HTTP_STATUS__:'
        need(marker in received, 'curl response status missing', 'TRANSPORT_ERROR')
        raw, status = bytes(received).rsplit(marker, 1)
        need(status.isdigit(), 'curl response status invalid', 'TRANSPORT_ERROR')
        try:
            decoded = json.loads(raw.decode('utf-8')) if raw else None
            canonical(decoded)
            body_format = 'json' if raw else 'empty'
        except (ValueError, UnicodeError, RecursionError):
            decoded, body_format = None, 'non_json'
        return {'status_code': int(status), 'body': decoded, 'body_format': body_format, 'bytes': len(raw)}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def save_result(path, value, secrets):
    temporary = path.with_suffix('.tmp')
    encoded = json.dumps(redact(value, secrets), ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    need(len(encoded.encode('utf-8')) <= 16 * MAX_BYTES, 'Evidence quota reached; inspect partial run before retry', 'EVIDENCE_LIMIT')
    temporary.write_text(encoded, encoding='utf-8')
    temporary.replace(path)


def assess_case(case_result, suite, environment, today=None):
    today = today or date.today()
    if case_result['execution_status'] == 'PASS':
        return 'PASS', []
    failures = case_result.get('failures', [])
    if case_result['execution_status'] != 'FAIL' or not failures or case_result.get('unexecuted_steps'):
        return 'BLOCKED', []
    matched = []
    for failure in failures:
        found = None
        for deviation in suite['deviations']:
            if (deviation['status'] == 'accepted' and deviation['case_id'] == case_result['case_id']
                    and deviation['assertion_id'] == failure.get('assertion_id')
                    and deviation['failure_signature'] == failure['failure_signature']
                    and deviation['scope'] == {'release': environment['release'], 'environment': environment['name']}
                    and date.fromisoformat(deviation['accepted_at']) <= today <= date.fromisoformat(deviation['expires_on'])):
                found = deviation['id']
                break
        if found is None:
            return 'BLOCKED', []
        matched.append(found)
    return 'ALLOWED_WITH_GAPS', matched


def run_plan(root, suite, adapter, plan, preview, run_id):
    ident(run_id, 'run_id')
    run_dir = workspace_path(root, 'runs/' + run_id)
    need(not run_dir.exists(), 'run_id already exists; do not repeat a possibly committed operation', 'RUN_EXISTS')
    used_actors = {s['actor'] for c in plan['cases'] for s in c['steps']}
    secrets = []
    for actor in used_actors:
        name = adapter['actors'][actor]['bearer_token_env']
        if name:
            value = os.environ.get(name, '')
            need(bool(value) and not any(c in value for c in ('\n', '\r')), 'Missing/invalid actor token environment variable: ' + name, 'ENVIRONMENT_ERROR')
            secrets.append(value)
    need(shutil.which('curl.exe') or shutil.which('curl'), 'curl executable missing', 'ENVIRONMENT_ERROR')
    try:
        run_dir.mkdir(parents=True, exist_ok=False)
    except FileExistsError as exc:
        raise ToolError('RUN_EXISTS', 'Concurrent invocation already reserved this run_id') from exc
    result_path = run_dir / 'results.json'
    result = {'result_version': PROTOCOL, 'runner_version': VERSION, 'run_id': run_id,
              'fingerprint': preview['fingerprint'], 'environment': adapter['environment'],
              'origin': adapter['base_url'], 'started_at': utc_now(), 'finished_at': None,
              'status': 'RUNNING', 'gate': 'BLOCKED', 'preparation_mode': 'replay',
              'selected_cases': preview['selected_cases'], 'not_selected_cases': preview['not_selected_cases'], 'cases': []}
    save_result(result_path, result, secrets)
    deadline = time.monotonic() + adapter['max_duration_seconds']
    for planned in plan['cases']:
        context = {'run_id': run_id, 'case_id': planned['case_id'], **planned['vars']}
        case_result = {'case_id': planned['case_id'], 'execution_status': 'RUNNING', 'gate': 'BLOCKED', 'steps': [], 'failures': []}
        result['cases'].append(case_result)
        save_result(result_path, result, secrets)
        try:
            for step in planned['steps']:
                need(time.monotonic() < deadline, 'Run deadline reached', 'DEADLINE_EXCEEDED')
                resolved = substitute(step, context)
                op = adapter['operations'][step['operation']]
                step_result = {'step_id': step['id'], 'operation': step['operation'], 'actor': step['actor'],
                               'method': op['method'], 'path_template': op['path'], 'request_state': 'PENDING', 'attempts': []}
                case_result['steps'].append(step_result)
                # Persist intent before sending a side effect, including before a process crash.
                save_result(result_path, result, secrets)
                failures = []
                poll = step.get('poll', {'attempts': 1, 'interval_seconds': 0})
                for attempt in range(poll['attempts']):
                    remaining = deadline - time.monotonic()
                    need(remaining > 0, 'Run deadline reached', 'DEADLINE_EXCEEDED')
                    step_result['request_state'] = 'SENDING'
                    save_result(result_path, result, secrets)
                    response = curl_request(adapter, op, step['actor'], resolved['params'], resolved['query'], resolved['body'],
                                            run_id + ':' + planned['case_id'] + ':' + step['id'],
                                            min(adapter['timeout_seconds'], remaining), secrets)
                    step_result['request_state'] = 'RECEIVED'
                    failures, checks = [], []
                    for check in resolved['checks']:
                        actual = json_pointer(response, check['pointer'])
                        passed = compare(actual, check['op'], check.get('expected', MISSING))
                        evidence = {'check_id': check['id'], 'assertion_id': check.get('assertion_id'),
                                    'pointer': check['pointer'], 'op': check['op'], 'expected': check.get('expected'),
                                    'actual': {'missing': True} if actual is MISSING else actual,
                                    'status': 'PASS' if passed else 'FAIL'}
                        if not passed:
                            signature = digest({'case_id': planned['case_id'], 'step_id': step['id'], **evidence})
                            failure = {**evidence, 'step_id': step['id'], 'failure_signature': signature}
                            failures.append(failure)
                        checks.append(evidence)
                    step_result['attempts'].append({'attempt': attempt + 1, 'at': utc_now(), 'response': response, 'checks': checks})
                    save_result(result_path, result, secrets)
                    if not failures:
                        break
                    if attempt + 1 < poll['attempts']:
                        need(time.monotonic() + poll['interval_seconds'] < deadline, 'Run deadline reached', 'DEADLINE_EXCEEDED')
                        time.sleep(poll['interval_seconds'])
                if failures:
                    case_result['failures'] = failures
                    case_result['execution_status'] = 'FAIL'
                    break
                for name, pointer in step['capture'].items():
                    value = json_pointer(response, pointer)
                    need(value is not MISSING, 'Capture pointer missing: ' + pointer, 'CAPTURE_ERROR')
                    if isinstance(value, str) and SECRET_KEYS.search(pointer):
                        secrets.append(value)
                    context[name] = value
            else:
                case_result['execution_status'] = 'PASS'
        except (ToolError, OSError, subprocess.SubprocessError, ValueError, KeyError, TypeError) as exc:
            case_result['execution_status'] = 'ERROR'
            case_result['error'] = {'code': getattr(exc, 'code', 'EXECUTION_ERROR'), 'message': str(exc)}
        executed_ids = {s['step_id'] for s in case_result['steps']}
        case_result['unexecuted_steps'] = [s['id'] for s in planned['steps'] if s['id'] not in executed_ids]
        case_result['gate'], case_result['deviation_ids'] = assess_case(case_result, suite, adapter['environment'])
        case_result['context'] = context
        save_result(result_path, result, secrets)
    statuses = [c['execution_status'] for c in result['cases']]
    result['status'] = 'ERROR' if 'ERROR' in statuses else ('FAIL' if 'FAIL' in statuses else 'PASS')
    gates = [c['gate'] for c in result['cases']]
    result['gate'] = 'BLOCKED' if 'BLOCKED' in gates else ('ALLOWED_WITH_GAPS' if 'ALLOWED_WITH_GAPS' in gates else 'PASS')
    result['finished_at'] = utc_now()
    result['summary'] = {status: statuses.count(status) for status in ('PASS', 'FAIL', 'ERROR')}
    save_result(result_path, result, secrets)
    return redact(result, secrets)
