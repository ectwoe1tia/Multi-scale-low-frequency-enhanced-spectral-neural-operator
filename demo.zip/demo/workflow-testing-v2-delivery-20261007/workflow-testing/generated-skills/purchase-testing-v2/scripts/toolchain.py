#!/usr/bin/env python3
"""One JSON request -> one JSON response. The only supported automation entrypoint."""
import argparse
import contextlib
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tempfile
import uuid
from pathlib import Path

import http_runner as runtime
import suite as suite_tools

TOOLS = {
    'describe': ([], []),
    'doctor': ([], []),
    'suite_validate': (['suite'], []),
    'suite_render': (['suite', 'out'], []),
    'skill_build': (['suite', 'out', 'name'], []),
    'plan_validate': (['suite', 'adapter', 'plan'], []),
    'plan_preview': (['suite', 'adapter', 'plan'], []),
    'run': (['suite', 'adapter', 'plan', 'expected_fingerprint', 'run_id'], []),
    'report': (['run_id', 'out'], []),
    'snapshot': (['files'], []),
    'claim': (['owner', 'change_id', 'base_hashes'], []),
    'release': (['lease_token'], []),
}
EXIT_CODES = {'OK': 0, 'TEST_FAILED': 10, 'EXECUTION_ERROR': 11, 'ENVIRONMENT_ERROR': 12,
              'PERMISSION_DENIED': 12, 'CHANGE_CONFLICT': 20, 'LEASE_BUSY': 21, 'RUN_EXISTS': 22}


def protocol_schema():
    variants = []
    for name, (required, optional) in TOOLS.items():
        properties = {key: {'type': 'string', 'minLength': 1} for key in required + optional}
        if 'files' in properties:
            properties['files'] = {'type': 'array', 'minItems': 1, 'maxItems': 100, 'items': {'type': 'string'}}
        if 'base_hashes' in properties:
            properties['base_hashes'] = {'type': 'object', 'minProperties': 1, 'additionalProperties': {'type': 'string', 'pattern': '^[a-f0-9]{64}$'}}
        variants.append({'type': 'object', 'additionalProperties': False,
                         'required': ['protocol_version', 'tool', 'arguments'],
                         'properties': {'protocol_version': {'const': runtime.PROTOCOL}, 'tool': {'const': name},
                                        'arguments': {'type': 'object', 'additionalProperties': False, 'required': required, 'properties': properties}}})
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema', 'oneOf': variants}


def envelope(tool, code='OK', data=None, message=''):
    return {'protocol_version': runtime.PROTOCOL, 'tool': tool, 'ok': code == 'OK',
            'code': code, 'message': message, 'data': data if data is not None else {}}


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshots(root, files):
    runtime.need(isinstance(files, list) and 1 <= len(files) <= 100 and all(isinstance(f, str) for f in files), 'files must contain 1..100 relative paths')
    runtime.need(len(files) == len(set(files)), 'Duplicate snapshot path')
    return {name: file_hash(runtime.workspace_path(root, name, existing=True)) for name in files}


def validate_request(request):
    runtime.shape(request, ['protocol_version', 'tool', 'arguments'], label='request')
    runtime.need(request['protocol_version'] == runtime.PROTOCOL, 'Unsupported protocol_version')
    tool = request['tool']
    runtime.need(isinstance(tool, str) and tool in TOOLS, 'Unknown tool')
    required, optional = TOOLS[tool]
    runtime.shape(request['arguments'], required, optional, 'arguments')
    for key, value in request['arguments'].items():
        if key not in ('files', 'base_hashes'):
            runtime.text(value, key)
    return tool, request['arguments']


def dispatch(root, request):
    tool, args = validate_request(request)
    root = Path(root).resolve()
    runtime.need(root.is_dir(), 'Workspace directory does not exist', 'ENVIRONMENT_ERROR')
    input_path = lambda name: runtime.workspace_path(root, args[name], existing=True)
    output_path = lambda name: runtime.workspace_path(root, args[name])
    if tool == 'describe':
        return envelope(tool, data={'runner_version': runtime.VERSION, 'request_schema': protocol_schema(),
                                   'execution_order': ['doctor', 'suite_validate', 'plan_validate', 'plan_preview', 'run', 'report'],
                                   'exit_codes': EXIT_CODES, 'default_error_exit_code': 2})
    if tool == 'doctor':
        try:
            with tempfile.NamedTemporaryFile(prefix='.workflow-probe-', dir=root, delete=True) as probe:
                probe.write(b'write-test')
                probe.flush()
        except OSError as exc:
            raise runtime.ToolError('PERMISSION_DENIED', 'Workspace write probe failed; no ACL changes were attempted') from exc
        curl = shutil.which('curl.exe') or shutil.which('curl')
        runtime.need(curl, 'curl executable not available', 'ENVIRONMENT_ERROR')
        return envelope(tool, data={'workspace': str(root), 'writable': True, 'python': sys.version.split()[0],
                                   'curl': curl, 'runner_version': runtime.VERSION, 'network_tested': False})
    if tool in ('suite_validate', 'suite_render', 'skill_build'):
        suite = runtime.read_json(input_path('suite'))
        errors, warnings = suite_tools.validate(suite)
        runtime.need(not errors, 'Suite invalid: ' + '; '.join(errors))
        data = {'warnings': warnings, 'cases': len(suite['cases']), 'business_tests_executed': False}
        if tool == 'suite_render':
            suite_tools.render(suite, output_path('out'), warnings)
            data['output'] = args['out']
        elif tool == 'skill_build':
            data['output'] = str(suite_tools.build_skill(suite, output_path('out'), args['name']))
        return envelope(tool, data=data)
    if tool in ('plan_validate', 'plan_preview', 'run'):
        suite, adapter, plan = (runtime.read_json(input_path(name)) for name in ('suite', 'adapter', 'plan'))
        preview = runtime.validate_bundle(suite, adapter, plan)
        if tool != 'run':
            return envelope(tool, data=preview)
        runtime.need(args['expected_fingerprint'] == preview['fingerprint'], 'Suite/adapter/plan changed after preview; preview again', 'STALE_PLAN')
        result = runtime.run_plan(root, suite, adapter, plan, preview, args['run_id'])
        result_file = runtime.workspace_path(root, 'runs/' + args['run_id'] + '/results.json', existing=True)
        result_file.with_suffix('.sha256').write_text(file_hash(result_file) + '\n', encoding='ascii')
        code = 'EXECUTION_ERROR' if result['status'] == 'ERROR' else ('TEST_FAILED' if result['status'] == 'FAIL' else 'OK')
        return envelope(tool, code, {'run_id': args['run_id'], 'status': result['status'], 'gate': result['gate'],
                                    'summary': result['summary'], 'results_path': 'runs/' + args['run_id'] + '/results.json',
                                    'not_selected_cases': result['not_selected_cases']},
                        'Raw FAIL remains FAIL even when an accepted gap applies; read gate separately.')
    if tool == 'report':
        runtime.ident(args['run_id'], 'run_id')
        source = runtime.workspace_path(root, 'runs/' + args['run_id'] + '/results.json', existing=True)
        checksum = source.with_suffix('.sha256')
        runtime.need(checksum.is_file() and checksum.read_text(encoding='ascii').strip() == file_hash(source),
                     'Run is incomplete or results were modified; inspect existing evidence before any retry', 'EVIDENCE_CHANGED')
        result = runtime.read_json(source, max_bytes=16 * runtime.MAX_BYTES)
        runtime.need(result.get('finished_at') and result.get('status') in ('PASS', 'FAIL', 'ERROR'), 'Run is incomplete')
        target = output_path('out')
        target.parent.mkdir(parents=True, exist_ok=True)
        lines = [f'# Run {result["run_id"]}', '', f'Raw status: {result["status"]}; gate: {result["gate"]}.', '',
                 'Only selected cases were executed. This is not a production release authorization.', '',
                 f'Environment: {suite_tools.md(result["environment"])}',
                 f'Not selected: {suite_tools.md(result["not_selected_cases"])}',
                 f'Fingerprint: `{result["fingerprint"]}`', '', '| Case | Raw status | Gate | Deviations |', '| --- | --- | --- | --- |']
        for case in result['cases']:
            lines.append('| ' + ' | '.join(suite_tools.md(case.get(k, [])) for k in ('case_id', 'execution_status', 'gate', 'deviation_ids')) + ' |')
        with target.open('x', encoding='utf-8') as handle:
            handle.write('\n'.join(lines) + '\n')
        return envelope(tool, data={'report': args['out'], 'status': result['status'], 'gate': result['gate']})
    if tool == 'snapshot':
        return envelope(tool, data={'base_hashes': snapshots(root, args['files']), 'runner_version': runtime.VERSION})
    lease_path = runtime.workspace_path(root, '.coordination/lease.json')
    if tool == 'claim':
        runtime.ident(args['owner'], 'owner')
        runtime.ident(args['change_id'], 'change_id')
        hashes = args['base_hashes']
        runtime.need(isinstance(hashes, dict) and hashes, 'base_hashes must be nonempty object')
        runtime.need(all(isinstance(v, str) and bool(re.fullmatch(r'[a-f0-9]{64}', v)) for v in hashes.values()), 'Invalid base_hashes')
        runtime.need(snapshots(root, list(hashes)) == hashes, 'Base files changed; re-read and rebase the proposed change', 'CHANGE_CONFLICT')
        lease_path.parent.mkdir(parents=True, exist_ok=True)
        lease = {'owner': args['owner'], 'change_id': args['change_id'], 'base_hashes': hashes,
                 'lease_token': uuid.uuid4().hex, 'created_at': runtime.utc_now()}
        try:
            with lease_path.open('x', encoding='utf-8') as handle:
                json.dump(lease, handle, ensure_ascii=False, indent=2)
        except FileExistsError as exc:
            raise runtime.ToolError('LEASE_BUSY', 'Another writer owns the lease; do not edit or delete its lock') from exc
        # Recheck after acquiring the lease to close the normal cooperating-writer race.
        if snapshots(root, list(hashes)) != hashes:
            lease_path.unlink()
            raise runtime.ToolError('CHANGE_CONFLICT', 'Base changed while acquiring lease')
        return envelope(tool, data=lease)
    if tool == 'release':
        runtime.need(lease_path.is_file(), 'No active lease')
        lease = runtime.read_json(lease_path)
        runtime.need(lease.get('lease_token') == args['lease_token'], 'Lease token does not match', 'LEASE_BUSY')
        lease_path.unlink()
        return envelope(tool, data={'released': True, 'change_id': lease['change_id']})
    raise runtime.ToolError('INVALID_INPUT', 'Unsupported tool')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True)
    parser.add_argument('--request')
    parser.add_argument('--describe', action='store_true')
    args = parser.parse_args(argv)
    tool = 'unknown'
    try:
        if args.describe:
            request = {'protocol_version': runtime.PROTOCOL, 'tool': 'describe', 'arguments': {}}
        else:
            runtime.need(args.request, '--request is required')
            request_file = Path(args.request).resolve()
            root = Path(args.workspace).resolve()
            runtime.need(root in request_file.parents, 'Request must be inside workspace')
            request = runtime.read_json(request_file)
        if isinstance(request, dict) and isinstance(request.get('tool'), str):
            tool = request['tool']
        # Underlying helpers cannot pollute the single-JSON stdout protocol.
        with contextlib.redirect_stdout(io.StringIO()):
            response = dispatch(args.workspace, request)
    except runtime.ToolError as exc:
        response = envelope(tool, exc.code, message=str(exc))
    except PermissionError:
        response = envelope(tool, 'PERMISSION_DENIED', message='File access denied by operating system or sandbox')
    except FileExistsError:
        response = envelope(tool, 'OUTPUT_EXISTS', message='Refusing to overwrite existing output')
    except (OSError, ValueError, TypeError, KeyError, RecursionError) as exc:
        response = envelope(tool, 'INVALID_INPUT', message='Input or filesystem error: ' + str(exc))
    print(json.dumps(response, ensure_ascii=False, allow_nan=False))
    return EXIT_CODES.get(response['code'], 2)


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    raise SystemExit(main())
