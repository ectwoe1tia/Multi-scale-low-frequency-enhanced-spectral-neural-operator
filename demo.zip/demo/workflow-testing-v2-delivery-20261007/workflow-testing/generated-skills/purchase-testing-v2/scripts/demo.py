#!/usr/bin/env python3
"""Run the published CLI against a temporary loopback HTTP process application."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import http_runner as runtime
from demo_support import DemoServer, make_assets


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True)
    parser.add_argument('--run-id', required=True)
    args = parser.parse_args()
    root = Path(args.workspace).resolve()
    runtime.ident(args.run_id, 'run_id')
    directory = runtime.workspace_path(root, 'demo-inputs/' + args.run_id)
    directory.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    for role in ('applicant', 'manager', 'director'):
        env['WF_DEMO_' + role.upper()] = 'demo-' + role

    def invoke(name, arguments):
        request = {'protocol_version': '1.0', 'tool': name, 'arguments': arguments}
        request_path = directory / (name + '.request.json')
        request_path.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding='utf-8')
        result = subprocess.run([sys.executable, '-X', 'utf8', str(Path(__file__).with_name('toolchain.py')),
                                 '--workspace', str(root), '--request', str(request_path)],
                                capture_output=True, encoding='utf-8', env=env)
        response = json.loads(result.stdout)
        (directory / (name + '.response.json')).write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding='utf-8')
        if result.returncode:
            raise runtime.ToolError(response['code'], response['message'])
        return response['data']

    with DemoServer() as server:
        suite, adapter, plan = make_assets(server.server_port)
        for name, value in [('suite', suite), ('adapter', adapter), ('plan', plan)]:
            (directory / (name + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        paths = {name: (directory / (name + '.json')).relative_to(root).as_posix() for name in ('suite', 'adapter', 'plan')}
        invoke('doctor', {})
        invoke('suite_validate', {'suite': paths['suite']})
        invoke('plan_validate', paths)
        preview = invoke('plan_preview', paths)
        result = invoke('run', {**paths, 'expected_fingerprint': preview['fingerprint'], 'run_id': args.run_id})
        report = invoke('report', {'run_id': args.run_id, 'out': 'reports/' + args.run_id + '.md'})
        print(json.dumps({'demo': True, 'http_requests': len(server.calls), 'result': result, 'report': report,
                          'note': 'Only the bundled local demo was tested. Demo instances expire when this command exits.'}, ensure_ascii=False))


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    main()
