# HTTP 适配与执行计划 1.0

suite.json 规定业务预期，adapter.json 绑定真实接口与身份，plan.json 绑定执行步骤。不要把未确认规则写进计划绕开 suite。三份文件参与指纹并在运行前一次性加载。

## Adapter

完整可执行演示见 `assets/http-demo.adapter.json`。其接口只属于本地演示服务。

```json
{
  "schema_version":"1.0","adapter_id":"purchase-api","platform":"custom",
  "base_url":"https://test.example.invalid",
  "environment":{"name":"uat","kind":"uat","release":"1.0"},
  "allow_mutations":true,"timeout_seconds":10,"max_duration_seconds":120,
  "actors":{"applicant":{"bearer_token_env":"PURCHASE_APPLICANT_TOKEN"}},
  "operations":{"get_state":{"method":"GET","path":"/api/instances/{instance_id}","actors":["applicant"]}}
}
```

示例域名和路径不是任何实际平台的 API。上方全部字段必填，唯额外的 idempotency_header 可选。无通用 headers/curl_options/shell/script/expression 入口。

- platform：lowcode / flowable / custom；environment.kind：local / test / uat，本版本拒绝 production。环境标签仍需接入者核对真实部署。
- base_url 仅含协议、主机、端口。HTTP 只允许 loopback；远程 HTTPS。不得含用户认证、query、路径或 fragment。
- timeout_seconds 1..30，max_duration_seconds 1..300。
- actors 的值只包含 bearer_token_env 环境变量名，不能填写令牌；仅 local 演示允许空值表示无认证。
- operations 的值只包含 method、path、actors。支持 GET/HEAD/POST/PUT/PATCH/DELETE；路径占位符来自 step.params。
- operation.actors 是允许用来测试端点的身份集合，不代替业务权限。越权负例可显式使用非候选角色，再检查 403 和状态不变。
- allow_mutations 控制写请求。可选 idempotency_header 的值为头名称，脚本发送 run_id:case_id:step_id。服务端是否实现幂等仍需验证。

## Plan

完整配对样例：`assets/http-demo.plan.json`、`assets/http-demo.suite.json`。以下对象拒绝未知字段。

| 对象 | 必填 | 可选 |
|---|---|---|
| plan | schema_version, plan_id, adapter_id, cases | 无 |
| case | case_id, vars, steps | 无 |
| step | id, operation, actor, params, query, body, capture, checks | poll |
| check | id, pointer, op | expected, assertion_id |
| poll | attempts, interval_seconds | 无 |

case_id 必须存在且 ready。每例独立准备数据，不依赖其他用例。可选 suite 子集，结果列出未选用例，不计通过。上限 100 例、每例 40 步。

变量占据完整值，例如 `"${instance_id}"`，不支持拼接、函数或表达式。vars 为初始字面量；capture 为新变量名到 JSON Pointer 的映射，只有本步检查全部通过后采集。不能覆盖旧变量；run_id/case_id 保留。采集不存在字段为 ERROR。

params 恰好匹配路径占位符，解析后须是受限标识字符串或整数，不能含斜线、URL 或路径跳转。query 为标量映射，不能传认证。GET/HEAD 的 body 为 null。

响应统一为 `{"status_code":200,"body":{"state":"finance"},"body_format":"json","bytes":19}`。非 JSON body 不保留原文，body=null；HTML/二进制需扩展适配，不能猜成功。

每步至少一次 `/status_code` 的 eq 整数检查。负例可明确检查 403/400，不能将任意 HTTP 错误算通过。业务检查关联 suite assertion_id，每个业务断言须在本例映射一次，避免只检查 HTTP 200。

op 支持 eq/ne/contains/exists/not_exists/gt/gte/lt/lte。exists/not_exists 不接受 expected，其余必须有。缺失字段与 null 不同，缺失值不能通过 eq/ne；布尔值不当数字。eq 比较规范 JSON 表示，1 与 1.0 是不同表示。contains 支持子串或数组元素。指针中 ~0 表示 ~，~1 表示 /。

poll 仅限 GET/HEAD，attempts 1..20，interval_seconds 0.05..5；受总截止时间约束。网络错误不是预期业务失败，不触发写请求重试。

## 妥协匹配

真实失败产生 failure_signature，计算用例、步骤、检查、操作符、指针、预期和实际值的 SHA-256。登记只能使用真实签名；未经业务接受保持 proposed。

accepted 需同时匹配 case_id、assertion_id、签名、release、environment 和有效日期。技术检查失败、不同实际值、ERROR、过期或未执行后续步骤都阻断。FAIL 不变；gate 只针对选中用例，不是全量质量或上线许可。
