# 固定工具调用协议 1.0

## 入口

本版采用 Skill + PowerShell + Python 标准库 + curl CLI。模型只写 JSON 数据；PowerShell 只传递路径，Python 验证后通过参数数组调用真实 curl.exe（Windows）或 curl。没有 MCP 服务进程；后续可按扩展文档增加薄封装。

在项目工作区保存 `requests/doctor.json`：

```json
{"protocol_version":"1.0","tool":"doctor","arguments":{}}
```

Windows 固定命令，只替换路径：

```powershell
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "C:\path\workflow-testing\scripts\Invoke-WorkflowTool.ps1" -Workspace "C:\path\my-project" -Request "C:\path\my-project\requests\doctor.json"
```

RemoteSigned 仅针对本次进程，不修改全局策略，不提升账户权限；组织策略仍可能阻止执行。直接 Python 等效入口：

```powershell
python -X utf8 "C:\path\workflow-testing\scripts\toolchain.py" --workspace "C:\path\my-project" --request "C:\path\my-project\requests\doctor.json"
```

请求文件须在工作区内。JSON 文件参数全为 Workspace 相对路径；不允许越界路径、重复 JSON 键、未知工具/字段。不在 JSON 中填写密码、令牌或 shell 命令。

## 工具目录

| tool | arguments 必填项 | 作用 |
|---|---|---|
| describe | 无 | 返回本版本工具 JSON Schema、顺序和退出码 |
| doctor | 无 | 验证 Python/curl/目录写入，不测试远端网络 |
| suite_validate | suite | 校验需求资产，不执行测试 |
| suite_render | suite, out | 在新目录导出设计报告和 CSV |
| skill_build | suite, out, name | 生成自包含项目 Skill |
| plan_validate | suite, adapter, plan | 校验配置、角色、变量和断言，不联网 |
| plan_preview | suite, adapter, plan | 返回步骤摘要及 fingerprint，不联网 |
| run | suite, adapter, plan, expected_fingerprint, run_id | 执行预览过的 HTTP 测试 |
| report | run_id, out | 从完整且校验和一致的结果导出 Markdown |
| snapshot | files | 返回文件 SHA-256 基线 |
| claim | owner, change_id, base_hashes | 取得唯一编辑租约 |
| release | lease_token | 仅正确令牌持有者释放租约 |

无可选扩展参数。describe 的输出是机器契约，`assets/tool-request.schema.json` 是由程序导出的副本。Schema 不能替代跨文件引用检查。

预览请求：

```json
{"protocol_version":"1.0","tool":"plan_preview","arguments":{"suite":"suite.json","adapter":"adapter.json","plan":"plan.json"}}
```

取返回的 data.fingerprint，生成执行请求：

```json
{"protocol_version":"1.0","tool":"run","arguments":{"suite":"suite.json","adapter":"adapter.json","plan":"plan.json","expected_fingerprint":"替换为预览返回的64位哈希","run_id":"RUN-20261007-001"}}
```

fingerprint 不是批准或权限凭据；它证明 suite/adapter/plan 和执行器版本与预览一致。输入变化必须重新预览。

## 返回与后续动作

stdout 只有一个 JSON 对象：protocol_version、tool、ok、code、message、data。读取 `$LASTEXITCODE` 或 returncode，同时检查 code/data。不要从自然语言猜状态。

| code | 退出码 | 下一步 |
|---|---|---|
| OK | 0 | 读 data 后进入下一步；资产检查 OK 不等于业务通过 |
| TEST_FAILED | 10 | 报告失败，不改断言、不自动重跑 |
| EXECUTION_ERROR | 11 | 可能已提交副作用，核对证据及服务端状态，不自动重发 |
| ENVIRONMENT_ERROR / PERMISSION_DENIED | 12 | 说明环境缺口；执行模型不自行改权限或绕过限制 |
| CHANGE_CONFLICT | 20 | 重读基线并重做变更，不覆盖他人修改 |
| LEASE_BUSY | 21 | 等持有者释放，不删锁或冒用令牌 |
| RUN_EXISTS | 22 | 读旧结果，不仅改运行 ID 来绕过保护 |
| STALE_PLAN | 2 | 尚未联网，重新预览 |
| NEEDS_CLARIFICATION | 2 | 澄清业务，继续设计无关场景 |
| INVALID_INPUT / OUTPUT_EXISTS | 2 | 修正数据或新建输出位置，不改验证器 |
| EVIDENCE_CHANGED | 2 | 结果变动或运行未完成，保留证据并调查 |

status 是原始 PASS/FAIL/ERROR，gate 是 PASS/ALLOWED_WITH_GAPS/BLOCKED。有效豁免不会把原始 FAIL 改为 PASS，也不会使退出码自动变零。CI 如需依据 gate 决策，须显式读取；不得把所有 exit 10 放行。

## 证据和边界

`runs/<run_id>/results.json` 保存时间、环境、指纹、发送意图、响应、断言、失败特征、变量、未执行步骤和未选用例。完成时生成 results.sha256。SENDING 残留意味着结果未知，不能推定请求未提交。

输入和单响应上限 1 MiB，证据上限 16 MiB。超限停止，保留此前检查点。认证从环境变量取值，经 curl stdin 传入；不放入进程参数。按秘密字段名和已知值脱敏仍不能识别所有业务敏感信息，接口应减少无关返回内容。

curl 调用设置超时、禁用默认配置、禁用跳转，不自动重试写请求，不自动使用环境代理。企业代理、证书、上传、OAuth 刷新要经扩展流程实现，不能临时加 flags。参照 [curl 官方文档](https://curl.se/docs/manpage.html)。
