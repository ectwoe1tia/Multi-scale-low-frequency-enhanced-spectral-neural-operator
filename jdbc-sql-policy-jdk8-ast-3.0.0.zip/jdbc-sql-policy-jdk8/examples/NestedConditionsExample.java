import com.bydauto.yunfan.agent.data.sqlpolicy.*;
import java.util.*;
import javax.sql.DataSource;
import static com.bydauto.yunfan.agent.data.sqlpolicy.Expressions.*;

/** Example schema: users(id,tenant_id,tier,status), orders(id,user_id,backup_user_id,amount,deleted). */
public final class NestedConditionsExample {
    static QueryChanges changes() {
        return QueryChanges.builder()
            // Original ON OR an alternative relationship between the same joined tables.
            .on("o", col("o.backup_user_id").eq(col("u.id")), QueryChanges.Merge.OR)
            // Original WHERE AND ((amount >= 100 OR VIP) AND NOT disabled).
            .where(and(
                or(col("o.amount").ge(100), col("u.tier").eq("VIP")),
                not(col("u.status").eq("DISABLED"))))
            .orderBy("u.id", QueryPolicy.Direction.DESC)
            .build();
    }
    static List<QueryPolicy> rules(long tenantId) {
        return Arrays.asList(
            QueryPolicy.forTable("users").where(col("tenant_id").eq(tenantId)).build(),
            QueryPolicy.forTable("orders").where(col("deleted").eq(false)).build());
    }
    public static DataSource attach(DataSource pool, SqlDialect dialect) {
        // Replace 42L with the application's trusted current-request tenant provider.
        return PolicyDataSource.withChanges(pool, dialect, () -> rules(42L), NestedConditionsExample::changes);
    }
    public static void main(String[] args) {
        Map<String,QueryPolicy> policies=new LinkedHashMap<String,QueryPolicy>();
        for(QueryPolicy p:rules(42L)) policies.put(p.table(),p);
        SqlPolicyRewriter.Rewrite result=SqlPolicyRewriter.rewrite(
            "select u.id,o.amount from users u left join orders o on o.user_id=u.id where u.id>? limit ?",
            SqlDialect.POSTGRESQL, policies, changes());
        System.out.println(result.sql());
        System.out.println("Original parameter indexes: "+result.remapOriginalParameter(1)+", "+result.remapOriginalParameter(2));
        System.out.println("Extra parameter indexes: "+result.policyParameterIndexes());
        System.out.println(result.actions());
    }
}
