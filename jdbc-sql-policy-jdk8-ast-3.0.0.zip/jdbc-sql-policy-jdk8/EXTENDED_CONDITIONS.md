# 3.0 条件树与多表组合

3.0 解决的是“附加条件只能平铺 AND”的限制。原 SQL 中的 OR 连接关系仍由 JSqlParser 保留；新增 Expressions 条件树可以在表级规则、外层 WHERE、指定 JOIN ON、HAVING 中组合 AND、OR、NOT。

## 直接使用

~~~java
import static com.bydauto.yunfan.agent.data.sqlpolicy.Expressions.*;

Expressions.Condition filter = and(
    or(col("o.amount").ge(100), col("u.tier").eq("VIP")),
    not(col("u.status").eq("DISABLED"))
);

QueryChanges changes = QueryChanges.builder()
    .on("o", col("o.backup_user_id").eq(col("u.id")), QueryChanges.Merge.OR)
    .where(filter)
    .orderBy("u.id", QueryPolicy.Direction.DESC)
    .build();

DataSource decorated = PolicyDataSource.withChanges(
    existingPool, SqlDialect.POSTGRESQL, trustedPolicySupplier, () -> changes);
~~~

对于原有 ON o.user_id=u.id，修改后的关系为：

~~~sql
ON (o.user_id = u.id) OR ("o"."backup_user_id" = "u"."id")
~~~

原 WHERE 始终完整分组，默认再 AND 新的 filter。如果业务需要扩大原查询条件，明确调用 .where(filter, QueryChanges.Merge.OR)。表级规则在各基础表上预先生效，不会因为外层 WHERE 使用 OR 而被合并到同一个 OR 分支中。

完整可编译示例：examples/NestedConditionsExample.java。示例仅演示 SQL 改写，不连接数据库。

## 可组合的节点

| 类别 | API / 含义 |
| --- | --- |
| 分组 | and(a,b,...)、or(a,b,...)、not(a)；也可 a.and(b).or(c) |
| 比较 | col("u.id").eq/ne/gt/ge/lt/le(value) |
| 列间比较 | col("o.user_id").eq(col("u.id"))；右侧字符串默认是值，列引用必须用 col |
| 范围 | between(low,high)、notBetween(low,high)；边界也可为列/表达式 |
| 集合 | in(collection)、notIn(collection) |
| 空值 | isNull、isNotNull；eq(null)/ne(null) 转为空值判断 |
| 三值逻辑 | 普通 NOT/比较保持 SQL UNKNOWN；nullSafeEq、distinctFrom 提供包含 NULL 的完整真假比较 |
| 字符匹配 | like、notLike；contains/startsWith/endsWith 自动转义 !、%、_，使用 ESCAPE '!' |
| 标量表达式 | lower、upper、length（CHAR_LENGTH）、abs、coalesce |
| 算术 | add、subtract、multiply、divide，操作数可为值或列；数据库负责类型/除零规则 |
| 聚合 | count、countAll、countDistinct、sum、avg、min、max，用于 HAVING 或排序 |
| 常量 | alwaysTrue、alwaysFalse；and() 为真、or() 为假 |

所有值都走 PreparedStatement 参数，不接受 raw SQL 字符串作为条件/函数/操作符。可变值对象仍要求在语句使用期间不修改。集合被复制为树节点。

空 IN 的语义是 FALSE，空 NOT IN 的语义是 TRUE。集合不接受 null，请显式用 or(col("x").in(values), col("x").isNull())。BETWEEN 的 null 边界会拒绝。空集合真值只作用于该节点；不能依赖可为空的业务列表提供强制隔离规则。

## 条件放置位置

**表级规则：**

~~~java
QueryPolicy.forTable("orders")
    .where(and(col("tenant_id").eq(42),
               or(col("status").eq("PAID"), col("status").eq("SHIPPED"))))
    .build();
~~~

同一 Builder 上多次 where(...) 按 AND 组合；要 OR 就在一次调用中传分组树。旧的 where(column, op, value) API 保留。conditions() 只返回旧式列表；完整组合请使用 predicate()。

**结果 WHERE：**在 JOIN 后、聚合前过滤。跨表字段用明确别名。所有自定义树的括号会保留。默认和原 WHERE 做 AND；Merge.OR 必须显式选择。

**JOIN ON：**按最外层查询块中的右表别名定位，可改变匹配关系并保留 LEFT/RIGHT JOIN 结构。支持原 ON 与新树的 AND/OR。同一个别名只设置一次，先在树中组合。没有找到别名或匹配多个 JOIN 会报错，不静默跳过。不会进入同名别名的内层子查询。

NATURAL/USING/CROSS/逗号连接不能直接附加 ON：这些连接没有相同的 ON 合并位置。需要改写原模板为显式 JOIN ... ON，或使用结果 WHERE。示例中对 ON 使用 OR 会明确扩大匹配集合，可能产生更多匹配行，这是调用方选择的业务语义。

**HAVING：**

~~~java
QueryChanges.builder()
    .having(or(count(col("o.id")).eq(0), sum(col("o.amount")).gt(1000)))
    .orderBy(count(col("o.id")), QueryPolicy.Direction.DESC)
    .build();
~~~

原 HAVING 也会整体分组，可显式选择 Merge.OR。聚合函数不能注入表级 WHERE、结果 WHERE 或 ON，否则报错。列类型、GROUP BY 合法性和聚合结果由实际数据库判断。

**排序：**默认追加；replaceOrder() 清除最终查询块的原排序（包括自动追加的表排序）再应用新排序。可按标量/聚合表达式排序。若被替换的原排序包含 JDBC ? 参数，会拒绝改写，避免删除调用方参数；应先调整该模板或使用追加模式。

## 与 2.0 的边界

JDK 8、JSqlParser 4.9、参数逐位置映射、表过滤和原查询作用域遍历保持有效。新条件树没有开放任意 SQL、任意函数或“自动添加新表”；修改的是已经解析的查询。

新的 WHERE/HAVING/ON 应用到最外层 PlainSelect；UNION 结果筛选仍需要显式外层 SELECT。递归 CTE、锁定 SELECT 等仍需单独语义实现。已有子查询中的原始复杂表达式仍照常遍历。

树限制为 64 层、4096 节点，过深/过大时在构造阶段报错。同一 QueryChanges.Builder 的 WHERE/HAVING 只设置一次，避免后一次调用意外覆盖前一次；先用 and/or 构造完整树。
