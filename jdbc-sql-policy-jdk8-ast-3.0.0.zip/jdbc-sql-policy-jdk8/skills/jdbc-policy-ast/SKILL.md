---
name: jdbc-policy-ast
description: Extend and review this JDK 8 JDBC SQL policy library using JSqlParser ASTs for PostgreSQL and MySQL, including JOIN semantics, query scopes, and parameter remapping.
---

Locate the project containing SqlPolicyRewriter, PolicyDataSource, build.ps1 and DEPENDENCIES.json. Read its README and the relevant implementation before changing behavior. This skill guides improvement of the supplied library; it does not authorize connecting to an unspecified database or changing an application's live DataSource.

Preserve JDK 8 compatibility. JSqlParser 4.9 is pinned because newer releases require newer Java. Keep SQL structure changes in AST nodes. SqlLexer only identifies JDBC parameter tokens and checks syntax boundaries; do not rebuild JOIN/WHERE manipulation using string offsets.

For every new condition, choose its semantic location:

- Table policy: restrict each physical relation before it enters the join. The current derived-table strategy preserves unmatched rows in LEFT/RIGHT/FULL joins. Do not move a right-side restriction into an outer WHERE by accident.
- Result condition: append to the outer PlainSelect WHERE after grouping the original predicate. Result filters run before aggregation; they are not HAVING. UNION result filtering requires an explicit outer SELECT.

Version 3 adds Expressions and QueryChanges. Read EXTENDED_CONDITIONS.md for the public API. Preserve nested AND/OR/NOT rather than flattening groups. Merge.AND is the default when combining with an existing WHERE/ON/HAVING; an explicit Merge.OR widens that original business predicate but must not move table policies into that OR group. JOIN ON targets the right-side alias in the outer query block only; unknown/ambiguous targets and USING/NATURAL/CROSS joins must not silently fall back to WHERE.

Distinguish columns from bound values: a string is a value unless represented by col(...). Aggregate expressions belong in HAVING/order. Standard comparisons and NOT retain SQL UNKNOWN; null-safe comparisons must remain correct under NOT as well. Keep the independent three-valued-logic evaluator regressions when changing boolean rendering.

Read [the regression matrix](references/regression-matrix.md) when changing traversal, alias resolution, parameter emission or supported syntax. Walk each scope independently, including CTE definitions and nested expressions. A CTE name can shadow a physical table policy; self-join aliases are distinct occurrences.

The emitted parameter sequence can interleave original and injected values arbitrarily. Update both directions of the parameter plan, the PreparedStatement setter mapping, and ParameterMetaData. Preserve clearParameters, batch snapshots, statement lifetime and close-on-bind-failure behavior. Never substitute business values into SQL literals.

Keep unsupported constructs explicit. Add a result-based regression for a supported construct before broadening its claim. Prefer comparisons with independently filtered views or manually authored expected SQL over checks of serialized formatting. Reproduce an engine issue with unwrapped JDBC before classifying a failure as a compatibility-mode limitation.

Run build.ps1 -JavaHome <JDK8> -Test after relevant changes, then pack.ps1. Validate actual class version 52, bundled dependency hashes, and archive contents. Report native database tests separately from H2 compatibility modes and AST-only checks. Update README, VALIDATION.md and the test matrix for the new boundary.

Open-source references: [JSqlParser 4.9](https://github.com/JSQLParser/JSqlParser/tree/jsqlparser-4.9), [MyBatis-Plus tenant plugin](https://baomidou.com/en/plugins/tenant/). The latter informs alias/table policy design; this library is a JDBC decorator, not a replacement MyBatis cache interceptor.
