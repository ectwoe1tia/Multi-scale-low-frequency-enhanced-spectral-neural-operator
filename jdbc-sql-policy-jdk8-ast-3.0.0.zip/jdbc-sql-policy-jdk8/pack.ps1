param([string]$Output = (Join-Path (Split-Path $PSScriptRoot) 'jdbc-sql-policy-jdk8-ast-3.0.0.zip'))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$packageRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$Output = [System.IO.Path]::GetFullPath($Output)
$temporary = $Output + '.tmp'
$files = @()
foreach ($name in @('.gitignore','README.md','VALIDATION.md','EXTENDED_CONDITIONS.md','THIRD_PARTY_NOTICES.md','DEPENDENCIES.json','pom.xml','build.ps1','pack.ps1',
    'dist\jdbc-sql-policy-jdk8-3.0.0.jar','dist\jdbc-sql-policy-jdk8-3.0.0-sources.jar','dist\validation.txt')) {
    $files += Get-Item -LiteralPath (Join-Path $packageRoot $name)
}
foreach ($folder in @('src','examples','skills','lib','test-lib','licenses')) {
    $files += Get-ChildItem -LiteralPath (Join-Path $packageRoot $folder) -Recurse -File
}
$manifest = @()
$archive = [System.IO.Compression.ZipFile]::Open($temporary,[System.IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($packageRoot.Length + 1).Replace('\','/')
        $entryName = 'jdbc-sql-policy-jdk8/' + $relative
        $manifest += [pscustomobject]@{path=$entryName; bytes=$file.Length; sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$entryName,[System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
    $entry = $archive.CreateEntry('jdbc-sql-policy-jdk8/PACKAGE_MANIFEST.json')
    $writer = New-Object System.IO.StreamWriter($entry.Open(),(New-Object System.Text.UTF8Encoding($false)))
    try { $writer.Write((ConvertTo-Json -InputObject $manifest -Depth 3)) } finally { $writer.Dispose() }
} finally { $archive.Dispose() }
if ((Get-Item -LiteralPath $temporary).Length -ge 15000000) { throw 'Package exceeds 15 MB' }
# Verify each archived file against its hash before publishing the ZIP.
$archive = [System.IO.Compression.ZipFile]::OpenRead($temporary)
try {
    foreach ($record in $manifest) {
        $entry = $archive.GetEntry($record.path)
        if ($null -eq $entry -or $entry.Length -ne $record.bytes) { throw "ZIP entry missing or wrong size: $($record.path)" }
        $stream = $entry.Open()
        $hasher = [System.Security.Cryptography.SHA256]::Create()
        try { $hash = [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
        finally { $stream.Dispose(); $hasher.Dispose() }
        if ($hash -ne $record.sha256) { throw "ZIP hash mismatch: $($record.path)" }
    }
} finally { $archive.Dispose() }
Move-Item -LiteralPath $temporary -Destination $Output -Force
$packageHash = (Get-FileHash -LiteralPath $Output -Algorithm SHA256).Hash.ToLowerInvariant()
($packageHash + '  ' + [System.IO.Path]::GetFileName($Output)) | Set-Content -Encoding ASCII -LiteralPath ($Output + '.sha256')
[pscustomobject]@{path=$Output; bytes=(Get-Item -LiteralPath $Output).Length; files=$manifest.Count; sha256=$packageHash}
