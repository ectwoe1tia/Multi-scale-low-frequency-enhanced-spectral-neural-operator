package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.util.*;
import javax.sql.DataSource;
import static com.bydauto.yunfan.agent.data.sqlpolicy.Expressions.*;
import static com.bydauto.yunfan.agent.data.sqlpolicy.ContractChecks.*;

final class ExpressionChecks {
    static void verify(DataSource raw,SqlDialect dialect) throws Exception {
        String join="select u.id,o.id from users u left join orders o on o.user_id=u.id";
        String visible="select u.id,o.id from users_visible u left join orders_visible o on o.user_id=u.id";
        check(raw,dialect,join,visible+" where (o.amount>80 or o.id is null) and not(u.id=2)",
                QueryChanges.builder().where(and(or(col("o.amount").gt(80),col("o.id").isNull()),not(col("u.id").eq(2)))).build());
        check(raw,dialect,join+" where u.id=?",visible+" where (u.id=?) or (u.id=5)",
                QueryChanges.builder().where(col("u.id").eq(5),QueryChanges.Merge.OR).build(),1);
        check(raw,dialect,join+" where u.id=? or u.id=?",visible+" where (u.id=? or u.id=?) and (o.amount>80 or o.id is null)",
                QueryChanges.builder().where(or(col("o.amount").gt(80),col("o.id").isNull())).build(),1,5);
        check(raw,dialect,join,visible+" where o.amount between 50 and 90",
                QueryChanges.builder().where(col("o.amount").between(50,90)).build());
        check(raw,dialect,join,visible+" where o.amount not between 50 and 90",
                QueryChanges.builder().where(col("o.amount").notBetween(50,90)).build());
        check(raw,dialect,join,visible+" where u.id not in(1,2)",
                QueryChanges.builder().where(col("u.id").notIn(Arrays.asList(1,2))).build());
        check(raw,dialect,join,visible+" where 1=0",QueryChanges.builder().where(col("u.id").in(Collections.emptyList())).build());
        check(raw,dialect,join,visible+" where 1=1",QueryChanges.builder().where(col("u.id").notIn(Collections.emptyList())).build());
        check(raw,dialect,join,visible+" where o.user_id=u.id",
                QueryChanges.builder().where(col("o.user_id").eq(col("u.id"))).build());
        check(raw,dialect,join,visible+" where o.amount+u.id*2>60",
                QueryChanges.builder().where(col("o.amount").add(col("u.id").multiply(2)).gt(60)).build());
        check(raw,dialect,join,visible+" where coalesce(o.amount,0)=0",
                QueryChanges.builder().where(coalesce(col("o.amount"),val(0)).eq(0)).build());
        check(raw,dialect,"select id from users","select id from users_visible where lower(name)='alice' or char_length(name)=3",
                QueryChanges.builder().where(or(lower(col("name")).eq("alice"),length(col("name")).eq(3))).build());
        check(raw,dialect,"select id from users","select id from users_visible where name not like 'a%'",
                QueryChanges.builder().where(col("name").notLike("a%")).build());
        check(raw,dialect,"select id from users","select id from users_visible where name like '%li%'",
                QueryChanges.builder().where(col("name").contains("li")).build());
        check(raw,dialect,"select id from users","select id from users_visible where name='nobody'",
                QueryChanges.builder().where(col("name").contains("%_' OR 1=1 --")).build());
        check(raw,dialect,"select id from users","select id from users_visible where parent_id is null",
                QueryChanges.builder().where(col("parent_id").eq(null)).build());
        check(raw,dialect,"select id from users","select id from users_visible where parent_id is null or parent_id<>1",
                QueryChanges.builder().where(col("parent_id").distinctFrom(1)).build());
        check(raw,dialect,join,visible+" where (u.parent_id=o.user_id) or (u.parent_id is null and o.user_id is null)",
                QueryChanges.builder().where(col("u.parent_id").nullSafeEq(col("o.user_id"))).build());
        // Extra ON keeps unmatched users; same predicate in WHERE does not.
        check(raw,dialect,join,visible+" and (o.amount>80 or u.id=5)",
                QueryChanges.builder().on("o",or(col("o.amount").gt(80),col("u.id").eq(5))).build());
        check(raw,dialect,join+" and o.amount>?",visible+" and o.amount>? or o.id=u.id+9",
                QueryChanges.builder().on("o",col("o.id").eq(col("u.id").add(9)),QueryChanges.Merge.OR).build(),60);
        check(raw,dialect,"select u.id,o.id from users u join orders o on o.user_id=u.id or o.id=u.id+9",
                "select u.id,o.id from users_visible u join orders_visible o on (o.user_id=u.id or o.id=u.id+9) and o.amount<90",
                QueryChanges.builder().on("o",col("o.amount").lt(90)).build());
        String group="select u.id,count(o.id) as n from users u left join orders o on o.user_id=u.id group by u.id";
        String groupVisible=group.replace("from users u","from users_visible u").replace("join orders o","join orders_visible o");
        check(raw,dialect,group,groupVisible+" having count(o.id)=0 or sum(o.amount)>80",
                QueryChanges.builder().having(or(count(col("o.id")).eq(0),sum(col("o.amount")).gt(80))).build());
        check(raw,dialect,group+" having count(o.id)>?",groupVisible+" having (count(o.id)>?) or u.id=5",
                QueryChanges.builder().having(col("u.id").eq(5),QueryChanges.Merge.OR).build(),0);
        check(raw,dialect,group,groupVisible+" having count(distinct o.id)=1",
                QueryChanges.builder().having(countDistinct(col("o.id")).eq(1)).build());
        DataSource ordered=source(raw,dialect,QueryChanges.builder().replaceOrder().orderBy(lower(col("name")),QueryPolicy.Direction.DESC).build());
        eq(rows(raw,"select id from users_visible order by lower(name) desc"),rows(ordered,"select id from users order by id"));
        DataSource aggregateOrder=source(raw,dialect,QueryChanges.builder().orderBy(count(col("o.id")),QueryPolicy.Direction.ASC).orderBy("u.id",QueryPolicy.Direction.DESC).build());
        eq(rows(raw,groupVisible+" order by count(o.id) asc,u.id desc"),rows(aggregateOrder,group));
        QueryPolicy tableRule=QueryPolicy.forTable("users").where(
                and(col("tenant_id").eq(42),or(col("id").eq(1),col("parent_id").isNull()),not(col("deleted").eq(true)))).build();
        compare(new PolicyDataSource(raw,dialect,Collections.singletonList(tableRule)),raw,
                "select id from users","select id from users where tenant_id=42 and (id=1 or parent_id is null) and not deleted=true");

        rejects(() -> source(raw,dialect,QueryChanges.builder().on("missing",col("o.id").eq(1)).build()).getConnection().prepareStatement(join));
        rejects(() -> source(raw,dialect,QueryChanges.builder().on("p",col("p.id").eq(1)).build()).getConnection()
                .prepareStatement("select u.id from users u join profiles p using(id)"));
        rejects(() -> source(raw,dialect,QueryChanges.builder().where(countAll().gt(0)).build()).getConnection().prepareStatement("select id from users"));
        rejects(() -> source(raw,dialect,QueryChanges.builder().replaceOrder().build()).getConnection().prepareStatement("select id from users order by ?"));
        rejects(() -> col("id").notIn(Arrays.asList(1,null)));
        rejects(() -> QueryChanges.builder().where(alwaysTrue()).where(alwaysFalse()));
        rejects(() -> {
            Expressions.Condition tree=col("id").eq(1);
            for(int i=0;i<80;i++) tree=not(tree);
        });

        // Independent SQL three-valued-logic evaluator; no generated reference SQL.
        Random random=new Random(20261118);
        Object[][] visibleUsers={{1,3,"alice"},{2,1,"bob"},{5,null,"empty"}};
        for(int i=0;i<50;i++) {
            Logic tree=randomTree(random,4);
            List<String> expected=new ArrayList<String>();
            for(Object[] row:visibleUsers) if(tree.truth.get(row)==1) expected.add("["+row[0]+"]");
            DataSource ds=source(raw,dialect,QueryChanges.builder().where(tree.sql).orderBy("id",QueryPolicy.Direction.ASC).build());
            eq(expected,rows(ds,"select id from users where id>?",0));queries++;
        }
    }
    static DataSource source(DataSource raw,SqlDialect dialect,QueryChanges changes) {
        return PolicyDataSource.withChanges(raw,dialect,() -> new ArrayList<QueryPolicy>(policies().values()),() -> changes);
    }
    static void check(DataSource raw,SqlDialect dialect,String sql,String expected,QueryChanges changes,Object... args) throws Exception {
        compare(source(raw,dialect,changes),raw,sql,expected,args);
    }
    interface Truth { int get(Object[] row); } // -1 UNKNOWN, 0 FALSE, 1 TRUE
    static final class Logic {
        final Expressions.Condition sql;final Truth truth;
        Logic(Expressions.Condition sql,Truth truth) { this.sql=sql;this.truth=truth; }
    }
    static Logic randomTree(Random random,int depth) {
        if(depth==0 || random.nextInt(4)==0) {
            switch(random.nextInt(3)) {
                case 0:return new Logic(col("id").ge(2),r -> ((Integer)r[0])>=2?1:0);
                case 1:return new Logic(col("parent_id").eq(1),r -> r[1]==null?-1:((Integer)r[1])==1?1:0);
                default:return new Logic(col("name").eq("alice"),r -> r[2].equals("alice")?1:0);
            }
        }
        Logic a=randomTree(random,depth-1),b=randomTree(random,depth-1);
        switch(random.nextInt(3)) {
            case 0:return new Logic(and(a.sql,b.sql),r -> {
                int x=a.truth.get(r),y=b.truth.get(r);return x==0||y==0?0:x==-1||y==-1?-1:1;
            });
            case 1:return new Logic(or(a.sql,b.sql),r -> {
                int x=a.truth.get(r),y=b.truth.get(r);return x==1||y==1?1:x==-1||y==-1?-1:0;
            });
            default:return new Logic(not(a.sql),r -> { int x=a.truth.get(r);return x==-1?-1:1-x; });
        }
    }
}
