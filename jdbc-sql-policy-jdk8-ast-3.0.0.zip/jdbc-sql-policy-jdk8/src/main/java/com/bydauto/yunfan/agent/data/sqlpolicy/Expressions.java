package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.util.*;
import java.util.function.Function;

/** Closed, typed expression tree. No raw SQL fragments or caller-supplied operators. */
public final class Expressions {
    private Expressions() {}
    private abstract static class Node {
        final int depth, size; final boolean aggregate;
        Node(List<? extends Node> children, boolean ownAggregate) {
            int d=1,s=1; boolean a=ownAggregate;
            for(Node child:children) { Objects.requireNonNull(child); d=Math.max(d,child.depth+1);s+=child.size;a|=child.aggregate; }
            if(d>64 || s>4096) throw new IllegalArgumentException("Expression exceeds depth 64 or 4096 nodes");
            depth=d;size=s;aggregate=a;
        }
        abstract String sql(Function<String,String> column, Function<Object,String> bind);
    }
    public static final class Value extends Node {
        final String kind; final Object payload; final List<Value> args;
        private Value(String kind,Object payload,List<Value> args,boolean aggregate) {
            super(args,aggregate); this.kind=kind;this.payload=payload;
            this.args=Collections.unmodifiableList(new ArrayList<Value>(args));
        }
        @Override String sql(Function<String,String> column,Function<Object,String> bind) {
            if(kind.equals("COLUMN")) return column.apply((String)payload);
            if(kind.equals("VALUE")) return bind.apply(payload);
            if(kind.equals("COUNT_ALL")) return "COUNT(*)";
            if(kind.equals("+") || kind.equals("-") || kind.equals("*") || kind.equals("/"))
                return "("+args.get(0).sql(column,bind)+" "+kind+" "+args.get(1).sql(column,bind)+")";
            StringJoiner joined=new StringJoiner(", ");
            for(Value value:args) joined.add(value.sql(column,bind));
            return kind.equals("COUNT_DISTINCT")?"COUNT(DISTINCT "+joined+")":kind+"("+joined+")";
        }
        public Condition eq(Object other) { return other==null?isNull():comparison("=",other); }
        public Condition ne(Object other) { return other==null?isNotNull():comparison("<>",other); }
        public Condition nullSafeEq(Object other) { return other==null?isNull():comparison("NULL_SAFE_EQ",other); }
        public Condition distinctFrom(Object other) { return nullSafeEq(other).not(); }
        public Condition gt(Object other) { return comparison(">",other); }
        public Condition ge(Object other) { return comparison(">=",other); }
        public Condition lt(Object other) { return comparison("<",other); }
        public Condition le(Object other) { return comparison("<=",other); }
        public Condition like(String pattern) { return comparison("LIKE",pattern); }
        public Condition notLike(String pattern) { return comparison("NOT LIKE",pattern); }
        public Condition contains(String text) { return escapedLike("%"+escape(text)+"%"); }
        public Condition startsWith(String text) { return escapedLike(escape(text)+"%"); }
        public Condition endsWith(String text) { return escapedLike("%"+escape(text)); }
        private Condition escapedLike(String pattern) { return leaf("LIKE_ESCAPE",this,val(pattern)); }
        public Condition isNull() { return leaf("IS NULL",this); }
        public Condition isNotNull() { return leaf("IS NOT NULL",this); }
        public Condition between(Object low,Object high) { return leaf("BETWEEN",this,value(low),value(high)); }
        public Condition notBetween(Object low,Object high) { return leaf("NOT BETWEEN",this,value(low),value(high)); }
        public Value add(Object other) { return function("+",false,this,value(other)); }
        public Value subtract(Object other) { return function("-",false,this,value(other)); }
        public Value multiply(Object other) { return function("*",false,this,value(other)); }
        public Value divide(Object other) { return function("/",false,this,value(other)); }
        public Condition in(Collection<?> values) { return set("IN",values); }
        public Condition notIn(Collection<?> values) { return set("NOT IN",values); }
        private Condition set(String op,Collection<?> values) {
            Objects.requireNonNull(values);
            if(values.isEmpty()) return op.equals("IN")?alwaysFalse():alwaysTrue();
            List<Node> args=new ArrayList<Node>();args.add(this);
            for(Object v:values) args.add(value(v));
            return new Condition(op,args);
        }
        private Condition comparison(String op,Object right) { return leaf(op,this,value(right)); }
    }
    public static final class Condition extends Node {
        final String op; final List<Node> args;
        private Condition(String op,List<? extends Node> args) {
            super(args,false); this.op=op;this.args=Collections.unmodifiableList(new ArrayList<Node>(args));
        }
        public Condition and(Condition other) { return Expressions.and(this,other); }
        public Condition or(Condition other) { return Expressions.or(this,other); }
        public Condition not() { return Expressions.not(this); }
        @Override String sql(Function<String,String> column,Function<Object,String> bind) {
            if(op.equals("TRUE")) return "(1 = 1)";
            if(op.equals("FALSE")) return "(1 = 0)";
            if(op.equals("NOT")) return "(NOT "+args.get(0).sql(column,bind)+")";
            if(op.equals("AND") || op.equals("OR")) {
                StringJoiner joined=new StringJoiner(" "+op+" ","(",")");
                for(Node n:args) joined.add(n.sql(column,bind)); return joined.toString();
            }
            String left=args.get(0).sql(column,bind);
            if(op.equals("NULL_SAFE_EQ")) {
                // CASE gives a total boolean (including under NOT), unlike a=b OR both-null.
                return "(CASE WHEN "+left+" IS NULL THEN "+args.get(1).sql(column,bind)+" IS NULL"
                        +" WHEN "+args.get(1).sql(column,bind)+" IS NULL THEN (1 = 0)"
                        +" ELSE "+args.get(0).sql(column,bind)+" = "+args.get(1).sql(column,bind)+" END)";
            }
            if(op.equals("IS NULL") || op.equals("IS NOT NULL")) return "("+left+" "+op+")";
            if(op.equals("BETWEEN") || op.equals("NOT BETWEEN"))
                return "("+left+" "+op+" "+args.get(1).sql(column,bind)+" AND "+args.get(2).sql(column,bind)+")";
            if(op.equals("IN") || op.equals("NOT IN")) {
                StringJoiner joined=new StringJoiner(", ");
                for(int i=1;i<args.size();i++) joined.add(args.get(i).sql(column,bind));
                return "("+left+" "+op+" ("+joined+"))";
            }
            if(op.equals("LIKE_ESCAPE")) return "("+left+" LIKE "+args.get(1).sql(column,bind)+" ESCAPE '!')";
            return "("+left+" "+op+" "+args.get(1).sql(column,bind)+")";
        }
    }
    public static Value col(String name) {
        QueryPolicy.identifier(name);return new Value("COLUMN",name,Collections.emptyList(),false);
    }
    public static Value val(Object value) {
        if(value==null) throw new IllegalArgumentException("Use isNull/isNotNull or eq(null); null values in IN/ranges are ambiguous");
        return new Value("VALUE",value,Collections.emptyList(),false);
    }
    private static Value value(Object value) { return value instanceof Value?(Value)value:val(value); }
    private static Value function(String name,boolean aggregate,Value... args) {
        if(args.length==0) throw new IllegalArgumentException("Function arguments required");
        for(Value value:args) if(aggregate && value.aggregate) throw new IllegalArgumentException("Nested aggregates unsupported");
        return new Value(name,null,Arrays.asList(args),aggregate);
    }
    public static Value lower(Value v) { return function("LOWER",false,v); }
    public static Value upper(Value v) { return function("UPPER",false,v); }
    public static Value length(Value v) { return function("CHAR_LENGTH",false,v); }
    public static Value abs(Value v) { return function("ABS",false,v); }
    public static Value coalesce(Value first,Value second,Value... rest) {
        List<Value> values=new ArrayList<Value>(Arrays.asList(first,second));Collections.addAll(values,rest);
        return function("COALESCE",false,values.toArray(new Value[0]));
    }
    public static Value count(Value v) { return function("COUNT",true,v); }
    public static Value countDistinct(Value v) { return function("COUNT_DISTINCT",true,v); }
    public static Value countAll() { return new Value("COUNT_ALL",null,Collections.emptyList(),true); }
    public static Value sum(Value v) { return function("SUM",true,v); }
    public static Value avg(Value v) { return function("AVG",true,v); }
    public static Value min(Value v) { return function("MIN",true,v); }
    public static Value max(Value v) { return function("MAX",true,v); }
    public static Condition and(Condition... conditions) {
        return conditions.length==0?alwaysTrue():new Condition("AND",Arrays.asList(conditions));
    }
    public static Condition or(Condition... conditions) {
        return conditions.length==0?alwaysFalse():new Condition("OR",Arrays.asList(conditions));
    }
    public static Condition not(Condition condition) { return new Condition("NOT",Collections.singletonList(condition)); }
    public static Condition alwaysTrue() { return new Condition("TRUE",Collections.emptyList()); }
    public static Condition alwaysFalse() { return new Condition("FALSE",Collections.emptyList()); }
    private static Condition leaf(String op,Value... values) { return new Condition(op,Arrays.asList(values)); }
    private static String escape(String value) { return Objects.requireNonNull(value).replace("!","!!").replace("%","!%").replace("_","!_"); }
    static String render(Condition condition,Function<String,String> column,Function<Object,String> bind,boolean aggregates) {
        if(condition.aggregate && !aggregates) throw new IllegalArgumentException("Aggregate functions belong in HAVING/order, not WHERE/ON/table policies");
        return condition.sql(column,bind);
    }
    static Condition legacy(QueryPolicy.Condition condition) {
        Value c=col(condition.column());
        switch(condition.op()) {
            case EQ:return c.eq(condition.value());case NE:return c.ne(condition.value());
            case GT:return c.gt(condition.value());case GTE:return c.ge(condition.value());
            case LT:return c.lt(condition.value());case LTE:return c.le(condition.value());
            case LIKE:return c.like((String)condition.value());case IN:return c.in((List<?>)condition.value());
            case IS_NULL:return c.isNull();case NOT_NULL:return c.isNotNull();
            default:throw new IllegalArgumentException("Unsupported legacy operator");
        }
    }
}
