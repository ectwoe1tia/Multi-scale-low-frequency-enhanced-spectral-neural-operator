package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** Structural fields are trusted server configuration; values are JDBC parameters. */
public final class QueryPolicy {
    public enum Op { EQ, NE, GT, GTE, LT, LTE, LIKE, IN, IS_NULL, NOT_NULL }
    public enum Direction { ASC, DESC }

    public static final class Condition {
        private final String column;
        private final Op op;
        private final Object value;
        public Condition(String column, Op op, Object value) {
            identifier(column);
            this.column = column;
            this.op = Objects.requireNonNull(op, "op");
            if (op == Op.IS_NULL || op == Op.NOT_NULL) {
                if (value != null) throw new IllegalArgumentException("Null check takes no value");
            } else if (value == null) {
                throw new IllegalArgumentException("Use IS_NULL / NOT_NULL for null");
            }
            if (op == Op.IN) {
                if (!(value instanceof List) || ((List<?>) value).isEmpty())
                    throw new IllegalArgumentException("IN requires a non-empty List");
                List<Object> copy = new ArrayList<Object>((List<?>) value);
                if (copy.contains(null)) throw new IllegalArgumentException("IN contains null");
                this.value = Collections.unmodifiableList(copy);
            } else this.value = value;
        }
        public String column() { return column; }
        public Op op() { return op; }
        public Object value() { return value; }
    }
    public static final class Sort {
        private final String column;
        private final Direction direction;
        public Sort(String column, Direction direction) {
            identifier(column); this.column = column;
            this.direction = Objects.requireNonNull(direction, "direction");
        }
        public String column() { return column; }
        public Direction direction() { return direction; }
    }
    private final String table;
    private final List<Condition> conditions;
    private final List<Sort> sorts;
    private final Expressions.Condition predicate;
    private QueryPolicy(Builder builder) {
        identifier(builder.table);
        table = builder.table;
        conditions = Collections.unmodifiableList(new ArrayList<Condition>(builder.conditions));
        sorts = Collections.unmodifiableList(new ArrayList<Sort>(builder.sorts));
        List<Expressions.Condition> all = new ArrayList<Expressions.Condition>(builder.groups);
        for (Condition condition : conditions) all.add(Expressions.legacy(condition));
        predicate = all.isEmpty() ? null : Expressions.and(all.toArray(new Expressions.Condition[0]));
    }
    static void identifier(String value) {
        if (value == null || !value.matches("[A-Za-z_][A-Za-z0-9_$]*(\\.[A-Za-z_][A-Za-z0-9_$]*)?"))
            throw new IllegalArgumentException("Expected column/table or qualifier.column: " + value);
    }
    public String table() { return table; }
    public List<Condition> conditions() { return conditions; }
    public List<Sort> sorts() { return sorts; }
    public Expressions.Condition predicate() { return predicate; }
    public static Builder forTable(String table) { return new Builder(table); }
    public static final class Builder {
        private final String table;
        private final List<Condition> conditions = new ArrayList<Condition>();
        private final List<Sort> sorts = new ArrayList<Sort>();
        private final List<Expressions.Condition> groups = new ArrayList<Expressions.Condition>();
        private Builder(String table) { this.table = table; }
        public Builder where(String column, Op op, Object value) {
            conditions.add(new Condition(column, op, value)); return this;
        }
        public Builder where(String column, Op op) { return where(column, op, null); }
        /** Repeated where calls are ANDed; build OR groups explicitly inside this tree. */
        public Builder where(Expressions.Condition condition) { groups.add(Objects.requireNonNull(condition)); return this; }
        public Builder orderBy(String column, Direction direction) {
            sorts.add(new Sort(column, direction)); return this;
        }
        public QueryPolicy build() { return new QueryPolicy(this); }
    }
}
