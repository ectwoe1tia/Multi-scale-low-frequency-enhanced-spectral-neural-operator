package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.util.*;
import net.sf.jsqlparser.expression.*;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.*;

/** JSqlParser AST rewrite. Filter table inputs BEFORE relational joins. */
public final class SqlPolicyRewriter {
    private SqlPolicyRewriter() {}
    public static final class Rewrite {
        private final String sql;
        private final List<Object> values;
        private final List<Integer> positions;
        private final int[] original;
        private final List<String> actions;
        Rewrite(String sql,List<Object> values,List<Integer> positions,int[] original,List<String> actions) {
            this.sql=sql; this.values=Collections.unmodifiableList(new ArrayList<Object>(values));
            this.positions=Collections.unmodifiableList(new ArrayList<Integer>(positions));
            this.original=original.clone(); this.actions=Collections.unmodifiableList(new ArrayList<String>(actions));
        }
        public String sql() { return sql; }
        public List<Object> policyValues() { return values; }
        public List<Integer> policyParameterIndexes() { return positions; }
        public int originalParameterCount() { return original.length; }
        public int insertedParameters() { return values.size(); }
        public boolean changed() { return !actions.isEmpty(); }
        public List<String> actions() { return actions; }
        public int remapOriginalParameter(int index) {
            if(index<1 || index>original.length) throw new IllegalArgumentException("Original parameter index out of range: "+index);
            return original[index-1];
        }
    }
    public static Rewrite rewrite(String sql,SqlDialect dialect,Map<String,QueryPolicy> policies) {
        return rewrite(sql,dialect,policies,Collections.<QueryPolicy.Sort>emptyList());
    }
    /** resultSorts are outer-query output columns/aliases, including UNION/CTE results. */
    public static Rewrite rewrite(String sql,SqlDialect dialect,Map<String,QueryPolicy> policies,List<QueryPolicy.Sort> resultSorts) {
        return rewrite(sql,dialect,policies,resultSorts,Collections.<QueryPolicy.Condition>emptyList());
    }
    /** resultConditions are explicitly post-join WHERE predicates on the outer PlainSelect. */
    public static Rewrite rewrite(String sql,SqlDialect dialect,Map<String,QueryPolicy> policies,
                                  List<QueryPolicy.Sort> resultSorts,List<QueryPolicy.Condition> resultConditions) {
        return rewrite(sql,dialect,policies,QueryChanges.legacy(resultSorts,resultConditions));
    }
    public static Rewrite rewrite(String sql,SqlDialect dialect,Map<String,QueryPolicy> policies,QueryChanges changes) {
        Objects.requireNonNull(sql); Objects.requireNonNull(dialect); Objects.requireNonNull(policies);
        Objects.requireNonNull(changes);
        if(policies.isEmpty() && changes.empty()) return unchanged(sql,0);
        return new Engine(dialect,policies).rewrite(sql,changes);
    }
    private static Rewrite unchanged(String sql,int count) {
        int[] map=new int[count]; for(int i=0;i<count;i++) map[i]=i+1;
        return new Rewrite(sql,Collections.emptyList(),Collections.emptyList(),map,Collections.emptyList());
    }
    private static final class Engine {
        final SqlDialect dialect;
        final Map<String,QueryPolicy> policies;
        final String prefix="jpol"+UUID.randomUUID().toString().replace("-","");
        final List<Object> added=new ArrayList<Object>();
        final List<String> actions=new ArrayList<String>();
        final Set<Select> visited=Collections.newSetFromMap(new IdentityHashMap<Select,Boolean>());
        int plainCount;
        Engine(SqlDialect dialect,Map<String,QueryPolicy> policies) { this.dialect=dialect; this.policies=policies; }
        Rewrite rewrite(String sql,QueryChanges changes) {
            List<SqlLexer.Token> tokens=SqlLexer.scan(sql,dialect);
            if(tokens.isEmpty()) return unchanged(sql,0);
            if(!tokens.get(0).keyword("select") && !tokens.get(0).keyword("with") && !tokens.get(0).symbol("("))
                return unchanged(sql,0);
            StringBuilder tagged=new StringBuilder(); int offset=0,originalCount=0,selectCount=0;
            for(int i=0;i<tokens.size();i++) {
                SqlLexer.Token token=tokens.get(i);
                if(token.keyword("select")) selectCount++;
                if(token.symbol(":") && (i==0 || !tokens.get(i-1).symbol(":"))
                        && (i+1==tokens.size() || !tokens.get(i+1).symbol(":")))
                    throw bad("Use JDBC positional parameters; named parameters are not supported");
                if(token.symbol("?")) {
                    if(i+1<tokens.size() && (tokens.get(i+1).symbol("?") || tokens.get(i+1).symbol("|") || tokens.get(i+1).symbol("&")))
                        throw bad("JSON question-mark operators unsupported; use jsonb_exists");
                    tagged.append(sql,offset,token.start).append(':').append(prefix).append('o').append(++originalCount);
                    offset=token.end;
                }
            }
            tagged.append(sql.substring(offset));
            Statement statement=parse(tagged.toString());
            if(!(statement instanceof Select)) throw bad("Only SELECT query rewriting is supported");
            Select root=(Select)statement;
            walk(root,Collections.<String>emptySet(),true);
            if(plainCount!=selectCount) throw bad("AST contains unvisited SELECT scopes; rewrite refused");
            applyChanges(root,changes);
            if(actions.isEmpty()) return unchanged(sql,originalCount);
            String emitted=root.toString();
            int[] mapping=new int[originalCount]; boolean[] seen=new boolean[added.size()];
            List<Object> values=new ArrayList<Object>(); List<Integer> positions=new ArrayList<Integer>();
            StringBuilder output=new StringBuilder(); offset=0; int bindIndex=0;
            List<SqlLexer.Token> emittedTokens=SqlLexer.scan(emitted,dialect);
            for(int i=0;i+1<emittedTokens.size();i++) {
                SqlLexer.Token colon=emittedTokens.get(i),name=emittedTokens.get(i+1);
                if(!colon.symbol(":") || !name.value.startsWith(prefix)) continue;
                String marker=name.value.substring(prefix.length());
                int id=Integer.parseInt(marker.substring(1)); bindIndex++;
                if(marker.charAt(0)=='o') {
                    if(id<1 || id>mapping.length || mapping[id-1]!=0) throw bad("Original parameter duplicated");
                    mapping[id-1]=bindIndex;
                } else {
                    if(id<1 || id>added.size() || seen[id-1]) throw bad("Policy parameter duplicated");
                    seen[id-1]=true; positions.add(bindIndex); values.add(added.get(id-1));
                }
                output.append(emitted,offset,colon.start).append('?'); offset=name.end; i++;
            }
            output.append(emitted.substring(offset));
            for(int mapped:mapping) if(mapped==0) throw bad("Original parameter lost during AST serialization");
            for(boolean present:seen) if(!present) throw bad("Policy parameter lost during AST serialization");
            return new Rewrite(output.toString(),values,positions,mapping,actions);
        }
        void walk(Select select,Set<String> inherited,boolean root) {
            if(!visited.add(select)) return;
            Set<String> scope=new HashSet<String>(inherited);
            if(select.getWithItemsList()!=null) for(WithItem item:select.getWithItemsList()) {
                if(item.isRecursive()) throw bad("Recursive CTE requires a separate policy model");
                walk(item.getSelect(),scope,false);
                scope.add(normalize(item.getAlias().getName()));
            }
            final Set<String> current=scope;
            ExpressionVisitorAdapter expression=new ExpressionVisitorAdapter() {
                @Override public void visit(Select nested) { walk(nested,current,false); }
                @Override public void visit(ParenthesedSelect nested) { walk(nested,current,false); }
                @Override public void visit(AnyComparisonExpression any) { walk(any.getSelect(),current,false); }
            };
            if(select instanceof ParenthesedSelect) {
                walk(((ParenthesedSelect)select).getSelect(),scope,root);
            } else if(select instanceof SetOperationList) {
                SetOperationList set=(SetOperationList)select;
                // 4.9 may attach an unparenthesized UNION's trailing pagination to its last
                // PlainSelect. MySQL/PG interpret that pagination as belonging to the UNION.
                Select last=set.getSelects().get(set.getSelects().size()-1);
                if(last instanceof PlainSelect) {
                    if(set.getLimit()==null && last.getLimit()!=null) { set.setLimit(last.getLimit()); last.setLimit(null); }
                    if(set.getOffset()==null && last.getOffset()!=null) { set.setOffset(last.getOffset()); last.setOffset(null); }
                    if(set.getFetch()==null && last.getFetch()!=null) { set.setFetch(last.getFetch()); last.setFetch(null); }
                }
                for(Select branch:set.getSelects()) walk(branch,scope,false);
            } else if(select instanceof PlainSelect) {
                plainCount++;
                PlainSelect plain=(PlainSelect)select;
                if(plain.getIntoTables()!=null || plain.getIntoTempTable()!=null || plain.getForMode()!=null)
                    throw bad("SELECT INTO and locking SELECT require dedicated rewrite semantics");
                if(plain.getOracleHierarchical()!=null || plain.getQualify()!=null || plain.getTop()!=null
                        || plain.getSkip()!=null || plain.getFirst()!=null || plain.getLateralViews()!=null
                        || plain.getWindowDefinitions()!=null && !plain.getWindowDefinitions().isEmpty())
                    throw bad("Unsupported query extension");
                List<QueryPolicy.Sort> tableSorts=new ArrayList<QueryPolicy.Sort>();
                plain.setFromItem(from(plain.getFromItem(),scope,expression,root?tableSorts:null));
                joins(plain.getJoins(),scope,expression,root?tableSorts:null);
                for(SelectItem<?> item:plain.getSelectItems()) expr(item.getExpression(),expression);
                expr(plain.getWhere(),expression); expr(plain.getHaving(),expression);
                if(plain.getGroupBy()!=null) expr(plain.getGroupBy().getGroupByExpressionList(),expression);
                if(plain.getDistinct()!=null && plain.getDistinct().getOnSelectItems()!=null)
                    for(SelectItem<?> item:plain.getDistinct().getOnSelectItems()) expr(item.getExpression(),expression);
                if(root) appendSorts(plain,tableSorts,null);
            } else throw bad("Unsupported SELECT node: "+select.getClass().getSimpleName());
            if(select.getOrderByElements()!=null)
                for(OrderByElement order:select.getOrderByElements()) expr(order.getExpression(),expression);
        }
        void joins(List<Join> joins,Set<String> scope,ExpressionVisitorAdapter visitor,List<QueryPolicy.Sort> sorts) {
            if(joins==null) return;
            for(Join join:joins) {
                if(join.isFull() && dialect==SqlDialect.MYSQL) throw bad("MySQL has no FULL OUTER JOIN");
                join.setRightItem(from(join.getRightItem(),scope,visitor,sorts));
                if(join.getOnExpressions()!=null) for(Expression on:join.getOnExpressions()) expr(on,visitor);
            }
        }
        FromItem from(FromItem item,Set<String> scope,ExpressionVisitorAdapter visitor,List<QueryPolicy.Sort> sorts) {
            if(item==null) return null;
            if(item instanceof ParenthesedSelect) { walk((Select)item,scope,false); return item; }
            if(item instanceof ParenthesedFromItem) {
                ParenthesedFromItem group=(ParenthesedFromItem)item;
                if(group.getAlias()!=null) throw bad("Aliased join groups require explicit derived SELECT");
                group.setFromItem(from(group.getFromItem(),scope,visitor,sorts));
                joins(group.getJoins(),scope,visitor,sorts); return group;
            }
            if(!(item instanceof Table)) throw bad("Unsupported FROM node: "+item.getClass().getSimpleName());
            Table table=(Table)item;
            String name=normalize(table.getName());
            if(table.getSchemaName()==null && scope.contains(name)) return item; // CTE, not a physical table.
            String key=table.getSchemaName()==null?name:normalize(table.getSchemaName())+"."+name;
            QueryPolicy policy=policies.get(key); if(policy==null) return item;
            String alias=table.getAlias()!=null?table.getAlias().getName():table.getName();
            if(sorts!=null) for(QueryPolicy.Sort s:policy.sorts())
                sorts.add(new QueryPolicy.Sort(unquote(alias)+"."+localColumn(s.column(),alias,table),s.direction()));
            if(policy.predicate()==null) return item;
            if(table.getSchemaName()!=null && table.getAlias()==null)
                throw bad("Add an explicit alias for filtered schema-qualified table "+key);
            if(table.getIndexHint()!=null || table.getSampleClause()!=null || table.getPivot()!=null || table.getUnPivot()!=null)
                throw bad("Table hints/sampling/pivot are not supported on filtered tables");
            String predicate=Expressions.render(policy.predicate(),
                    c -> dialect.quoteIdentifier(localColumn(c,alias,table)),this::parameter,false);
            PlainSelect inner=(PlainSelect)parse("SELECT * FROM "+table.getFullyQualifiedName()+" WHERE "+predicate);
            ParenthesedSelect wrapped=new ParenthesedSelect();
            wrapped.setSelect(inner);
            wrapped.setAlias(table.getAlias()!=null?table.getAlias():new Alias(table.getName(),true));
            actions.add("filter "+key+" as "+alias+" before join");
            return wrapped;
        }
        void applyChanges(Select root,QueryChanges changes) {
            Select target=root;
            while(target instanceof ParenthesedSelect) target=((ParenthesedSelect)target).getSelect();
            if(changes.where!=null || changes.having!=null || !changes.joins.isEmpty()) {
                if(!(target instanceof PlainSelect)) throw bad("Result WHERE/HAVING/ON on UNION requires an explicit outer SELECT");
                PlainSelect plain=(PlainSelect)target;
                if(changes.where!=null) {
                    plain.setWhere(merge(plain.getWhere(),changes.where,changes.whereMerge,false));
                    actions.add("merge outer WHERE with "+changes.whereMerge);
                }
                if(changes.having!=null) {
                    plain.setHaving(merge(plain.getHaving(),changes.having,changes.havingMerge,true));
                    actions.add("merge outer HAVING with "+changes.havingMerge);
                }
                List<Join> candidates=new ArrayList<Join>();
                collectJoins(plain.getFromItem(),plain.getJoins(),candidates);
                for(QueryChanges.JoinChange change:changes.joins) {
                    Join found=null;
                    for(Join join:candidates) {
                        FromItem item=join.getRightItem();
                        String alias=item.getAlias()!=null?normalize(item.getAlias().getName()):
                                item instanceof Table?normalize(((Table)item).getName()):null;
                        if(change.alias.equals(alias)) {
                            if(found!=null) throw bad("JOIN alias is ambiguous: "+alias);
                            found=join;
                        }
                    }
                    if(found==null) throw bad("JOIN right alias not found in outer scope: "+change.alias);
                    if(found.isNatural() || found.isCross() || found.isSimple()
                            || found.getUsingColumns()!=null && !found.getUsingColumns().isEmpty())
                        throw bad("ON mutation needs an explicit ON join, not NATURAL/USING/CROSS/comma");
                    Expression original=null;
                    if(found.getOnExpressions()!=null) for(Expression on:found.getOnExpressions())
                        original=original==null?on:conditionAst("("+original+") AND ("+on+")");
                    found.setOnExpressions(Collections.singletonList(merge(original,change.condition,change.merge,false)));
                    actions.add("merge JOIN "+change.alias+" ON with "+change.merge);
                }
            }
            if(changes.replaceOrder) {
                target.setOrderByElements(null);actions.add("replace outer ORDER BY");
            }
            if(!changes.orders.isEmpty()) {
                List<OrderByElement> all=new ArrayList<OrderByElement>();
                if(target.getOrderByElements()!=null) all.addAll(target.getOrderByElements());
                for(QueryChanges.Order requested:changes.orders) {
                    String expression=requested.expression.sql(this::quote,this::parameter);
                    OrderByElement order=new OrderByElement();
                    try { order.setExpression(CCJSqlParserUtil.parseExpression(expression)); }
                    catch(Exception e) { throw new IllegalArgumentException("Sort AST failed",e); }
                    order.setAsc(requested.direction==QueryPolicy.Direction.ASC);
                    order.setAscDescPresent(true);all.add(order);
                }
                target.setOrderByElements(all);actions.add("append "+changes.orders.size()+" expression sort keys");
            }
        }
        Expression merge(Expression original,Expressions.Condition extra,QueryChanges.Merge merge,boolean aggregate) {
            String rendered=Expressions.render(extra,this::quote,this::parameter,aggregate);
            return conditionAst(original==null?rendered:"("+original+") "+merge.name()+" ("+rendered+")");
        }
        Expression conditionAst(String sql) {
            try { return CCJSqlParserUtil.parseCondExpression(sql); }
            catch(Exception e) { throw new IllegalArgumentException("Predicate AST failed",e); }
        }
        String quote(String column) {
            QueryPolicy.identifier(column); StringJoiner out=new StringJoiner(".");
            for(String part:column.split("\\.")) out.add(dialect.quoteIdentifier(part));
            return out.toString();
        }
        void collectJoins(FromItem base,List<Join> joins,List<Join> output) {
            if(base instanceof ParenthesedFromItem) {
                ParenthesedFromItem group=(ParenthesedFromItem)base;
                collectJoins(group.getFromItem(),group.getJoins(),output);
            }
            if(joins!=null) for(Join join:joins) { output.add(join);collectJoins(join.getRightItem(),null,output); }
        }
        String parameter(Object value) { added.add(value); return ":"+prefix+"p"+added.size(); }
        String localColumn(String column,String alias,Table table) {
            String[] parts=column.split("\\.");
            if(parts.length==2 && !parts[0].equals(unquote(alias)) && !parts[0].equals(unquote(table.getName())))
                throw bad("Policy column qualifier does not match table occurrence: "+column);
            return parts[parts.length-1];
        }
        void appendSorts(Select select,List<QueryPolicy.Sort> sorts,String ignored) {
            if(sorts==null || sorts.isEmpty()) return;
            List<OrderByElement> all=new ArrayList<OrderByElement>();
            if(select.getOrderByElements()!=null) all.addAll(select.getOrderByElements());
            for(QueryPolicy.Sort s:sorts) {
                StringBuilder qualified=new StringBuilder();
                for(String part:s.column().split("\\.")) { if(qualified.length()>0) qualified.append('.'); qualified.append(dialect.quoteIdentifier(part)); }
                OrderByElement order=new OrderByElement(); order.setExpression(new Column(qualified.toString()));
                order.setAsc(s.direction()==QueryPolicy.Direction.ASC); order.setAscDescPresent(true); all.add(order);
            }
            select.setOrderByElements(all); actions.add("append "+sorts.size()+" outer sort keys");
        }
        String normalize(String identifier) {
            return identifier.charAt(0)=='"' || identifier.charAt(0)==96?unquote(identifier):
                    dialect==SqlDialect.POSTGRESQL?identifier.toLowerCase(Locale.ROOT):identifier;
        }
    }
    static String unquote(String value) {
        if(value.length()>1 && (value.charAt(0)=='"' || value.charAt(0)==96)) {
            String q=value.substring(0,1); return value.substring(1,value.length()-1).replace(q+q,q);
        }
        return value;
    }
    static Statement parse(String sql) {
        try { return CCJSqlParserUtil.parse(sql,p -> p.withTimeOut(5000)); }
        catch(Exception e) { throw new IllegalArgumentException("SQL AST parse failed",e); }
    }
    static void expr(Expression value,ExpressionVisitorAdapter visitor) { if(value!=null) value.accept(visitor); }
    static IllegalArgumentException bad(String message) { return new IllegalArgumentException(message); }
    static String operator(QueryPolicy.Op op) {
        switch(op) {
            case EQ:return "=";case NE:return "<>";case GT:return ">";case GTE:return ">=";
            case LT:return "<";case LTE:return "<=";case LIKE:return "LIKE";
            default:throw bad("Unsupported operator");
        }
    }
}
