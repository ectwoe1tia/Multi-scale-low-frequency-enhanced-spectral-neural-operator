package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.util.*;

/** Immutable changes to the outer query block. Missing join targets fail rather than silently skip. */
public final class QueryChanges {
    public enum Merge { AND, OR }
    static final class JoinChange {
        final String alias;final Expressions.Condition condition;final Merge merge;
        JoinChange(String alias,Expressions.Condition condition,Merge merge) {
            QueryPolicy.identifier(alias);
            if(alias.contains(".")) throw new IllegalArgumentException("Use a simple JOIN right-hand alias");
            this.alias=alias;this.condition=Objects.requireNonNull(condition);this.merge=Objects.requireNonNull(merge);
        }
    }
    static final class Order {
        final Expressions.Value expression;final QueryPolicy.Direction direction;
        Order(Expressions.Value e,QueryPolicy.Direction d) { expression=Objects.requireNonNull(e);direction=Objects.requireNonNull(d); }
    }
    final Expressions.Condition where,having;
    final Merge whereMerge,havingMerge;
    final List<JoinChange> joins;
    final List<Order> orders;
    final boolean replaceOrder;
    private QueryChanges(Builder b) {
        where=b.where;having=b.having;whereMerge=b.whereMerge;havingMerge=b.havingMerge;replaceOrder=b.replaceOrder;
        joins=Collections.unmodifiableList(new ArrayList<JoinChange>(b.joins));
        orders=Collections.unmodifiableList(new ArrayList<Order>(b.orders));
    }
    public static Builder builder() { return new Builder(); }
    public static QueryChanges none() { return builder().build(); }
    boolean empty() { return where==null && having==null && joins.isEmpty() && orders.isEmpty() && !replaceOrder; }
    public static final class Builder {
        Expressions.Condition where,having; Merge whereMerge=Merge.AND,havingMerge=Merge.AND;boolean replaceOrder;
        final List<JoinChange> joins=new ArrayList<JoinChange>();
        final List<Order> orders=new ArrayList<Order>();
        public Builder where(Expressions.Condition c) { return where(c,Merge.AND); }
        public Builder where(Expressions.Condition c,Merge merge) {
            if(where!=null) throw new IllegalArgumentException("Combine conditions with and/or before setting WHERE");
            where=Objects.requireNonNull(c);whereMerge=Objects.requireNonNull(merge);return this;
        }
        public Builder having(Expressions.Condition c) { return having(c,Merge.AND); }
        public Builder having(Expressions.Condition c,Merge merge) {
            if(having!=null) throw new IllegalArgumentException("Combine conditions with and/or before setting HAVING");
            having=Objects.requireNonNull(c);havingMerge=Objects.requireNonNull(merge);return this;
        }
        public Builder on(String rightAlias,Expressions.Condition c) { return on(rightAlias,c,Merge.AND); }
        public Builder on(String rightAlias,Expressions.Condition c,Merge merge) {
            for(JoinChange j:joins) if(j.alias.equals(rightAlias)) throw new IllegalArgumentException("Combine the conditions for this JOIN");
            joins.add(new JoinChange(rightAlias,c,merge));return this;
        }
        public Builder orderBy(String column,QueryPolicy.Direction direction) { return orderBy(Expressions.col(column),direction); }
        public Builder orderBy(Expressions.Value expression,QueryPolicy.Direction direction) { orders.add(new Order(expression,direction));return this; }
        public Builder replaceOrder() { replaceOrder=true;return this; }
        public QueryChanges build() { return new QueryChanges(this); }
    }
    static QueryChanges legacy(List<QueryPolicy.Sort> sorts,List<QueryPolicy.Condition> conditions) {
        Builder builder=builder();
        if(!conditions.isEmpty()) {
            List<Expressions.Condition> nodes=new ArrayList<Expressions.Condition>();
            for(QueryPolicy.Condition c:conditions) nodes.add(Expressions.legacy(c));
            builder.where(Expressions.and(nodes.toArray(new Expressions.Condition[0])));
        }
        for(QueryPolicy.Sort s:sorts) builder.orderBy(s.column(),s.direction());
        return builder.build();
    }
}
