# AST 2.0 验证 — 2026-11-18

实际编译器与运行时：本机 JDK 8 1.8.0_42。部署请使用公司维护的 JDK 8 更新版本。主程序 class 版本为 52；JSqlParser 4.9 与 H2 2.2.224 在该运行时加载成功。

自动检查：243 项断言通过，包含 61 组关系查询结果对比。H2 分别运行 MySQL、PostgreSQL 兼容模式；用独立创建的过滤视图作为预期结果，不以改写后的 SQL 字符串作为唯一标准。

覆盖 INNER/LEFT/RIGHT/CROSS/逗号连接、自连接、链式/括号连接、USING、NATURAL INNER、派生表、EXISTS/NOT EXISTS/IN/ANY/ALL、相关标量子查询、CASE、分组/HAVING、ROW_NUMBER、普通及遮蔽 CTE、UNION/UNION ALL、原 OR 条件、结果级 WHERE、结果排序、分页和交错参数位置。JDBC 检查包含原参数元数据、clearParameters、非法索引、动态规则生命周期与普通 Statement 限制。

验证中修正了 JSqlParser 4.9 的 UNION 尾部 LIMIT 归属适配：在追加最终 ORDER BY 前，将未加括号的最后分支分页归到集合查询，避免输出 LIMIT ... ORDER BY。

H2 局限：

- 在 MySQL 模式，未限定 USING 合并列在原 SQL 中也会报歧义；结果对比使用限定列。
- NATURAL LEFT JOIN、PostgreSQL FULL OUTER JOIN 未在该引擎执行。FULL OUTER 仅验证 AST 双侧过滤和连接保留；不等价于原生 PostgreSQL 验收。
- 多层链式 CTE 在 H2 2.2.224 中会丢失绑定参数，已用完全绕过包装器的原始 JDBC 查询复现。该用例验证 AST 参数计划，并仅在测试中把固定 fixture 值转换为字面量检查关系结果；生产代码一直使用绑定参数。

没有连接原生 MySQL/PostgreSQL 服务器。兼容模式结果不代表驱动、优化器、锁、ORM 缓存和生产规模数据均已验收。Maven 构建未执行；本次使用附带依赖的 PowerShell/JDK 构建。

打包脚本验证逐文件 SHA256，发行包只包含 2.0 代码、运行依赖、测试依赖、许可证、Skill 和示例；不包含本地调试缓存或数据库凭据。
