# JDBC SQL Policy AST 2.0 — JDK 8 / MySQL / PostgreSQL

这是独立 JDBC DataSource 装饰器。2.0 使用 JSqlParser 4.9 解析和改写 AST，支持多表查询、子查询和非递归 CTE，不再使用字符串位置拼接 WHERE/JOIN。运行时需要本库 JAR 和 lib/jsqlparser-4.9.jar；数据库驱动及连接池仍由应用提供。

## 交付物

- dist/jdbc-sql-policy-jdk8-2.0.0.jar：业务库；dist 中另含源码 JAR 和验证日志。
- lib/jsqlparser-4.9.jar：运行时解析依赖，随包提供，离线可构建。
- test-lib/h2-2.2.224.jar：仅测试使用，不要放到生产运行依赖。
- examples/JoinExample.java：多表附加条件、排序及参数映射示例。
- skills/jdbc-policy-ast/SKILL.md：后续改进 Skill，与 references 一起复制到公司的 Skill 目录即可使用。
- build.ps1、pack.ps1、pom.xml：JDK 8 构建与独立打包。

保留 1.0 的 Java 包名方便迁移，但 2.0 的参数计划结构已升级；替换旧 JAR，不要同时加载。原插入点偏移接口已移除，改用 policyParameterIndexes 和 remapOriginalParameter。Maven 版本为 2.0.0。

## 两种附加条件的含义

**表级规则**限制进入 JOIN 的基础表记录。例如：orders.deleted=false。实现将 orders 替换为：

~~~sql
(SELECT * FROM orders WHERE deleted = ?) AS o
~~~

然后参与原有 LEFT JOIN / RIGHT JOIN / INNER JOIN。这样不会因为把右表条件加到外层 WHERE 而意外丢掉左表没有匹配记录的行。原有 ON、USING、WHERE、聚合和投影保留在各自 AST 位置。

**结果级条件**是业务查询筛选，显式加在最外层 SELECT 的 WHERE。例如 o.amount > 100 会按预期移除金额为 NULL 的连接结果。原 WHERE 整体加括号再 AND，保留 OR 的逻辑。结果级 WHERE 发生在聚合前；它不是 HAVING。UNION 结果需要筛选时，SQL 应写显式外层 SELECT。

## 挂载示例（Java 8）

~~~java
import com.bydauto.yunfan.agent.data.sqlpolicy.*;
import javax.sql.DataSource;
import java.util.*;

DataSource decorated = new PolicyDataSource(
    existingPool, SqlDialect.POSTGRESQL,  // MySQL 使用 SqlDialect.MYSQL
    () -> Arrays.asList(
        QueryPolicy.forTable("users")
            .where("tenant_id", QueryPolicy.Op.EQ, trustedTenantId()).build(),
        QueryPolicy.forTable("orders")
            .where("deleted", QueryPolicy.Op.EQ, false).build()),
    () -> Arrays.asList(new QueryPolicy.Sort("u.id", QueryPolicy.Direction.DESC)),
    () -> Arrays.asList(new QueryPolicy.Condition("o.amount", QueryPolicy.Op.GT, 100))
);
~~~

最后两个 Supplier 分别提供结果排序和结果 WHERE。只需要表级规则时，使用原有三参数构造器；只加结果排序时，使用四参数构造器。Supplier 在 prepareStatement 时取一次快照。规则来自可信服务端上下文；排序字段须先通过业务字段白名单映射。

原 SQL：

~~~sql
select u.id,o.amount
from users u left join orders o on o.user_id=u.id
where u.name=?
limit ?
~~~

改写为如下形状（实际输出由 AST 格式化）：

~~~sql
SELECT u.id, o.amount
FROM (SELECT * FROM users WHERE "tenant_id" = ?) u
LEFT JOIN (SELECT * FROM orders WHERE "deleted" = ?) o ON o.user_id = u.id
WHERE (u.name = ?) AND ("o"."amount" > ?)
ORDER BY "u"."id" DESC
LIMIT ?
~~~

调用方仍绑定原参数 1、2。最终位置是 3、5，新增值位于 1、2、4；每个索引由参数计划独立映射，不再假定新增参数连续出现。数值、字符串、IN 列表始终使用 JDBC 参数，禁止插入值字面量。

将 decorated 注入 DAO、JdbcTemplate 或 MyBatis SqlSessionFactory 的 DataSource 创建点。库不修改字节码，也不会自动挂载 DriverManager 的连接。普通 Statement 命中改写规则时会报错并要求 PreparedStatement。

## 支持矩阵

| 类型 | 2.0 行为 |
| --- | --- |
| INNER / LEFT / RIGHT / CROSS / 逗号连接 | 遍历每个表节点，按表规则过滤 |
| 自连接、链式连接、括号连接组 | 各表别名独立处理；给整个连接组起别名时要求改成显式派生 SELECT |
| USING / NATURAL | 保留连接结构；NATURAL 外连接及 USING 合并列仍需原生数据库验收 |
| FULL OUTER JOIN | PostgreSQL AST 支持；MySQL 拒绝；本地只做 AST 检查 |
| FROM 派生表、EXISTS、NOT EXISTS、IN、ANY、ALL、标量子查询、CASE | 遍历独立查询作用域，包含相关子查询 |
| 非递归 CTE、同名遮蔽、多 CTE | 按可见范围区分 CTE 引用与物理表；不把 CTE 别名当成基础表重复过滤 |
| UNION / UNION ALL / INTERSECT / EXCEPT | 遍历分支；实测覆盖 UNION 两种形式，其他集合运算需实库验收 |
| 原 WHERE、GROUP BY、HAVING、DISTINCT、行号窗口、排序、分页 | 保留原表达式；普通 ROW_NUMBER 已做结果对比 |
| 结果排序 | 在既有排序后追加；支持 JOIN 别名或 CTE/UNION 输出列 |

表级 QueryPolicy.orderBy 仅应用到最外层直接出现的物理表，并自动限定别名；不会向内层子查询插入无意义排序。对于 CTE、UNION 或需要固定输出排序的查询，使用结果排序 Supplier。分页最后建议追加唯一键。聚合/DISTINCT 查询必须自行配置其合法排序列。

## 明确边界

- 递归 CTE、锁定 SELECT（FOR UPDATE/SHARE）、SELECT INTO、表采样、表索引提示、优化器提示、特殊窗口定义及特殊方言扩展明确拒绝。派生表改写会影响锁定语义，不能直接沿用 1.0 的锁查询声明。
- 本次过滤策略适合普通列投影。系统列（ctid/tableoid 等）、复合整行类型、依赖源表元数据的业务不属于已验证范围。
- 表名按完整名称精确匹配。users 与 public.users 分别配置；schema-qualified 表被过滤时要求显式别名，如 public.users u。PostgreSQL 未引用名称转小写，引用名称保留大小写。
- 表级条件建议用无别名的列名以便复用到自连接。指定限定列时，限定名必须符合本次表别名或表名。结果条件用明确别名，如 u.status / o.amount。
- 不支持问号形式的 PostgreSQL JSON 运算符、反斜杠转义 SQL 字符串、JDBC 非问号命名参数。JSON 存在判断可用 jsonb_exists；字符串尽量参数化。
- 解析失败、未遍历 SELECT 作用域、参数丢失/重复会拒绝执行，不静默退回原 SQL。SQL 必须来自服务端已审核模板；AST 改写不是任意 SQL 授权机制。
- INSERT/UPDATE/DELETE 按原路径处理；不处理存储过程内部 SQL。未命中的物理表不自动获得规则。
- 每份 PreparedStatement 固定其准备时的策略，不得跨租户复用；值对象在语句使用期间不要修改。clearParameters 会恢复策略参数。
- ORM/应用结果缓存可能在 JDBC 前命中。动态规则需要关闭相关缓存或把规则和上下文纳入缓存键。原连接池、厂商 unwrap 和 prepareCall 不受这层完全覆盖。
- 派生表是否被优化器合并、是否使用索引，必须用目标数据库的 EXPLAIN 和真实数据验收，不承诺零性能开销。

## 构建与使用依赖

~~~powershell
.\build.ps1 -JavaHome "C:\Java\jdk8" -Test
.\pack.ps1
~~~

脚本校验 DEPENDENCIES.json 中的依赖哈希，使用真实 JDK 8 编译，或在更高 JDK 下用 --release 8；检查 class 版本 52。所有依赖已随包提供。输出 ZIP 小于 15 MB，含逐文件哈希。

Maven 可用 mvn package 构建（构建插件可能需下载）。无 JUnit 依赖，契约测试由 build.ps1 -Test 执行，Maven 默认不执行该 main 测试类。

~~~xml
<dependency>
  <groupId>com.bydauto.yunfan</groupId>
  <artifactId>jdbc-sql-policy-jdk8</artifactId>
  <version>2.0.0</version>
</dependency>
~~~

安装到本地仓库：mvn install:install-file -Dfile=dist/jdbc-sql-policy-jdk8-2.0.0.jar -DpomFile=pom.xml。该 POM 声明 JSqlParser 4.9 运行依赖。手动 classpath 使用时将 lib/jsqlparser-4.9.jar 一起放入应用依赖，不要只复制本库 JAR。

开源来源、许可和固定版本见 THIRD_PARTY_NOTICES.md。JSqlParser 5.x 不能在保持 JDK 8 的情况下直接升级。
