package com.bydauto.yunfan.agent.data.sqlpolicy;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.*;
import java.util.*;
import java.util.function.Supplier;
import java.util.logging.Logger;

/** JDBC 4.2 / Java 8 decorator; policy scope is the lifetime of a prepared statement. */
public final class PolicyDataSource implements DataSource {
    private final DataSource delegate;
    private final SqlDialect dialect;
    private final Supplier<List<QueryPolicy>> provider;
    private final Supplier<List<QueryPolicy.Sort>> resultSorts;
    private final Supplier<List<QueryPolicy.Condition>> resultConditions;
    public PolicyDataSource(DataSource delegate,SqlDialect dialect,List<QueryPolicy> policies) {
        this(delegate,dialect,fixed(policies));
    }
    public PolicyDataSource(DataSource delegate,SqlDialect dialect,Supplier<List<QueryPolicy>> provider) {
        this(delegate,dialect,provider,Collections::emptyList);
    }
    public PolicyDataSource(DataSource delegate,SqlDialect dialect,Supplier<List<QueryPolicy>> provider,
                            Supplier<List<QueryPolicy.Sort>> resultSorts) {
        this(delegate,dialect,provider,resultSorts,Collections::emptyList);
    }
    public PolicyDataSource(DataSource delegate,SqlDialect dialect,Supplier<List<QueryPolicy>> provider,
                            Supplier<List<QueryPolicy.Sort>> resultSorts,Supplier<List<QueryPolicy.Condition>> resultConditions) {
        this.delegate=Objects.requireNonNull(delegate,"delegate");
        this.dialect=Objects.requireNonNull(dialect,"dialect");
        this.provider=Objects.requireNonNull(provider,"provider");
        this.resultSorts=Objects.requireNonNull(resultSorts,"resultSorts");
        this.resultConditions=Objects.requireNonNull(resultConditions,"resultConditions");
    }
    private static Supplier<List<QueryPolicy>> fixed(List<QueryPolicy> policies) {
        final List<QueryPolicy> copy=Collections.unmodifiableList(new ArrayList<QueryPolicy>(policies));
        return () -> copy;
    }
    public static PolicyDataSource fromJdbcUrl(DataSource ds,String url,List<QueryPolicy> policies) {
        return new PolicyDataSource(ds,SqlDialect.fromJdbcUrl(url),policies);
    }
    public static PolicyDataSource fromJdbcUrl(DataSource ds,String url,Supplier<List<QueryPolicy>> provider) {
        return new PolicyDataSource(ds,SqlDialect.fromJdbcUrl(url),provider);
    }
    private SqlPolicyRewriter.Rewrite rewrite(String sql) throws SQLException {
        try {
            Map<String,QueryPolicy> map=new LinkedHashMap<String,QueryPolicy>();
            for (QueryPolicy p:Objects.requireNonNull(provider.get(),"Null policies"))
                if (map.put(p.table(),p)!=null) throw new IllegalArgumentException("Duplicate table policy: "+p.table());
            return SqlPolicyRewriter.rewrite(sql,dialect,map,Objects.requireNonNull(resultSorts.get(),"Null result sorts"),
                    Objects.requireNonNull(resultConditions.get(),"Null result conditions"));
        } catch (IllegalArgumentException | NullPointerException e) {
            throw new SQLException("Cannot apply SQL policy: "+e.getMessage(),"42000",e);
        }
    }
    @Override public Connection getConnection() throws SQLException { return wrap(delegate.getConnection()); }
    @Override public Connection getConnection(String user,String password) throws SQLException { return wrap(delegate.getConnection(user,password)); }
    private Connection wrap(final Connection raw) {
        return proxy(Connection.class,raw,(self,method,args) -> {
            if (method.getName().equals("prepareStatement") && args!=null && args[0] instanceof String) {
                SqlPolicyRewriter.Rewrite plan=rewrite((String)args[0]);
                Object[] changed=args.clone(); changed[0]=plan.sql();
                PreparedStatement ps=(PreparedStatement)invoke(raw,method,changed);
                try { return prepared(ps,plan,(Connection)self); }
                catch (SQLException | RuntimeException e) {
                    try { ps.close(); } catch (SQLException close) { e.addSuppressed(close); }
                    throw e;
                }
            }
            if (method.getName().equals("createStatement")) {
                final Statement statement=(Statement)invoke(raw,method,args);
                final Connection wrappedConnection=(Connection)self;
                return proxy(Statement.class,statement,(p,m,a) -> {
                    if (m.getName().equals("getConnection")) return wrappedConnection;
                    if (a!=null && a.length>0 && a[0] instanceof String
                            && (m.getName().startsWith("execute") || m.getName().equals("addBatch")))
                        if (rewrite((String)a[0]).changed())
                            throw new SQLFeatureNotSupportedException("Policy applies: use PreparedStatement instead of Statement");
                    return invoke(statement,m,a);
                });
            }
            return invoke(raw,method,args);
        });
    }
    private PreparedStatement prepared(final PreparedStatement raw,final SqlPolicyRewriter.Rewrite plan,final Connection connection) throws SQLException {
        if (plan.changed()) bind(raw,plan);
        return proxy(PreparedStatement.class,raw,(self,method,args) -> {
            String name=method.getName();
            if (name.equals("getConnection")) return connection;
            if (plan.changed()) {
                if (name.equals("getParameterMetaData")) {
                    final ParameterMetaData metadata=raw.getParameterMetaData();
                    return proxy(ParameterMetaData.class,metadata,(p,m,a) -> {
                        if (m.getName().equals("getParameterCount")) return plan.originalParameterCount();
                        if (a!=null && a.length==1 && a[0] instanceof Integer) {
                            Object[] mapped=a.clone(); mapped[0]=remap(plan,(Integer)a[0]);
                            return invoke(metadata,m,mapped);
                        }
                        return invoke(metadata,m,a);
                    });
                }
                if (name.equals("clearParameters")) { raw.clearParameters(); bind(raw,plan); return null; }
                if (name.startsWith("set") && args!=null && args.length>=2 && args[0] instanceof Integer) {
                    Object[] mapped=args.clone(); mapped[0]=remap(plan,(Integer)args[0]);
                    return invoke(raw,method,mapped);
                }
                if (args==null && (name.equals("execute") || name.equals("executeQuery") || name.equals("executeUpdate")
                        || name.equals("executeLargeUpdate") || name.equals("addBatch"))) bind(raw,plan);
            }
            return invoke(raw,method,args);
        });
    }
    private static int remap(SqlPolicyRewriter.Rewrite plan,int index) throws SQLException {
        try { return plan.remapOriginalParameter(index); }
        catch (IllegalArgumentException e) { throw new SQLException(e.getMessage(),"07009",e); }
    }
    private static void bind(PreparedStatement statement,SqlPolicyRewriter.Rewrite plan) throws SQLException {
        for (int i=0;i<plan.policyValues().size();i++)
            statement.setObject(plan.policyParameterIndexes().get(i),plan.policyValues().get(i));
    }
    private interface Call { Object invoke(Object self,Method method,Object[] args) throws Throwable; }
    private static <T> T proxy(Class<T> type,Object target,Call call) {
        Object wrapped=Proxy.newProxyInstance(PolicyDataSource.class.getClassLoader(),new Class<?>[]{type},(self,method,args) -> {
            String name=method.getName();
            if (method.getDeclaringClass()==Object.class) {
                if (name.equals("equals")) return self==args[0];
                if (name.equals("hashCode")) return System.identityHashCode(self);
                return "Policy"+type.getSimpleName();
            }
            if (name.equals("unwrap") && ((Class<?>)args[0]).isInstance(self)) return self;
            if (name.equals("isWrapperFor") && ((Class<?>)args[0]).isInstance(self)) return true;
            return call.invoke(self,method,args);
        });
        return type.cast(wrapped);
    }
    private static Object invoke(Object target,Method method,Object[] args) throws Throwable {
        try { return method.invoke(target,args); }
        catch (InvocationTargetException e) { throw e.getCause(); }
    }
    @Override public PrintWriter getLogWriter() throws SQLException { return delegate.getLogWriter(); }
    @Override public void setLogWriter(PrintWriter out) throws SQLException { delegate.setLogWriter(out); }
    @Override public void setLoginTimeout(int seconds) throws SQLException { delegate.setLoginTimeout(seconds); }
    @Override public int getLoginTimeout() throws SQLException { return delegate.getLoginTimeout(); }
    @Override public Logger getParentLogger() throws SQLFeatureNotSupportedException { return delegate.getParentLogger(); }
    @Override public <T> T unwrap(Class<T> type) throws SQLException { return type.isInstance(this)?type.cast(this):delegate.unwrap(type); }
    @Override public boolean isWrapperFor(Class<?> type) throws SQLException { return type.isInstance(this)||delegate.isWrapperFor(type); }
}
