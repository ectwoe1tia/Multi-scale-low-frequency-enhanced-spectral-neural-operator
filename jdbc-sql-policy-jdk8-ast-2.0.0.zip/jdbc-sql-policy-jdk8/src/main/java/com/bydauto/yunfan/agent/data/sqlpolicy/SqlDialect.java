package com.bydauto.yunfan.agent.data.sqlpolicy;

/** Identifier quoting supported by the SQL policy interceptor. */
public enum SqlDialect {
    MYSQL('`'), POSTGRESQL('"');

    private final char quote;
    SqlDialect(char quote) { this.quote = quote; }

    public String quoteIdentifier(String identifier) {
        if (identifier == null || !identifier.matches("[A-Za-z_][A-Za-z0-9_$]*"))
            throw new IllegalArgumentException("Unsafe SQL identifier: " + identifier);
        return quote + identifier + quote;
    }

    public static SqlDialect fromJdbcUrl(String jdbcUrl) {
        if (jdbcUrl == null) throw new IllegalArgumentException("JDBC URL is required");
        String value = jdbcUrl.toLowerCase(java.util.Locale.ROOT);
        if (value.startsWith("jdbc:mysql:")) return MYSQL;
        if (value.startsWith("jdbc:postgresql:")) return POSTGRESQL;
        throw new IllegalArgumentException("Only MySQL and PostgreSQL are supported");
    }
}
