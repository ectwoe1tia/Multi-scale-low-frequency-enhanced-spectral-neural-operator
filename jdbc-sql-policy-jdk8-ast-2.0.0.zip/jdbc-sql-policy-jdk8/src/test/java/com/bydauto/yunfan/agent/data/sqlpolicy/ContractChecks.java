package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.sql.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sql.DataSource;
import org.h2.jdbcx.JdbcDataSource;

/** Compares rewritten JDBC results with independently filtered SQL views. */
public final class ContractChecks {
    static int assertions,queries;
    static void eq(Object wanted,Object actual) {
        assertions++;
        if(!Objects.equals(wanted,actual)) throw new AssertionError("Expected "+wanted+"\nActual "+actual);
    }
    interface Action { void run() throws Exception; }
    static void rejects(Action action) throws Exception {
        assertions++;
        try { action.run(); } catch(IllegalArgumentException | SQLException expected) { return; }
        throw new AssertionError("Unsupported SQL was accepted");
    }
    static QueryPolicy rule(String table) {
        return QueryPolicy.forTable(table).where("tenant_id",QueryPolicy.Op.EQ,42)
                .where("deleted",QueryPolicy.Op.EQ,false).build();
    }
    static Map<String,QueryPolicy> policies() {
        Map<String,QueryPolicy> p=new LinkedHashMap<String,QueryPolicy>();
        for(String t:Arrays.asList("users","orders","profiles")) p.put(t,rule(t)); return p;
    }
    static List<String> rows(DataSource ds,String sql,Object...args) throws Exception {
        try(Connection c=ds.getConnection(); PreparedStatement s=c.prepareStatement(sql)) {
            eq(args.length,s.getParameterMetaData().getParameterCount());
            for(int i=0;i<args.length;i++) s.setObject(i+1,args[i]);
            List<String> rows=new ArrayList<String>();
            try(ResultSet r=s.executeQuery()) {
                while(r.next()) {
                    List<String> row=new ArrayList<String>();
                    for(int j=1;j<=r.getMetaData().getColumnCount();j++) row.add(String.valueOf(r.getObject(j)));
                    rows.add(row.toString());
                }
            } return rows;
        }
    }
    static void compare(DataSource wrapped,DataSource raw,String sql,String reference,Object...args) throws Exception {
        try {
            List<String> actual=rows(wrapped,sql,args),expected=rows(raw,reference,args);
            Collections.sort(actual); Collections.sort(expected); eq(expected,actual); queries++;
        } catch(Throwable e) {
            SqlPolicyRewriter.Rewrite debug=SqlPolicyRewriter.rewrite(sql,SqlDialect.POSTGRESQL,policies());
            throw new AssertionError("Query: "+sql+"\nRewritten: "+debug.sql()+"\nBindings: "+debug.policyParameterIndexes()+" "+debug.policyValues(),e);
        }
    }
    static void dialect(SqlDialect dialect,String mode) throws Exception {
        JdbcDataSource raw=new JdbcDataSource();
        raw.setURL("jdbc:h2:mem:"+mode+";MODE="+mode+";DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1");
        try(Connection c=raw.getConnection(); Statement s=c.createStatement()) {
            s.execute("create table users(id int,tenant_id int,deleted boolean,name varchar(30),parent_id int)");
            s.execute("create table orders(id int,user_id int,tenant_id int,deleted boolean,amount int)");
            s.execute("create table profiles(id int,tenant_id int,deleted boolean,label varchar(30))");
            s.execute("insert into users values(1,42,false,'alice',3),(2,42,false,'bob',1),(3,7,false,'hidden',null),(4,42,true,'deleted',1),(5,42,false,'empty',null)");
            s.execute("insert into orders values(10,1,42,false,100),(11,1,7,false,999),(12,3,42,false,80),(13,2,42,true,33),(14,2,42,false,55),(15,99,42,false,11)");
            s.execute("insert into profiles values(1,42,false,'A'),(2,7,false,'hidden'),(5,42,false,'E')");
            for(String table:policies().keySet())
                s.execute("create view "+table+"_visible as select * from "+table+" where tenant_id=42 and deleted=false");
        }
        PolicyDataSource ds=new PolicyDataSource(raw,dialect,new ArrayList<QueryPolicy>(policies().values()));
        compare(ds,raw,"select id from users where id=? or id=?","select id from users_visible where id=? or id=?",1,3);
        String[][] cases={
            {"select u.id,o.id from users u inner join orders o on o.user_id=u.id","select u.id,o.id from users_visible u inner join orders_visible o on o.user_id=u.id"},
            {"select u.id,o.id from users u left join orders o on o.user_id=u.id","select u.id,o.id from users_visible u left join orders_visible o on o.user_id=u.id"},
            {"select u.id,o.id from users u right join orders o on o.user_id=u.id","select u.id,o.id from users_visible u right join orders_visible o on o.user_id=u.id"},
            {"select u.id,o.id,p.label from users u left join orders o on o.user_id=u.id left join profiles p on p.id=u.id","select u.id,o.id,p.label from users_visible u left join orders_visible o on o.user_id=u.id left join profiles_visible p on p.id=u.id"},
            {"select u.id,p.id from users u left join users p on u.parent_id=p.id","select u.id,p.id from users_visible u left join users_visible p on u.parent_id=p.id"},
            {"select u.id,p.label from users u cross join profiles p","select u.id,p.label from users_visible u cross join profiles_visible p"},
            {"select u.id,p.label from users u, profiles p where u.id=p.id","select u.id,p.label from users_visible u, profiles_visible p where u.id=p.id"},
            {"select u.id from users u join profiles p using(id)","select u.id from users_visible u join profiles_visible p using(id)"},
            {"select u.id from users u natural join profiles p","select u.id from users_visible u natural join profiles_visible p"},
            {"select d.id from (select u.id from users u join orders o on u.id=o.user_id) d","select d.id from (select u.id from users_visible u join orders_visible o on u.id=o.user_id) d"},
            {"select u.id from users u where exists(select 1 from orders o where o.user_id=u.id)","select u.id from users_visible u where exists(select 1 from orders_visible o where o.user_id=u.id)"},
            {"select u.id from users u where not exists(select 1 from orders o where o.user_id=u.id)","select u.id from users_visible u where not exists(select 1 from orders_visible o where o.user_id=u.id)"},
            {"select id from users where id in(select user_id from orders)","select id from users_visible where id in(select user_id from orders_visible)"},
            {"select id from users where id=any(select user_id from orders)","select id from users_visible where id=any(select user_id from orders_visible)"},
            {"select id from users where id<>all(select user_id from orders)","select id from users_visible where id<>all(select user_id from orders_visible)"},
            {"select u.id,o.id from (users u left join orders o on u.id=o.user_id)","select u.id,o.id from (users_visible u left join orders_visible o on u.id=o.user_id)"},
            {"select id,row_number() over(order by id) as rn from users","select id,row_number() over(order by id) as rn from users_visible"},
            {"select u.id,(select count(*) from orders o where o.user_id=u.id) as n from users u","select u.id,(select count(*) from orders_visible o where o.user_id=u.id) as n from users_visible u"},
            {"select u.id,count(o.id) from users u left join orders o on u.id=o.user_id group by u.id having count(o.id)>=0","select u.id,count(o.id) from users_visible u left join orders_visible o on u.id=o.user_id group by u.id having count(o.id)>=0"},
            {"select id from users union all select id from orders","select id from users_visible union all select id from orders_visible"},
            {"select id from users union select user_id from orders","select id from users_visible union select user_id from orders_visible"},
            {"with chosen as(select * from users) select c.id,o.id from chosen c left join orders o on c.id=o.user_id","with chosen as(select * from users_visible) select c.id,o.id from chosen c left join orders_visible o on c.id=o.user_id"},
            {"with users as(select * from orders) select id from users","with users as(select * from orders_visible) select id from users"},
            {"with users as(select * from users) select id from users","with users as(select * from users_visible) select id from users"},
            {"select u.id from users u where case when exists(select 1 from orders o where o.user_id=u.id) then 1 else 0 end=1","select u.id from users_visible u where case when exists(select 1 from orders_visible o where o.user_id=u.id) then 1 else 0 end=1"}
        };
        for(String[] pair:cases) compare(ds,raw,pair[0],pair[1]);
        // H2 2.2.224 loses parameters in chained CTEs, including without this interceptor.
        eq(Collections.emptyList(),rows(raw,"with a as(select * from users where tenant_id=?), b as(select id from a) select id from b",42));
        SqlPolicyRewriter.Rewrite chain=SqlPolicyRewriter.rewrite("with a as(select * from users), b as(select id from a) select id from b",dialect,policies());
        String literalChain=chain.sql();
        for(Object value:chain.policyValues()) literalChain=literalChain.replaceFirst("\\?",String.valueOf(value));
        eq(rows(raw,"with a as(select * from users_visible), b as(select id from a) select id from b"),rows(raw,literalChain));
        compare(ds,raw,"select ? as tag,u.id,o.id from users u left join orders o on o.user_id=u.id and o.amount>? where u.id>? order by u.id limit ? offset ?",
                "select ? as tag,u.id,o.id from users_visible u left join orders_visible o on o.user_id=u.id and o.amount>? where u.id>? order by u.id limit ? offset ?","hello",60,0,10,0);
        compare(ds,raw,"with a as(select id from users where id>?) select id from a union all select id from orders where amount>? order by id limit ?",
                "with a as(select id from users_visible where id>?) select id from a union all select id from orders_visible where amount>? order by id limit ?",0,50,8);
        compare(ds,raw,"select '?' as literal,id from users where name<>? -- ? comment\n",
                "select '?' as literal,id from users_visible where name<>?","hidden");
        QueryPolicy sorted=QueryPolicy.forTable("users").where("tenant_id",QueryPolicy.Op.EQ,42).where("deleted",QueryPolicy.Op.EQ,false)
                .orderBy("id",QueryPolicy.Direction.DESC).build();
        DataSource sortedDs=new PolicyDataSource(raw,dialect,Arrays.asList(sorted,rule("orders")));
        eq(Arrays.asList("[5]","[2]","[1]"),rows(sortedDs,"select id from users"));
        eq(Arrays.asList("[5, null]","[2, 14]","[1, 10]"),rows(sortedDs,"select u.id,o.id from users u left join orders o on o.user_id=u.id"));
        DataSource resultSorted=new PolicyDataSource(raw,dialect,() -> new ArrayList<QueryPolicy>(policies().values()),
                () -> Collections.singletonList(new QueryPolicy.Sort("id",QueryPolicy.Direction.DESC)));
        eq(Arrays.asList("[15]","[14]"),rows(resultSorted,"select id from users union all select id from orders limit ?",2));
        DataSource resultFiltered=new PolicyDataSource(raw,dialect,() -> new ArrayList<QueryPolicy>(policies().values()),
                () -> Collections.singletonList(new QueryPolicy.Sort("u.id",QueryPolicy.Direction.DESC)),
                () -> Collections.singletonList(new QueryPolicy.Condition("o.amount",QueryPolicy.Op.GT,60)));
        compare(resultFiltered,raw,"select u.id,o.id from users u left join orders o on o.user_id=u.id where u.id=? or u.id=?",
                "select u.id,o.id from users_visible u left join orders_visible o on o.user_id=u.id where (u.id=? or u.id=?) and o.amount>60 order by u.id desc",1,5);
        AtomicInteger tenant=new AtomicInteger(42),calls=new AtomicInteger();
        DataSource dynamic=new PolicyDataSource(raw,dialect,() -> {
            calls.incrementAndGet();
            return Collections.singletonList(QueryPolicy.forTable("users").where("tenant_id",QueryPolicy.Op.EQ,tenant.get()).build());
        });
        try(Connection c=dynamic.getConnection();PreparedStatement s=c.prepareStatement("select id from users where id>? order by id limit ?")) {
            s.setInt(1,0);s.setInt(2,2); eq(2,s.getParameterMetaData().getParameterCount());
            eq(Types.INTEGER,s.getParameterMetaData().getParameterType(2)); eq(true,s.getConnection()==c);
            tenant.set(7); s.clearParameters(); s.setInt(1,0);s.setInt(2,1);
            try(ResultSet r=s.executeQuery()) { eq(true,r.next());eq(1,r.getInt(1));eq(false,r.next()); }
            rejects(() -> s.setInt(3,999));eq(1,calls.get());
        }
        eq(Collections.singletonList("[3]"),rows(dynamic,"select id from users"));eq(2,calls.get());
        rejects(() -> ds.getConnection().createStatement().executeQuery("select * from users"));
        if(dialect==SqlDialect.POSTGRESQL) {
            DataSource qualified=new PolicyDataSource(raw,dialect,Collections.singletonList(rule("public.users")));
            compare(qualified,raw,"select u.id from public.users u","select id from users_visible");
        }
        System.out.println(mode+" result comparisons complete");
    }
    public static void main(String[] args) throws Exception {
        dialect(SqlDialect.MYSQL,"MySQL");
        dialect(SqlDialect.POSTGRESQL,"PostgreSQL");
        Map<String,QueryPolicy> p=policies();
        SqlPolicyRewriter.Rewrite plan=SqlPolicyRewriter.rewrite("select ? from users u join orders o on o.user_id=u.id and o.amount>? where u.id>? limit ?",SqlDialect.POSTGRESQL,p);
        eq(1,plan.remapOriginalParameter(1)); eq(6,plan.remapOriginalParameter(2));eq(7,plan.remapOriginalParameter(3));eq(8,plan.remapOriginalParameter(4));
        eq(Arrays.asList(2,3,4,5),plan.policyParameterIndexes());
        String full=SqlPolicyRewriter.rewrite("select u.id,o.id from users u full outer join orders o on u.id=o.user_id",SqlDialect.POSTGRESQL,p).sql();
        eq(true,full.contains("FULL OUTER JOIN (SELECT * FROM orders WHERE"));
        rejects(() -> SqlPolicyRewriter.rewrite("select * from users full outer join orders on users.id=orders.user_id",SqlDialect.MYSQL,p));
        rejects(() -> SqlPolicyRewriter.rewrite("with recursive x as(select * from users union all select * from x) select * from x",SqlDialect.POSTGRESQL,p));
        rejects(() -> SqlPolicyRewriter.rewrite("select * from users for update",SqlDialect.POSTGRESQL,p));
        rejects(() -> SqlPolicyRewriter.rewrite("select * into tmp from users",SqlDialect.POSTGRESQL,p));
        rejects(() -> SqlPolicyRewriter.rewrite("select * from users; delete from users",SqlDialect.POSTGRESQL,p));
        rejects(() -> SqlPolicyRewriter.rewrite("select * from users where name ? 'a'",SqlDialect.POSTGRESQL,p));
        rejects(() -> QueryPolicy.forTable("users").orderBy("id;drop",QueryPolicy.Direction.ASC));
        List<Integer> in=new ArrayList<Integer>(Arrays.asList(1,2));
        QueryPolicy inPolicy=QueryPolicy.forTable("users").where("id",QueryPolicy.Op.IN,in).where("gone",QueryPolicy.Op.IS_NULL).build();
        in.clear();eq(Arrays.<Object>asList(1,2),SqlPolicyRewriter.rewrite("select id from users",SqlDialect.POSTGRESQL,Collections.singletonMap("users",inPolicy)).policyValues());
        System.out.println("PASS: "+assertions+" assertions, "+queries+" relational result comparisons; JDK "+System.getProperty("java.version"));
        System.out.println("H2 2.2.224 MySQL/PostgreSQL modes; no native database servers. FULL OUTER: AST validation only.");
    }
}
