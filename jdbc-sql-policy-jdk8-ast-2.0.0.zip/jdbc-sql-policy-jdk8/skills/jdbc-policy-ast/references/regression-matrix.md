# Required semantic evidence for relevant changes

Use small fixtures with visible/invisible rows on BOTH sides, missing matches, soft-deleted matches, and duplicate matches. Comparing only non-null successful inner joins misses the main failure modes.

| Change | Regression to preserve |
| --- | --- |
| Table filtering | INNER, LEFT, RIGHT, CROSS/comma; self join; chained/nested joins; USING and NATURAL |
| Outer-join behavior | Invisible right row produces null for a visible left row; invisible left row is absent even when ON would fail; RIGHT/FULL have symmetric behavior |
| Scope traversal | Derived tables, EXISTS/NOT EXISTS, IN/ANY/ALL, scalar SELECT, CASE, GROUP/HAVING, CTE definitions, CTE shadowing, set-operation branches |
| Result filtering | Original OR stays parenthesized; a result predicate on a nullable side may intentionally remove unmatched rows |
| Sorting | Existing order keys retained; table sorts only on directly visible outer table occurrences; explicit output sort for CTE/UNION; sort before pagination |
| Parameters | Values in projection, ON, WHERE, CTE, HAVING, ORDER and LIMIT; strings/comments containing ?; arbitrary index mapping; invalid index rejection |
| JDBC lifecycle | clearParameters restores policy bindings; metadata reports original indexes; policies fixed per prepare; setters preserve types; resource closed on initial bind failure |

JSqlParser 4.9 has an empty default visitor for AnyComparisonExpression. Explicitly visit its Select. Audit other adapter methods when extending coverage; AST SELECT-count checking is a backstop, not a substitute for correct traversal.

JSqlParser 4.9 can attach a trailing unparenthesized UNION LIMIT to its last PlainSelect. Normalize it to the set operation before appending a result ORDER BY. Do not pull pagination out of a parenthesized branch.

H2 2.2.224 limitations observed locally:

- Unqualified USING merged columns in MySQL mode can be rejected even on original SQL.
- NATURAL LEFT JOIN and FULL OUTER JOIN are not available in this harness; do not claim native execution coverage.
- Chained CTEs can lose bound parameters, reproduced without the interceptor. The suite checks the generated chain with fixed fixture literals only in tests, plus verifies the parameter plan separately. Production always binds parameters.

Native MySQL/PostgreSQL validation remains a separate acceptance step. Include projection metadata, qualified star, query plans/index use, server SQL modes, driver-side preparation and application ORM cache configuration in that step. Do not describe a derived-table rewrite as optimizer-neutral.
