# Open-source components

Runtime dependency: JSqlParser 4.9, unmodified binary, selected under Apache License 2.0. Copyright notices and license are included in licenses/JSqlParser-APACHE-2.0.txt. Source: https://github.com/JSQLParser/JSqlParser/tree/jsqlparser-4.9 . This is the last upstream JDK 8 line: https://jsqlparser.github.io/JSqlParser/usage.html .

Test-only dependency: H2 Database 2.2.224, unmodified binary. Copyright 2004–2023 H2 Group. Available under MPL 2.0 or EPL 1.0; the complete upstream license/disclaimer is included in licenses/H2-license.html. Source: https://github.com/h2database/h2database/tree/version-2.2.224 . H2 is not required in the application runtime.

Downloaded Maven Central URLs, binary sizes and SHA256 hashes are recorded in DEPENDENCIES.json. JSqlParser is used for parsing/AST construction; the table-input filtering, scope rules and JDBC parameter plan in this project are our implementation.

Design reference only: MyBatis-Plus multi-tenant plugin, https://baomidou.com/en/plugins/tenant/ . No MyBatis-Plus code or binary is bundled. This reference helped identify alias handling and the difference between table rules and ORM result caching.
