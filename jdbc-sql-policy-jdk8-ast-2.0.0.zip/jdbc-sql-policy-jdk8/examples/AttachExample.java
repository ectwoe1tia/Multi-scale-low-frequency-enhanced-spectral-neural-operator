import com.bydauto.yunfan.agent.data.sqlpolicy.PolicyDataSource;
import com.bydauto.yunfan.agent.data.sqlpolicy.QueryPolicy;
import com.bydauto.yunfan.agent.data.sqlpolicy.SqlDialect;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

/** Java 8 integration: underlyingPool is your existing Hikari/Druid/DBCP DataSource. */
public final class AttachExample {
    public static DataSource attach(DataSource underlyingPool, String jdbcUrl,
                                    final Supplier<Long> trustedTenantId) {
        Supplier<List<QueryPolicy>> provider = new Supplier<List<QueryPolicy>>() {
            @Override public List<QueryPolicy> get() {
                Long tenant = trustedTenantId.get();
                if (tenant == null) throw new IllegalArgumentException("Tenant context is required");
                QueryPolicy rule = QueryPolicy.forTable("orders")
                        .where("tenant_id", QueryPolicy.Op.EQ, tenant)
                        .where("deleted", QueryPolicy.Op.EQ, false)
                        .orderBy("created_at", QueryPolicy.Direction.DESC)
                        .orderBy("id", QueryPolicy.Direction.DESC)
                        .build();
                return Collections.singletonList(rule);
            }
        };
        return new PolicyDataSource(underlyingPool, SqlDialect.fromJdbcUrl(jdbcUrl), provider);
    }
    public static long countReturnedRows(DataSource decorated) throws SQLException {
        // Existing parameter positions are unchanged for the caller.
        try (Connection c = decorated.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "select id, created_at from orders where status = ? limit ?")) {
            ps.setString(1, "PAID");
            ps.setInt(2, 50);
            try (ResultSet result = ps.executeQuery()) {
                long rows = 0;
                while (result.next()) rows++;
                return rows;
            }
        }
    }
}
