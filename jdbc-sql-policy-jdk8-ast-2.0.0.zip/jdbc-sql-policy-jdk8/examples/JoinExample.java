import com.bydauto.yunfan.agent.data.sqlpolicy.*;
import javax.sql.DataSource;
import java.util.*;

public final class JoinExample {
    public static DataSource attach(DataSource pool, SqlDialect dialect) {
        return new PolicyDataSource(pool, dialect,
            () -> Arrays.asList(
                QueryPolicy.forTable("users").where("tenant_id", QueryPolicy.Op.EQ, 42L).build(),
                QueryPolicy.forTable("orders").where("deleted", QueryPolicy.Op.EQ, false).build()),
            () -> Arrays.asList(new QueryPolicy.Sort("u.id", QueryPolicy.Direction.DESC)),
            () -> Arrays.asList(new QueryPolicy.Condition("o.amount", QueryPolicy.Op.GT, 100)));
    }
    public static void main(String[] args) {
        Map<String, QueryPolicy> rules = new LinkedHashMap<String, QueryPolicy>();
        rules.put("users", QueryPolicy.forTable("users").where("tenant_id", QueryPolicy.Op.EQ, 42L).build());
        rules.put("orders", QueryPolicy.forTable("orders").where("deleted", QueryPolicy.Op.EQ, false).build());
        SqlPolicyRewriter.Rewrite plan = SqlPolicyRewriter.rewrite(
            "select u.id,o.amount from users u left join orders o on o.user_id=u.id where u.name=? limit ?",
            SqlDialect.POSTGRESQL, rules,
            Collections.singletonList(new QueryPolicy.Sort("u.id", QueryPolicy.Direction.DESC)),
            Collections.singletonList(new QueryPolicy.Condition("o.amount", QueryPolicy.Op.GT, 100)));
        System.out.println(plan.sql());
        System.out.println("Original parameters -> " + plan.remapOriginalParameter(1) + ", " + plan.remapOriginalParameter(2));
        System.out.println("Policy parameter positions -> " + plan.policyParameterIndexes());
        System.out.println(plan.actions());
    }
}
