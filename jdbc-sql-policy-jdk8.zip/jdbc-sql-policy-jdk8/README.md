# JDBC SQL 条件与排序外挂（JDK 8）

独立 Java 8 库。无需 Spring、MyBatis 或其他第三方运行时依赖。把现有连接池的 DataSource 包装后交给 DAO / JdbcTemplate / SqlSessionFactory，即可在 Connection.prepareStatement 时附加参数化条件与排序。连接池和数据库 JDBC 驱动由宿主应用提供。

## 交付内容

- dist/jdbc-sql-policy-jdk8-1.0.0.jar：直接引用的库（非 java -jar 启动程序）。
- dist/jdbc-sql-policy-jdk8-1.0.0-sources.jar：对应源码。
- src/：独立源码和无需数据库的 JDBC 契约检查。
- examples/AttachExample.java：Java 8 接入示例。
- build.ps1 / pom.xml：离线 JDK 构建与 Maven 项目。
- VALIDATION.md / dist/validation.txt：本次构建证据和验证边界。

沿用原实现的包名 com.bydauto.yunfan.agent.data.sqlpolicy 方便迁移；不要同时加载旧 Java 17 版本的同名源码/JAR。

## 快速接入

~~~java
import com.bydauto.yunfan.agent.data.sqlpolicy.*;
import javax.sql.DataSource;
import java.util.Collections;

QueryPolicy rule = QueryPolicy.forTable("orders")
    .where("tenant_id", QueryPolicy.Op.EQ, 42L)
    .where("deleted", QueryPolicy.Op.EQ, false)
    .orderBy("created_at", QueryPolicy.Direction.DESC)
    .orderBy("id", QueryPolicy.Direction.DESC)
    .build();

DataSource decorated = PolicyDataSource.fromJdbcUrl(
    existingPool,
    "jdbc:postgresql://localhost/app", // MySQL 用 jdbc:mysql://localhost/app
    Collections.singletonList(rule));
// 将 decorated 交给调用方；按原有生命周期管理底层 existingPool。
~~~

原 SQL：

~~~sql
select id from orders where status = ? or priority = ? limit ?
~~~

PostgreSQL 改写形状：

~~~sql
select id from orders
where (status = ? or priority = ?)
  and ("tenant_id" = ? and "deleted" = ?)
order by "created_at" DESC, "id" DESC limit ?
~~~

调用方仍按原 SQL 设置参数 1、2、3；包装器把原来的 LIMIT 参数 3 映射到 5。MySQL 使用反引号引用列名。

已有 WHERE 整体加括号再 AND 附加条件；没有 WHERE 时创建。已有 ORDER BY 保留在前，配置排序追加为后续排序键。若要稳定分页，请最后追加唯一键（如 id）。排序列/方向是服务端配置；前端字段必须先映射到业务字段白名单。

## 动态条件

构造器也接受 Supplier<List<QueryPolicy>>，每次 prepareStatement 调用一次，以当前可信请求上下文生成规则。完整示例见 examples/AttachExample.java。

一份 PreparedStatement 固定该次 prepare 时的规则，execute/addBatch 不刷新租户身份。不要跨租户或跨请求复用同一个 PreparedStatement，也不要在使用期间修改值对象。如果 ThreadLocal 提供上下文，由宿主请求过滤器在 finally 清理；异步线程显式传递上下文。

支持 EQ、NE、GT、GTE、LT、LTE、LIKE、IN、IS_NULL、NOT_NULL。空 IN 集合与 IN 中的 null 会拒绝；LIKE 模式由调用方给出；所有值通过 setObject 绑定。普通值不得作为 SQL 片段传入。

## 挂载到现有应用

在连接池创建完成后，向 DAO/JdbcTemplate/MyBatis SqlSessionFactory 注入 decorated。不需要修改每个 PreparedStatement 调用点。该库不执行 javaagent 字节码注入，也不会自动替换 DriverManager.getConnection 得到的连接。

MyBatis/Hibernate/应用层结果缓存可能在 JDBC 之前命中。使用按请求变化的过滤规则时，应关闭相关结果缓存或把规则和参数纳入缓存键。底层驱动的 PreparedStatement 缓存应按最终 SQL 区分。对于强制租户隔离，这个受限 SQL 装饰器不能代替授权、数据库 RLS 或完整的 ORM 策略层。

原始 Statement 命中需改写的规则时抛 SQLFeatureNotSupportedException，要求改用 PreparedStatement；未命中策略表的普通语句按原路径执行。

## SQL 支持范围

- 单表 SELECT；支持 table / schema.table、可选别名、已有 WHERE、GROUP BY/HAVING、ORDER BY、LIMIT/OFFSET、FETCH、FOR UPDATE。
- 处理字符串、标准转义单引号、注释、PostgreSQL dollar quote；保留原 SQL 的主要内容。
- 命中规则时拒绝 JOIN、子查询、UNION/INTERSECT/EXCEPT、SELECT INTO、WINDOW 等不支持结构。安装非空规则时，WITH/CTE 和无法识别的 FROM 会直接拒绝。
- 不改写 INSERT/UPDATE/DELETE，不覆盖 prepareCall 的存储过程内部查询、原始 DataSource、厂商 unwrap 后的直接操作。不是覆盖任意 SQL 的通用解析器。
- 不支持 PostgreSQL 问号 JSON 运算符、MySQL 可执行注释、反斜杠转义 SQL 字符串；将字符串值改用 ? 绑定。SQL 本身应来自已审核的代码/模板。
- 表策略按完整名称匹配；orders 与 public.orders 是不同规则。PostgreSQL 未加引号的表名按数据库规则转小写，带引号的表名及 MySQL 表名按实际拼写精确匹配。
- 附加列自动加方言引号，大小写必须符合实际列名。别名列可配置 o.tenant_id；别名应与模板固定对应。
- 添加过滤是在聚合前的 WHERE 中；排序受原 SQL 的 DISTINCT/聚合约束。不要给聚合结果追加不合法的排序列，由服务端按查询模板配置策略。
- ParameterMetaData.getParameterCount 和按参数索引访问的元数据映射回原参数；额外参数不能通过越界 setX 索引覆盖。

## 构建与检查

Windows 使用本机 JDK 8（路径换成你的安装位置）：

~~~powershell
.\build.ps1 -JavaHome "C:\Java\jdk8" -Test
~~~

不传 -Test 只构建 JAR。也可使用 JDK 9+ 构建，脚本会使用 --release 8，并核对 class 文件主版本号 52。脚本不联网，不安装软件。

完成带 -Test 的构建后，运行 .\pack.ps1 可生成独立 ZIP。包内包含逐文件 SHA256 清单，脚本校验压缩内容与大小后才发布 ZIP（严格小于 15 MB）；默认输出到项目的上级目录。

Maven 在 JDK 8 下可执行 mvn package；首次运行可能需要下载构建插件。库无依赖。契约检查不是 JUnit 测试，Maven 默认不会执行它；可运行：

~~~powershell
java -cp "target/classes;target/test-classes" com.bydauto.yunfan.agent.data.sqlpolicy.ContractChecks
~~~

公司 Maven 仓库/本地仓库接入可先执行（这里安装的是这个库，不含数据库驱动）：

~~~powershell
mvn install:install-file -Dfile=dist/jdbc-sql-policy-jdk8-1.0.0.jar -DpomFile=pom.xml
~~~

~~~xml
<dependency>
  <groupId>com.bydauto.yunfan</groupId>
  <artifactId>jdbc-sql-policy-jdk8</artifactId>
  <version>1.0.0</version>
</dependency>
~~~

数据库驱动需要选择公司认可且支持 JDK 8 的版本。本交付不包含驱动、连接信息或凭据。
