param([string]$JavaHome = $env:JAVA_HOME, [switch]$Test)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
if (-not $JavaHome) { $JavaHome = Split-Path (Split-Path (Get-Command javac.exe).Source) }
$compiler = Join-Path $JavaHome 'bin\javac.exe'
$runtime = Join-Path $JavaHome 'bin\java.exe'
$jarTool = Join-Path $JavaHome 'bin\jar.exe'
foreach ($tool in @($compiler, $runtime, $jarTool)) { if (-not (Test-Path -LiteralPath $tool)) { throw "Missing JDK tool: $tool" } }
$release = Get-Content -LiteralPath (Join-Path $JavaHome 'release') -Raw
$targetFlags = if ($release -match 'JAVA_VERSION="1\.8') { @('-source','1.8','-target','1.8') } else { @('--release','8') }
$buildRoot = Join-Path $projectRoot ('target\build-' + [Guid]::NewGuid().ToString('N'))
$classes = Join-Path $buildRoot 'classes'
$testClasses = Join-Path $buildRoot 'test-classes'
$dist = Join-Path $projectRoot 'dist'
New-Item -ItemType Directory -Force -Path $classes,$testClasses,$dist | Out-Null
$sources = @(Get-ChildItem (Join-Path $projectRoot 'src\main\java') -Recurse -Filter *.java | ForEach-Object FullName)
& $compiler @targetFlags -encoding UTF-8 -d $classes @sources
if ($LASTEXITCODE -ne 0) { throw 'Main compilation failed' }
# Java 8 class-file major version is 52.
foreach ($classFile in Get-ChildItem $classes -Recurse -Filter *.class) {
    $bytes = [System.IO.File]::ReadAllBytes($classFile.FullName)
    if (([int]$bytes[6] * 256 + [int]$bytes[7]) -ne 52) { throw "Wrong class version: $classFile" }
}
$binary = Join-Path $dist 'jdbc-sql-policy-jdk8-1.0.0.jar'
& $jarTool cf $binary -C $classes .
if ($LASTEXITCODE -ne 0) { throw 'JAR creation failed' }
& $jarTool cf (Join-Path $dist 'jdbc-sql-policy-jdk8-1.0.0-sources.jar') -C (Join-Path $projectRoot 'src\main\java') .
if ($LASTEXITCODE -ne 0) { throw 'Source JAR creation failed' }
$examples = @(Get-ChildItem (Join-Path $projectRoot 'examples') -Filter *.java | ForEach-Object FullName)
if ($examples.Count -gt 0) {
    & $compiler @targetFlags -encoding UTF-8 -cp $binary -d $testClasses @examples
    if ($LASTEXITCODE -ne 0) { throw 'Example compilation failed' }
}
if ($Test) {
    $tests = @(Get-ChildItem (Join-Path $projectRoot 'src\test\java') -Recurse -Filter *.java | ForEach-Object FullName)
    & $compiler @targetFlags -encoding UTF-8 -cp $classes -d $testClasses @tests
    if ($LASTEXITCODE -ne 0) { throw 'Contract compilation failed' }
    $result = & $runtime -cp "$classes;$testClasses" com.bydauto.yunfan.agent.data.sqlpolicy.ContractChecks
    if ($LASTEXITCODE -ne 0) { throw 'Contract checks failed' }
    $result | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $dist 'validation.txt')
    $result
}
Get-FileHash -Algorithm SHA256 -LiteralPath $binary
