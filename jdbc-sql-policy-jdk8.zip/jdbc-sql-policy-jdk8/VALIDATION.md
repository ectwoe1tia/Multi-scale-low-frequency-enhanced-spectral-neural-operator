# 2026-11-17 构建记录

- 使用本机实际 JDK 8 1.8.0_42 编译主程序及契约检查，并在该 JDK 的运行时执行。
- 所有打包 class 文件主版本号为 52（Java 8）。此外已用 javac 18 的 --release 8 编译主源码，约束 Java 8 API。
- 53 项断言通过。覆盖 WHERE 原有 OR 分组、MySQL/PostgreSQL 引号、已有/新增排序、分页参数位置、GROUP/HAVING 顺序、注释及字符串、SQL 形态拒绝、IN 快照、JDBC 绑定、参数元数据、clearParameters、批处理、策略生命周期、普通 Statement 限制、初次绑定失败关闭资源。
- 测试用记录参数的 JDBC 代理检查真实 Java 方法调用路径；没有连接 MySQL/PostgreSQL 实例，没有完成公司 ORM/连接池集成验证。
- 示例只编译，不连接数据库。Maven 构建未在本机运行；本次采用无依赖 PowerShell/JDK 构建。

JDK 8u42 是本机现有验证环境的版本号，部署使用公司维护的 JDK 8 更新版本。
