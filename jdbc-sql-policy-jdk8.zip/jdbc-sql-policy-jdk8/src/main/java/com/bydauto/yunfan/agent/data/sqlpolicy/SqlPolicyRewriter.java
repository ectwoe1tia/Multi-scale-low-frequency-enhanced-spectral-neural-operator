package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import com.bydauto.yunfan.agent.data.sqlpolicy.SqlLexer.Token;

/** Single-table SELECT augmentation. No SQL-value interpolation. */
public final class SqlPolicyRewriter {
    private SqlPolicyRewriter() { }
    public static final class Rewrite {
        private final String sql;
        private final List<Object> values;
        private final int before, originalCount;
        private final boolean changed;
        Rewrite(String sql,List<Object> values,int before,int originalCount,boolean changed) {
            this.sql=sql; this.values=Collections.unmodifiableList(new ArrayList<Object>(values));
            this.before=before; this.originalCount=originalCount; this.changed=changed;
        }
        public String sql() { return sql; }
        public List<Object> policyValues() { return values; }
        public int originalParametersBeforeInsertion() { return before; }
        public int originalParameterCount() { return originalCount; }
        public int insertedParameters() { return values.size(); }
        public boolean changed() { return changed; }
        public int remapOriginalParameter(int index) {
            if (index<1 || index>originalCount) throw new IllegalArgumentException("Original parameter index out of range: "+index);
            return index<=before ? index : index+values.size();
        }
    }
    public static Rewrite rewrite(String sql,SqlDialect dialect,Map<String,QueryPolicy> policies) {
        List<Token> tokens=SqlLexer.scan(sql,dialect);
        if (tokens.isEmpty() || policies.isEmpty()) return unchanged(sql);
        if (tokens.get(0).keyword("with")) throw new IllegalArgumentException("CTE unsupported by SQL policy");
        if (!tokens.get(0).keyword("select")) return unchanged(sql);
        int from=find(tokens,"from",0);
        if (from<0) return unchanged(sql);
        int cursor=from+1;
        if (cursor>=tokens.size() || !tokens.get(cursor).identifier())
            throw new IllegalArgumentException("FROM requires a simple table");
        String table=tablePart(tokens.get(cursor++),dialect);
        if (cursor<tokens.size() && tokens.get(cursor).symbol(".")) {
            cursor++;
            if (cursor>=tokens.size() || !tokens.get(cursor).identifier()) throw new IllegalArgumentException("Invalid schema.table");
            table+="."+tablePart(tokens.get(cursor++),dialect);
        }
        QueryPolicy policy=policies.get(table);
        if (policy==null) return unchanged(sql);
        int where=find(tokens,"where",cursor), order=find(tokens,"order",cursor);
        for (int i=1;i<tokens.size();i++) {
            Token t=tokens.get(i);
            if (t.keyword("select") || t.keyword("union") || t.keyword("intersect") || t.keyword("except")
                    || t.keyword("into") || t.keyword("window") || t.keyword("qualify") || t.keyword("lock"))
                throw new IllegalArgumentException("Unsupported SQL construct: "+t.value);
        }
        int sourceEnd=cursor;
        while (sourceEnd<tokens.size() && !isClause(tokens,sourceEnd) && !tokens.get(sourceEnd).symbol(";")) sourceEnd++;
        int aliasEnd=cursor;
        if (aliasEnd<sourceEnd && tokens.get(aliasEnd).keyword("as")) aliasEnd++;
        if (aliasEnd<sourceEnd && tokens.get(aliasEnd).identifier() && !tokens.get(aliasEnd).keyword("join")) aliasEnd++;
        if (aliasEnd!=sourceEnd) throw new IllegalArgumentException("Only one table and optional alias are supported");

        int end=contentEnd(tokens,sql.length());
        int insertAt=end;
        for (int i=where>=0?where+1:sourceEnd; i<tokens.size();i++)
            if (isClause(tokens,i)) { insertAt=tokens.get(i).start; break; }
        int before=0,total=0;
        for (int i=0;i<tokens.size();i++) if (tokens.get(i).symbol("?")) {
            rejectJsonOperator(tokens,i);
            total++; if (tokens.get(i).start<insertAt) before++;
        }
        List<Object> values=new ArrayList<Object>();
        String predicate=predicate(policy,dialect,values);
        String modified=sql;
        if (!predicate.isEmpty()) {
            if (where>=0) {
                int expression=tokens.get(where).end;
                if (sql.substring(expression,insertAt).trim().isEmpty()) throw new IllegalArgumentException("Empty WHERE");
                // Newlines keep a trailing -- comment from swallowing the closing parenthesis.
                modified=sql.substring(0,expression)+" (\n"+sql.substring(expression,insertAt)
                        +"\n) AND ("+predicate+") "+sql.substring(insertAt);
            } else modified=sql.substring(0,insertAt)+" WHERE ("+predicate+") "+sql.substring(insertAt);
        }
        if (!policy.sorts().isEmpty()) {
            List<Token> updated=SqlLexer.scan(modified,dialect);
            order=find(updated,"order",0);
            int tail=contentEnd(updated,modified.length());
            for (Token t:updated) if (t.depth==0 && (t.keyword("limit") || t.keyword("offset") || t.keyword("fetch") || t.keyword("for"))) {
                tail=t.start; break;
            }
            StringBuilder sort=new StringBuilder(order>=0 ? ", " : " ORDER BY ");
            for (int i=0;i<policy.sorts().size();i++) {
                if (i>0) sort.append(", ");
                QueryPolicy.Sort s=policy.sorts().get(i);
                sort.append(quote(s.column(),dialect)).append(' ').append(s.direction());
            }
            modified=modified.substring(0,tail)+sort+" "+modified.substring(tail);
        }
        return new Rewrite(modified,values,before,total,!sql.equals(modified));
    }
    private static String tablePart(Token t,SqlDialect dialect) {
        return dialect==SqlDialect.POSTGRESQL && t.kind==1 ? t.value.toLowerCase(Locale.ROOT) : t.value;
    }
    private static Rewrite unchanged(String sql) { return new Rewrite(sql,Collections.emptyList(),0,0,false); }
    private static boolean isClause(List<Token> tokens,int i) {
        Token t=tokens.get(i);
        if (t.depth!=0 || t.kind!=1) return false;
        if (t.keyword("order") || t.keyword("group")) {
            if (i+1>=tokens.size() || !tokens.get(i+1).keyword("by")) throw new IllegalArgumentException("Expected BY");
            return true;
        }
        return t.keyword("where") || t.keyword("having") || t.keyword("limit") || t.keyword("offset")
                || t.keyword("fetch") || t.keyword("for") || t.keyword("union");
    }
    private static int find(List<Token> tokens,String keyword,int start) {
        for (int i=start;i<tokens.size();i++) if (tokens.get(i).depth==0 && tokens.get(i).keyword(keyword)) return i;
        return -1;
    }
    private static int contentEnd(List<Token> tokens,int fallback) {
        if (tokens.isEmpty()) return fallback;
        Token last=tokens.get(tokens.size()-1);
        return last.symbol(";") ? last.start : last.end;
    }
    private static void rejectJsonOperator(List<Token> tokens,int i) {
        if (i+1<tokens.size() && (tokens.get(i+1).symbol("?") || tokens.get(i+1).symbol("|") || tokens.get(i+1).symbol("&")))
            throw new IllegalArgumentException("JSON question-mark operators unsupported");
        if (i>0) {
            Token prev=tokens.get(i-1);
            String allowed=" SELECT DISTINCT BY LIMIT OFFSET FIRST NEXT AND OR NOT WHEN THEN ELSE BETWEEN LIKE ILIKE IS IN ";
            if (prev.kind==2 || prev.kind==3 || prev.symbol(")")
                    || (prev.kind==1 && !allowed.contains(" "+prev.value.toUpperCase(Locale.ROOT)+" ")))
                throw new IllegalArgumentException("Ambiguous question mark; JSON operators unsupported");
        }
    }
    private static String quote(String identifier,SqlDialect dialect) {
        QueryPolicy.identifier(identifier);
        StringBuilder out=new StringBuilder();
        for (String part:identifier.split("\\.")) {
            if (out.length()>0) out.append('.');
            out.append(dialect.quoteIdentifier(part));
        }
        return out.toString();
    }
    private static String predicate(QueryPolicy policy,SqlDialect dialect,List<Object> values) {
        StringBuilder out=new StringBuilder();
        for (QueryPolicy.Condition c:policy.conditions()) {
            if (out.length()>0) out.append(" AND ");
            out.append(quote(c.column(),dialect));
            switch (c.op()) {
                case IS_NULL: out.append(" IS NULL"); break;
                case NOT_NULL: out.append(" IS NOT NULL"); break;
                case IN:
                    out.append(" IN (");
                    for (Object value:(List<?>)c.value()) {
                        if (out.charAt(out.length()-1)!='(') out.append(", ");
                        out.append('?'); values.add(value);
                    }
                    out.append(')'); break;
                default: out.append(' ').append(operator(c.op())).append(" ?"); values.add(c.value());
            }
        }
        return out.toString();
    }
    private static String operator(QueryPolicy.Op op) {
        switch (op) {
            case EQ:return "="; case NE:return "<>"; case GT:return ">"; case GTE:return ">=";
            case LT:return "<"; case LTE:return "<="; case LIKE:return "LIKE";
            default:throw new IllegalArgumentException("Unsupported operator");
        }
    }
}
