package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.util.ArrayList;
import java.util.List;

/** Small lexical scanner, not a general SQL parser. All offsets refer to original SQL. */
final class SqlLexer {
    static final class Token {
        final String value;
        final int start, end, depth, kind; // 0 symbol, 1 word, 2 quoted identifier, 3 literal
        Token(String value, int start, int end, int depth, int kind) {
            this.value=value; this.start=start; this.end=end; this.depth=depth; this.kind=kind;
        }
        boolean keyword(String word) { return kind==1 && value.equalsIgnoreCase(word); }
        boolean symbol(String s) { return kind==0 && value.equals(s); }
        boolean identifier() { return kind==1 || kind==2; }
    }
    static List<Token> scan(String sql, SqlDialect dialect) {
        if (sql==null || sql.length()>1000000) throw new IllegalArgumentException("SQL missing or too large");
        List<Token> tokens=new ArrayList<Token>();
        int depth=0;
        for (int i=0; i<sql.length();) {
            char c=sql.charAt(i); int start=i;
            if (Character.isWhitespace(c)) { i++; continue; }
            if (sql.startsWith("--", i) || (c=='#' && dialect==SqlDialect.MYSQL)) {
                if (dialect==SqlDialect.MYSQL && c=='-' && i+2<sql.length() && !Character.isWhitespace(sql.charAt(i+2)))
                    throw new IllegalArgumentException("Ambiguous MySQL -- syntax");
                while (i<sql.length() && sql.charAt(i)!='\n' && sql.charAt(i)!='\r') i++;
                continue;
            }
            if (sql.startsWith("/*", i)) {
                if (sql.startsWith("/*!", i)) throw new IllegalArgumentException("Executable SQL comment unsupported");
                i+=2; int level=1;
                while (i<sql.length() && level>0) {
                    if (sql.startsWith("/*", i)) {
                        if (dialect==SqlDialect.MYSQL) throw new IllegalArgumentException("Nested MySQL comment unsupported");
                        level++; i+=2;
                    } else if (sql.startsWith("*/", i)) { level--; i+=2; } else i++;
                }
                if (level!=0) throw new IllegalArgumentException("Unclosed comment");
                continue;
            }
            if (c=='\'' || c=='"' || c==96) {
                char q=c; i++; boolean closed=false;
                StringBuilder value=new StringBuilder();
                while (i<sql.length()) {
                    char x=sql.charAt(i++);
                    if (x=='\\') throw new IllegalArgumentException("Backslash-escaped SQL literals unsupported; bind the value");
                    if (x==q) {
                        if (i<sql.length() && sql.charAt(i)==q) { value.append(q); i++; }
                        else { closed=true; break; }
                    } else value.append(x);
                }
                if (!closed) throw new IllegalArgumentException("Unclosed quote");
                tokens.add(new Token(value.toString(), start, i, depth, q=='\''?3:2)); continue;
            }
            if (c=='$' && dialect==SqlDialect.POSTGRESQL) {
                int delimiterEnd=sql.indexOf('$', i+1);
                if (delimiterEnd>=0) {
                    String tag=sql.substring(i+1, delimiterEnd);
                    if (tag.isEmpty() || tag.matches("[A-Za-z_][A-Za-z0-9_]*")) {
                        String delimiter=sql.substring(i, delimiterEnd+1);
                        int close=sql.indexOf(delimiter, delimiterEnd+1);
                        if (close<0) throw new IllegalArgumentException("Unclosed dollar quote");
                        i=close+delimiter.length();
                        tokens.add(new Token(sql.substring(start,i),start,i,depth,3)); continue;
                    }
                }
                throw new IllegalArgumentException("Use JDBC ? parameters, not PostgreSQL $n");
            }
            if (c=='(') { tokens.add(new Token("(",i,i+1,depth,0)); depth++; i++; continue; }
            if (c==')') {
                if (--depth<0) throw new IllegalArgumentException("Unbalanced parentheses");
                tokens.add(new Token(")",i,i+1,depth,0)); i++; continue;
            }
            if (Character.isLetter(c) || c=='_') {
                i++;
                while (i<sql.length() && (Character.isLetterOrDigit(sql.charAt(i)) || sql.charAt(i)=='_' || sql.charAt(i)=='$')) i++;
                tokens.add(new Token(sql.substring(start,i),start,i,depth,1)); continue;
            }
            tokens.add(new Token(String.valueOf(c),i,i+1,depth,0)); i++;
        }
        if (depth!=0) throw new IllegalArgumentException("Unbalanced parentheses");
        for (int i=0;i<tokens.size();i++) {
            Token t=tokens.get(i);
            if (t.symbol(";") && i!=tokens.size()-1) throw new IllegalArgumentException("Multiple statements unsupported");
        }
        return tokens;
    }
}
