package com.bydauto.yunfan.agent.data.sqlpolicy;

import java.lang.reflect.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sql.DataSource;

/** Dependency-free executable JDBC contracts. No database is contacted. */
public final class ContractChecks {
    private static int checks;
    private static void eq(Object expected,Object actual) {
        checks++;
        if (!Objects.equals(expected,actual)) throw new AssertionError("Expected "+expected+" but got "+actual);
    }
    private static void yes(boolean value) { eq(true,value); }
    private static String spaces(String sql) { return sql.replaceAll("\\s+"," ").trim(); }
    private static SqlPolicyRewriter.Rewrite rewrite(String sql,SqlDialect dialect,QueryPolicy p) {
        return SqlPolicyRewriter.rewrite(sql,dialect,Collections.singletonMap(p.table(),p));
    }
    private interface Action { void run() throws Exception; }
    private static void fails(Class<? extends Throwable> type,Action action) throws Exception {
        checks++;
        try { action.run(); } catch (Throwable e) { if (type.isInstance(e)) return; throw new AssertionError(e); }
        throw new AssertionError("Expected "+type);
    }
    public static void main(String[] args) throws Exception {
        QueryPolicy p=QueryPolicy.forTable("orders").where("tenant_id",QueryPolicy.Op.EQ,42)
                .orderBy("created_at",QueryPolicy.Direction.DESC).orderBy("id",QueryPolicy.Direction.ASC).build();
        SqlPolicyRewriter.Rewrite r=rewrite("select id from orders where a=? OR b=? limit ? offset ?;",SqlDialect.POSTGRESQL,p);
        eq("select id from orders where ( a=? OR b=? ) AND (\"tenant_id\" = ?) ORDER BY \"created_at\" DESC, \"id\" ASC limit ? offset ?;",spaces(r.sql()));
        eq(1,r.remapOriginalParameter(1)); eq(2,r.remapOriginalParameter(2));
        eq(4,r.remapOriginalParameter(3)); eq(5,r.remapOriginalParameter(4));
        eq(Collections.<Object>singletonList(42),r.policyValues());
        fails(IllegalArgumentException.class,() -> r.remapOriginalParameter(5));
        eq("select id from orders WHERE ("+(char)96+"tenant_id"+(char)96+" = ?) ORDER BY "+(char)96+"created_at"+(char)96+" DESC, "+(char)96+"id"+(char)96+" ASC ;",
                spaces(rewrite("select id from orders;",SqlDialect.MYSQL,p).sql()));
        String ordered=spaces(rewrite("select id from orders order by score desc limit ?",SqlDialect.POSTGRESQL,p).sql());
        yes(ordered.contains("order by score desc , \"created_at\" DESC, \"id\" ASC limit ?"));
        String grouped=spaces(rewrite("select status,count(*) from orders group by status having count(*)>? limit ?",SqlDialect.POSTGRESQL,p).sql());
        yes(grouped.indexOf("WHERE")<grouped.indexOf("group by"));
        yes(grouped.indexOf("ORDER BY")>grouped.indexOf("having"));
        yes(grouped.indexOf("ORDER BY")<grouped.indexOf("limit"));
        QueryPolicy filter=QueryPolicy.forTable("orders").where("id",QueryPolicy.Op.GT,3).build();
        String comment=rewrite("select id from orders where a=1 -- tail",SqlDialect.POSTGRESQL,filter).sql();
        yes(comment.indexOf("AND")<comment.indexOf("-- tail"));
        String middle=rewrite("select id from orders where a=1 -- tail\norder by id",SqlDialect.POSTGRESQL,filter).sql();
        yes(middle.contains("-- tail\n\n) AND"));
        eq(2,rewrite("select '?' from orders where note=$x$?;$x$ and id=? limit ?",SqlDialect.POSTGRESQL,filter).originalParameterCount());
        eq(1,rewrite("select 'a''?' from orders where id=? /*?*/",SqlDialect.POSTGRESQL,filter).originalParameterCount());
        String lastLiteral=rewrite("select id from orders where note='text'",SqlDialect.POSTGRESQL,filter).sql();
        yes(lastLiteral.contains("note='text'\n) AND"));
        yes(rewrite("select id from other_table",SqlDialect.POSTGRESQL,p).sql().equals("select id from other_table"));
        fails(IllegalArgumentException.class,() -> rewrite("select * from orders o join items i on o.id=i.id",SqlDialect.POSTGRESQL,p));
        fails(IllegalArgumentException.class,() -> rewrite("select * from orders, items",SqlDialect.POSTGRESQL,p));
        fails(IllegalArgumentException.class,() -> rewrite("select * from orders union select * from orders",SqlDialect.POSTGRESQL,p));
        fails(IllegalArgumentException.class,() -> rewrite("with x as (select * from orders) select * from x",SqlDialect.POSTGRESQL,p));
        fails(IllegalArgumentException.class,() -> rewrite("select * from orders where id in (select id from other_table)",SqlDialect.POSTGRESQL,p));
        fails(IllegalArgumentException.class,() -> rewrite("select * from orders; delete from orders",SqlDialect.POSTGRESQL,p));
        fails(IllegalArgumentException.class,() -> rewrite("select * from orders where doc ? 'key'",SqlDialect.POSTGRESQL,p));
        fails(IllegalArgumentException.class,() -> rewrite("select * from orders /*! where id=1 */",SqlDialect.MYSQL,p));
        fails(IllegalArgumentException.class,() -> QueryPolicy.forTable("orders").orderBy("id;delete",QueryPolicy.Direction.ASC));
        List<Integer> in=new ArrayList<Integer>(Arrays.asList(1,2));
        QueryPolicy inPolicy=QueryPolicy.forTable("orders").where("id",QueryPolicy.Op.IN,in).where("gone",QueryPolicy.Op.IS_NULL).build();
        in.clear(); eq(Arrays.<Object>asList(1,2),rewrite("select id from orders",SqlDialect.POSTGRESQL,inPolicy).policyValues());
        QueryPolicy qualified=QueryPolicy.forTable("public.orders").where("o.id",QueryPolicy.Op.EQ,7).build();
        yes(rewrite("select o.id from public.orders as o",SqlDialect.POSTGRESQL,qualified).sql().contains("\"o\".\"id\""));

        Fake fake=new Fake(); AtomicInteger tenant=new AtomicInteger(42),calls=new AtomicInteger();
        PolicyDataSource ds=new PolicyDataSource(fake.ds(),SqlDialect.POSTGRESQL,() -> {
            calls.incrementAndGet();
            return Collections.singletonList(QueryPolicy.forTable("orders").where("tenant_id",QueryPolicy.Op.EQ,tenant.get()).build());
        });
        Connection connection=ds.getConnection();
        PreparedStatement ps=connection.prepareStatement("select id from orders where state=? limit ?");
        eq(1,calls.get()); eq(42,fake.bindings.get(2));
        ps.setString(1,"PAID"); ps.setInt(2,10);
        eq("PAID",fake.bindings.get(1)); eq(10,fake.bindings.get(3));
        eq(2,ps.getParameterMetaData().getParameterCount()); eq(3,ps.getParameterMetaData().getParameterType(2));
        yes(ps.getConnection()==connection); yes(ps.unwrap(PreparedStatement.class)==ps);
        ps.setFetchSize(200); eq(200,fake.fetchSize);
        fails(SQLException.class,() -> ps.setInt(3,999)); eq(42,fake.bindings.get(2));
        ps.addBatch(); eq(42,fake.batch.get(0).get(2));
        tenant.set(99); ps.execute(); eq(42,fake.bindings.get(2)); eq(1,calls.get());
        ps.clearParameters(); eq(1,fake.bindings.size()); eq(42,fake.bindings.get(2));
        ps.setString(1,"NEW"); ps.setInt(2,20); ps.addBatch();
        eq(20,fake.batch.get(1).get(3)); eq(10,fake.batch.get(0).get(3));
        PreparedStatement second=connection.prepareStatement("select id from orders");
        eq(2,calls.get()); eq(99,fake.bindings.get(1)); second.close();
        fails(SQLFeatureNotSupportedException.class,() -> connection.createStatement().execute("select * from orders"));
        connection.createStatement().execute("select * from other_table");
        ps.close(); connection.close(); yes(fake.closed);
        Fake failure=new Fake(); failure.bindFailure=true;
        PolicyDataSource failDs=new PolicyDataSource(failure.ds(),SqlDialect.POSTGRESQL,Collections.singletonList(filter));
        fails(SQLException.class,() -> failDs.getConnection().prepareStatement("select * from orders"));
        yes(failure.statementClosed);
        System.out.println("PASS: "+checks+" contract assertions; runtime "+System.getProperty("java.version"));
        System.out.println("Scope: SQL rewrite and recorded JDBC interactions. No MySQL/PostgreSQL server was used.");
    }
    private static final class Fake {
        final Map<Integer,Object> bindings=new TreeMap<Integer,Object>();
        final List<Map<Integer,Object>> batch=new ArrayList<Map<Integer,Object>>();
        boolean closed,statementClosed,bindFailure; int fetchSize;
        DataSource ds() { return make(DataSource.class,(p,m,a)->m.getName().equals("getConnection")?connection():zero(m)); }
        Connection connection() {
            return make(Connection.class,(p,m,a)->{
                if (m.getName().equals("prepareStatement")) { bindings.clear(); return statement(); }
                if (m.getName().equals("createStatement")) return make(Statement.class,(x,n,b)->zero(n));
                if (m.getName().equals("close")) closed=true;
                return zero(m);
            });
        }
        PreparedStatement statement() {
            return make(PreparedStatement.class,(p,m,a)->{
                String n=m.getName();
                if (n.startsWith("set") && a.length>=2 && a[0] instanceof Integer) {
                    if (bindFailure) throw new SQLException("binding failed");
                    bindings.put((Integer)a[0],a[1]); return null;
                }
                if (n.equals("setFetchSize")) fetchSize=(Integer)a[0];
                if (n.equals("clearParameters")) bindings.clear();
                if (n.equals("addBatch")) batch.add(new TreeMap<Integer,Object>(bindings));
                if (n.equals("close")) statementClosed=true;
                if (n.equals("getParameterMetaData")) return make(ParameterMetaData.class,(x,q,b)->q.getName().equals("getParameterCount")?3:b[0]);
                return zero(m);
            });
        }
    }
    private static Object zero(Method m) {
        Class<?> type=m.getReturnType();
        if (type==boolean.class) return false;
        if (type==int.class) return 0;
        if (type==long.class) return 0L;
        return null;
    }
    private static <T>T make(Class<T> type,InvocationHandler handler) {
        return type.cast(Proxy.newProxyInstance(ContractChecks.class.getClassLoader(),new Class<?>[]{type},handler));
    }
}
