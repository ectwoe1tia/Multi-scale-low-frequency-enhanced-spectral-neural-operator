# 云帆 Java 8 Agent 后端

基于 **JDK 8** 的独立后端服务，核心不依赖 Spring、Maven 下载或第三方运行库。原 `yunfan-lowcode-agent` Java 17 工程保留，本工程在独立目录重新实现；两者的数据文件不能直接混用。

已经实现：

- Java Agent 执行循环、异步任务、会话历史、请求幂等、取消、预算及重启恢复。
- MCP stdio / Streamable HTTP 客户端；另有 `/mcp` 只读工具服务端。
- 运行中追加消息、重复提醒、调用链记录、完整工具调用组的上下文裁剪。
- 文本与脚本 Skill、本地进程执行、Python/Bash/Java/C++ 部署配置模板。
- Bearer 身份认证、用户/租户隔离、权限与角色工具白名单交集、参数绑定的写操作确认。
- 私有文件工作区、文本/DOCX 解析、基础进程限额、HTTP API 和本地网页控制台。
- 可继承的 Agent Profile，以及工具、模型、认证、策略、上下文、存储和进程隔离 SPI。

## 1. 先运行本地演示

需要完整 JDK 8。构建和服务启动均不需要 Maven；Python 只用于可选的交付打包及真实 Python 技能演示。

Windows：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/build.ps1 -JavaHome 'C:\Java\jdk8'
powershell -ExecutionPolicy Bypass -File scripts/start.ps1 -JavaHome 'C:\Java\jdk8' -Config config/demo.properties
```

Linux：

```sh
export JAVA_HOME=/opt/jdk8
sh scripts/build.sh
sh scripts/start.sh config/demo.properties
```

源码包用于编译；运行包已包含 JAR，可直接启动，无需运行构建脚本：

```sh
java -jar target/agent-jdk8-1.0.0.jar config/demo.properties
```

访问 `http://127.0.0.1:8088/`。演示模式限定监听回环地址，不需要令牌；默认模型为明确标识的 **offline mock**，方便先验证接口和权限流程。它不会生成真实智能回答。

控制台输入以下内容，可完整体验“模型请求工具 → 等待确认 → 写入 → 返回结果”：

```text
/tool files_write {"path":"hello.txt","content":"你好，Java 8"}
```

点击允许后，可再测试：

```text
/tool files_read {"path":"hello.txt"}
```

## 2. 接入公司模型和身份

使用 `config/application.properties`，默认启用令牌认证。令牌由部署环境提供，不写入配置、提示词或日志。

```powershell
$env:AGENT_API_TOKEN = [guid]::NewGuid().ToString('N')
$env:AGENT_MODEL_KEY = '公司模型访问密钥'
```

在配置中设置：

```properties
model.provider=chat-completions
model.endpoint=https://company-model.example/v1/chat/completions
model.name=your-model
model.apiKeyEnv=AGENT_MODEL_KEY
```

启动时改为 `config/application.properties`。请求使用 `Authorization: Bearer <AGENT_API_TOKEN>`。默认用户及权限见 `config/users.json`；可增加多个用户，每个用户绑定独立的环境变量令牌。

真实模型需要兼容 Chat Completions 的消息、工具调用和 usage 格式。当前适配器采用完整响应；网页事件流展示运行与工具进度，不是模型逐字输出。公司 IAM、其他模型协议可通过 SPI 接入。

服务默认只监听 `127.0.0.1`。提供给其他机器时配置监听地址、`server.allowedHosts`、`server.allowedOrigins`，并通过公司 HTTPS 网关接入。生产环境使用公司维护的 JDK 8 补丁版本。

## 3. 从通用角色升级到专用角色

`config/profiles.json` 提供 `general`、`document-review`、`python-demo` 三个示例。

角色支持 `extends`，可调整系统提示词、工具白名单、技能、模型名、temperature、上下文与运行限额。最终能力始终为 **用户权限 ∩ 角色工具白名单 ∩ 文本技能的 allowed-tools ∩ 策略插件**。

进一步定制无需修改 Agent 循环。`examples/extension/` 是可编译的企业质量审查插件；详见 [扩展接口](docs/extensions.md)。

## 4. 本地技能与 MCP

将技能放到 `skills/<目录>/SKILL.md`，修改配置后重启加载。文本技能只作为指令和资源；脚本技能的入口必须显式声明 `type: script`、`runtime`、`entrypoint`。核心不会执行 Markdown 中的代码块。

脚本默认禁用。要启用：

1. 将 `config/processes.json` 中所需运行时的可执行文件路径改为本机实际绝对路径。
2. 配置 `process.enabled=true`，并只给需要的角色和用户开放对应技能工具。
3. 选择 `python-demo`，输入 `/tool skill_json_echo_run {"text":"你好"}`，审核 HIGH 风险提示后确认。

Java 8 不支持直接 `java Xxx.java`，Java 配置采用 `javac` 编译后启动新 JVM；C++ 使用部署配置中的编译步骤生成本机程序。Bash 在 Windows 需要单独部署 Bash。脚本、解释器依赖和编译工具链仍由部署者管理。

MCP 配置见 `examples/mcp.json`。需要明确列出服务器允许暴露的工具及其 `READ` / `WRITE` / `HIGH` 风险，不能依赖远端工具自行声明权限。stdio 使用 `processes.json` 中的命令配置。详见 [架构与边界](docs/architecture.md)。

## 5. 文档与 API

用户可通过 `POST /api/files` 上传文本或 Base64 编码的文件，文件存放在自己的工作区。`documents_extract` 支持 UTF-8 文本和 DOCX 正文；禁止外部 XML 实体，限制 ZIP 膨胀。PDF、OCR、旧版 DOC 需通过工具插件或 MCP 接入。

完整请求示例和权限表见 [HTTP API](docs/api.md)。运行记录、事件、确认、会话及消息保存在 `data/store/state.json`；服务拒绝多个进程同时使用同一数据目录。

## 6. 验证与交付

- `scripts/build.ps1` / `scripts/build.sh`：编译、执行契约测试、生成可运行 JAR。
- `scripts/build-extension.ps1` / `.sh`：构建可选的企业插件示例。
- `scripts/smoke.py --java-home <JDK路径>`：用独立 JVM 验证成品 JAR、实际 Python/Java 技能和插件加载，需要 Python 3。
- `scripts/package.py`：生成源码包、运行包和 SHA-256 校验文件，需要 Python 3。
- Windows / Linux JDK 8 CI 矩阵已配置；本次实际测试环境和未验证项见 [验证记录](docs/verification.md)。

**沙箱边界：** 内置文件工具有路径与配额约束；脚本有独立工作目录、环境清理、并发/时长/输出限额，但仍继承服务账户的系统权限。默认执行器不承诺阻止网络访问、限制全部磁盘/CPU/内存，或回收脱离父进程的子孙进程。需要强隔离时接入 `ProcessLauncher`，并开启 `process.requireOsIsolation=true`，缺少合格适配器会拒绝启动。
