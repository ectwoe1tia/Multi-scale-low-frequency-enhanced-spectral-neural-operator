package io.yunfan.agent;

import io.yunfan.agent.Extensions.*;
import java.util.*;

public final class Builtins {
    private Builtins(){}
    public abstract static class Basic implements Tool {
        private final String name,description;private final Risk risk;private final Map<String,Object> schema;
        public Basic(String name,String description,Risk risk,Map<String,Object> schema){this.name=name;this.description=description;this.risk=risk;this.schema=schema;}
        public String name(){return name;}public String description(){return description;}public Risk risk(){return risk;}public Map<String,Object> schema(){return schema;}
    }
    public static List<Tool> create(){return Arrays.<Tool>asList(
        new Basic("time_now","Get current UTC time",Risk.READ,Schema.object(Json.map())){public Object execute(ToolContext c,Map<String,Object> a){return Json.map("utc",Util.now());}},
        new Basic("files_list","List files in your private workspace",Risk.READ,Schema.object(Json.map())){public Object execute(ToolContext c,Map<String,Object> a)throws Exception{return c.files.list();}},
        new Basic("files_read","Read a UTF-8 text document, up to 1 MiB",Risk.READ,Schema.object(Json.map("path",Schema.string(240)),"path")){public Object execute(ToolContext c,Map<String,Object> a)throws Exception{return Json.map("text",c.files.read(Json.required(a,"path")));}},
        new Basic("documents_extract","Extract text from a workspace text file or DOCX document",Risk.READ,Schema.object(Json.map("path",Schema.string(240)),"path")){public Object execute(ToolContext c,Map<String,Object> a)throws Exception{return Documents.extract(c.files,Json.required(a,"path"));}},
        new Basic("files_write","Write a UTF-8 document in your workspace; requires confirmation",Risk.WRITE,Schema.object(Json.map("path",Schema.string(240),"content",Schema.string(1024*1024)),"path","content")){public Object execute(ToolContext c,Map<String,Object> a)throws Exception{c.files.write(Json.required(a,"path"),Json.str(a,"content",""));return Json.map("written",a.get("path"));}},
        new Basic("text_analyze","Count lines and words in supplied text without launching a process",Risk.READ,Schema.object(Json.map("text",Schema.string(64000)),"text")){public Object execute(ToolContext c,Map<String,Object> a){String text=Json.str(a,"text","");return Json.map("characters",text.length(),"lines",text.isEmpty()?0:text.split("\\r?\\n",-1).length,"words",text.trim().isEmpty()?0:text.trim().split("\\s+").length);}}
    );}
}
