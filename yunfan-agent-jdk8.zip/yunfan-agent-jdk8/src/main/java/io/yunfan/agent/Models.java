package io.yunfan.agent;

import io.yunfan.agent.Extensions.*;
import java.util.*;
import java.util.function.BooleanSupplier;

public final class Models {
    private Models(){}
    public static Model create(Settings settings,Net net){
        String provider=settings.get("model.provider","mock");
        if(provider.equals("mock"))return new Mock();
        Fault.require(provider.equals("chat-completions"),"Unknown model provider");
        final String endpoint=settings.get("model.endpoint","");Fault.require(!endpoint.isEmpty(),"model.endpoint is required");
        final String token=settings.secret("model.apiKeyEnv");
        return (messages,tools,profile,cancelled)->{
            Map<String,Object> request=Json.map("model",Json.str(profile,"model",settings.get("model.name","")),"messages",messages,"stream",false,"max_tokens",Json.integer(profile,"maxOutputTokens",1024),"temperature",profile.get("temperature"));
            if(!tools.isEmpty()){request.put("tools",tools);request.put("tool_choice","auto");}
            Map<String,String> headers=new HashMap<String,String>();headers.put("Accept","application/json");if(!token.isEmpty())headers.put("Authorization","Bearer "+token);
            Map<String,Object> response=Json.obj(net.post(endpoint,headers,request,settings.integer("model.timeoutMs",60000,100,180000),cancelled,null).body);
            List<Object> choices=Json.list(response,"choices");Fault.require(!choices.isEmpty(),"Model returned no choices");
            Map<String,Object> answer=Json.child(Json.obj(choices.get(0)),"message");return Json.map("message",answer,"usage",Json.child(response,"usage"));
        };
    }
    /** Explicit offline test model. /tool NAME {json} exercises the complete permission/approval path. */
    public static final class Mock implements Model {
        public Map<String,Object> complete(List<Object> messages,List<Object> tools,Map<String,Object> profile,BooleanSupplier cancelled){
            Map<String,Object> last=Json.obj(messages.get(messages.size()-1));String role=Json.str(last,"role","");String content=Json.str(last,"content","");
            if(role.equals("tool"))return Json.map("message",Json.map("role","assistant","content","Tool result: "+content),"usage",Json.map("total_tokens",32));
            if(content.startsWith("/tool ")){String[] parts=content.substring(6).split(" ",2);Fault.require(parts.length==2,"Usage: /tool NAME {json}");Json.obj(Json.parse(parts[1]));
                return Json.map("message",Json.map("role","assistant","content",null,"tool_calls",Arrays.asList(Json.map("id",Util.id(),"type","function","function",Json.map("name",parts[0],"arguments",parts[1])))),"usage",Json.map("total_tokens",32));}
            return Json.map("message",Json.map("role","assistant","content","[offline mock] "+content),"usage",Json.map("total_tokens",16));
        }
    }
}
