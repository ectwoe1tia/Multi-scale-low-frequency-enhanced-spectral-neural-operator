package io.yunfan.agent;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final class Util {
    private Util(){}
    public static byte[] bytes(String s){return s.getBytes(StandardCharsets.UTF_8);}
    public static String utf8(byte[] b){return new String(b,StandardCharsets.UTF_8);}
    public static String now(){return Instant.now().toString();}
    public static String id(){return UUID.randomUUID().toString();}
    public static byte[] read(InputStream in,int limit) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;
        while((n=in.read(b))!=-1){if(out.size()+n>limit)throw new IOException("Input limit exceeded");out.write(b,0,n);}return out.toByteArray();
    }
    public static String file(Path p,int limit) throws IOException {try(InputStream in=Files.newInputStream(p)){return utf8(read(in,limit));}}
    public static String hash(String s){try{byte[] h=MessageDigest.getInstance("SHA-256").digest(bytes(s));StringBuilder b=new StringBuilder();for(byte v:h)b.append(String.format("%02x",v&255));return b.toString();}catch(Exception e){throw new IllegalStateException(e);}}
    public static String canonical(Object value){
        if(value instanceof Map){Map<String,Object> sorted=new TreeMap<String,Object>();for(Map.Entry<String,Object> e:Json.obj(value).entrySet())sorted.put(e.getKey(),canonicalValue(e.getValue()));return Json.write(sorted);}
        return Json.write(canonicalValue(value));
    }
    private static Object canonicalValue(Object v){if(v instanceof Map)return Json.parse(canonical(v));if(v instanceof List){List<Object> a=new ArrayList<Object>();for(Object x:Json.arr(v))a.add(canonicalValue(x));return a;}return v;}
    public static void atomic(Path target,byte[] b) throws IOException {
        Files.createDirectories(target.toAbsolutePath().getParent());Path tmp=Files.createTempFile(target.getParent(),".pending-",".tmp");
        try{try(FileOutputStream out=new FileOutputStream(tmp.toFile())){out.write(b);out.getFD().sync();}
            try{Files.move(tmp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException e){throw new IOException("Atomic replacement is required for this filesystem",e);}
        }finally{Files.deleteIfExists(tmp);}
    }
    public static ThreadFactory threads(final String name){return new ThreadFactory(){final AtomicInteger n=new AtomicInteger();public Thread newThread(Runnable r){Thread t=new Thread(r,name+"-"+n.incrementAndGet());t.setDaemon(true);return t;}};}
    public static boolean matches(Collection<String> rules,String name){for(String s:rules)if(s.equals("*")||s.equals(name)||s.endsWith("*")&&name.startsWith(s.substring(0,s.length()-1)))return true;return false;}
}
