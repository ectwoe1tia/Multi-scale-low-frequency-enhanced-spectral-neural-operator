package io.yunfan.agent;

public final class Fault extends RuntimeException {
    public final int status;
    public final String code;
    public Fault(int status, String code, String message) { super(message); this.status=status; this.code=code; }
    public static Fault bad(String message) { return new Fault(400,"INVALID_REQUEST",message); }
    public static Fault forbidden(String message) { return new Fault(403,"FORBIDDEN",message); }
    public static void require(boolean condition, String message) { if(!condition) throw bad(message); }
}
