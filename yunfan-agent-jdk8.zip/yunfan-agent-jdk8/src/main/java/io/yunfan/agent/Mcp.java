package io.yunfan.agent;

import io.yunfan.agent.Extensions.*;
import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BooleanSupplier;

/** MCP tools client: stdio and Streamable HTTP. A connection belongs to exactly one run. */
public final class Mcp {
    public static final String VERSION="2025-11-25";
    private static final List<String> VERSIONS=Arrays.asList(VERSION,"2025-06-18","2025-03-26");
    private final List<Object> servers;
    private final Processes processes;private final Net net;private final Security security;
    public Mcp(Settings settings,Processes processes,Net net,Security security)throws Exception{
        this.servers=Json.arr(settings.json("mcp.servers","config/mcp.json"));this.processes=processes;this.net=net;this.security=security;
        Set<String> ids=new HashSet<String>();for(Object o:servers){Map<String,Object> s=Json.obj(o);String id=Json.required(s,"id");
            Fault.require(id.matches("[a-zA-Z0-9_-]{1,24}")&&ids.add(id),"Invalid or duplicate MCP server ID");
            String transport=Json.str(s,"transport","http");Fault.require(transport.equals("http")||transport.equals("stdio"),"Unsupported MCP transport");
            Fault.require(!Json.child(s,"tools").isEmpty(),"MCP requires an explicit tool allowlist and risk mapping");
            for(Object risk:Json.child(s,"tools").values())Risk.valueOf(risk.toString());
        }
    }
    public Scope open(Identity actor,List<String> allowed,BooleanSupplier cancelled)throws Exception{
        Scope scope=new Scope();try{
            for(Object raw:servers){Map<String,Object> config=Json.obj(raw);if(!Json.bool(config,"enabled",true))continue;
                String prefix=Json.required(config,"id")+"__";Map<String,Object> policy=Json.child(config,"tools");boolean needed=false;
                for(String name:policy.keySet())if(Util.matches(allowed,prefix+name)&&security.permits(actor,"tool:"+prefix+name,config))needed=true;
                if(!needed)continue;
                Channel channel=Json.str(config,"transport","http").equals("stdio")?new Stdio(config,cancelled):new Http(config,cancelled);
                scope.channels.add(channel);
                Map<String,Object> init=channel.call("initialize",Json.map("protocolVersion",VERSION,"capabilities",Json.map(),"clientInfo",Json.map("name","yunfan-agent-jdk8","version","1.0.0")));
                String selected=Json.required(init,"protocolVersion");Fault.require(VERSIONS.contains(selected),"Unsupported negotiated MCP version");channel.version(selected);
                channel.notify("notifications/initialized",Json.map());
                List<Tool> discovered=new ArrayList<Tool>();String cursor=null;Set<String> cursors=new HashSet<String>(),names=new HashSet<String>();
                int pages=0,count=0;
                do{
                    if(++pages>50)throw Fault.bad("MCP pagination limit");Map<String,Object> page=channel.call("tools/list",cursor==null?Json.map():Json.map("cursor",cursor));
                    for(Object item:Json.list(page,"tools")){if(++count>500)throw Fault.bad("MCP tool count limit");Map<String,Object> spec=Json.obj(item);String remote=Json.required(spec,"name");
                        Fault.require(names.add(remote),"Duplicate MCP tool");String name=prefix+remote;
                        if(!policy.containsKey(remote)||!Util.matches(allowed,name)||!security.permits(actor,"tool:"+name,config))continue;
                        Fault.require(name.matches("[A-Za-z0-9_-]{1,64}"),"MCP tool alias must fit 64 ASCII characters");
                        Map<String,Object> schema=Json.child(spec,"inputSchema");Schema.supported(schema);
                        final Risk risk=Risk.valueOf(policy.get(remote).toString());final String description=Json.str(spec,"description",remote);
                        discovered.add(new Tool(){public String name(){return name;}public String description(){return description;}public Risk risk(){return risk;}public Map<String,Object> schema(){return schema;}
                            public Object execute(ToolContext context,Map<String,Object> args)throws Exception{
                                return channel.call("tools/call",Json.map("name",remote,"arguments",args,"_meta",Json.map("yunfan/invocationId",context.invocationId)));
                            }});
                    }
                    cursor=Json.str(page,"nextCursor",null);if(cursor!=null)Fault.require(cursors.add(cursor),"Repeated MCP cursor");
                }while(cursor!=null);
                scope.tools.addAll(discovered);
            }return scope;
        }catch(Exception e){scope.close();throw e;}
    }
    public final class Scope implements AutoCloseable {
        public final List<Tool> tools=new ArrayList<Tool>();private final List<Channel> channels=new ArrayList<Channel>();
        public void close(){for(Channel c:channels)try{c.close();}catch(Exception ignored){}}
    }
    private interface Channel extends AutoCloseable {Map<String,Object> call(String method,Map<String,Object> params)throws Exception;void notify(String method,Map<String,Object> params)throws Exception;void version(String value);}
    private static Map<String,Object> checked(Object raw,String id){Map<String,Object> m=Json.obj(raw);
        Fault.require("2.0".equals(m.get("jsonrpc"))&&id.equals(String.valueOf(m.get("id"))),"MCP response ID mismatch");
        if(m.containsKey("error"))throw new Fault(502,"MCP_ERROR","MCP server returned an RPC error");
        return Json.obj(m.get("result"));
    }
    private final class Http implements Channel {
        final Map<String,Object> config;final BooleanSupplier cancelled;String version=VERSION,session;final String endpoint,token;
        Http(Map<String,Object> config,BooleanSupplier cancelled){this.config=config;this.cancelled=cancelled;endpoint=Json.required(config,"endpoint");
            String ref=Json.str(config,"tokenEnv","");token=ref.isEmpty()?"":System.getenv(ref);Fault.require(token!=null,"Missing MCP token environment variable");}
        public void version(String value){version=value;}
        private Net.Response send(Object message,Object expected)throws Exception{Map<String,String> h=new HashMap<String,String>();h.put("Accept","application/json, text/event-stream");h.put("MCP-Protocol-Version",version);
            if(session!=null)h.put("Mcp-Session-Id",session);if(!token.isEmpty())h.put("Authorization","Bearer "+token);
            return net.post(endpoint,h,message,Math.max(100,Math.min(120000,Json.integer(config,"timeoutMs",30000))),cancelled,expected);}
        public synchronized Map<String,Object> call(String method,Map<String,Object> params)throws Exception{
            String id=Util.id();Net.Response r=send(Json.map("jsonrpc","2.0","id",id,"method",method,"params",params),id);
            if(method.equals("initialize")){session=r.header("Mcp-Session-Id");if(session!=null)Fault.require(session.matches("[\\x21-\\x7E]{1,256}"),"Invalid MCP session header");}
            return checked(r.body,id);
        }
        public synchronized void notify(String method,Map<String,Object> params)throws Exception{send(Json.map("jsonrpc","2.0","method",method,"params",params),null);}
        public void close(){} // Session termination is optional; no retry/replay after ambiguous network failure.
    }
    private final class Stdio implements Channel {
        final Processes.Managed child;final BooleanSupplier cancelled;final int timeout;final BlockingQueue<Object> queue=new ArrayBlockingQueue<Object>(64);
        final OutputStream output;volatile boolean broken;
        Stdio(Map<String,Object> config,BooleanSupplier cancelled)throws Exception{
            this.cancelled=cancelled;timeout=Math.max(100,Math.min(120000,Json.integer(config,"timeoutMs",30000)));
            Path work=processes.job();child=processes.start(Json.required(config,"profile"),work,"",600000,cancelled);output=child.process.getOutputStream();
            processes.io.submit(()->{try{InputStream in=child.process.getInputStream();ByteArrayOutputStream frame=new ByteArrayOutputStream();int b;
                while((b=in.read())!=-1){if(b=='\n'){Object message=Json.parse(Util.utf8(frame.toByteArray()));frame.reset();if(!queue.offer(message))throw new IOException("MCP receive queue full");}
                    else{if(frame.size()>=1024*1024)throw new IOException("MCP frame too large");frame.write(b);}}
                throw new EOFException("MCP process exited");
            }catch(Exception e){broken=true;queue.offer(e);child.close();}});
        }
        public void version(String value){}
        private synchronized void write(Object object)throws IOException{if(broken)throw new IOException("MCP channel closed");output.write(Util.bytes(Json.write(object)+"\n"));output.flush();}
        public synchronized Map<String,Object> call(String method,Map<String,Object> params)throws Exception{
            String id=Util.id();long deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(timeout);
            // The writer must not acquire the channel monitor held by call().
            Future<?> writer=processes.io.submit(()->{try{output.write(Util.bytes(Json.write(Json.map("jsonrpc","2.0","id",id,"method",method,"params",params))+"\n"));output.flush();}catch(IOException e){throw new UncheckedIOException(e);}});
            try{writer.get(timeout,TimeUnit.MILLISECONDS);
                while(System.nanoTime()<deadline&&!cancelled.getAsBoolean()){
                    Object raw=queue.poll(100,TimeUnit.MILLISECONDS);if(raw==null){if(broken)throw new IOException("MCP channel closed");continue;}if(raw instanceof Exception)throw (Exception)raw;
                    Map<String,Object> m=Json.obj(raw);
                    if(m.containsKey("method")){
                        if(m.containsKey("id"))write("ping".equals(m.get("method"))?Json.map("jsonrpc","2.0","id",m.get("id"),"result",Json.map()):Json.map("jsonrpc","2.0","id",m.get("id"),"error",Json.map("code",-32601,"message","Client method not supported")));
                        continue;
                    }
                    return checked(m,id);
                }throw new IOException("MCP request cancelled or timed out");
            }catch(Exception e){close();throw e;}finally{writer.cancel(true);}
        }
        public void notify(String method,Map<String,Object> params)throws Exception{write(Json.map("jsonrpc","2.0","method",method,"params",params));}
        public void close(){broken=true;child.close();}
    }
}
