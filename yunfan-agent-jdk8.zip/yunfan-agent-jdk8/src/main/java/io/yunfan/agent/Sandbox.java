package io.yunfan.agent;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

/** Path and quota enforcement for built-in file tools. Not an OS sandbox for native programs. */
public final class Sandbox {
    private final Path root;
    private final long quota;
    public Sandbox(Path root,long quota) throws IOException {Files.createDirectories(root);this.root=root.toRealPath();this.quota=quota;}
    public Path root(){return root;}
    public static void portable(String name){
        Fault.require(name!=null&&!name.isEmpty()&&name.length()<=240&&!name.startsWith("/")&&!name.contains("\\"),"Use a relative portable path with / separators");
        for(String c:name.split("/",-1)){
            Fault.require(!c.isEmpty()&&!c.equals(".")&&!c.equals("..")&&!c.endsWith(".")&&!c.endsWith(" ")&&!c.matches(".*[<>:\"|?*\\p{Cntrl}].*"),"Invalid path component");
            String base=c.split("\\.",2)[0].toUpperCase(Locale.ROOT);
            Fault.require(!base.matches("CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]"),"Reserved Windows path component");
        }
    }
    public Path resolve(String name) throws IOException {
        portable(name);Path p=root;
        for(String c:name.split("/")){p=p.resolve(c);
            if(Files.isSymbolicLink(p))throw Fault.forbidden("Symbolic links are not allowed");
            if(Files.exists(p,LinkOption.NOFOLLOW_LINKS)&&!p.toRealPath().startsWith(root))throw Fault.forbidden("Path escapes workspace");
        }
        if(!p.normalize().startsWith(root))throw Fault.forbidden("Path escapes workspace");return p;
    }
    public String read(String name) throws IOException {Path p=resolve(name);if(!Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS))throw new Fault(404,"NOT_FOUND","File not found");return Util.file(p,1024*1024);}
    public synchronized void write(String name,String content) throws IOException {writeBytes(name,Util.bytes(content));}
    public synchronized void writeBytes(String name,byte[] bytes) throws IOException {
        Fault.require(bytes.length<=1024*1024,"File exceeds 1 MiB");Path p=resolve(name);
        final long[] total={0};Files.walkFileTree(root,new SimpleFileVisitor<Path>(){
            @Override public FileVisitResult preVisitDirectory(Path dir,BasicFileAttributes a)throws IOException{verify(dir);return FileVisitResult.CONTINUE;}
            @Override public FileVisitResult visitFile(Path f,BasicFileAttributes a)throws IOException{
            verify(f);total[0]+=a.size();if(total[0]>quota)throw new IOException("Workspace quota exceeded");return FileVisitResult.CONTINUE;}});
        long old=Files.exists(p)?Files.size(p):0;Fault.require(total[0]-old+bytes.length<=quota,"Workspace quota exceeded");
        Files.createDirectories(p.getParent());resolve(name);Util.atomic(p,bytes);
    }
    public List<Object> list() throws IOException {
        final List<Object> files=new ArrayList<Object>();Files.walkFileTree(root,EnumSet.noneOf(FileVisitOption.class),8,new SimpleFileVisitor<Path>(){
            @Override public FileVisitResult preVisitDirectory(Path dir,BasicFileAttributes a)throws IOException{verify(dir);return FileVisitResult.CONTINUE;}
            @Override public FileVisitResult visitFile(Path p,BasicFileAttributes a)throws IOException{verify(p);if(files.size()>=500)return FileVisitResult.TERMINATE;
                if(a.isRegularFile())files.add(Json.map("path",root.relativize(p).toString().replace('\\','/'),"bytes",a.size()));return FileVisitResult.CONTINUE;}});return files;
    }
    private void verify(Path path)throws IOException{if(Files.isSymbolicLink(path)||!path.toRealPath().startsWith(root))throw Fault.forbidden("Workspace link escapes or symbolic links are not allowed");}
}
