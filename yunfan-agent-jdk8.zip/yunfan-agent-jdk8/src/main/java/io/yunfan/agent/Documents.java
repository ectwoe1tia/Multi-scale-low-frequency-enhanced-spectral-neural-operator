package io.yunfan.agent;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

/** Local text/DOCX extraction with bounded ZIP inflation and no external XML entities. */
public final class Documents {
    private Documents(){}
    public static Map<String,Object> extract(Sandbox files,String name)throws Exception{
        Path path=files.resolve(name);String lower=name.toLowerCase(Locale.ROOT);
        if(!lower.endsWith(".docx")){
            Fault.require(lower.matches(".*\\.(txt|md|csv|json|xml|log)$"),"Supported documents: UTF-8 text, Markdown, CSV, JSON, XML, log, DOCX");
            return Json.map("path",name,"format","text","text",files.read(name));
        }
        Fault.require(Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS)&&Files.size(path)<=1024*1024,"DOCX compressed size limit is 1 MiB");
        byte[] document=null;long total=0;int count=0;Set<String> names=new HashSet<String>();
        try(ZipInputStream zip=new ZipInputStream(Files.newInputStream(path))){ZipEntry entry;while((entry=zip.getNextEntry())!=null){
            Fault.require(++count<=256&&names.add(entry.getName()),"DOCX entry limit or duplicate ZIP entry");
            if(entry.isDirectory())continue;byte[] bytes=Util.read(zip,4*1024*1024);total+=bytes.length;Fault.require(total<=16*1024*1024,"DOCX expansion limit exceeded");
            if(entry.getName().equals("word/document.xml"))document=bytes;
        }}
        Fault.require(document!=null,"DOCX main document not found");
        SAXParserFactory factory=SAXParserFactory.newInstance();factory.setNamespaceAware(true);factory.setXIncludeAware(false);
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities",false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd",false);
        final StringBuilder text=new StringBuilder();final String word="http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        factory.newSAXParser().parse(new ByteArrayInputStream(document),new DefaultHandler(){boolean inside;
            @Override public void startElement(String uri,String local,String qName,Attributes attributes)throws SAXException{if(!word.equals(uri))return;if(local.equals("t"))inside=true;if(local.equals("tab"))text.append('\t');if(local.equals("br"))text.append('\n');limit();}
            @Override public void characters(char[] chars,int start,int length)throws SAXException{if(inside)text.append(chars,start,length);limit();}
            @Override public void endElement(String uri,String local,String qName)throws SAXException{if(!word.equals(uri))return;if(local.equals("t"))inside=false;if(local.equals("p"))text.append('\n');limit();}
            void limit()throws SAXException{if(text.length()>1024*1024)throw new SAXException("Extracted document too large");}
            @Override public InputSource resolveEntity(String publicId,String systemId)throws SAXException{throw new SAXException("External entities forbidden");}
        });
        return Json.map("path",name,"format","docx","text",text.toString(),"scope","Main document paragraphs and tables; no OCR, headers, footnotes or layout reconstruction");
    }
}
