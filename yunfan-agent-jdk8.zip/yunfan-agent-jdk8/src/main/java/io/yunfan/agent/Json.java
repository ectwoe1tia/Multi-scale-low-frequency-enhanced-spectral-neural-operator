package io.yunfan.agent;

import java.math.BigDecimal;
import java.util.*;

/** Bounded JSON codec. Duplicate keys and trailing input are rejected. */
public final class Json {
    private Json() {}
    public static Object parse(String text) { return new Parser(text).parse(); }
    @SuppressWarnings("unchecked") public static Map<String,Object> obj(Object value) {
        if(!(value instanceof Map)) throw Fault.bad("Expected JSON object");
        return (Map<String,Object>)value;
    }
    @SuppressWarnings("unchecked") public static List<Object> arr(Object value) {
        if(!(value instanceof List)) throw Fault.bad("Expected JSON array");
        return (List<Object>)value;
    }
    public static Map<String,Object> map(Object... pairs) {
        Map<String,Object> out=new LinkedHashMap<String,Object>();
        for(int i=0;i<pairs.length;i+=2)out.put((String)pairs[i],pairs[i+1]);
        return out;
    }
    public static String str(Map<String,Object> m,String key,String fallback) {
        Object v=m.get(key); if(v==null)return fallback;
        if(!(v instanceof String))throw Fault.bad(key+" must be a string"); return (String)v;
    }
    public static String required(Map<String,Object> m,String key) {
        String s=str(m,key,"").trim(); Fault.require(!s.isEmpty(),key+" is required"); return s;
    }
    public static int integer(Map<String,Object> m,String key,int fallback) {
        if(!m.containsKey(key))return fallback;
        try { return new BigDecimal(m.get(key).toString()).intValueExact(); }
        catch(Exception e){throw Fault.bad(key+" must be integer");}
    }
    public static boolean bool(Map<String,Object> m,String key,boolean fallback) {
        if(!m.containsKey(key))return fallback;
        if(!(m.get(key) instanceof Boolean))throw Fault.bad(key+" must be boolean"); return (Boolean)m.get(key);
    }
    public static Map<String,Object> child(Map<String,Object> m,String key){return m.get(key)==null?map():obj(m.get(key));}
    public static List<Object> list(Map<String,Object> m,String key){return m.get(key)==null?new ArrayList<Object>():arr(m.get(key));}
    public static List<String> strings(Object value) {
        List<String> out=new ArrayList<String>(); if(value==null)return out;
        for(Object o:arr(value)){if(!(o instanceof String))throw Fault.bad("Expected string array");out.add((String)o);} return out;
    }
    public static Object copy(Object o){return parse(write(o));}
    public static String write(Object o){StringBuilder b=new StringBuilder();encode(o,b);return b.toString();}
    private static void encode(Object o,StringBuilder b) {
        if(o==null){b.append("null");return;}
        if(o instanceof String||o instanceof Enum){quote(o.toString(),b);return;}
        if(o instanceof Boolean){b.append(o);return;}
        if(o instanceof Number){String n=o.toString();new BigDecimal(n);b.append(n);return;}
        if(o instanceof Map){b.append('{');boolean comma=false;for(Map.Entry<?,?> e:((Map<?,?>)o).entrySet()){
            if(comma)b.append(',');quote(e.getKey().toString(),b);b.append(':');encode(e.getValue(),b);comma=true;}b.append('}');return;}
        if(o instanceof Iterable){b.append('[');boolean comma=false;for(Object v:(Iterable<?>)o){if(comma)b.append(',');encode(v,b);comma=true;}b.append(']');return;}
        throw new IllegalArgumentException("Unsupported JSON value: "+o.getClass());
    }
    private static void quote(String s,StringBuilder b){b.append('"');for(int i=0;i<s.length();i++){char c=s.charAt(i);switch(c){
        case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\n':b.append("\\n");break;
        case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;
        default:if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);
    }}b.append('"');}
    private static final class Parser {
        final String s;int p,depth;
        Parser(String s){this.s=Objects.requireNonNull(s);Fault.require(s.length()<=32*1024*1024,"JSON too large");}
        Object parse(){Object v=value();ws();if(p!=s.length())fail();return v;}
        void ws(){while(p<s.length()&&" \r\n\t".indexOf(s.charAt(p))>=0)p++;}
        void fail(){throw Fault.bad("Malformed JSON at "+p);}
        boolean take(char c){if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
        Object value(){ws();if(++depth>64)throw Fault.bad("JSON nesting limit");try{
            if(p==s.length())fail();char c=s.charAt(p);if(c=='"')return string();if(c=='{')return object();if(c=='[')return array();
            for(String l:Arrays.asList("true","false","null"))if(s.startsWith(l,p)){p+=l.length();return l.equals("null")?null:l.equals("true");}
            int start=p;take('-');if(!take('0')){if(p==s.length()||s.charAt(p)<'1'||s.charAt(p)>'9')fail();digits();}
            if(take('.'))digits();if(take('e')||take('E')){if(!take('+'))take('-');digits();}
            try{return new BigDecimal(s.substring(start,p));}catch(NumberFormatException e){fail();return null;}
        }finally{depth--;}}
        void digits(){int start=p;while(p<s.length()&&s.charAt(p)>='0'&&s.charAt(p)<='9')p++;if(start==p)fail();}
        String string(){p++;StringBuilder b=new StringBuilder();while(p<s.length()){char c=s.charAt(p++);if(c=='"')return b.toString();if(c<32)fail();
            if(c=='\\'){if(p==s.length())fail();char e=s.charAt(p++);switch(e){case '"':case '\\':case '/':b.append(e);break;
                case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;
                case 'u':if(p+4>s.length())fail();try{b.append((char)Integer.parseInt(s.substring(p,p+4),16));}catch(Exception x){fail();}p+=4;break;default:fail();}
            }else b.append(c);
        }fail();return null;}
        Map<String,Object> object(){p++;Map<String,Object> m=map();ws();if(take('}'))return m;do{ws();if(p==s.length()||s.charAt(p)!='"')fail();String k=string();ws();
            if(!take(':')||m.containsKey(k))fail();m.put(k,value());ws();if(take('}'))return m;
        }while(take(','));fail();return m;}
        List<Object> array(){p++;List<Object> a=new ArrayList<Object>();ws();if(take(']'))return a;do{a.add(value());ws();if(take(']'))return a;}while(take(','));fail();return a;}
    }
}
