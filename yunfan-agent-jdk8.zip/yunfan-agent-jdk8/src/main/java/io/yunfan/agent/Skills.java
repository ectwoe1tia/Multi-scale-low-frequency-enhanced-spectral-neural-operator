package io.yunfan.agent;

import io.yunfan.agent.Extensions.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Versioned local skill snapshots. The REST API cannot upload executable code. */
public final class Skills {
    public static final class Skill {
        public String id,prompt,version,runtime,entry,type;public int timeout;
        public Map<String,Object> metadata;public final Map<String,byte[]> resources=new LinkedHashMap<String,byte[]>();
    }
    private final Map<String,Skill> skills=new LinkedHashMap<String,Skill>();private final Processes processes;
    public Skills(Settings settings,Processes processes)throws IOException{
        this.processes=processes;Path root=settings.path("skills.dir","skills");Files.createDirectories(root);
        long total=0;try(DirectoryStream<Path> dirs=Files.newDirectoryStream(root)){
            for(Path dir:dirs){if(!Files.isDirectory(dir,LinkOption.NOFOLLOW_LINKS))continue;Fault.require(skills.size()<64,"Too many skills");
                Skill s=load(dir);for(byte[] b:s.resources.values())total+=b.length;Fault.require(total<=16*1024*1024,"Skill repository exceeds 16 MiB");
                Fault.require(!skills.containsKey(s.id),"Duplicate skill name");skills.put(s.id,s);
            }
        }
    }
    public Skill get(String id){Skill s=skills.get(id);if(s==null)throw Fault.bad("Unknown skill: "+id);return s;}
    public List<Object> describe(){List<Object> out=new ArrayList<Object>();for(Skill s:skills.values())out.add(Json.map("id",s.id,"type",s.type,"version",s.version,"description",s.metadata.get("description"),"resources",s.resources.keySet()));return out;}
    public static Map<String,Object> frontmatter(String markdown){
        String text=markdown.replace("\r\n","\n");if(text.startsWith("\uFEFF"))text=text.substring(1);
        Fault.require(text.startsWith("---\n"),"SKILL.md requires YAML frontmatter");int end=text.indexOf("\n---\n",4);if(end<0&&text.endsWith("\n---"))end=text.length()-4;
        Fault.require(end>=0,"Unclosed skill frontmatter");Map<String,Object> m=Json.map();String[] lines=text.substring(4,end).split("\n",-1);
        for(int i=0;i<lines.length;i++){String line=lines[i];if(line.trim().isEmpty()||line.trim().startsWith("#"))continue;
            int colon=line.indexOf(':');Fault.require(colon>0&&!Character.isWhitespace(line.charAt(0)),"Only flat skill metadata is supported");String key=line.substring(0,colon).trim(),v=line.substring(colon+1).trim();
            Fault.require(key.matches("[A-Za-z][A-Za-z0-9_-]*")&&!m.containsKey(key),"Invalid or duplicate skill key");
            if(v.equals("|")||v.equals(">")){StringBuilder b=new StringBuilder();boolean folded=v.equals(">");while(i+1<lines.length&&(lines[i+1].startsWith(" ")||lines[i+1].isEmpty())){String next=lines[++i];if(b.length()>0)b.append(folded?' ':'\n');b.append(next.trim());}m.put(key,b.toString());}
            else if(v.isEmpty()){List<Object> a=new ArrayList<Object>();while(i+1<lines.length&&lines[i+1].trim().startsWith("- "))a.add(scalar(lines[++i].trim().substring(2).trim()));m.put(key,a);}
            else if(v.startsWith("[")){if(v.contains("\"")){m.put(key,Json.arr(Json.parse(v)));}else{Fault.require(v.endsWith("]"),"Invalid metadata list");List<Object> a=new ArrayList<Object>();String inner=v.substring(1,v.length()-1).trim();if(!inner.isEmpty())for(String x:inner.split(","))a.add(scalar(x.trim()));m.put(key,a);}}
            else m.put(key,scalar(v));
        }
        int start=end+4;if(start<text.length()&&text.charAt(start)=='\n')start++;m.put("body",text.substring(start));return m;
    }
    private static String scalar(String v){Fault.require(!v.startsWith("!")&&!v.startsWith("&")&&!v.startsWith("*")&&!v.startsWith("{"),"YAML tags, anchors and nested objects are unsupported");
        if(v.startsWith("\""))return (String)Json.parse(v);if(v.startsWith("'")){Fault.require(v.endsWith("'")&&v.length()>=2,"Invalid quote");return v.substring(1,v.length()-1).replace("''","'");}return v;}
    private Skill load(Path root)throws IOException{
        Skill s=new Skill();Path md=root.resolve("SKILL.md");Fault.require(Files.isRegularFile(md,LinkOption.NOFOLLOW_LINKS),"Missing SKILL.md");
        Map<String,Object> m=frontmatter(Util.file(md,64*1024));s.metadata=m;s.id=Json.required(m,"name");Fault.require(s.id.matches("[a-zA-Z0-9_-]{1,32}"),"Invalid skill name");
        s.type=Json.str(m,"type","text");Fault.require(s.type.equals("text")||s.type.equals("script"),"Skill type must be text or script");
        s.prompt=Json.required(m,"body");s.runtime=Json.str(m,"runtime","");s.entry=Json.str(m,"entrypoint","");s.timeout=Json.integer(m,"timeoutSeconds",30);Fault.require(s.timeout>=1&&s.timeout<=120,"Invalid skill timeout");
        final Set<String> folded=new HashSet<String>();try(java.util.stream.Stream<Path> stream=Files.walk(root,8)){
            Iterator<Path> it=stream.iterator();long total=0;int visited=0;while(it.hasNext()){Path p=it.next();Fault.require(++visited<=256,"Too many skill paths");if(p.equals(root))continue;
                Fault.require(!Files.isSymbolicLink(p)&&p.toRealPath().startsWith(root.toRealPath()),"Skill links are forbidden");if(Files.isDirectory(p,LinkOption.NOFOLLOW_LINKS)){Fault.require(root.relativize(p).getNameCount()<8,"Skill directory nesting limit");continue;}
                String name=root.relativize(p).toString().replace('\\','/');Sandbox.portable(name);Fault.require(folded.add(name.toLowerCase(Locale.ROOT)),"Case-colliding skill paths");
                Fault.require(s.resources.size()<100,"Too many skill files");byte[] data;try(InputStream in=Files.newInputStream(p)){data=Util.read(in,1024*1024);}total+=data.length;Fault.require(total<=4*1024*1024,"Skill exceeds 4 MiB");s.resources.put(name,data);
            }
        }
        Map<String,Object> hashes=Json.map();for(Map.Entry<String,byte[]> e:s.resources.entrySet())hashes.put(e.getKey(),Util.hash(Base64.getEncoder().encodeToString(e.getValue())));s.version=Util.hash(Util.canonical(hashes));
        if(s.type.equals("script")){Fault.require(processes.hasProfile(s.runtime),"Unknown runtime for skill "+s.id);Fault.require(s.resources.containsKey(s.entry),"Missing script entrypoint");}
        return s;
    }
    public List<Tool> tools(List<String> ids){List<Tool> out=new ArrayList<Tool>();for(String id:ids){final Skill s=get(id);
        out.add(new Builtins.Basic("skill_"+id+"_resource","Read a versioned resource from skill "+id,Risk.READ,Schema.object(Json.map("path",Schema.string(240)),"path")){
            public Object execute(ToolContext c,Map<String,Object> args){String path=Json.required(args,"path");Sandbox.portable(path);byte[] b=s.resources.get(path);if(b==null)throw new Fault(404,"NOT_FOUND","Skill resource not found");Fault.require(b.length<=64*1024,"Resource too large for inline text");return Json.map("text",Util.utf8(b),"version",s.version);}});
        if(s.type.equals("script")&&processes.enabled())out.add(new Builtins.Basic("skill_"+id+"_run","Execute local skill "+id+"; may access files/network as the service account",Risk.HIGH,Json.map("type","object")){
            public Object execute(ToolContext c,Map<String,Object> args)throws Exception{Path work=processes.job();for(Map.Entry<String,byte[]> e:s.resources.entrySet()){Path file=work.resolve(e.getKey());Files.createDirectories(file.getParent());Files.write(file,e.getValue(),StandardOpenOption.CREATE_NEW);}
                return processes.script(s.runtime,work,work.resolve(s.entry).toString(),Json.map("arguments",args,"runId",c.runId,"invocationId",c.invocationId,"skillVersion",s.version),s.timeout,c.cancelled);}});
    }return out;}
}
