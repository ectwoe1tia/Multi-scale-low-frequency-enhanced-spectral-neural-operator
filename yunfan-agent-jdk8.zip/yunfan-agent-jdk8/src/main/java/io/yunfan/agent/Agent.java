package io.yunfan.agent;

import io.yunfan.agent.Extensions.*;
import java.io.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Explicit model -> validation -> confirmation -> tool -> model state machine. */
public final class Agent implements AutoCloseable {
    private static final Set<String> TERMINAL=new HashSet<String>(Arrays.asList("COMPLETED","FAILED","CANCELLED","EXPIRED","INTERRUPTED","RECONCILIATION_REQUIRED"));
    private final Settings settings;private final Repository store;private final Security security;private final Profiles profiles;
    private final Skills skills;private final Mcp mcp;private final Model model;private final Registry extensions;
    private final List<Tool> base=new ArrayList<Tool>();private final Map<String,Execution> live=new ConcurrentHashMap<String,Execution>();
    private final Map<String,Sandbox> workspaces=new ConcurrentHashMap<String,Sandbox>();
    private final ThreadPoolExecutor workers;
    private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor(Util.threads("run-watchdog"));
    private volatile boolean closed;
    public Agent(Settings settings,Repository store,Security security,Profiles profiles,Skills skills,Mcp mcp,Model model,Registry extensions){
        this.settings=settings;this.store=store;this.security=security;this.profiles=profiles;this.skills=skills;this.mcp=mcp;this.model=model;this.extensions=extensions;
        base.addAll(Builtins.create());base.addAll(extensions.tools);validateTools(base);
        int count=settings.integer("agent.workers",4,1,32);workers=new ThreadPoolExecutor(count,count,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<Runnable>(32),Util.threads("agent"),new ThreadPoolExecutor.AbortPolicy());
        store.transact(db->{for(Object raw:Json.child(db,"runs").values()){Map<String,Object> r=Json.obj(raw);if(!terminal(Json.str(r,"status",""))){
            Map<String,Object> flight=Json.child(r,"inFlight");r.put("status",!flight.isEmpty()&&!"READ".equals(flight.get("risk"))?"RECONCILIATION_REQUIRED":"INTERRUPTED");r.put("error","Service restarted; execution will not be replayed");r.put("endedAt",Util.now());r.remove("approval");
            for(Object entry:Json.list(r,"context")){Map<String,Object> c=Json.obj(entry);if(!"APPLIED".equals(c.get("status")))c.put("status","RUN_ENDED");}
        }}for(Object s:Json.child(db,"sessions").values())Json.obj(s).remove("activeRun");return null;});
        timer.scheduleWithFixedDelay(()->{for(Execution e:live.values())try{synchronized(e){if(System.currentTimeMillis()>e.deadline&&!terminal(e.status()))e.stop("EXPIRED");}}catch(RuntimeException ignored){}},250,250,TimeUnit.MILLISECONDS);
    }
    public static boolean terminal(String state){return TERMINAL.contains(state);}
    private void validateTools(Collection<Tool> tools){Set<String> names=new HashSet<String>();for(Tool t:tools){Fault.require(t.name().matches("[A-Za-z0-9_-]{1,64}")&&names.add(t.name()),"Duplicate/invalid tool name: "+t.name());Schema.supported(t.schema());}}
    public List<Object> profiles(Identity actor){List<Object> out=new ArrayList<Object>();for(Object raw:profiles.list()){Map<String,Object> p=Json.obj(raw);if(security.permits(actor,"profile:"+p.get("id"),p))out.add(p);}return out;}
    public List<Object> skills(Identity actor){security.require(actor,"skills:read",Json.map());return skills.describe();}
    public Sandbox workspace(Identity actor)throws IOException{
        Sandbox found=workspaces.get(actor.key());if(found!=null)return found;
        synchronized(workspaces){found=workspaces.get(actor.key());if(found==null){found=new Sandbox(settings.path("data.dir","data").resolve("workspaces").resolve(actor.key()),10*1024*1024);workspaces.put(actor.key(),found);}return found;}
    }
    public synchronized Map<String,Object> submit(Identity actor,Map<String,Object> request){
        if(closed)throw new Fault(503,"STOPPING","Service is stopping");security.require(actor,"runs:create",request);
        String requestId=Json.required(request,"requestId"),message=Json.required(request,"message");Fault.require(requestId.length()<=100&&message.length()<=16000,"Run input too large");
        String hash=Util.hash(Util.canonical(request));
        Map<String,Object> duplicate=store.read(db->{for(Object raw:Json.child(db,"runs").values()){Map<String,Object> r=Json.obj(raw);if(actor.key().equals(r.get("owner"))&&requestId.equals(r.get("requestId")))return r;}return null;});
        if(duplicate!=null){if(!hash.equals(duplicate.get("requestHash")))throw new Fault(409,"IDEMPOTENCY_CONFLICT","requestId was already used with different input");return duplicate;}
        if(live.size()>=64)throw new Fault(429,"RUN_LIMIT","Too many active runs");
        Map<String,Object> profile=profiles.get(Json.str(request,"profile","general"));security.require(actor,"profile:"+profile.get("id"),profile);
        String id=Util.id(),requestedSession=Json.str(request,"sessionId",""),session=requestedSession.isEmpty()?Util.id():requestedSession;
        Map<String,Object> run=store.transact(db->{Map<String,Object> runs=Json.child(db,"runs"),sessions=Json.child(db,"sessions");
            if(runs.size()>=1000)throw new Fault(507,"RETENTION_LIMIT","Archive old run data before creating more runs");
            Map<String,Object> s;if(requestedSession.isEmpty()){s=Json.map("id",session,"owner",actor.key(),"messages",new ArrayList<Object>());sessions.put(session,s);}
            else{if(!sessions.containsKey(session))throw new Fault(404,"NOT_FOUND","Session not found");s=Json.obj(sessions.get(session));security.owner(actor,s);if(s.containsKey("activeRun"))throw new Fault(409,"SESSION_BUSY","Session already has an active run");}
            List<Object> messages=new ArrayList<Object>();StringBuilder prompt=new StringBuilder(Json.required(profile,"systemPrompt"));Map<String,Object> versions=Json.map();
            for(String skillId:Json.strings(profile.get("skills"))){Skills.Skill skill=skills.get(skillId);prompt.append("\n\n[Skill ").append(skill.id).append("]\n").append(skill.prompt);versions.put(skill.id,skill.version);}
            messages.add(Json.map("role","system","content",prompt.toString()));messages.addAll(Json.list(s,"messages"));messages.add(Json.map("role","user","content",message));
            Map<String,Object> r=Json.map("id",id,"sessionId",session,"owner",actor.key(),"tenant",actor.tenant,"user",actor.user,"requestId",requestId,"requestHash",hash,"profile",profile,"profileVersion",Util.hash(Util.canonical(profile)),"skillVersions",versions,
                "status","QUEUED","createdAt",Util.now(),"messages",messages,"context",new ArrayList<Object>(),"events",new ArrayList<Object>(),"calls",new ArrayList<Object>(),"rounds",0,"toolCount",0,"tokens",0,"eventSeq",0);
            s.put("activeRun",id);runs.put(id,Json.copy(r));return r;});
        Execution e=new Execution(actor,run);live.put(id,e);synchronized(e){e.event("run.created",Json.map("profile",profile.get("id")));e.save();e.schedule();return e.snapshot();}
    }
    public Map<String,Object> get(Identity actor,String id){security.require(actor,"runs:read",Json.map("id",id));Map<String,Object> r=store.read(db->Json.child(db,"runs").get(id)==null?null:Json.obj(Json.child(db,"runs").get(id)));
        if(r==null)throw new Fault(404,"NOT_FOUND","Run not found");security.owner(actor,r);return r;}
    public List<Object> list(Identity actor){security.require(actor,"runs:read",Json.map());return store.read(db->{List<Object> out=new ArrayList<Object>();for(Object raw:Json.child(db,"runs").values()){Map<String,Object> r=Json.obj(raw);if(actor.key().equals(r.get("owner")))out.add(Json.map("id",r.get("id"),"sessionId",r.get("sessionId"),"status",r.get("status"),"createdAt",r.get("createdAt")));}return out;});}
    private Execution active(Identity actor,String id){get(actor,id);Execution e=live.get(id);if(e==null)throw new Fault(409,"RUN_ENDED","Run is no longer active");return e;}
    public Map<String,Object> cancel(Identity actor,String id){security.require(actor,"runs:cancel",Json.map("id",id));Map<String,Object> r=get(actor,id);Execution e=live.get(id);if(e==null)return r;synchronized(e){e.stop("CANCELLED");return e.snapshot();}}
    public Map<String,Object> append(Identity actor,String id,Map<String,Object> input){security.require(actor,"runs:context",Json.map("id",id));Execution e=active(actor,id);synchronized(e){
        e.ensureActive();String requestId=Json.required(input,"requestId"),text=Json.required(input,"text"),kind=Json.str(input,"kind","MESSAGE");
        Fault.require(requestId.length()<=100&&text.length()<=8000,"Context input too large");Fault.require(kind.equals("MESSAGE")||kind.equals("REMINDER"),"Unknown context kind");
        int repeat=Json.integer(input,"repeat",1);Fault.require(repeat>=1&&repeat<=20&&(kind.equals("REMINDER")||repeat==1),"Invalid reminder repeat count");
        String hash=Util.hash(Util.canonical(input));for(Object raw:Json.list(e.run,"context")){Map<String,Object> c=Json.obj(raw);if(requestId.equals(c.get("requestId"))){if(!hash.equals(c.get("hash")))throw new Fault(409,"IDEMPOTENCY_CONFLICT","Context requestId conflict");return Json.obj(Json.copy(c));}}
        Fault.require(Json.list(e.run,"context").size()<100,"Context queue limit reached");String expires=Json.str(input,"expiresAt",null);if(expires!=null)try{Fault.require(Instant.parse(expires).toEpochMilli()>System.currentTimeMillis(),"Context already expired");}catch(java.time.format.DateTimeParseException x){throw Fault.bad("Invalid expiresAt");}
        Map<String,Object> entry=Json.map("id",Util.id(),"requestId",requestId,"hash",hash,"text",text,"kind",kind,"remaining",repeat,"expiresAt",expires,"status","QUEUED","createdAt",Util.now());
        Json.list(e.run,"context").add(entry);e.event("context.queued",Json.map("id",entry.get("id"),"kind",kind));e.save();return Json.obj(Json.copy(entry));
    }}
    public void removeContext(Identity actor,String id,String contextId){security.require(actor,"runs:context",Json.map("id",id));Execution e=active(actor,id);synchronized(e){e.ensureActive();for(Object raw:Json.list(e.run,"context")){Map<String,Object> c=Json.obj(raw);if(contextId.equals(c.get("id"))){Fault.require(!"APPLIED".equals(c.get("status")),"Context already applied");c.put("status","CANCELLED");e.event("context.cancelled",Json.map("id",contextId));e.save();return;}}throw new Fault(404,"NOT_FOUND","Context entry not found");}}
    public Map<String,Object> approve(Identity actor,String id,String approvalId,boolean accepted){security.require(actor,"tools:approve",Json.map("id",id));Execution e=active(actor,id);synchronized(e){e.ensureActive();
        Map<String,Object> approval=Json.child(e.run,"approval");if(!e.status().equals("WAITING_APPROVAL")||!approvalId.equals(approval.get("id")))throw new Fault(409,"APPROVAL_STALE","Approval is no longer pending");
        security.require(actor,"tool:"+approval.get("tool"),approval);Map<String,Object> call=Json.obj(Json.list(e.run,"pendingCalls").get(Json.integer(e.run,"nextTool",0)));
        Fault.require(approval.get("argumentsHash").equals(Util.hash(Util.canonical(call.get("arguments")))),"Approval argument snapshot mismatch");
        e.event(accepted?"approval.accepted":"approval.rejected",Json.map("id",approvalId,"tool",approval.get("tool")));e.run.remove("approval");
        if(!accepted)e.finish("CANCELLED","Tool execution was rejected");else{call.put("approved",true);e.run.put("status","QUEUED");e.save();e.schedule();}return e.snapshot();
    }}
    private final class Execution {
        final Identity actor;final Map<String,Object> run;final String id;final long deadline;
        final AtomicBoolean cancelled=new AtomicBoolean();final Map<String,Tool> tools=new LinkedHashMap<String,Tool>();
        Mcp.Scope scope;boolean prepared,scheduled;volatile boolean executing;boolean writing;
        Execution(Identity actor,Map<String,Object> run){this.actor=actor;this.run=run;id=Json.required(run,"id");deadline=System.currentTimeMillis()+Json.integer(Json.child(run,"profile"),"maxRunSeconds",180)*1000L;}
        String status(){return Json.str(run,"status","");}
        void ensureActive(){if(terminal(status()))throw new Fault(409,"RUN_ENDED","Run ended");if(System.currentTimeMillis()>deadline){stop("EXPIRED");throw new Fault(409,"RUN_EXPIRED","Run expired");}}
        Map<String,Object> snapshot(){return Json.obj(Json.copy(run));}
        void event(String type,Map<String,Object> data){int seq=Json.integer(run,"eventSeq",0)+1;run.put("eventSeq",seq);List<Object> events=Json.list(run,"events");events.add(Json.map("seq",seq,"type",type,"time",Util.now(),"data",data));if(events.size()>500)events.remove(0);}
        void save(){Map<String,Object> copy=snapshot();store.transact(db->{Json.child(db,"runs").put(id,copy);return null;});}
        void schedule(){if(scheduled||terminal(status()))return;scheduled=true;
            try{workers.execute(()->{try{drive();}catch(Exception ex){synchronized(Execution.this){if(!terminal(status()))finish(writing?"RECONCILIATION_REQUIRED":"FAILED",ex instanceof Fault?((Fault)ex).code+": "+ex.getMessage():"Execution failed: "+ex.getClass().getSimpleName());}}
                finally{synchronized(Execution.this){scheduled=false;if(terminal(status()))cleanup();else if(status().equals("QUEUED"))schedule();}}});}
            catch(RejectedExecutionException e){scheduled=false;finish("FAILED","Agent worker queue is full");}}
        void stop(String state){cancelled.set(true);finish(executing&&writing?"RECONCILIATION_REQUIRED":state,executing&&writing?"Cancelled during a side-effecting tool; verify its external result":state);}
        void finish(String state,String error){if(terminal(status()))return;run.put("status",state);run.put("endedAt",Util.now());if(error!=null)run.put("error",error);run.remove("approval");
            for(Object raw:Json.list(run,"context")){Map<String,Object> c=Json.obj(raw);if("QUEUED".equals(c.get("status"))||"ACTIVE".equals(c.get("status")))c.put("status","RUN_ENDED");}
            event("run.ended",Json.map("status",state));Map<String,Object> copy=snapshot();
            store.transact(db->{Json.child(db,"runs").put(id,copy);Map<String,Object> session=Json.obj(Json.child(db,"sessions").get(run.get("sessionId")));session.remove("activeRun");
                if(state.equals("COMPLETED")){List<Object> history=new ArrayList<Object>(Json.list(run,"messages"));if(!history.isEmpty())history.remove(0);
                    // Bound persisted conversation by removing complete old turns.
                    while(Json.write(history).length()>64000&&history.size()>1){int next=1;while(next<history.size()&&!"user".equals(Json.obj(history.get(next)).get("role")))next++;if(next>=history.size())break;history.subList(0,next).clear();}
                    if(Json.write(history).length()<=128000)session.put("messages",history);
                }return null;});
            if(!scheduled)cleanup();
        }
        void cleanup(){if(scope!=null){scope.close();scope=null;}live.remove(id,this);}
        void prepare()throws Exception{
            Map<String,Object> p=Json.child(run,"profile");List<String> allowed=Json.strings(p.get("tools"));List<Tool> candidates=new ArrayList<Tool>(base);candidates.addAll(skills.tools(Json.strings(p.get("skills"))));
            scope=mcp.open(actor,allowed,cancelled::get);candidates.addAll(scope.tools);validateTools(candidates);
            for(Tool t:candidates){boolean ok=Util.matches(allowed,t.name())&&security.permits(actor,"tool:"+t.name(),Json.map("risk",t.risk().name()));
                for(String skillId:Json.strings(p.get("skills"))){Object rules=skills.get(skillId).metadata.get("allowed-tools");if(rules!=null)ok&=Util.matches(Json.strings(rules),t.name());}
                if(ok)tools.put(t.name(),t);
            }prepared=true;
            Fault.require(tools.size()<=64&&Json.write(definitions()).length()<=128000,"Selected tool catalog is too large; narrow the profile allowlist");
        }
        List<Object> definitions(){List<Object> out=new ArrayList<Object>();for(Tool t:tools.values())out.add(Json.map("type","function","function",Json.map("name",t.name(),"description",t.description(),"parameters",t.schema())));return out;}
        void drive()throws Exception{
            synchronized(this){ensureActive();run.put("status","RUNNING");save();}
            if(!prepared)prepare();
            while(true){synchronized(this){if(terminal(status()))return;ensureActive();}
                if(Json.integer(run,"nextTool",0)<Json.list(run,"pendingCalls").size()){if(!tool())return;continue;}
                List<Object> input,definitions;Map<String,Object> trace;Map<String,Object> p=Json.child(run,"profile");
                List<Object> contributed=new ArrayList<Object>();
                if(!extensions.context.isEmpty()){
                    List<Object> history;synchronized(this){ensureActive();history=Json.arr(Json.copy(Json.list(run,"messages")));}
                    // Trusted extensions may perform retrieval; do not hold the run lock during I/O.
                    for(ContextContributor contributor:extensions.context){String text=contributor.contribute(actor,Json.obj(Json.copy(p)),Json.arr(Json.copy(history)));if(text!=null&&!text.isEmpty())contributed.add(Json.map("role","user","content","[Additional context]\n"+text));}
                }
                synchronized(this){ensureActive();int rounds=Json.integer(run,"rounds",0);if(rounds>=Json.integer(p,"maxRounds",12)||Json.integer(run,"tokens",0)>=Json.integer(p,"maxTokens",24000))throw new Fault(429,"BUDGET_LIMIT","Agent budget exhausted");
                    List<Object> extra=new ArrayList<Object>(),applied=new ArrayList<Object>();
                    for(Object raw:Json.list(run,"context")){Map<String,Object> c=Json.obj(raw);String state=Json.str(c,"status","");if(!state.equals("QUEUED")&&!state.equals("ACTIVE"))continue;
                        String expires=Json.str(c,"expiresAt",null);if(expires!=null&&Instant.parse(expires).toEpochMilli()<=System.currentTimeMillis()){c.put("status","EXPIRED");continue;}
                        Map<String,Object> message=Json.map("role","user","content",("REMINDER".equals(c.get("kind"))?"[Reminder]\n":"")+c.get("text"));
                        if("MESSAGE".equals(c.get("kind")))Json.list(run,"messages").add(message);else extra.add(message);
                        int left=Json.integer(c,"remaining",1)-1;c.put("remaining",left);c.put("status",left>0?"ACTIVE":"APPLIED");applied.add(c.get("id"));
                    }
                    extra.addAll(contributed);
                    definitions=definitions();int contextBudget=Json.integer(p,"maxContextChars",24000)-Json.write(definitions).length();input=ContextWindow.fit(Json.list(run,"messages"),extra,contextBudget);
                    trace=Json.map("id",Util.id(),"parentId",Json.str(run,"lastModelCall",null),"kind","MODEL","startedAt",Util.now(),"inputHash",Util.hash(Util.canonical(input)),"inputChars",Json.write(input).length(),"contextIds",applied,"status","STARTED");
                    run.put("lastModelCall",trace.get("id"));Json.list(run,"calls").add(trace);run.put("rounds",rounds+1);event("model.started",Json.map("callId",trace.get("id"),"round",rounds+1));save();
                }
                Map<String,Object> response=model.complete(input,definitions,Json.obj(Json.copy(p)),cancelled::get);
                synchronized(this){if(terminal(status()))return;ensureActive();trace.put("endedAt",Util.now());trace.put("status","COMPLETED");Map<String,Object> usage=Json.child(response,"usage");trace.put("usage",usage);
                    int used=Json.integer(usage,"total_tokens",0);Fault.require(used>=0&&used<=10000000,"Invalid model usage");run.put("tokens",Json.integer(run,"tokens",0)+used);
                    Map<String,Object> raw=Json.child(response,"message");String content=Json.str(raw,"content",null);Fault.require(content==null||content.length()<=64000,"Model output too large");
                    List<Object> calls=Json.list(raw,"tool_calls");Fault.require(calls.size()<=16,"Too many model tool calls");
                    Map<String,Object> assistant=Json.map("role","assistant","content",content);List<Object> pending=new ArrayList<Object>();
                    if(!calls.isEmpty()){
                        Set<String> ids=new HashSet<String>();for(Object item:calls){Map<String,Object> call=Json.obj(item);String cid=Json.required(call,"id");Fault.require(cid.length()<=100&&ids.add(cid)&&"function".equals(call.get("type")),"Invalid tool call");
                            Map<String,Object> f=Json.child(call,"function");String name=Json.required(f,"name"),arguments=Json.required(f,"arguments");Fault.require(arguments.length()<=64000,"Tool arguments too large");Tool t=tools.get(name);
                            if(t==null)throw Fault.forbidden("Model requested an unavailable tool: "+name);Map<String,Object> args=Json.obj(Json.parse(arguments));Schema.validate(args,t.schema());security.require(actor,"tool:"+name,Json.map("argumentsHash",Util.hash(Util.canonical(args))));
                            pending.add(Json.map("toolCallId",cid,"tool",name,"arguments",args,"invocationId",Util.id(),"approved",false));
                        }
                        assistant.put("tool_calls",Json.copy(calls));
                    }
                    Json.list(run,"messages").add(assistant);run.put("pendingCalls",pending);run.put("nextTool",0);event("model.completed",Json.map("callId",trace.get("id"),"toolCalls",pending.size()));
                    if(pending.isEmpty()){
                        boolean queued=false;for(Object c:Json.list(run,"context")){Map<String,Object> entry=Json.obj(c);if("QUEUED".equals(entry.get("status"))){String expiry=Json.str(entry,"expiresAt",null);if(expiry==null||Instant.parse(expiry).toEpochMilli()>System.currentTimeMillis())queued=true;else entry.put("status","EXPIRED");}}
                        if(!queued){run.put("answer",content);finish("COMPLETED",null);return;}
                    }save();
                }
            }
        }
        boolean tool()throws Exception{
            Tool tool;Map<String,Object> call,args,trace;int index;
            synchronized(this){ensureActive();index=Json.integer(run,"nextTool",0);call=Json.obj(Json.list(run,"pendingCalls").get(index));tool=tools.get(Json.required(call,"tool"));args=Json.child(call,"arguments");
                security.require(actor,"tool:"+tool.name(),Json.map("argumentsHash",Util.hash(Util.canonical(args))));Schema.validate(args,tool.schema());
                if(Json.integer(run,"toolCount",0)>=Json.integer(Json.child(run,"profile"),"maxToolCalls",20))throw new Fault(429,"TOOL_LIMIT","Tool call budget exhausted");
                if(tool.risk()!=Risk.READ&&!Json.bool(call,"approved",false)){
                    run.put("approval",Json.map("id",Util.id(),"tool",tool.name(),"arguments",Json.copy(args),"argumentsHash",Util.hash(Util.canonical(args)),"risk",tool.risk().name(),"invocationId",call.get("invocationId"),"warning",tool.risk()==Risk.HIGH?"May execute local code or affect external systems using service-account privileges":"Will modify workspace files or external state"));
                    run.put("status","WAITING_APPROVAL");event("approval.required",Json.child(run,"approval"));save();return false;
                }
                executing=true;writing=tool.risk()!=Risk.READ;run.put("toolCount",Json.integer(run,"toolCount",0)+1);
                trace=Json.map("id",call.get("invocationId"),"parentId",run.get("lastModelCall"),"kind","TOOL","tool",tool.name(),"risk",tool.risk().name(),"argumentsHash",Util.hash(Util.canonical(args)),"startedAt",Util.now(),"status","STARTED");
                Json.list(run,"calls").add(trace);run.put("inFlight",Json.copy(trace));event("tool.started",Json.map("callId",trace.get("id"),"tool",tool.name()));save();
            }
            Object result;
            try{result=tool.execute(new ToolContext(actor,id,Json.required(call,"invocationId"),workspace(actor),cancelled::get),Json.obj(Json.copy(args)));}
            catch(Exception e){synchronized(this){trace.put("status","FAILED");trace.put("endedAt",Util.now());if(!terminal(status()))finish(writing?"RECONCILIATION_REQUIRED":"FAILED",writing?"Tool result is uncertain; verify external state before retrying":"Tool failed: "+e.getClass().getSimpleName());executing=false;writing=false;}return false;}
            synchronized(this){executing=false;writing=false;if(terminal(status()))return false;ensureActive();trace.put("status","COMPLETED");trace.put("endedAt",Util.now());run.remove("inFlight");
                String text=Json.write(result);if(text.length()>16000)text=Json.write(Json.map("truncated",true,"preview",text.substring(0,15000)));
                Json.list(run,"messages").add(Json.map("role","tool","tool_call_id",call.get("toolCallId"),"content",text));run.put("nextTool",index+1);event("tool.completed",Json.map("callId",trace.get("id"),"tool",tool.name()));save();return true;
            }
        }
    }
    public void close(){closed=true;timer.shutdownNow();for(Execution e:live.values())synchronized(e){if(!terminal(e.status()))e.stop("INTERRUPTED");}workers.shutdownNow();try{workers.awaitTermination(3,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}for(Execution e:live.values())synchronized(e){e.cleanup();}}
}
