package io.yunfan.agent;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import io.yunfan.agent.Extensions.*;

public final class Security {
    private final Authenticator authenticator;
    private final List<Policy> policies;
    public Security(Settings settings,Registry registry) throws Exception {
        policies=new ArrayList<Policy>(registry.policies);
        if(registry.authenticator!=null){authenticator=registry.authenticator;return;}
        if(settings.get("auth.mode","token").equals("demo")){
            Fault.require(settings.get("server.host","127.0.0.1").equals("127.0.0.1"),"Demo authentication requires loopback binding");
            authenticator=headers->new Identity("demo","developer",Arrays.asList("*"));return;
        }
        Fault.require(settings.get("auth.mode","token").equals("token"),"Unknown auth mode");
        final Map<String,Identity> identities=new LinkedHashMap<String,Identity>();Set<String> secrets=new HashSet<String>();
        for(Object item:Json.arr(settings.json("auth.users","config/users.json"))){Map<String,Object> u=Json.obj(item);
            String env=Json.required(u,"tokenEnv"),token=System.getenv(env);
            if(token==null||token.length()<24)throw new IllegalStateException("Set "+env+" to a random token of at least 24 characters");
            Fault.require(secrets.add(token),"Duplicate authentication token");
            identities.put(token,new Identity(Json.required(u,"tenant"),Json.required(u,"user"),Json.strings(u.get("permissions"))));
        }
        Fault.require(!identities.isEmpty(),"No users configured");
        authenticator=headers->{String h=headers.get("authorization");if(h==null||!h.startsWith("Bearer "))throw new Fault(401,"UNAUTHORIZED","Bearer token required");
            byte[] provided=h.substring(7).getBytes(StandardCharsets.UTF_8);Identity found=null;
            for(Map.Entry<String,Identity> e:identities.entrySet())if(MessageDigest.isEqual(provided,e.getKey().getBytes(StandardCharsets.UTF_8)))found=e.getValue();
            if(found==null)throw new Fault(401,"UNAUTHORIZED","Invalid token");return found;};
    }
    public Identity authenticate(Map<String,String> headers){Identity i=authenticator.authenticate(headers);if(i==null)throw new Fault(401,"UNAUTHORIZED","Authentication failed");return i;}
    public boolean permits(Identity actor,String action,Map<String,Object> resource){
        if(!actor.allows(action))return false;for(Policy p:policies)if(!p.allow(actor,action,Json.obj(Json.copy(resource))))return false;return true;
    }
    public void require(Identity actor,String action,Map<String,Object> resource){if(!permits(actor,action,resource))throw Fault.forbidden("Permission required: "+action);}
    public void owner(Identity actor,Map<String,Object> run){if(!actor.key().equals(run.get("owner")))throw new Fault(404,"NOT_FOUND","Run not found");}
}
