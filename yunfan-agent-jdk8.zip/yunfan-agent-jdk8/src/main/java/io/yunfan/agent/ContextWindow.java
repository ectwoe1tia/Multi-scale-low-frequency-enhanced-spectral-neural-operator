package io.yunfan.agent;

import java.util.*;

/** Remove complete assistant/tool groups; never leave an orphan tool response. */
public final class ContextWindow {
    private ContextWindow(){}
    public static List<Object> fit(List<Object> messages,List<Object> extra,int limit){
        List<List<Object>> groups=new ArrayList<List<Object>>();int latestUser=-1;
        for(int i=0;i<messages.size();i++){
            Map<String,Object> m=Json.obj(messages.get(i));List<Object> group=new ArrayList<Object>();group.add(m);
            if("assistant".equals(m.get("role"))&&!Json.list(m,"tool_calls").isEmpty()){
                Set<String> expected=new HashSet<String>();for(Object call:Json.list(m,"tool_calls"))expected.add(Json.required(Json.obj(call),"id"));
                while(i+1<messages.size()&&"tool".equals(Json.obj(messages.get(i+1)).get("role"))){Map<String,Object> result=Json.obj(messages.get(++i));Fault.require(expected.remove(Json.required(result,"tool_call_id")),"Orphan or duplicate tool response");group.add(result);}
                Fault.require(expected.isEmpty(),"Incomplete tool result group");
            }else Fault.require(!"tool".equals(m.get("role")),"Orphan tool response");
            if("user".equals(m.get("role")))latestUser=groups.size();groups.add(group);
        }
        Set<Integer> removed=new HashSet<Integer>();
        while(true){List<Object> out=new ArrayList<Object>();for(int i=0;i<groups.size();i++)if(!removed.contains(i))out.addAll(groups.get(i));out.addAll(extra);
            if(Json.write(out).length()<=limit)return Json.arr(Json.copy(out));
            boolean changed=false;for(int i=1;i<groups.size()-1;i++)if(i!=latestUser&&!removed.contains(i)){removed.add(i);changed=true;break;}
            if(!changed)throw new Fault(413,"CONTEXT_LIMIT","Pinned context exceeds maxContextChars");
        }
    }
}
