package io.yunfan.agent;

import java.io.*;
import java.nio.channels.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Function;

/** Single-instance transactional snapshot store; never silently reinitializes corrupt data. */
public final class FileRepository implements Extensions.Repository {
    private final Path file;
    private final FileChannel channel;
    private final FileLock lock;
    private Map<String,Object> state;
    public FileRepository(Path root) throws IOException {
        Files.createDirectories(root);file=root.resolve("state.json");
        channel=FileChannel.open(root.resolve("instance.lock"),StandardOpenOption.CREATE,StandardOpenOption.WRITE);
        FileLock acquired=null;
        try{acquired=channel.tryLock();if(acquired==null)throw new IOException("Data directory already in use");
            state=Files.exists(file)?Json.obj(Json.parse(Util.file(file,32*1024*1024))):Json.map("format",1,"runs",Json.map(),"sessions",Json.map());
            Fault.require(Json.integer(state,"format",0)==1,"Unsupported store format");
        }catch(Exception e){if(acquired!=null)acquired.release();channel.close();throw new IOException("Cannot open repository",e);}lock=acquired;
    }
    public synchronized <T>T read(Function<Map<String,Object>,T> work){return work.apply(Json.obj(Json.copy(state)));}
    public synchronized <T>T transact(Function<Map<String,Object>,T> work){
        Map<String,Object> next=Json.obj(Json.copy(state));T result=work.apply(next);byte[] bytes=Util.bytes(Json.write(next));
        if(bytes.length>32*1024*1024)throw new Fault(507,"STORE_FULL","Snapshot limit reached; archive old runs");
        try{Util.atomic(file,bytes);}catch(IOException e){throw new Fault(503,"STORE_FAILURE","Could not commit state");}
        // A transaction callback may return a map; never publish that same mutable object internally.
        state=Json.obj(Json.parse(Util.utf8(bytes)));return result;
    }
    public synchronized void close() throws IOException {lock.release();channel.close();}
}
