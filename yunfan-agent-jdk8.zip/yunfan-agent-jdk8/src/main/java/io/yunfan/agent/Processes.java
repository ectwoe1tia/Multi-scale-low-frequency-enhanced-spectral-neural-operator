package io.yunfan.agent;

import io.yunfan.agent.Extensions.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;

/** Deployment-approved argv only. Never interpolates input into a shell command. */
public final class Processes implements AutoCloseable {
    private final Settings settings;
    private final Map<String,Object> profiles;
    private final ProcessLauncher launcher;
    private final Semaphore slots;
    final ExecutorService io;
    private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor(Util.threads("process-watchdog"));
    private final Set<Managed> active=Collections.newSetFromMap(new ConcurrentHashMap<Managed,Boolean>());
    public Processes(Settings settings,Registry registry) throws Exception {
        this.settings=settings;profiles=Json.obj(settings.json("process.profiles","config/processes.json"));
        int max=settings.integer("process.maxConcurrent",4,1,32);slots=new Semaphore(max);io=Executors.newFixedThreadPool(max*4,Util.threads("process-io"));
        launcher=registry.launcher==null?new ProcessLauncher(){
            public Process start(List<String> argv,Path work,Map<String,String> env)throws IOException{
                ProcessBuilder b=new ProcessBuilder(argv).directory(work.toFile());b.environment().clear();b.environment().putAll(env);return b.start();}
            public void stop(Process p){p.destroy();if(p.isAlive())p.destroyForcibly();}
            public boolean enforcesOsIsolation(){return false;}
        }:registry.launcher;
        if(settings.enabled("process.enabled")&&settings.enabled("process.requireOsIsolation")&&!launcher.enforcesOsIsolation())throw new IllegalStateException("An OS-isolating ProcessLauncher plugin is required");
    }
    public Map<String,Object> capabilities(){return Json.map("enabled",settings.enabled("process.enabled"),"osIsolation",launcher.enforcesOsIsolation(),"profiles",profiles.keySet(),"active",active.size(),"descendantCleanup","Requires OS-specific ProcessLauncher for a strict guarantee");}
    public boolean hasProfile(String name){return profiles.containsKey(name);}
    public boolean enabled(){return settings.enabled("process.enabled");}
    public Path job() throws IOException {Path root=settings.path("data.dir","data").resolve("jobs");Files.createDirectories(root);return Files.createDirectory(root.resolve(Util.id()));}
    public Map<String,Object> profile(String name){if(!profiles.containsKey(name))throw Fault.bad("Unknown process profile: "+name);return Json.obj(profiles.get(name));}
    private Map<String,Object> platform(Map<String,Object> profile){String os=System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win")?"windows":"linux";return profile.containsKey(os)?Json.child(profile,os):profile;}
    private List<String> argv(Object raw,Path work,String entry){List<String> out=new ArrayList<String>();for(String s:Json.strings(raw))out.add(s.replace("{work}",work.toString()).replace("{entry}",entry));
        Fault.require(!out.isEmpty()&&out.size()<=40,"Invalid command profile");Path executable=Paths.get(out.get(0));
        Fault.require(executable.isAbsolute()&&Files.isRegularFile(executable),"Configured executable must be an existing absolute file: "+out.get(0));return out;}
    public Managed start(String name,Path work,String entry,long millis,BooleanSupplier cancelled) throws Exception {
        Map<String,Object> p=profile(name);return startCommand(argv(platform(p).get("command"),work,entry),p,work,millis,cancelled);
    }
    private Managed startCommand(List<String> argv,Map<String,Object> profile,Path work,long millis,BooleanSupplier cancelled)throws Exception{
        if(!settings.enabled("process.enabled"))throw Fault.forbidden("Local processes are disabled");
        if(!slots.tryAcquire())throw new Fault(429,"PROCESS_LIMIT","Process concurrency limit reached");
        Managed started=null;
        try{
            Map<String,String> env=new HashMap<String,String>();
            for(String key:Arrays.asList("SystemRoot","WINDIR")){String value=System.getenv(key);if(value!=null)env.put(key,value);}
            for(String key:Arrays.asList("HOME","USERPROFILE","TMP","TEMP","TMPDIR"))env.put(key,work.toString());
            env.put("LANG","C.UTF-8");env.put("PYTHONIOENCODING","utf-8");env.put("PYTHONUTF8","1");
            for(Map.Entry<String,Object> e:Json.child(profile,"envRefs").entrySet()){
                Fault.require(e.getKey().matches("[A-Za-z_][A-Za-z0-9_]*"),"Invalid environment name");
                String value=System.getenv(e.getValue().toString());if(value==null)throw Fault.bad("Missing configured process environment reference");env.put(e.getKey(),value);
            }
            Managed m=new Managed(launcher.start(argv,work,env));started=m;active.add(m);m.startDraining();
            final long deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(millis);
            m.watch=timer.scheduleWithFixedDelay(()->{if(cancelled.getAsBoolean()||System.nanoTime()>deadline){m.timedOut=true;m.close();}},50,50,TimeUnit.MILLISECONDS);
            if(m.closed.get()){m.watch.cancel(false);active.remove(m);}
            return m;
        }catch(Exception e){if(started==null)slots.release();else started.close();throw e;}
    }
    public Object script(String name,Path work,String entry,Object input,int timeoutSeconds,BooleanSupplier cancelled)throws Exception{
        Map<String,Object> p=profile(name),platform=platform(p);long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(timeoutSeconds);
        for(Object command:Json.list(platform,"prepare")){
            long remaining=TimeUnit.NANOSECONDS.toMillis(deadline-System.nanoTime());if(remaining<=0)throw new IOException("Preparation timed out");
            try(Managed m=startCommand(argv(command,work,entry),p,work,remaining,cancelled)){Map<String,Object> result=m.collect("");if(Json.integer(result,"exitCode",-1)!=0)throw new IOException("Skill compilation failed: "+Json.str(result,"stderr",""));}
        }
        long remaining=TimeUnit.NANOSECONDS.toMillis(deadline-System.nanoTime());if(remaining<=0)throw new IOException("Script deadline exceeded");
        try(Managed m=start(name,work,entry,remaining,cancelled)){Map<String,Object> result=m.collect(Json.write(input)+"\n");
            if(Json.integer(result,"exitCode",-1)!=0)throw new IOException("Script exited with code "+result.get("exitCode"));
            String stdout=Json.str(result,"stdout","");Object value;try{value=Json.parse(stdout);}catch(Fault e){value=stdout;}
            return Json.map("output",value,"stderr",result.get("stderr"),"exitCode",0);
        }
    }
    public final class Managed implements AutoCloseable {
        public final Process process;private final AtomicBoolean closed=new AtomicBoolean();
        volatile boolean timedOut;volatile ScheduledFuture<?> watch;
        Future<byte[]> stderr;
        Managed(Process process){this.process=process;}
        void startDraining(){stderr=io.submit(()->{try{return Util.read(process.getErrorStream(),256*1024);}catch(Exception e){close();throw e;}});}
        public Map<String,Object> collect(String input)throws Exception{
            Future<byte[]> stdout=io.submit(()->{try{return Util.read(process.getInputStream(),256*1024);}catch(Exception e){close();throw e;}});
            Future<?> writer=io.submit(()->{try(OutputStream out=process.getOutputStream()){out.write(Util.bytes(input));}catch(IOException e){throw new UncheckedIOException(e);}});
            try{
                while(!process.waitFor(100,TimeUnit.MILLISECONDS))if(closed.get())break;
                if(timedOut)throw new IOException("Process cancelled or timed out");
                writer.get(2,TimeUnit.SECONDS);return Json.map("exitCode",process.exitValue(),"stdout",Util.utf8(stdout.get(2,TimeUnit.SECONDS)),"stderr",Util.utf8(stderr.get(2,TimeUnit.SECONDS)));
            }finally{stdout.cancel(true);writer.cancel(true);}
        }
        public void close(){if(!closed.compareAndSet(false,true))return;try{launcher.stop(process);}
            finally{ScheduledFuture<?> w=watch;if(w!=null)w.cancel(false);
                try{process.getOutputStream().close();}catch(IOException ignored){}
                try{process.getInputStream().close();}catch(IOException ignored){}
                try{process.getErrorStream().close();}catch(IOException ignored){}
                active.remove(this);slots.release();}}
    }
    public void close(){for(Managed m:active)m.close();timer.shutdownNow();io.shutdownNow();}
}
