package io.yunfan.agent;

import java.math.BigDecimal;
import java.util.*;

/** Common tool schema subset. Unsupported validation keywords fail closed at tool registration. */
public final class Schema {
    private static final Set<String> KEYS=new HashSet<String>(Arrays.asList("type","properties","required","additionalProperties","items","enum","const","minimum","maximum","minLength","maxLength","minItems","maxItems","description","title","default","$schema","$id","examples","$defs","definitions","$ref","anyOf","oneOf","allOf"));
    public static void supported(Map<String,Object> s){supported(s,0);}
    private static void supported(Map<String,Object> s,int depth){
        Fault.require(depth<32,"Schema nesting limit");for(String k:s.keySet())Fault.require(KEYS.contains(k),"Unsupported schema keyword: "+k);
        for(String k:Arrays.asList("properties","$defs","definitions"))for(Object v:Json.child(s,k).values())supported(Json.obj(v),depth+1);
        for(String k:Arrays.asList("items","additionalProperties"))if(s.get(k) instanceof Map)supported(Json.obj(s.get(k)),depth+1);
        for(String k:Arrays.asList("anyOf","oneOf","allOf"))for(Object v:Json.list(s,k))supported(Json.obj(v),depth+1);
    }
    public static void validate(Object v,Map<String,Object> s){check(v,s,s,0);}
    private static void check(Object v,Map<String,Object> s,Map<String,Object> root,int depth){
        Fault.require(depth<40,"Schema recursion limit");
        if(s.containsKey("$ref")){String ref=Json.required(s,"$ref");Fault.require(ref.startsWith("#/"),"Only local schema references supported");Object r=root;for(String key:ref.substring(2).split("/"))r=Json.obj(r).get(key.replace("~1","/").replace("~0","~"));check(v,Json.obj(r),root,depth+1);}
        Object type=s.get("type");if(type!=null){boolean ok=false;for(Object t:type instanceof List?Json.arr(type):Arrays.asList(type))ok|=type(v,t.toString());Fault.require(ok,"Tool argument type mismatch");}
        if(s.containsKey("const"))Fault.require(Util.canonical(v).equals(Util.canonical(s.get("const"))),"Constant mismatch");
        if(s.containsKey("enum")){boolean ok=false;for(Object x:Json.arr(s.get("enum")))ok|=Util.canonical(x).equals(Util.canonical(v));Fault.require(ok,"Value outside enum");}
        for(String mode:Arrays.asList("anyOf","oneOf","allOf"))if(s.containsKey(mode)){int n=0;List<Object> a=Json.arr(s.get(mode));for(Object x:a)try{check(v,Json.obj(x),root,depth+1);n++;}catch(Fault ignored){}
            Fault.require(mode.equals("anyOf")?n>0:mode.equals("oneOf")?n==1:n==a.size(),"Schema alternative mismatch");}
        if(v instanceof Map){Map<String,Object> m=Json.obj(v),p=Json.child(s,"properties");for(Object key:Json.list(s,"required"))Fault.require(m.containsKey(key.toString()),"Missing argument: "+key);
            for(Map.Entry<String,Object> e:m.entrySet())if(p.containsKey(e.getKey()))check(e.getValue(),Json.obj(p.get(e.getKey())),root,depth+1);
            else if(Boolean.FALSE.equals(s.get("additionalProperties")))throw Fault.bad("Unknown argument: "+e.getKey());
            else if(s.get("additionalProperties") instanceof Map)check(e.getValue(),Json.obj(s.get("additionalProperties")),root,depth+1);
        }
        if(v instanceof String){int n=((String)v).length();Fault.require(n>=Json.integer(s,"minLength",0)&&n<=Json.integer(s,"maxLength",Integer.MAX_VALUE),"String length out of bounds");}
        if(v instanceof List){List<Object> a=Json.arr(v);Fault.require(a.size()>=Json.integer(s,"minItems",0)&&a.size()<=Json.integer(s,"maxItems",Integer.MAX_VALUE),"Array length out of bounds");if(s.containsKey("items"))for(Object x:a)check(x,Json.obj(s.get("items")),root,depth+1);}
        if(v instanceof Number){BigDecimal n=new BigDecimal(v.toString());if(s.containsKey("minimum"))Fault.require(n.compareTo(new BigDecimal(s.get("minimum").toString()))>=0,"Number below minimum");if(s.containsKey("maximum"))Fault.require(n.compareTo(new BigDecimal(s.get("maximum").toString()))<=0,"Number above maximum");}
    }
    private static boolean type(Object v,String type){switch(type){case "object":return v instanceof Map;case "array":return v instanceof List;case "string":return v instanceof String;case "boolean":return v instanceof Boolean;case "null":return v==null;case "number":return v instanceof Number;case "integer":return v instanceof Number&&new BigDecimal(v.toString()).stripTrailingZeros().scale()<=0;default:throw Fault.bad("Unsupported schema type");}}
    public static Map<String,Object> object(Map<String,Object> properties,String... required){return Json.map("type","object","properties",properties,"required",Arrays.asList(required),"additionalProperties",false);}
    public static Map<String,Object> string(int max){return Json.map("type","string","maxLength",max);}
}
