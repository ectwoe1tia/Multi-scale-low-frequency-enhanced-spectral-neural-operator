package io.yunfan.agent;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Function;

/** Stable Java 8 extension contracts. Plugins are trusted deployment code, not uploaded skills. */
public final class Extensions {
    private Extensions(){}
    public enum Risk { READ, WRITE, HIGH }
    public static final class Identity {
        public final String tenant,user;
        public final Set<String> permissions;
        public Identity(String tenant,String user,Collection<String> permissions){
            Fault.require(!tenant.isEmpty()&&!user.isEmpty(),"Identity is empty");this.tenant=tenant;this.user=user;
            this.permissions=Collections.unmodifiableSet(new LinkedHashSet<String>(permissions));
        }
        public boolean allows(String permission){return Util.matches(permissions,permission);}
        public String key(){return Util.hash(tenant+"\u0000"+user);}
    }
    public interface Authenticator { Identity authenticate(Map<String,String> headers); }
    public interface Policy { boolean allow(Identity actor,String action,Map<String,Object> resource); }
    public interface Model {
        Map<String,Object> complete(List<Object> messages,List<Object> tools,Map<String,Object> profile,BooleanSupplier cancelled) throws Exception;
    }
    public interface Tool {
        String name(); String description(); Map<String,Object> schema(); Risk risk();
        Object execute(ToolContext context,Map<String,Object> arguments) throws Exception;
    }
    public static final class ToolContext {
        public final Identity actor;public final String runId,invocationId;public final Sandbox files;
        public final BooleanSupplier cancelled;
        public ToolContext(Identity actor,String runId,String invocationId,Sandbox files,BooleanSupplier cancelled){
            this.actor=actor;this.runId=runId;this.invocationId=invocationId;this.files=files;this.cancelled=cancelled;
        }
    }
    public interface ContextContributor {
        /** Return additional context, never a permission grant. Called at model boundaries. */
        String contribute(Identity actor,Map<String,Object> profile,List<Object> messages) throws Exception;
    }
    public interface Repository extends AutoCloseable {
        <T> T read(Function<Map<String,Object>,T> work);
        <T> T transact(Function<Map<String,Object>,T> work);
        void close() throws IOException;
    }
    public interface ProcessLauncher {
        /** OS sandbox adapters can wrap with a restricted account, Job Object or cgroup. */
        Process start(List<String> argv,Path work,Map<String,String> environment) throws IOException;
        void stop(Process process);
        boolean enforcesOsIsolation();
    }
    public interface Plugin {
        void install(Registry registry,Settings settings) throws Exception;
    }
    public static final class Registry {
        public final List<Tool> tools=new ArrayList<Tool>();
        public final List<Policy> policies=new ArrayList<Policy>();
        public final List<ContextContributor> context=new ArrayList<ContextContributor>();
        public Authenticator authenticator;public Model model;public Repository repository;public ProcessLauncher launcher;
    }
}
