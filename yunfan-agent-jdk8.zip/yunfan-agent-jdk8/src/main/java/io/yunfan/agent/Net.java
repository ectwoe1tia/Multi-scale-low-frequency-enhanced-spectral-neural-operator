package io.yunfan.agent;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.BooleanSupplier;

/** Java 8 HTTP transport with bounded bodies, no redirects, cancellation and a wall-clock timeout. */
public final class Net implements AutoCloseable {
    private final ScheduledExecutorService timer=Executors.newScheduledThreadPool(2,Util.threads("http-watchdog"));
    public static final class Response {public int status;public Map<String,List<String>> headers;public Object body;public String header(String name){for(Map.Entry<String,List<String>> e:headers.entrySet())if(name.equalsIgnoreCase(e.getKey())&&!e.getValue().isEmpty())return e.getValue().get(0);return null;}}
    public Response post(String endpoint,Map<String,String> headers,Object body,int timeout,BooleanSupplier cancelled,Object expectedId)throws Exception{
        URL url=new URL(endpoint);Fault.require((url.getProtocol().equals("https")||url.getProtocol().equals("http"))&&url.getUserInfo()==null&&url.getRef()==null,"Invalid HTTP endpoint");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);c.setRequestMethod("POST");c.setConnectTimeout(timeout);c.setReadTimeout(timeout);c.setDoOutput(true);
        c.setRequestProperty("Content-Type","application/json; charset=utf-8");for(Map.Entry<String,String> e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());
        long deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(timeout);
        ScheduledFuture<?> watch=timer.scheduleWithFixedDelay(()->{if(cancelled.getAsBoolean()||System.nanoTime()>deadline)c.disconnect();},50,50,TimeUnit.MILLISECONDS);
        try{
            if(cancelled.getAsBoolean())throw new IOException("Cancelled");byte[] data=Util.bytes(Json.write(body));c.setFixedLengthStreamingMode(data.length);try(OutputStream out=c.getOutputStream()){out.write(data);}
            Response r=new Response();r.status=c.getResponseCode();r.headers=c.getHeaderFields();
            if(r.status==202||r.status==204){r.body=Json.map();return r;}
            if(r.status<200||r.status>=300)throw new IOException("Upstream HTTP status "+r.status);
            try(InputStream in=c.getInputStream()){
                String ct=c.getContentType();if(ct!=null&&ct.toLowerCase(Locale.ROOT).startsWith("text/event-stream"))r.body=sse(in,expectedId);
                else{Fault.require(ct!=null&&ct.toLowerCase(Locale.ROOT).startsWith("application/json"),"Expected upstream JSON or SSE response");r.body=Json.parse(Util.utf8(Util.read(in,2*1024*1024)));}
            }return r;
        }finally{watch.cancel(false);c.disconnect();}
    }
    private Object sse(InputStream in,Object expected)throws IOException{
        ByteArrayOutputStream line=new ByteArrayOutputStream();StringBuilder event=new StringBuilder();int total=0,b;
        while((b=in.read())!=-1){if(++total>2*1024*1024)throw new IOException("SSE response too large");if(b!='\n'){line.write(b);continue;}
            String text=new String(line.toByteArray(),StandardCharsets.UTF_8);line.reset();if(text.endsWith("\r"))text=text.substring(0,text.length()-1);
            if(text.isEmpty()){if(event.length()>0){Map<String,Object> m=Json.obj(Json.parse(event.toString()));event.setLength(0);if(expected!=null&&Objects.equals(expected.toString(),String.valueOf(m.get("id"))))return m;}}
            else if(text.startsWith("data:")){if(event.length()>0)event.append('\n');String v=text.substring(5);event.append(v.startsWith(" ")?v.substring(1):v);}
        }throw new IOException("SSE ended without matching response");
    }
    public void close(){timer.shutdownNow();}
}
