package io.yunfan.agent;

import java.util.*;

public final class Profiles {
    private final Map<String,Object> raw=new LinkedHashMap<String,Object>(),resolved=new LinkedHashMap<String,Object>();
    public Profiles(Settings settings,Skills skills)throws Exception{
        for(Object item:Json.arr(settings.json("agent.profiles","config/profiles.json"))){Map<String,Object> p=Json.obj(item);String id=Json.required(p,"id");Fault.require(id.matches("[a-zA-Z0-9_-]{1,40}")&&!raw.containsKey(id),"Invalid or duplicate agent profile");raw.put(id,p);}
        for(String id:raw.keySet()){Map<String,Object> p=resolve(id,new HashSet<String>());for(String skill:Json.strings(p.get("skills")))skills.get(skill);
            limit(p,"maxRounds",12,1,settings.integer("agent.maxRounds",32,1,128));limit(p,"maxToolCalls",20,1,100);
            limit(p,"maxContextChars",24000,2000,120000);limit(p,"maxRunSeconds",180,1,900);limit(p,"maxOutputTokens",1024,1,8192);limit(p,"maxTokens",24000,1,1000000);
            if(!p.containsKey("temperature"))p.put("temperature",0.2);Fault.require(!Json.strings(p.get("tools")).isEmpty(),"Profile must declare tool allowlist");
            Json.required(p,"systemPrompt");resolved.put(id,p);
        }
        Fault.require(!resolved.isEmpty(),"At least one agent profile is required");
    }
    private void limit(Map<String,Object> p,String key,int fallback,int min,int max){int n=Json.integer(p,key,fallback);Fault.require(n>=min&&n<=max,"Invalid profile "+key);p.put(key,n);}
    private Map<String,Object> resolve(String id,Set<String> seen){Fault.require(seen.size()<8&&seen.add(id),"Profile inheritance cycle/depth limit");Fault.require(raw.containsKey(id),"Unknown parent profile");Map<String,Object> own=Json.obj(raw.get(id)),out=Json.map();String parent=Json.str(own,"extends","");if(!parent.isEmpty())out.putAll(resolve(parent,seen));out.putAll(own);return out;}
    public Map<String,Object> get(String id){if(!resolved.containsKey(id))throw new Fault(404,"NOT_FOUND","Profile not found");return Json.obj(Json.copy(resolved.get(id)));}
    public List<Object> list(){return new ArrayList<Object>(Json.arr(Json.copy(new ArrayList<Object>(resolved.values()))));}
}
