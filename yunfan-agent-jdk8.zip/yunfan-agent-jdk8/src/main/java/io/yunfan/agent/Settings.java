package io.yunfan.agent;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Configuration is deployment-owned; HTTP clients cannot change commands, credentials or endpoints. */
public final class Settings {
    private final Properties props;
    public final Path base;
    public Settings(Path base,Properties props){this.base=base.toAbsolutePath().normalize();this.props=props;}
    public static Settings load(Path path) throws IOException {
        Properties p=new Properties();try(Reader r=Files.newBufferedReader(path,StandardCharsets.UTF_8)){p.load(r);}
        return new Settings(path.toAbsolutePath().getParent().getParent(),p);
    }
    public String get(String k,String def){return props.getProperty(k,def).trim();}
    public int integer(String k,int def,int min,int max){int v=Integer.parseInt(get(k,""+def));Fault.require(v>=min&&v<=max,"Invalid config "+k);return v;}
    public boolean enabled(String k){String v=get(k,"false");Fault.require(v.equals("true")||v.equals("false"),"Invalid boolean "+k);return Boolean.parseBoolean(v);}
    public Path path(String key,String def){return base.resolve(get(key,def)).toAbsolutePath().normalize();}
    public Object json(String key,String def) throws IOException{return Json.parse(Util.file(path(key,def),2*1024*1024));}
    public String secret(String key){String ref=get(key,"");if(ref.isEmpty())return "";String v=System.getenv(ref);if(v==null||v.trim().isEmpty())throw new IllegalStateException("Missing environment variable "+ref);return v;}
}
