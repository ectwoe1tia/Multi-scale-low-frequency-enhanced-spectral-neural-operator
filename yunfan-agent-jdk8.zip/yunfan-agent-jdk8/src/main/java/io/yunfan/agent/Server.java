package io.yunfan.agent;

import com.sun.net.httpserver.*;
import io.yunfan.agent.Extensions.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/** JDK 8 HTTP adapter. Business services are independent of this transport. */
public final class Server implements AutoCloseable {
    private final HttpServer server;private final ExecutorService workers;
    private final Agent agent;private final Security security;private final Processes processes;private final Settings settings;
    private final Map<String,Tool> exposed=new LinkedHashMap<String,Tool>();
    public Server(Settings settings,Agent agent,Security security,Processes processes,Registry extensions)throws IOException{
        this.settings=settings;this.agent=agent;this.security=security;this.processes=processes;
        server=HttpServer.create(new InetSocketAddress(settings.get("server.host","127.0.0.1"),settings.integer("server.port",8088,0,65535)),64);
        int count=settings.integer("server.workers",16,2,64);workers=new ThreadPoolExecutor(count,count,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<Runnable>(128),Util.threads("api"),new ThreadPoolExecutor.CallerRunsPolicy());server.setExecutor(workers);
        List<Tool> tools=new ArrayList<Tool>(Builtins.create());tools.addAll(extensions.tools);
        List<String> allow=Arrays.asList(settings.get("mcp.exposeTools","time_now,text_analyze,files_list,files_read").split(","));
        for(Tool t:tools)if(t.risk()==Risk.READ&&Util.matches(allow,t.name()))exposed.put(t.name(),t);
        server.createContext("/",this::handle);
    }
    public int port(){return server.getAddress().getPort();}
    public void start(){server.start();}
    private void handle(HttpExchange x)throws IOException{
        String trace=Util.id();x.getResponseHeaders().set("X-Request-Id",trace);x.getResponseHeaders().set("X-Content-Type-Options","nosniff");x.getResponseHeaders().set("Cache-Control","no-store");
        try{
            origin(x);
            String method=x.getRequestMethod(),path=x.getRequestURI().getPath();
            if(method.equals("OPTIONS")){x.getResponseHeaders().set("Access-Control-Allow-Methods","GET,POST,DELETE,OPTIONS");x.getResponseHeaders().set("Access-Control-Allow-Headers","Authorization,Content-Type,Last-Event-ID,MCP-Protocol-Version,Mcp-Session-Id");x.sendResponseHeaders(204,-1);return;}
            if(method.equals("GET")&&path.equals("/health")){send(x,200,Json.map("status","UP","service","yunfan-agent-jdk8"));return;}
            if(method.equals("GET")&&path.equals("/")){try(InputStream in=Server.class.getResourceAsStream("/console.html")){byte[] body=Util.read(in,128*1024);x.getResponseHeaders().set("Content-Type","text/html; charset=utf-8");x.getResponseHeaders().set("Content-Security-Policy","default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'");x.sendResponseHeaders(200,body.length);x.getResponseBody().write(body);}return;}
            Map<String,String> headers=new HashMap<String,String>();for(Map.Entry<String,List<String>> e:x.getRequestHeaders().entrySet()){if(e.getValue().size()!=1)throw Fault.bad("Duplicate request header");headers.put(e.getKey().toLowerCase(Locale.ROOT),e.getValue().get(0));}
            Identity actor=security.authenticate(headers);
            if(path.equals("/mcp")){if(!method.equals("POST")){x.getResponseHeaders().set("Allow","POST");throw new Fault(405,"METHOD_NOT_ALLOWED","Standalone MCP SSE stream is not offered");}mcp(x,actor,body(x));return;}
            if(method.equals("GET")&&path.equals("/api/capabilities")){security.require(actor,"system:read",Json.map());send(x,200,Json.map("java",System.getProperty("java.version"),"os",System.getProperty("os.name"),"process",processes.capabilities(),"model",settings.get("model.provider","mock"),"mcp",Arrays.asList("stdio","streamable-http"),"storage","single-instance snapshot"));return;}
            if(method.equals("GET")&&path.equals("/api/profiles")){send(x,200,agent.profiles(actor));return;}
            if(method.equals("GET")&&path.equals("/api/skills")){send(x,200,agent.skills(actor));return;}
            if(path.equals("/api/files")){
                if(method.equals("GET")){security.require(actor,"files:read",Json.map());send(x,200,agent.workspace(actor).list());return;}
                if(method.equals("POST")){security.require(actor,"files:write",Json.map());Map<String,Object> input=body(x);String file=Json.required(input,"path");
                    Fault.require(input.containsKey("content")!=input.containsKey("base64"),"Provide either content or base64");
                    byte[] bytes;if(input.containsKey("base64")){try{bytes=Base64.getDecoder().decode(Json.required(input,"base64"));}catch(IllegalArgumentException e){throw Fault.bad("Invalid base64");}}
                    else bytes=Util.bytes(Json.str(input,"content",""));agent.workspace(actor).writeBytes(file,bytes);send(x,201,Json.map("path",file,"bytes",bytes.length));return;}
            }
            if(path.equals("/api/runs")){
                if(method.equals("POST")){send(x,202,agent.submit(actor,body(x)));return;}
                if(method.equals("GET")){send(x,200,agent.list(actor));return;}
            }
            if(path.startsWith("/api/runs/")){
                String[] parts=path.substring(10).split("/",-1);String id=parts[0];Fault.require(id.matches("[a-f0-9-]{36}"),"Invalid run ID");
                if(parts.length==1&&method.equals("GET")){send(x,200,agent.get(actor,id));return;}
                if(parts.length==2&&parts[1].equals("cancel")&&method.equals("POST")){send(x,200,agent.cancel(actor,id));return;}
                if(parts.length==2&&parts[1].equals("context")&&method.equals("POST")){send(x,201,agent.append(actor,id,body(x)));return;}
                if(parts.length==3&&parts[1].equals("context")&&method.equals("DELETE")){agent.removeContext(actor,id,parts[2]);send(x,200,Json.map("removed",true));return;}
                if(parts.length==3&&parts[1].equals("approvals")&&method.equals("POST")){Map<String,Object> b=body(x);Fault.require(b.containsKey("approved"),"approved is required");send(x,200,agent.approve(actor,id,parts[2],Json.bool(b,"approved",false)));return;}
                if(parts.length==2&&parts[1].equals("calls")&&method.equals("GET")){send(x,200,Json.list(agent.get(actor,id),"calls"));return;}
                if(parts.length==2&&parts[1].equals("events")&&method.equals("GET")){events(x,actor,id);return;}
            }
            throw new Fault(404,"NOT_FOUND","Endpoint not found");
        }catch(Fault e){send(x,e.status,Json.map("error",Json.map("code",e.code,"message",e.getMessage(),"requestId",trace)));}
        catch(Exception e){System.err.println("request="+trace+" error="+e.getClass().getSimpleName());send(x,500,Json.map("error",Json.map("code","INTERNAL_ERROR","message","Request failed","requestId",trace)));}
        finally{x.close();}
    }
    private void origin(HttpExchange x){
        String host=x.getRequestHeaders().getFirst("Host");Fault.require(host!=null,"Host required");String hostName=host.replaceFirst(":\\d+$","").toLowerCase(Locale.ROOT);
        if(!Arrays.asList(settings.get("server.allowedHosts","127.0.0.1,localhost").split(",")).contains(hostName))throw Fault.forbidden("Host is not allowed");
        String origin=x.getRequestHeaders().getFirst("Origin");if(origin!=null){List<String> allowed=Arrays.asList(settings.get("server.allowedOrigins","http://127.0.0.1:"+port()+",http://localhost:"+port()).split(","));
            if(!allowed.contains(origin))throw Fault.forbidden("Origin is not allowed");x.getResponseHeaders().set("Access-Control-Allow-Origin",origin);x.getResponseHeaders().set("Vary","Origin");}
    }
    private Map<String,Object> body(HttpExchange x)throws IOException{
        String contentType=x.getRequestHeaders().getFirst("Content-Type");Fault.require(contentType!=null&&contentType.toLowerCase(Locale.ROOT).startsWith("application/json"),"Content-Type must be application/json");
        int limit=x.getRequestURI().getPath().equals("/api/files")?2*1024*1024:1024*1024;
        try{return Json.obj(Json.parse(Util.utf8(Util.read(x.getRequestBody(),limit))));}catch(IOException e){throw new Fault(413,"BODY_LIMIT","Request body exceeds limit or could not be read");}
    }
    private void send(HttpExchange x,int status,Object body)throws IOException{byte[] bytes=Util.bytes(Json.write(body));x.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");x.sendResponseHeaders(status,bytes.length);x.getResponseBody().write(bytes);}
    private void events(HttpExchange x,Identity actor,String id)throws Exception{
        int after=0;String query=x.getRequestURI().getRawQuery();if(query!=null)for(String part:query.split("&"))if(part.startsWith("after="))try{after=Integer.parseInt(part.substring(6));}catch(NumberFormatException e){throw Fault.bad("Invalid event cursor");}
        String last=x.getRequestHeaders().getFirst("Last-Event-ID");if(last!=null)try{after=Math.max(after,Integer.parseInt(last));}catch(NumberFormatException e){throw Fault.bad("Invalid Last-Event-ID");}
        Map<String,Object> first=agent.get(actor,id);List<Object> available=Json.list(first,"events");if(!available.isEmpty()&&after<Json.integer(Json.obj(available.get(0)),"seq",1)-1)throw new Fault(409,"EVENT_CURSOR_EXPIRED","Event cursor expired; fetch run snapshot");
        String accept=x.getRequestHeaders().getFirst("Accept");if(accept==null||!accept.contains("text/event-stream")){List<Object> selected=new ArrayList<Object>();for(Object event:available)if(Json.integer(Json.obj(event),"seq",0)>after)selected.add(event);send(x,200,selected);return;}
        x.getResponseHeaders().set("Content-Type","text/event-stream; charset=utf-8");x.getResponseHeaders().set("X-Accel-Buffering","no");x.sendResponseHeaders(200,0);
        OutputStream out=x.getResponseBody();long until=System.currentTimeMillis()+25000,heartbeat=0;
        try{while(System.currentTimeMillis()<until){Map<String,Object> r=agent.get(actor,id);
            for(Object raw:Json.list(r,"events")){Map<String,Object> e=Json.obj(raw);int seq=Json.integer(e,"seq",0);if(seq>after){out.write(Util.bytes("id: "+seq+"\nevent: "+e.get("type")+"\ndata: "+Json.write(e)+"\n\n"));after=seq;}}
            if(System.currentTimeMillis()>heartbeat){out.write(Util.bytes(": heartbeat\n\n"));heartbeat=System.currentTimeMillis()+5000;}out.flush();
            if(Agent.terminal(Json.str(r,"status",""))||"WAITING_APPROVAL".equals(r.get("status")))return;Thread.sleep(200);
        }}catch(IOException ignored){/* A disconnected reader does not cancel the run. */}
    }
    private void mcp(HttpExchange x,Identity actor,Map<String,Object> request)throws Exception{
        security.require(actor,"mcp:serve",Json.map());Fault.require("2.0".equals(request.get("jsonrpc")),"Expected JSON-RPC 2.0");
        String method=Json.required(request,"method");Object id=request.get("id");if(!request.containsKey("id")){x.sendResponseHeaders(202,-1);return;}
        Fault.require(id instanceof String||id instanceof Number,"Invalid RPC ID");Map<String,Object> params=Json.child(request,"params"),result;
        try{switch(method){
            case "initialize":String proposed=Json.str(params,"protocolVersion",Mcp.VERSION);String version=Arrays.asList(Mcp.VERSION,"2025-06-18","2025-03-26").contains(proposed)?proposed:Mcp.VERSION;
                result=Json.map("protocolVersion",version,"capabilities",Json.map("tools",Json.map("listChanged",false)),"serverInfo",Json.map("name","yunfan-agent-jdk8","version","1.0.0"));break;
            case "ping":result=Json.map();break;
            case "tools/list":List<Object> list=new ArrayList<Object>();for(Tool t:exposed.values())if(security.permits(actor,"tool:"+t.name(),Json.map()))list.add(Json.map("name",t.name(),"description",t.description(),"inputSchema",t.schema(),"annotations",Json.map("readOnlyHint",true)));result=Json.map("tools",list);break;
            case "tools/call":String name=Json.required(params,"name");Tool t=exposed.get(name);if(t==null)throw new Fault(404,"NOT_FOUND","MCP tool unavailable");security.require(actor,"tool:"+name,Json.map());Map<String,Object> args=Json.child(params,"arguments");Schema.validate(args,t.schema());
                Object value=t.execute(new ToolContext(actor,"mcp",Util.id(),agent.workspace(actor),()->false),args);String text=Json.write(value);Fault.require(text.length()<=1024*1024,"Tool result too large");result=Json.map("content",Arrays.asList(Json.map("type","text","text",text)),"isError",false);break;
            default:send(x,200,Json.map("jsonrpc","2.0","id",id,"error",Json.map("code",-32601,"message","Method not supported")));return;
        }send(x,200,Json.map("jsonrpc","2.0","id",id,"result",result));}
        catch(Fault e){send(x,200,Json.map("jsonrpc","2.0","id",id,"error",Json.map("code",-32602,"message",e.getMessage())));}
    }
    public void close(){server.stop(0);workers.shutdownNow();}
}
