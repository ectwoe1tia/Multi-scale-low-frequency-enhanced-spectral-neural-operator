package io.yunfan.agent;

import io.yunfan.agent.Extensions.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CountDownLatch;

public final class Main {
    private Main(){}
    public static final class Application implements AutoCloseable {
        public final Settings settings;public final Registry extensions;public final Repository repository;
        public final Net net;public final Security security;public final Processes processes;public final Skills skills;public final Profiles profiles;
        public final Agent agent;public final Server server;
        private boolean closed;
        public Application(Settings settings,Registry extensions)throws Exception{
            this.settings=settings;this.extensions=extensions;
            List<AutoCloseable> opened=new ArrayList<AutoCloseable>();
            try{
                security=new Security(settings,extensions);
                repository=extensions.repository==null?new FileRepository(settings.path("data.dir","data").resolve("store")):extensions.repository;opened.add(repository);
                net=new Net();opened.add(net);processes=new Processes(settings,extensions);opened.add(processes);
                skills=new Skills(settings,processes);profiles=new Profiles(settings,skills);Mcp mcp=new Mcp(settings,processes,net,security);
                Model model=extensions.model==null?Models.create(settings,net):extensions.model;
                agent=new Agent(settings,repository,security,profiles,skills,mcp,model,extensions);opened.add(agent);
                server=new Server(settings,agent,security,processes,extensions);opened.add(server);
            }catch(Exception e){Collections.reverse(opened);for(AutoCloseable c:opened)try{c.close();}catch(Exception ignored){}throw e;}
        }
        public synchronized void close(){if(closed)return;closed=true;server.close();agent.close();processes.close();net.close();try{repository.close();}catch(Exception e){System.err.println("Repository close failed");}}
    }
    public static void main(String[] args)throws Exception{
        Path path=Paths.get(args.length==0?"config/application.properties":args[0]);Settings settings=Settings.load(path);Registry extensions=new Registry();
        for(Plugin plugin:ServiceLoader.load(Plugin.class))plugin.install(extensions,settings);
        final Application app=new Application(settings,extensions);Runtime.getRuntime().addShutdownHook(new Thread(app::close,"shutdown"));app.server.start();
        System.out.println("Agent ready at http://"+settings.get("server.host","127.0.0.1")+":"+app.server.port()+" (Java "+System.getProperty("java.version")+")");
        if(settings.get("model.provider","mock").equals("mock"))System.out.println("Offline mock model enabled; configure model.provider for real inference.");
        if(settings.enabled("process.enabled"))System.out.println("Local processes enabled; OS isolation: "+app.processes.capabilities().get("osIsolation"));
        new CountDownLatch(1).await();
    }
}
