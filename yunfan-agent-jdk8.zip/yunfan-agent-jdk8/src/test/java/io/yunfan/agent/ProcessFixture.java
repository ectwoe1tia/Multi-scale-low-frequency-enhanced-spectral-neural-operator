package io.yunfan.agent;

import java.io.*;
import java.util.*;

/** Portable child process and MCP fixture: no shell or Python dependency in the test suite. */
public final class ProcessFixture {
    public static void main(String[] args)throws Exception{
        String mode=args[0];BufferedReader in=new BufferedReader(new InputStreamReader(System.in,"UTF-8"));PrintWriter out=new PrintWriter(new OutputStreamWriter(System.out,"UTF-8"),true);
        if(mode.equals("hang")){Thread.sleep(60000);return;}
        if(mode.equals("flood")){for(int i=0;i<400000;i++)System.out.write('x');System.out.flush();return;}
        if(mode.equals("stderr")){for(int i=0;i<400000;i++)System.err.write('x');System.err.flush();return;}
        if(mode.equals("echo")){String line=in.readLine();out.println(Json.write(Json.map("input",Json.parse(line),"pathInherited",System.getenv("PATH")!=null,"cwd",System.getProperty("user.dir"))));return;}
        if(mode.startsWith("mcp")){
            String line;boolean initialized=false;while((line=in.readLine())!=null){Map<String,Object> m=Json.obj(Json.parse(line));String method=Json.str(m,"method","");Object id=m.get("id");
                if(method.equals("notifications/initialized")){initialized=true;continue;}if(id==null)continue;
                Object result;
                if(method.equals("initialize"))result=Json.map("protocolVersion",Mcp.VERSION,"capabilities",Json.map("tools",Json.map()),"serverInfo",Json.map("name","fixture","version","1"));
                else if(method.equals("tools/list")){if(!initialized)throw new IllegalStateException("not initialized");
                    if(Json.child(m,"params").containsKey("cursor"))result=Json.map("tools",Arrays.asList(Json.map("name","other","description","other","inputSchema",Schema.object(Json.map()))));
                    else result=Json.map("tools",Arrays.asList(Json.map("name","echo","description","echo","inputSchema",Json.map("type","object"))),"nextCursor","page2");
                }else result=Json.map("content",Arrays.asList(Json.map("type","text","text",Json.write(Json.child(Json.child(m,"params"),"arguments")))));
                out.println(Json.write(Json.map("jsonrpc","2.0","id",mode.equals("mcp-wrong")?"wrong":id,"result",result)));
            }
        }
    }
}
