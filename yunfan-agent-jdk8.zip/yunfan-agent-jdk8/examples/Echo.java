import java.io.*;
/** Copy into a script skill using runtime java-echo and entrypoint Echo.java. */
public class Echo {
    public static void main(String[] args)throws Exception{
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in,"UTF-8"));
        PrintWriter output=new PrintWriter(new OutputStreamWriter(System.out,"UTF-8"),true);
        output.println(input.readLine());
    }
}
