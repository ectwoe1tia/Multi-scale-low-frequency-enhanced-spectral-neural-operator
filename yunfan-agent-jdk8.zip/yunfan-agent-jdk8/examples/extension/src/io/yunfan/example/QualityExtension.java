package io.yunfan.example;

import io.yunfan.agent.*;
import io.yunfan.agent.Extensions.*;
import java.util.*;

/** Trusted deployment plugin; no change to the agent engine is needed. */
public final class QualityExtension implements Plugin {
    public void install(Registry registry,Settings settings){
        registry.tools.add(new Builtins.Basic("quality_checklist","Return the company's review checklist",Risk.READ,
            Schema.object(Json.map("category",Json.map("type","string","enum",Arrays.asList("requirement","release"))),"category")){
            public Object execute(ToolContext context,Map<String,Object> args){
                List<String> items="release".equals(args.get("category"))?Arrays.asList("验证证据","回滚方案","变更责任人"):Arrays.asList("业务目标","验收标准","数据权限","异常流程");
                return Json.map("category",args.get("category"),"items",items,"policyVersion","company-example-1");
            }
        });
        // Extra policy can deny an existing grant, but cannot grant permissions absent from Identity.
        registry.policies.add((actor,action,resource)->!action.equals("tool:files_write")||actor.allows("documents:write"));
        registry.context.add((actor,profile,messages)->"quality-review".equals(profile.get("id"))?
            "企业偏好：优先说明验收标准、权限边界和异常流程；结论必须关联原文证据。":"");
    }
}
