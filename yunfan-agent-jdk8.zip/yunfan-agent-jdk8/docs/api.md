# HTTP 接口

默认地址 `http://127.0.0.1:8088`；除 `/`、`/health` 和受 Origin 控制的 OPTIONS 外均需要 Bearer 认证。所有 JSON 使用 UTF-8。默认请求体上限 1 MiB，文件上传请求 2 MiB。错误格式：

```json
{"error":{"code":"FORBIDDEN","message":"Permission required: runs:create","requestId":"..."}}
```

## 接口和权限

| 方法与路径 | 用途 | 权限 |
|---|---|---|
| GET `/health` | 存活检查，无敏感配置 | 无 |
| GET `/api/capabilities` | Java/OS、进程模式与模型类型 | `system:read` |
| GET `/api/profiles` | 当前用户可选择的角色 | 逐项检查 `profile:<id>` |
| GET `/api/skills` | 本地技能和版本/资源目录 | `skills:read` |
| GET `/api/files` | 列出本人工作区文件 | `files:read` |
| POST `/api/files` | 直接上传文件 | `files:write` |
| POST `/api/runs` | 异步创建任务，返回 202 | `runs:create`、`profile:<id>` |
| GET `/api/runs` | 当前用户的运行摘要 | `runs:read` |
| GET `/api/runs/{id}` | 完整运行快照 | `runs:read` + 所有者 |
| GET `/api/runs/{id}/calls` | 模型/工具调用链元数据 | 同上 |
| GET `/api/runs/{id}/events?after=0` | 事件列表或 SSE | 同上 |
| POST `/api/runs/{id}/cancel` | 取消运行 | `runs:cancel` + 所有者 |
| POST `/api/runs/{id}/context` | 排队追加消息/提醒 | `runs:context` + 所有者 |
| DELETE `/api/runs/{id}/context/{contextId}` | 取消尚可取消的上下文 | 同上 |
| POST `/api/runs/{id}/approvals/{approvalId}` | 接受/拒绝工具调用 | `tools:approve`、`tool:<name>` + 所有者 |
| POST `/mcp` | 只读 MCP 工具服务 | `mcp:serve`、`tool:<name>` |

除创建以外的运行操作也需要 `runs:read`，以便检查所有者。权限字符串支持精确匹配或末尾 `*` 前缀匹配。

## 创建运行

```json
{
  "requestId":"client-order-001",
  "profile":"general",
  "message":"读取需求文档并给出审查意见"
}
```

首次创建返回 `id`、`sessionId`、`status`。后续对话传回同一个 `sessionId`；同一会话有运行进行时返回 409。相同用户的相同 requestId、相同完整请求体返回已有运行；不同请求体返回 `IDEMPOTENCY_CONFLICT`。幂等不会隐式延续已结束的运行。

## 工具确认

当快照状态为 `WAITING_APPROVAL`，读取其中的 `approval`：

```json
{
  "id":"approval-id",
  "tool":"files_write",
  "arguments":{"path":"review.md","content":"审查结果"},
  "argumentsHash":"sha256...",
  "risk":"WRITE",
  "invocationId":"tool-call-id",
  "warning":"Will modify workspace files or external state"
}
```

确认请求：

```json
{"approved":true}
```

`false` 表示拒绝。不能在确认请求内修改参数；旧确认 ID 不能重复使用。需要修改参数时拒绝本次调用并创建新任务。HIGH 风险会明确提示可能以服务账户执行本地代码或访问外部系统。

## 运行中追加

```json
{"requestId":"append-001","kind":"MESSAGE","text":"补充：只检查审批流程"}
```

```json
{
  "requestId":"reminder-001",
  "kind":"REMINDER",
  "text":"每条结论附上文档原文依据",
  "repeat":3,
  "expiresAt":"2030-01-01T00:00:00Z"
}
```

消息最多 8000 字符，队列最多 100 项；MESSAGE 的 repeat 只能为 1，REMINDER 为 1–20。expiresAt 可省略；状态可为 QUEUED、ACTIVE、APPLIED、EXPIRED、CANCELLED 或 RUN_ENDED。已结束运行不能追加。

## 事件

默认返回 JSON 数组。携带 `Accept: text/event-stream` 时返回 SSE，可用 `after` 或 `Last-Event-ID` 恢复。连接最多持续约 25 秒，在运行结束或等待确认时提前结束；客户端保存最后 seq 后重新连接即可。断开事件连接不会取消任务。

```text
id: 4
event: approval.required
data: {"seq":4,"type":"approval.required","time":"...","data":{...}}
```

事件保留窗口之外的游标返回 `EVENT_CURSOR_EXPIRED`，客户端需重新读取运行快照。事件中不会输出供应商密钥或隐藏思维链；确认事件包含当前用户需要审核的工具参数。

## 文件与文档

直接上传文本：

```json
{"path":"requirements.md","content":"项目需求……"}
```

上传 DOCX：

```json
{"path":"requirements.docx","base64":"UEsDB..."}
```

两种内容字段不能同时出现；单文件上限 1 MiB、工作区总量 10 MiB，路径使用相对路径和 `/` 分隔符。用户直接调用上传接口表示明确的上传动作，需要 `files:write`；模型使用 `files_write` 工具仍需要运行确认。

随后创建 `document-review` 角色任务，或者在 mock 模式用 `/tool documents_extract {"path":"requirements.docx"}` 检验解析结果。DOCX 仅提取正文段落与表格文字，不处理 OCR、页眉页脚、脚注或版式还原。

## MCP

`POST /mcp` 按 JSON-RPC 2.0 使用 initialize、notifications/initialized、tools/list、tools/call。默认只公开 `time_now`、`text_analyze`、`files_list`、`files_read`；可通过 `mcp.exposeTools` 增加已安装的 READ 工具。WRITE/HIGH 工具始终不通过此入口公开。
