# 架构与执行边界

## 分层

```mermaid
flowchart TD
    A[网页 / 业务系统 / MCP 客户端] --> H[HTTP Server + 认证 + Origin 校验]
    H --> E[Java Agent 状态机]
    E --> C[Profile / Skills / ContextWindow]
    E --> M[Model SPI / Chat Completions]
    E --> P[权限交集 / Schema / 确认快照]
    P --> T[Java 工具 SPI]
    P --> R[MCP HTTP / stdio]
    P --> S[本地技能进程]
    S --> I[ProcessLauncher SPI]
    E --> D[Repository SPI / 原子文件快照]
```

`Server` 只承担 HTTP 适配，`Agent` 管理 Java 调用循环，`Extensions` 定义定制接口。可以在现有 Servlet、Spring 或公司框架中嵌入服务类；交付物本身不要求升级到 Spring Boot 3 或 JDK 17。

## Agent 执行

创建运行时绑定用户、租户、角色配置快照、技能版本和 requestId。会话同时只允许一个运行；不同会话可并行，执行线程与排队长度均有上限。

主要状态：`QUEUED → RUNNING → WAITING_APPROVAL → RUNNING → COMPLETED`；结束状态还包括 `FAILED`、`CANCELLED`、`EXPIRED`、`INTERRUPTED` 和 `RECONCILIATION_REQUIRED`。

模型返回的一整批工具调用先完成名称、权限与参数校验，再逐个派发。所有 `WRITE` / `HIGH` 调用保存参数、SHA-256、调用 ID、风险等级及确认 ID；确认接口不接收替换参数。批准前和执行前重新检查权限。拒绝会结束运行。

有副作用的调用一旦开始，遇到连接中断、超时、取消或重启，不能推定外部事务回滚。此时标记 `RECONCILIATION_REQUIRED`，保留调用 ID，不自动重放。确认外部结果后由用户创建新请求。调用 ID 放入 MCP `_meta`，但服务端是否支持幂等仍取决于对端。

运行限额包括最大模型轮数、工具次数、时长、上下文字符数和模型报告的 token 用量。token 限额依赖模型返回 usage；缺少 usage 时仍受轮数、输出请求上限与字符限额约束，不声称精确计费控制。

## 上下文追加

- `MESSAGE`：排队到下一次模型调用边界，加入会话历史一次。
- `REMINDER`：每次模型调用临时附加，最多重复 20 次，不写入会话历史。
- 工具返回结果全部配对后才进入下一次模型调用。不会在 assistant/tool 配对中间插入用户消息。
- 模型生成最终回答期间收到的新消息，会触发下一轮模型调用；最终提交与追加操作共用运行锁，避免“追加成功却没有使用”的竞态。
- 支持追加幂等、过期时间和取消。结束时未消耗的提醒标记 `RUN_ENDED`。
- `ContextWindow` 删除完整的旧 assistant/tool 组，保留系统提示、最近用户消息和最后一组。原始运行消息保留供审计；不进行隐式模型摘要调用。

`/calls` 记录 MODEL/TOOL 调用及父 ID、输入摘要、参数摘要、usage 与时间。它是执行元数据，不采集模型隐藏思维链。

## MCP 范围

客户端支持 2025-11-25、2025-06-18、2025-03-26 生命周期：initialize、版本协商、initialized、tools/list 分页、tools/call。HTTP 支持 JSON 与 SSE 返回、session header；stdio 使用 UTF-8 换行 JSON-RPC、独立 stderr、响应 ID 匹配、ping 回应。每个运行独享连接与 stdio 进程，避免跨用户共享子进程状态。

工具发现失败时丢弃整次发现；不返回半套工具目录。只暴露部署配置允许的工具，风险以本地配置为准。模型名称采用 `serverId__toolName`；所选工具目录最多 64 个。

工具参数支持常用 JSON Schema 子集：type、properties、required、additionalProperties、items、enum、const、数值/字符串/数组长度边界、局部 `$ref` 和 anyOf/oneOf/allOf。未支持的验证关键字会明确拒绝工具注册，例如 pattern，不会默默忽略规则。接入带复杂 Schema 的 MCP 服务时，需调整其工具输入合同或扩展验证器。

这是明确范围的 MCP tools 实现：不提供 OAuth 自动发现、sampling、elicitation、资源订阅、旧版 HTTP+SSE 传输或自动断点重连。HTTP 服务端会话终止 DELETE 是可选能力，当前客户端不发送；外部服务应配置会话过期。stdio 子进程最长存活 10 分钟；等待确认过久可能使连接失效，运行会失败并保留记录。

本服务 `/mcp` 为无状态只读工具服务端，提供 initialize、ping、tools/list、tools/call；GET 返回 405，不宣称后台订阅能力。不会把写入及脚本工具直接暴露给外部 MCP 客户端，避免绕过 Agent 确认流程。

参考：[MCP 传输规范](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)、[生命周期规范](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle)。

## 沙箱与权限

| 范围 | 已实施的限制 | 限制之外 |
|---|---|---|
| HTTP | Bearer、请求体限制、固定 Origin/Host、线程限制 | TLS、互联网攻击防护和连接限速由入口网关承担 |
| 用户隔离 | tenant+user 派生私有工作区、运行所有者检查 | 默认无跨用户管理员查询 API |
| 内置文件工具 | 相对路径、Windows 保留名、符号链接/越界检查、1 MiB 单文件与 10 MiB 工作区 | 同账户恶意本地进程并发替换目录的 TOCTOU 风险需 OS 权限隔离 |
| 本地进程 | 独立目录、清理环境、明确 envRefs、argv 数组、默认 4 并发、超时、stdout/stderr 各 256 KiB | 不默认限制网络、全磁盘写入、总内存/CPU；不是强 OS 沙箱 |
| 脚本输入 | JSON stdin，禁止模型设置命令/环境/cwd | 用户脚本自身的 shell 行为与依赖仍需部署审核 |
| 扩展代码 | 仅本地部署 JAR，启动时加载 | SPI 插件与服务拥有同等权限，不能用于不受信任的上传代码 |

Java 8 的标准 [Process API](https://docs.oracle.com/javase/8/docs/api/java/lang/Process.html) 没有 Java 9+ 的 ProcessHandle 后代枚举接口。默认 launcher 终止直接子进程，不通过易误杀的进程名匹配来声称回收整个进程树。Windows 可实现 Job Object + 受限令牌；Linux 可实现独立账户、进程组/cgroup、命名空间等适配器。若要对任意用户脚本保证隔离，应配置相应系统适配器并要求 `enforcesOsIsolation()`。

## 跨环境运行

业务逻辑和协议全部使用 Java 8 API。源码 UTF-8，脚本输入输出 UTF-8；路径通过 Java Path 处理，命令通过参数数组传递。`processes.json` 为同一个 runtime 分别配置 `windows` 和 `linux` 路径，输入输出合同保持一致。

这保证调用合同与 Java 行为可复用，不保证 Bash、原生 C++ 库、Python 扩展或第三方命令在不同操作系统中天然相同。固定解释器/编译器版本，并用实际目标环境执行项目自带测试；CI 矩阵不是已经执行过的验证结果。

## 存储与运维

默认仓库对每次变更执行深拷贝事务、完整 JSON 校验、文件同步与原子替换。要求本地文件系统支持原子替换；锁文件阻止多实例共享数据。损坏数据拒绝加载，不会悄悄重建空数据库。

设计定位为公司单节点或单副本部署：快照最多 32 MiB、累计最多 1000 个运行、每个运行保留最近 500 个事件。达到限额返回明确错误；当前没有自动归档/删除和分布式调度。可停机备份并更换数据目录，或实现 `Repository` 接入公司数据库。不要手工删除部分运行记录后仍假设旧 requestId 永久幂等。

`data/jobs` 保留执行目录，便于核对异常结果，需部署者安排保留期和磁盘清理。进程的任意磁盘写入不受内置文件工具配额控制。事件与对话可能包含业务数据，数据目录需要与业务敏感级别匹配的账户权限、备份和保留策略。
