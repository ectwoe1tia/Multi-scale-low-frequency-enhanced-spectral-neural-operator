# 企业定制接口

## 由配置到专用能力

第一层是 Profile：继承 `general`，设置领域系统提示词、工具白名单、模型参数、技能和预算。例如已有的 `document-review` 偏向证据式中文文档审查。Profile 不能绕过用户身份与策略。

第二层是文本 Skill：`SKILL.md` 保存业务规则、操作流程和模板。支持平面 YAML 字段、字符串/列表、`|` 和 `>` 多行描述；不支持复杂 YAML 对象、标签和锚点。`allowed-tools` 是额外的收窄约束，多技能同时启用时取交集；需要多个独立专业能力时建议拆分 Profile，避免无意把工具目录收窄为空。

第三层是可信 Java 插件。`io.yunfan.agent.Extensions` 提供以下接口：

| 接口 | 用途 |
|---|---|
| `Plugin` | 启动时注册其他扩展 |
| `Tool` | Java 工具、参数 Schema、风险和执行逻辑 |
| `Model` | 公司模型网关或其他推理协议 |
| `Authenticator` | 公司 IAM、网关身份或服务账号认证 |
| `Policy` | 额外拒绝规则、部门/业务资源权限 |
| `ContextContributor` | 为每次模型调用提供领域上下文或检索结果 |
| `Repository` | 替换默认文件快照，例如接公司 JDBC 数据库 |
| `ProcessLauncher` | Windows/Linux 系统隔离与进程回收适配 |

这些接口均是 Java 8 接口。`Repository` 适配必须提供快照隔离、原子提交、持久化失败处理和单实例所有权保证；仅换成数据库并不自动获得分布式调度。模型与工具需要遵守取消信号，插件回调应有限时且不得绕过权限执行额外副作用。插件在主 JVM 中运行，不能接收不可信用户上传的任意 JAR。

## 可编译示例

示例源码：`examples/extension/src/io/yunfan/example/QualityExtension.java`。

它增加 `quality_checklist` 只读工具、企业审查上下文，以及文件写入的附加权限要求。构建：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/build-extension.ps1 -JavaHome 'C:\Java\jdk8'
New-Item -ItemType Directory -Path lib -Force
Copy-Item target/quality-extension.jar lib/
```

Linux 使用 `sh scripts/build-extension.sh`。将 `examples/quality-profile.json` 中的对象加入 `config/profiles.json` 的数组，使用 `scripts/start.*` 启动，`lib/*` 会加入类路径。`java -jar` 本身不会额外加载 lib 中的插件。

ServiceLoader 文件为：

```text
META-INF/services/io.yunfan.agent.Extensions$Plugin
```

文件中写入实现类全名。插件不需要改动核心源码。

## 脚本合同

```yaml
---
name: company_parser
type: script
runtime: python
entrypoint: parser.py
timeoutSeconds: 30
---
解析公司文档的操作说明。
```

父进程写入一行 JSON 到 stdin 并关闭输入：

```json
{"arguments":{"path":"..."},"runId":"...","invocationId":"...","skillVersion":"..."}
```

脚本向 stdout 输出一个 JSON 值；非 JSON 输出按文本处理。stderr 独立捕获，最多 256 KiB；输出不应包含密钥。工作目录中有该技能的资源快照，不能靠相对路径读取其他技能或用户文件。确需读取上传文档时应设计明确的 Java 工具或文件传递接口；当前不会自动把整个用户工作区复制给脚本。

每个 runtime 在 `config/processes.json` 配置：

- `windows` / `linux`：分别配置平台命令。
- `prepare`：可选的编译命令数组，按顺序执行。
- `command`：执行参数数组。
- `envRefs`：可选的环境变量映射，值是部署环境变量名。
- `{entry}` / `{work}`：只在部署者编写的参数模板中替换；用户参数不会参与命令字符串拼接。

示例 Java 使用固定 `Echo` 类名；实际 Java 技能应独立配置主类或 JAR，不能依赖 JDK 11 的源码启动功能。Python、Bash 和 C++ 的依赖不会自动安装。清空 PATH 后，Bash 中调用外部程序需写绝对路径，或由部署者通过 envRefs 显式提供受控 PATH。编译器也可能需要受控 PATH 和动态库路径。

## 强隔离适配

自定义 `ProcessLauncher.start(argv, work, environment)` 应只运行批准的命令，并设置受限账号/访问控制、资源限额及进程组归属。`stop(process)` 应回收整个隔离单元；只有这些条件在实际平台得到保证时才返回 `enforcesOsIsolation() = true`。

配置 `process.requireOsIsolation=true` 后，默认 launcher 会被拒绝。交付中没有假装实现 Windows Job Object 或 Linux cgroup 的空壳适配器；公司部署可按实际权限和已有运行设施实现该接口。
