# 本次验证记录

验证日期：2026-10-24（Asia/Shanghai）。

## 实际执行

| 项目 | 结果 |
|---|---|
| 编译器和测试 JVM | 本机 OpenJDK `1.8.0_42`，真实 Java 8 编译及运行 |
| 系统 | Windows；该旧版 JVM 的 `os.name` 报告为 Windows 8.1 |
| Java 契约测试 | **41 组通过，1 组跳过** |
| 成品 JAR 独立 JVM 测试 | **14 项通过** |
| Java 8 字节码 | JAR 中所有 class 的 major version 都为 **52** |
| 新版 JDK 交叉编译 | 使用本机 JDK 18 的 `javac --release 8` 编译通过 |
| 企业插件 | 示例插件在 JDK 8 编译，通过 ServiceLoader 从独立 JAR 加载并执行领域工具 |
| 真实脚本 | Python 3.9.9 JSON 输入输出、JDK 8 `javac → java` 技能链通过 |

机器可读结果：`target/verification-results.json`、`target/package-smoke-results.json`，源码包和运行包均附带这些记录。

## 测试内容

测试覆盖 JSON/Schema 校验、便携路径与配额、文件事务回滚和锁、事务引用隔离、损坏存储拒绝启动、实际令牌认证、Origin 拒绝、用户所有权、角色权限交集、请求幂等、确认参数快照、拒绝不写入、取消与预算、消息/提醒注入、提醒次数、会话单运行限制、SSE 事件、MCP stdio 握手与分页、HTTP JSON/SSE 和会话头、错误响应 ID、远程写入失败不自动重试、进程环境/超时/输出限额、技能版本、外部 XML 实体拒绝、DOCX 解压限额和重启恢复。

## 明确未验证的部分

- Windows 创建符号链接需要额外权限，本次相关用例标记为 **SKIP**，没有伪报通过；路径穿越、保留名等其余文件限制已执行。
- 没有可用 Linux 环境，本次未执行 Linux 实机测试。已提供相同测试代码、Linux 构建脚本和 Windows/Linux JDK 8 CI 矩阵，CI 未在此环境实际触发。
- 没有在本机测试 Bash 与 C++ 工具链；提供的是运行/编译配置模板，需要按目标机器填写路径和依赖环境。
- 真实公司模型、IAM 和外部 MCP 服务不在本次环境内；模型 HTTP 合同与 MCP 通过本地协议模拟服务验证。
- 未提供也未验证 Windows Job Object、Linux cgroup 等 OS 强隔离适配器。`process.requireOsIsolation=true` 缺少适配器时拒绝启动的行为已验证。
- 没有 Maven 可执行程序，本次使用随附离线构建脚本；不把 Maven 构建配置视为已在本机执行的结果。

使用旧 JDK 8 是为了验证兼容性，交付不包含该 JDK，也不要求部署它；部署应使用公司维护的 Java 8 补丁版本。
