#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
if [ -n "${JAVA_HOME:-}" ]; then JAVAC="$JAVA_HOME/bin/javac"; JAVA="$JAVA_HOME/bin/java"; JAR="$JAVA_HOME/bin/jar"; else JAVAC=javac; JAVA=java; JAR=jar; fi
mkdir -p target
rm -rf target/classes target/test-classes
mkdir -p target/classes target/test-classes
find src/main/java -name '*.java' | sort | sed 's/.*/"&"/' > target/sources.txt
case "$($JAVA -version 2>&1)" in *'version "1.8.'*) COMPAT='-source 8 -target 8';; *) COMPAT='--release 8';; esac
"$JAVAC" $COMPAT -encoding UTF-8 -d target/classes @target/sources.txt
cp -R src/main/resources/. target/classes/
find src/test/java -name '*.java' | sort | sed 's/.*/"&"/' > target/tests.txt
"$JAVAC" $COMPAT -encoding UTF-8 -cp target/classes -d target/test-classes @target/tests.txt
AGENT_TEST_TOKEN=test-only-token-abcdefghijklmnopqrstuvwxyz "$JAVA" -ea -cp target/classes:target/test-classes io.yunfan.agent.Tests
"$JAR" cfe target/agent-jdk8-1.0.0.jar io.yunfan.agent.Main -C target/classes .
echo 'Built target/agent-jdk8-1.0.0.jar'
