#!/usr/bin/env python3
"""Optional release packager. Never includes live data, tokens, local config or test workspaces."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
PREFIX = "yunfan-agent-jdk8/"


def package(name, files):
    path = DIST / name
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(set(files)):
            relative = file.relative_to(ROOT).as_posix()
            if relative == "config/local.properties":
                continue
            info = zipfile.ZipInfo.from_file(file, PREFIX + relative)
            if file.suffix == ".sh":
                info.external_attr = 0o100755 << 16
            archive.writestr(info, file.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)
    return path


def main():
    DIST.mkdir(exist_ok=True)
    jar = ROOT / "target/agent-jdk8-1.0.0.jar"
    required = [jar, ROOT / "target/verification-results.json", ROOT / "target/package-smoke-results.json"]
    for file in required:
        if not file.is_file():
            raise SystemExit("Build and verify first: missing " + str(file))
    common = [ROOT / "README.md"]
    for directory in ("config", "skills", "docs", "examples", "scripts"):
        common += [p for p in (ROOT / directory).rglob("*") if p.is_file() and "__pycache__" not in p.parts]
    runtime = common + required
    if (ROOT / "target/quality-extension.jar").exists():
        runtime.append(ROOT / "target/quality-extension.jar")
    source = common + [ROOT / "pom.xml", ROOT / ".gitattributes", ROOT / ".gitignore"]
    for directory in ("src", ".github"):
        source += [p for p in (ROOT / directory).rglob("*") if p.is_file()]
    source += required[1:]
    archives = [package("yunfan-agent-jdk8-1.0.0-source.zip", source), package("yunfan-agent-jdk8-1.0.0-runtime.zip", runtime)]
    lines = [hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.name for p in archives]
    (DIST / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
