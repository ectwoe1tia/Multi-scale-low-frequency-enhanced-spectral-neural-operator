param([string]$JavaHome = $env:JAVA_HOME)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
if (-not $JavaHome) { $JavaHome = Split-Path -Parent (Split-Path -Parent (Get-Command javac).Source) }
$javac = Join-Path $JavaHome 'bin\javac.exe'
$java = Join-Path $JavaHome 'bin\java.exe'
$jar = Join-Path $JavaHome 'bin\jar.exe'
if (-not (Test-Path -LiteralPath $javac)) { throw 'A full JDK 8 or newer is required.' }
$targetRoot = Join-Path $projectRoot 'target'
foreach ($name in @('classes','test-classes')) {
    $target = [IO.Path]::GetFullPath((Join-Path $targetRoot $name))
    if (-not $target.StartsWith($projectRoot + [IO.Path]::DirectorySeparatorChar)) { throw 'Unsafe output path' }
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
    New-Item -ItemType Directory -Path $target -Force | Out-Null
}
$ErrorActionPreference = 'Continue'
$version = (& $java -version 2>&1 | Out-String)
$versionExit = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
if ($versionExit -ne 0) { throw 'Cannot run the selected JDK' }
$compat = if ($version -match 'version "1\.8\.') { @('-source','8','-target','8') } else { @('--release','8') }
$utf8 = New-Object System.Text.UTF8Encoding($false)
$sources = @(Get-ChildItem -LiteralPath 'src\main\java' -Filter '*.java' -Recurse | ForEach-Object { '"' + $_.FullName.Replace('\','/') + '"' })
[IO.File]::WriteAllLines((Join-Path $targetRoot 'sources.txt'), $sources, $utf8)
& $javac @compat -encoding UTF-8 -d target/classes '@target/sources.txt'
if ($LASTEXITCODE -ne 0) { throw 'Main compilation failed' }
Copy-Item -Path 'src\main\resources\*' -Destination 'target\classes' -Recurse -Force
$tests = @(Get-ChildItem -LiteralPath 'src\test\java' -Filter '*.java' -Recurse | ForEach-Object { '"' + $_.FullName.Replace('\','/') + '"' })
[IO.File]::WriteAllLines((Join-Path $targetRoot 'tests.txt'), $tests, $utf8)
& $javac @compat -encoding UTF-8 -cp target/classes -d target/test-classes '@target/tests.txt'
if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed' }
$env:AGENT_TEST_TOKEN = 'test-only-token-abcdefghijklmnopqrstuvwxyz'
& $java -ea -cp 'target/classes;target/test-classes' io.yunfan.agent.Tests
if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
& $jar cfe target/agent-jdk8-1.0.0.jar io.yunfan.agent.Main -C target/classes .
if ($LASTEXITCODE -ne 0) { throw 'JAR packaging failed' }
Write-Host 'Built target/agent-jdk8-1.0.0.jar'
