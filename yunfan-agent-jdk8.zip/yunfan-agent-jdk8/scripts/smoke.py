#!/usr/bin/env python3
"""Exercise the built JAR in a separate JVM, including real Python/Java skills and ServiceLoader."""
import argparse
import base64
import io
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))
CHECKS = []


def require(condition, name):
    if not condition:
        raise AssertionError(name)
    CHECKS.append(name)
    print("PASS", name)


def request(port, method, path, body=None, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path), data=data, headers=headers, method=method)
    try:
        response = OPENER.open(req, timeout=10)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        raw = response.read().decode("utf-8")
        return response.status, json.loads(raw) if raw else None


def wait_run(port, run_id, token, wanted):
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        status, run = request(port, "GET", "/api/runs/" + run_id, token=token)
        if status != 200:
            raise AssertionError(run)
        if run["status"] in wanted:
            return run
        if run["status"] in ("FAILED", "EXPIRED", "CANCELLED", "RECONCILIATION_REQUIRED"):
            raise AssertionError(run)
        time.sleep(.05)
    raise AssertionError("Run did not reach " + str(wanted))


def start(java, directory, plugin, env):
    command = [str(java), "-Xmx256m"]
    if plugin:
        command += ["-cp", os.pathsep.join([str(ROOT / "target/agent-jdk8-1.0.0.jar"), str(ROOT / "target/quality-extension.jar")]), "io.yunfan.agent.Main"]
    else:
        command += ["-jar", str(ROOT / "target/agent-jdk8-1.0.0.jar")]
    command += [str(directory / "config/application.properties")]
    process = subprocess.Popen(command, cwd=str(directory), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, encoding="utf-8", errors="replace",
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    lines = queue.Queue()
    threading.Thread(target=lambda: [lines.put(line) for line in process.stdout], daemon=True).start()
    deadline = time.monotonic() + 15
    log = []
    while time.monotonic() < deadline:
        try:
            line = lines.get(timeout=.2)
            log.append(line)
            match = re.search(r"Agent ready at http://[^:]+:(\d+)", line)
            if match:
                return process, int(match.group(1))
        except queue.Empty:
            if process.poll() is not None:
                break
    process.kill()
    process.wait(timeout=5)
    raise RuntimeError("JAR did not start: " + "".join(log))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--java-home", required=True)
    args = parser.parse_args()
    jdk = Path(args.java_home).resolve()
    suffix = ".exe" if os.name == "nt" else ""
    java = jdk / "bin" / ("java" + suffix)
    javac = jdk / "bin" / ("javac" + suffix)
    work = Path(tempfile.mkdtemp(prefix="package-smoke-", dir=str(ROOT / "target")))
    shutil.copytree(ROOT / "config", work / "config")
    shutil.copytree(ROOT / "skills", work / "skills")
    (work / "config/application.properties").write_text(
        "server.host=127.0.0.1\nserver.port=0\nauth.mode=token\nprocess.enabled=true\nmodel.provider=mock\n"
        "mcp.exposeTools=time_now,quality_checklist\n", encoding="utf-8")
    runtimes = json.loads((work / "config/processes.json").read_text(encoding="utf-8"))
    runtimes["python"] = {"command": [os.path.abspath(os.sys.executable), "-I", "-u", "{entry}"]}
    runtimes["java-echo"] = {
        "prepare": [[str(javac), "-encoding", "UTF-8", "-d", "{work}", "{entry}"]],
        "command": [str(java), "-Xmx64m", "-cp", "{work}", "Echo"]}
    (work / "config/processes.json").write_text(json.dumps(runtimes), encoding="utf-8")
    skill = work / "skills/java_echo"
    skill.mkdir()
    shutil.copyfile(ROOT / "examples/Echo.java", skill / "Echo.java")
    (skill / "SKILL.md").write_text("---\nname: java_echo\ntype: script\nruntime: java-echo\nentrypoint: Echo.java\ntimeoutSeconds: 15\n---\nJava 8 compilation test.", encoding="utf-8")
    profiles = json.loads((work / "config/profiles.json").read_text(encoding="utf-8"))
    profiles.append({"id": "java-demo", "extends": "general", "skills": ["java_echo"], "tools": ["skill_java_echo_run"]})
    profiles.append(json.loads((ROOT / "examples/quality-profile.json").read_text(encoding="utf-8")))
    (work / "config/profiles.json").write_text(json.dumps(profiles), encoding="utf-8")
    token = "package-smoke-only-" + os.urandom(20).hex()
    env = dict(os.environ, AGENT_API_TOKEN=token)
    process, port = start(java, work, False, env)
    try:
        require(request(port, "GET", "/health")[0] == 200, "standalone JAR health")
        require(request(port, "GET", "/api/runs")[0] == 401, "packaged token authentication")
        status, profiles_response = request(port, "GET", "/api/profiles", token=token)
        require(status == 200 and any(p["id"] == "document-review" for p in profiles_response), "default profiles and text skills load")
        status, capabilities = request(port, "GET", "/api/capabilities", token=token)
        require(status == 200 and capabilities["java"].startswith("1.8."), "actual JDK 8 runtime")
        require(capabilities["process"]["osIsolation"] is False, "sandbox capability truthfully reported")
        status, upload = request(port, "POST", "/api/files", {"path": "sample.md", "content": "公司文档正文"}, token)
        require(status == 201, "UTF-8 document upload")
        status, run = request(port, "POST", "/api/runs", {"requestId": "text", "profile": "document-review", "message": '/tool documents_extract {"path":"sample.md"}'}, token)
        done = wait_run(port, run["id"], token, {"COMPLETED"})
        require("公司文档正文" in done["answer"], "document-review tool pipeline")
        for profile, tool in [("python-demo", "skill_json_echo_run"), ("java-demo", "skill_java_echo_run")]:
            status, run = request(port, "POST", "/api/runs", {"requestId": profile, "profile": profile, "message": '/tool %s {"text":"实际脚本输入"}' % tool}, token)
            pending = wait_run(port, run["id"], token, {"WAITING_APPROVAL"})
            require(pending["approval"]["risk"] == "HIGH", profile + " requires confirmation")
            request(port, "POST", "/api/runs/" + run["id"] + "/approvals/" + pending["approval"]["id"], {"approved": True}, token)
            done = wait_run(port, run["id"], token, {"COMPLETED"})
            require("实际脚本输入" in done["answer"], profile + " real interpreter/compiler execution")
        status, persisted = request(port, "POST", "/api/runs", {"requestId": "persisted", "message": "persist me"}, token)
        wait_run(port, persisted["id"], token, {"COMPLETED"})
    finally:
        process.terminate()
        process.wait(timeout=10)
    process, port = start(java, work, True, env)
    try:
        require(request(port, "GET", "/api/runs/" + persisted["id"], token=token)[1]["status"] == "COMPLETED", "restart retains committed runs")
        rpc = {"jsonrpc": "2.0", "id": "plugin", "method": "tools/call", "params": {"name": "quality_checklist", "arguments": {"category": "release"}}}
        status, result = request(port, "POST", "/mcp", rpc, token)
        require(status == 200 and "回滚方案" in json.dumps(result, ensure_ascii=False), "ServiceLoader plugin JAR supplies a real domain tool")
    finally:
        process.terminate()
        process.wait(timeout=10)
    majors = set()
    with zipfile.ZipFile(ROOT / "target/agent-jdk8-1.0.0.jar") as jar:
        for name in jar.namelist():
            if name.endswith(".class"):
                majors.add(int.from_bytes(jar.read(name)[6:8], "big"))
    require(majors == {52}, "all packaged bytecode targets Java 8 (major 52)")
    report = {"passed": len(CHECKS), "checks": CHECKS, "javaHome": str(jdk), "python": os.sys.version,
              "platform": os.name, "finishedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    (ROOT / "target/package-smoke-results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Passed %d packaged checks" % len(CHECKS))


if __name__ == "__main__":
    main()
