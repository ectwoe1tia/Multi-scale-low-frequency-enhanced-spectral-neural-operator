#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
if [ -n "${JAVA_HOME:-}" ]; then JAVA="$JAVA_HOME/bin/java"; else JAVA=java; fi
exec "$JAVA" -Xms64m -Xmx256m -cp 'target/agent-jdk8-1.0.0.jar:lib/*' io.yunfan.agent.Main "${1:-config/application.properties}"
