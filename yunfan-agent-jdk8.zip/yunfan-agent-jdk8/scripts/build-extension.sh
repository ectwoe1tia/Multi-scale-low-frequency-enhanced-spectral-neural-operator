#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
if [ -n "${JAVA_HOME:-}" ]; then JAVAC="$JAVA_HOME/bin/javac"; JAR="$JAVA_HOME/bin/jar"; else JAVAC=javac; JAR=jar; fi
mkdir -p target/extension-classes
"$JAVAC" -source 8 -target 8 -encoding UTF-8 -cp target/agent-jdk8-1.0.0.jar -d target/extension-classes examples/extension/src/io/yunfan/example/QualityExtension.java
cp -R examples/extension/resources/. target/extension-classes/
"$JAR" cf target/quality-extension.jar -C target/extension-classes .
