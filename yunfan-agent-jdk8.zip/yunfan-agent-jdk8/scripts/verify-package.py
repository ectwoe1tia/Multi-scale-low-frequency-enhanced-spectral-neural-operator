#!/usr/bin/env python3
"""Validate release archives, then start the extracted runtime using a separate JDK 8 JVM."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
import zipfile
import smoke


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--java-home", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    dist = root / "dist"
    for line in (dist / "SHA256SUMS.txt").read_text().splitlines():
        digest, name = line.split("  ")
        assert hashlib.sha256((dist / name).read_bytes()).hexdigest() == digest
    checks = ["archive SHA-256 checksums"]
    for name in ("source", "runtime"):
        with zipfile.ZipFile(dist / ("yunfan-agent-jdk8-1.0.0-" + name + ".zip")) as archive:
            names = archive.namelist()
            assert names and all(n.startswith("yunfan-agent-jdk8/") and ".." not in PurePosixPath(n).parts for n in names)
            assert not any("/data/" in n or "/data-demo/" in n or n.endswith("config/local.properties") for n in names)
            assert "yunfan-agent-jdk8/README.md" in names
            if name == "source":
                assert "yunfan-agent-jdk8/src/main/java/io/yunfan/agent/Agent.java" in names
            else:
                assert archive.read("yunfan-agent-jdk8/target/agent-jdk8-1.0.0.jar") == (root / "target/agent-jdk8-1.0.0.jar").read_bytes()
                destination = Path(tempfile.mkdtemp(prefix="extracted-runtime-", dir=str(root / "target")))
                archive.extractall(destination)
        checks.append(name + " archive content and path validation")
    runtime = destination / "yunfan-agent-jdk8"
    configuration = runtime / "config/application.properties"
    configuration.write_text(configuration.read_text(encoding="utf-8").replace("server.port=8088", "server.port=0"), encoding="utf-8")
    smoke.ROOT = runtime
    token = "archive-verification-" + os.urandom(20).hex()
    java = Path(args.java_home) / "bin" / ("java.exe" if os.name == "nt" else "java")
    process, port = smoke.start(java, runtime, False, dict(os.environ, AGENT_API_TOKEN=token))
    try:
        assert smoke.request(port, "GET", "/health")[0] == 200
        assert smoke.request(port, "GET", "/api/profiles", token=token)[0] == 200
        checks.append("extracted runtime starts with standard token configuration")
    finally:
        process.terminate()
        process.wait(timeout=10)
    (dist / "archive-verification.json").write_text(json.dumps({"passed": len(checks), "checks": checks}, indent=2), encoding="utf-8")
    print("Passed %d archive checks" % len(checks))


if __name__ == "__main__":
    main()
