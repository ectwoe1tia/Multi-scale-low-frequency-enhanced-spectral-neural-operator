param([string]$JavaHome = $env:JAVA_HOME)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Split-Path -Parent $PSScriptRoot)
if (-not $JavaHome) { $JavaHome = Split-Path -Parent (Split-Path -Parent (Get-Command javac).Source) }
New-Item -ItemType Directory -Path 'target\extension-classes' -Force | Out-Null
& (Join-Path $JavaHome 'bin\javac.exe') -source 8 -target 8 -encoding UTF-8 -cp target/agent-jdk8-1.0.0.jar -d target/extension-classes examples/extension/src/io/yunfan/example/QualityExtension.java
if ($LASTEXITCODE -ne 0) { throw 'Extension compilation failed' }
Copy-Item -Path 'examples\extension\resources\*' -Destination 'target\extension-classes' -Recurse -Force
& (Join-Path $JavaHome 'bin\jar.exe') cf target/quality-extension.jar -C target/extension-classes .
if ($LASTEXITCODE -ne 0) { throw 'Extension packaging failed' }
Write-Host 'Built target/quality-extension.jar; copy to lib/ to enable it on restart.'
