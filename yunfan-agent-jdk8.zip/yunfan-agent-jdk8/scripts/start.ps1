param([string]$Config = 'config/application.properties', [string]$JavaHome = $env:JAVA_HOME)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Split-Path -Parent $PSScriptRoot)
$java = if ($JavaHome) { Join-Path $JavaHome 'bin\java.exe' } else { 'java' }
& $java -Xms64m -Xmx256m -cp 'target/agent-jdk8-1.0.0.jar;lib/*' io.yunfan.agent.Main $Config
exit $LASTEXITCODE
