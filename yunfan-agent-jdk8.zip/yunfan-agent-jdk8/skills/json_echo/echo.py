import json
import sys

request = json.load(sys.stdin)
print(json.dumps({"echo": request["arguments"], "runId": request["runId"]}, ensure_ascii=False))
