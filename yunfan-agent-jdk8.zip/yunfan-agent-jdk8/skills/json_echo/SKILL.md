---
name: json_echo
description: Demonstrate the JSON stdin/stdout contract for local scripts.
type: script
runtime: python
entrypoint: echo.py
timeoutSeconds: 10
---
使用 skill_json_echo_run 演示结构化输入和输出。该工具会启动本地 Python 子进程，需要用户确认。
