# workflow-testing v7 · 20261024

业务方只提供已有需求、设计、接口文档、系统规约和可选 Recorder/HAR，并说明测试目标。AI 负责内部配置、技术关系排查与调度；内核负责验证、执行、恢复和报告。

使用 [workflow-testing/SKILL.md](workflow-testing/SKILL.md) 后，可直接交代：

> 请根据这些资料覆盖报销流程的正常路径、权限和边界。资料在……，项目工作区使用……。先完成设计，再执行已授权且已连接的测试，给我报告。

无需业务方写 JSON、profile、绑定清单或脚本。程序内部保存这些产物，换模型后仍可通过同一工作区接续。中文业务说明与英文机器错误契约同时提供。

当前安装包只包含当前 v7 的27个文件，不带旧 session/batch 入口及历史路由文档。安装入口为 workflow-testing/SKILL.md；当前操作只有 open、advance、submit、inspect、report。日常使用由 AI 调用，业务方不必学习命令参数。

运行环境：Python3.9+、curl，Windows 可通过 PowerShell5.1/7 调用；PDF 文本提取使用可选 pypdf/PyPDF2。系统接入者提供测试环境和已有身份连接，身份不进入命令参数或对话。

执行模式需要已存在的用户授权。每次 open 选择设计模式或 Execute 模式，advance 沿用该模式；设计模式不发 HTTP。产品经理只需解释真正的业务冲突，环境与技术故障由 AI/系统接入者处理。

实现、验证与边界见 [REPORT.md](REPORT.md)；架构见 [DESIGN.md](DESIGN.md)。研发接续见 [handoff.json](handoff.json) 及包内 [职责契约](workflow-testing/docs/AGENT-KERNEL.md)。

本包未自动安装到全局目录，未修改系统执行策略，未连接公司真实接口。旧工作区保持原样，建议在独立工作区使用当前包。
