"""Offline structural/AST and temporal equality candidates; never execution authority."""
import ast
import datetime
import itertools
import json
import re
from collections import defaultdict
from urllib.parse import urlsplit,parse_qsl,unquote
from . import common as c

def leaves(value,prefix='',depth=0):
    if depth>20:return
    if isinstance(value,dict):
        for key,item in value.items():
            if not c.SECRET_KEYS.search(key):yield from leaves(item,prefix+'/'+key.replace('~','~0').replace('/','~1'),depth+1)
    elif isinstance(value,list):
        for i,item in enumerate(value[:100]):yield from leaves(item,prefix+'/'+str(i),depth+1)
    elif isinstance(value,(str,int,float)) and not isinstance(value,bool) and value not in ('','[REDACTED]',0,1):yield prefix,value

def configuration_summary(data):
    fields=list(itertools.islice(leaves(data),2001));issues=[];dependencies=[]
    for pointer,value in fields[:2000]:
        if isinstance(value,str) and ('\ufffd' in value or re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',value)):issues.append(pointer)
        if isinstance(value,str) and value.startswith('='):
            try:
                tree=ast.parse(value[1:],mode='eval')
                dependencies.append({'pointer':pointer,'reads':sorted({n.id for n in ast.walk(tree) if isinstance(n,ast.Name)})[:20],'interpretation':'syntax_reads_only'})
            except SyntaxError:issues.append(pointer)
    return {'root_type':type(data).__name__,'sampled_fields':min(2000,len(fields)),'truncated':len(fields)>2000,
            'suspicious_locations':issues[:10],'expression_dependencies':dependencies[:10],'values_omitted':True}

def timepoint(value):
    try:
        t=datetime.datetime.fromisoformat(value.replace('Z','+00:00'));return t.timestamp() if t.tzinfo else None
    except (ValueError,TypeError,AttributeError):return None

def match_path(template,path):
    names=[];parts=[];start=0
    for m in re.finditer(r'\{([A-Za-z][A-Za-z0-9_-]*)\}',template):
        names.append(m[1]);parts += [re.escape(template[start:m.start()]),'([^/]+)'];start=m.end()
    parts.append(re.escape(template[start:]));match=re.fullmatch(''.join(parts),path)
    return dict(zip(names,[unquote(v) for v in match.groups()])) if match else None

def analyze(root,db,ops,snapshot):
    from .storage import meta
    rows=db.execute("SELECT * FROM sources WHERE active=1 AND kind='har' ORDER BY path").fetchall()
    known=defaultdict(set);samples=defaultdict(list);seen=set();salt=meta(db,'salt');limited=False;budget=20000
    for source in rows:
        if source['sha'] in seen:continue
        seen.add(source['sha']);raw=c.read_json(c.workspace_path(root,source['copy'],True),32*c.MAX_BYTES);previous=[]
        events=sorted(raw['log']['entries'],key=lambda e:timepoint(e.get('startedDateTime')) or float('inf'))
        for event in events:
            start=timepoint(event.get('startedDateTime'));duration=event.get('time')
            if start is None or type(duration) not in (int,float) or duration<0:continue
            request,response=event['request'],event['response'];url=urlsplit(request.get('url',''))
            if url.scheme not in ('http','https') or not url.hostname or url.username or url.password:continue
            matches=[(key,match_path(op['path'],url.path)) for key,op in ops.items() if op['method']==request.get('method')]
            matches=[(key,params) for key,params in matches if params is not None]
            if len(matches)!=1:continue
            op,params=matches[0];origin=url.scheme+'://'+url.netloc
            def body(container):
                try:
                    if container.get('encoding') or len(container.get('text',''))>c.MAX_BYTES:return None
                    value=json.loads(container.get('text',''));c.encoded(value);return value
                except (ValueError,TypeError,AttributeError,RecursionError):return None
            inputs=list(itertools.islice(leaves({'params':params,'query':dict(parse_qsl(url.query)),'body':body(request.get('postData',{}))}),1001))
            reverse=defaultdict(set);fields=set()
            for previous_op,end,previous_origin,outputs in previous[-50:]:
                if end>start or previous_origin!=origin:continue
                for pointer,hashed in outputs:reverse[hashed].add((previous_op,pointer));fields.add((previous_op,pointer))
            for pointer,value in inputs[:1000]:
                hashed=c.digest([salt,type(value).__name__,value]);matching=reverse[hashed];target=(origin,op,pointer)
                identities=matching|(known[target]&fields);known[target].update(matching)
                if len(identities)>50:limited=True
                for producer,output in sorted(identities)[:50]:
                    samples[(origin,producer,output,op,pointer)].append((source['sha'],hashed,(producer,output) in matching,len(matching)))
                    budget-=1
                    if budget<=0:limited=True;break
                if budget<=0:break
            if len(inputs)>1000:limited=True
            outputs=list(itertools.islice(leaves({'body':body(response.get('content',{}))}),1001))
            if len(outputs)>1000:limited=True
            if type(response.get('status')) is int and 200<=response['status']<300:
                previous.append((op,start+duration/1000,origin,[(p,c.digest([salt,type(v).__name__,v])) for p,v in outputs[:1000]]));previous=previous[-50:]
            if budget<=0:break
        if budget<=0:break
    db.execute('DELETE FROM relations')
    for key,items in samples.items():
        yes=[x for x in items if x[2]]
        if not yes:continue
        episodes=len({x[0] for x in yes});values=len({x[1] for x in yes});counter=sum(not x[2] for x in items)
        state='TRUNCATED' if limited else 'CONTRADICTED' if counter else 'AMBIGUOUS' if any(x[3]>1 for x in yes) else 'SUPPORTED_OBSERVATION' if episodes>=2 and values>=2 else 'CANDIDATE'
        result=dict(origin=key[0],producer=key[1],output=key[2],consumer=key[3],input=key[4],state=state,episodes=episodes,
                    distinct_values=values,support_samples=len(yes),counterexamples=counter,automatic_binding=False)
        db.execute('INSERT INTO relations VALUES(?,?,?)',('REL-'+c.digest(key)[:24],c.encoded(result),snapshot))
