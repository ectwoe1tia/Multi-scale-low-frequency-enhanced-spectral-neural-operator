"""Bounded local primitives shared by current contracts and extractors."""
import hashlib
import json
import math
import os
import re
import uuid
from pathlib import Path
from .contract import Fault,require

MAX_BYTES=1024*1024
MISSING=object()
SECRET_KEYS=re.compile(r'password|passwd|secret|token|authorization|cookie|api.?key',re.I)
IDENT=re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,59}$')
READ_METHODS={'GET','HEAD'}
METHODS={'GET','HEAD','POST','PUT','PATCH','DELETE'}
OPERATORS={'eq','ne','contains','exists','not_exists','gt','gte','lt','lte'}

def encoded(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(value):return hashlib.sha256(encoded(value).encode('utf-8')).hexdigest()
def file_hash(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_json(path,max_bytes=MAX_BYTES):
    path=Path(path)
    require(path.stat().st_size<=max_bytes,detail='JSON size limit')
    def pairs(items):
        value={}
        for key,item in items:
            require(key not in value,detail='Duplicate JSON key')
            value[key]=item
        return value
    def constant(value):raise Fault('DECISION_INVALID',detail='Nonfinite JSON constant')
    try:return json.loads(path.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs,parse_constant=constant)
    except (ValueError,UnicodeError,RecursionError) as exc:raise Fault('DECISION_INVALID',detail=type(exc).__name__) from exc

def write(path,value):
    data=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    write_bytes(path,data)

def write_bytes(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temporary.open('xb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
    except OSError as exc:raise Fault('IO_ERROR',detail=type(exc).__name__) from exc
    finally:
        if temporary.exists():temporary.unlink()

def workspace_path(root,relative,existing=False):
    root=Path(root).resolve()
    require(isinstance(relative,str) and relative and not Path(relative).is_absolute() and not re.match(r'^[A-Za-z]:',relative),pointer='/path')
    path=(root/relative).resolve()
    require(path!=root and root in path.parents,pointer='/path')
    require(not existing or path.is_file(),pointer='/path')
    return path

def shape(value,required,optional=(),pointer=''):
    require(isinstance(value,dict),pointer=pointer,detail='object required')
    require(set(required)<=value.keys() and value.keys()<=set(required)|set(optional),pointer=pointer,
            detail={'missing':sorted(set(required)-value.keys()),'unknown':sorted(value.keys()-set(required)-set(optional))})

def ident(value,pointer=''):
    require(isinstance(value,str) and IDENT.fullmatch(value),pointer=pointer)
    return value

def json_pointer(document,pointer):
    require(isinstance(pointer,str) and (pointer=='' or pointer.startswith('/')) and not re.search(r'~(?![01])',pointer),pointer='/pointer')
    value=document
    for part in pointer.split('/')[1:] if pointer else []:
        part=part.replace('~1','/').replace('~0','~')
        if isinstance(value,dict) and part in value:value=value[part]
        elif isinstance(value,list) and re.fullmatch(r'0|[1-9][0-9]*',part) and int(part)<len(value):value=value[int(part)]
        else:return MISSING
    return value

def refs(value,depth=0):
    require(depth<=40,detail='Template nesting exceeds current limit')
    if isinstance(value,str):
        match=re.fullmatch(r'\$\{([A-Za-z][A-Za-z0-9_-]{0,59})\}',value)
        if match:return {match[1]}
        require('${' not in value,detail='Whole-value references only')
    if isinstance(value,dict):return set().union(*(refs(v,depth+1) for v in value.values())) if value else set()
    if isinstance(value,list):return set().union(*(refs(v,depth+1) for v in value)) if value else set()
    return set()

def substitute(value,context,depth=0):
    require(depth<=40,detail='Template nesting exceeds current limit')
    if isinstance(value,str) and re.fullmatch(r'\$\{[A-Za-z][A-Za-z0-9_-]{0,59}\}',value):return context[value[2:-1]]
    if isinstance(value,dict):return {k:substitute(v,context,depth+1) for k,v in value.items()}
    if isinstance(value,list):return [substitute(v,context,depth+1) for v in value]
    return value

def redact(value,secrets=()):
    if value is MISSING:return {'missing':True}
    if isinstance(value,dict):return {k:'[REDACTED]' if SECRET_KEYS.search(k) else redact(v,secrets) for k,v in value.items()}
    if isinstance(value,list):return [redact(v,secrets) for v in value]
    if isinstance(value,str):
        value=re.sub(r'(?i)(bearer\s+)[A-Za-z0-9._~+/-]+=*',r'\1[REDACTED]',value)
        for secret in sorted((s for s in secrets if s),key=len,reverse=True):value=value.replace(secret,'[REDACTED]')
    return value

def compare(actual,op,expected=MISSING):
    if op=='exists':return actual is not MISSING
    if op=='not_exists':return actual is MISSING
    if actual is MISSING:return False
    if op in ('eq','ne'):return (encoded(actual)==encoded(expected))==(op=='eq')
    if op=='contains':
        return any(encoded(x)==encoded(expected) for x in actual) if isinstance(actual,list) else isinstance(actual,str) and isinstance(expected,str) and expected in actual
    if type(actual) not in (int,float) or type(expected) not in (int,float):return False
    return {'gt':actual>expected,'gte':actual>=expected,'lt':actual<expected,'lte':actual<=expected}[op]

# The retained document extractor uses these primitive helpers, not a legacy protocol.
def need(condition,message,code='INVALID_INPUT'):
    if not condition:raise ToolError(code,message)
class ToolError(Fault):
    def __init__(self,code,message):
        super().__init__('SOURCE_UNREADABLE' if code in ('DEPENDENCY_MISSING','DOCUMENT_LOCKED') else 'SOURCE_CORRUPT',detail=message)

def fingerprint(names):
    folder=Path(__file__).parent
    return digest({name:file_hash(folder/name) for name in names})
