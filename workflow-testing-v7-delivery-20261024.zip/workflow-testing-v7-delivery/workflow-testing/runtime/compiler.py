"""Cited current decision IR -> validated deterministic cases, no transport."""
import json
import re
from urllib.parse import urlsplit
from . import common as c
from .contract import Fault,require,PAYLOAD_FIELDS,STEP_FIELDS

KINDS={'requirement','convention','scenario','query_strategy','unknown'}
CATEGORIES={'happy_path','boundary','validation','permission','transition','parallel','idempotency','concurrency','recovery','integration','timing','data_consistency','compatibility','performance'}

def operations(db):
    result={}
    for row in db.execute("SELECT chunks.id,text FROM chunks JOIN sources ON sources.id=source WHERE active=1 AND kind='document'"):
        for match in re.finditer(r'\b(GET|HEAD|POST|PUT|PATCH|DELETE)\s+(/[^\s`，。,;；|]+)',row['text']):
            path=match[2]
            try:check_path(path)
            except Fault:continue
            key=match[1]+' '+path
            result.setdefault(key,{'method':match[1],'path':path,'chunks':[]})['chunks'].append(row['id'])
    return result

def check_path(path):
    require(isinstance(path,str) and path.startswith('/') and not path.startswith('//') and not any(x in path for x in ('?','#','%','\\')) and '..' not in path.split('/'),pointer='/operation/path')
    require(not any(ch.isspace() or ord(ch)<32 for ch in path) and len(path)<=500,pointer='/operation/path')
    names=re.findall(r'\{([A-Za-z][A-Za-z0-9_-]{0,59})\}',path)
    rest=re.sub(r'\{[A-Za-z][A-Za-z0-9_-]{0,59}\}','',path)
    require('{' not in rest and '}' not in rest and len(names)==len(set(names)),pointer='/operation/path')
    return set(names)

def citations(db,value,document=True):
    require(isinstance(value,list) and 1<=len(value)<=20,pointer='/citations')
    for cite in value:
        c.shape(cite,['chunk','quote'],pointer='/citations')
        row=db.execute('SELECT chunks.*,kind,active FROM chunks JOIN sources ON sources.id=source WHERE chunks.id=?',(cite['chunk'],)).fetchone()
        require(row and row['active'] and isinstance(cite['quote'],str) and 4<=len(cite['quote'])<=800 and cite['quote'] in row['text'],
                'EVIDENCE_MISMATCH',pointer='/citations')
        require(not document or row['kind']=='document','EVIDENCE_MISMATCH',detail='Normative claims cannot come from traces')

def valid_facts(db,fingerprint):
    result=[]
    for row in db.execute('SELECT * FROM facts f WHERE revision=(SELECT MAX(revision) FROM facts WHERE name=f.name) ORDER BY name'):
        fact=dict(row)
        if fact['fingerprint']!=fingerprint:continue
        fact['payload']=json.loads(fact['payload']);fact['citations']=json.loads(fact['citations'])
        try:citations(db,fact['citations'],document=fact['kind']!='unknown')
        except Fault:continue
        result.append(fact)
    return result

def validate_finding(db,fact):
    c.shape(fact,['name','kind','summary','citations','payload'],pointer='/findings')
    c.ident(fact['name'],'/findings/name')
    require(fact['kind'] in KINDS and isinstance(fact['summary'],str) and 1<=len(fact['summary'])<=800,pointer='/findings')
    citations(db,fact['citations'],document=fact['kind']!='unknown')
    p=fact['payload']
    c.shape(p,*PAYLOAD_FIELDS[fact['kind']],pointer='/payload')
    if fact['kind']=='convention':
        policy(p)
    elif fact['kind']=='scenario':
        require(p['category'] in CATEGORIES and p['priority'] in ('P0','P1','P2','P3') and isinstance(p['vars'],dict) and isinstance(p['bindings'],dict),pointer='/payload')
        require(p.get('mode','test') in ('test','probe') and isinstance(p.get('depends_on',[]),list),pointer='/payload')
        if p.get('mode')=='probe':require(isinstance(p.get('question'),str) and p['question'],pointer='/payload/question')
        require(isinstance(p['steps'],list) and 1<=len(p['steps'])<=40,pointer='/payload/steps')
        for index,step in enumerate(p['steps']):step_shape(step,'/payload/steps/'+str(index))
    elif fact['kind']=='query_strategy':
        require(all(isinstance(p[x],str) and p[x] for x in ('goal','first_query')) and all(isinstance(p[x],list) and all(isinstance(v,str) and v for v in p[x]) for x in ('variables','prerequisites')),pointer='/payload')
    else:
        require(all(isinstance(v,str) and v for v in p.values()) and p.get('target','TECHNICAL') in ('BUSINESS','SYSTEM','TECHNICAL'),pointer='/payload')

def headers(value):
    require(isinstance(value,dict) and len(value)<=32,pointer='/headers')
    for name,item in value.items():
        require(isinstance(name,str) and re.fullmatch(r'[A-Za-z][A-Za-z0-9-]{0,63}',name) and name.lower() not in
                {'host','authorization','cookie','content-length','content-type','connection','transfer-encoding','proxy-authorization'},pointer='/headers')
        if isinstance(item,dict):c.shape(item,['env'],pointer='/headers');env_name(item['env'])
        else:require(isinstance(item,str) and len(item)<=4096 and all(32<=ord(ch)<=126 for ch in item),pointer='/headers')

def env_name(name,empty=False):
    require(isinstance(name,str) and ((empty and name=='') or re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',name)),pointer='/env')
    require(name.upper() not in {'PATH','HOME','USERPROFILE','SYSTEMROOT','COMSPEC','TEMP','TMP','PATHEXT','CODEX_HOME'} and not name.upper().startswith(('LD_','DYLD_','PYTHON','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY')),pointer='/env')

def policy(p):
    origin=urlsplit(p['base_url'])
    require(origin.scheme in ('http','https') and origin.hostname and not origin.username and not origin.password and origin.path in ('','/') and not origin.query and not origin.fragment,'POLICY_DENIED')
    try:origin.port
    except ValueError:raise Fault('POLICY_DENIED') from None
    local=origin.hostname in ('127.0.0.1','localhost','::1')
    c.shape(p['environment'],['name','kind','release'],pointer='/environment')
    require(p['environment']['kind'] in ('local','test','uat') and all(isinstance(p['environment'][k],str) and p['environment'][k] and '*' not in p['environment'][k] for k in ('name','release')),'POLICY_DENIED')
    require((origin.scheme=='https' or local) and (p['environment']['kind']!='local' or local),'POLICY_DENIED')
    require(type(p['allow_mutations']) is bool and isinstance(p['actors'],dict) and p['actors'],pointer='/actors')
    for actor,spec in p['actors'].items():
        c.ident(actor,'/actors');c.shape(spec,['bearer_token_env'],['headers'],pointer='/actors/'+actor)
        env_name(spec['bearer_token_env'],empty=local and p['environment']['kind']=='local')
        headers(spec.get('headers',{}))
    headers(p.get('headers',{}))
    require(type(p.get('timeout_seconds',5)) in (int,float) and 1<=p.get('timeout_seconds',5)<=30,pointer='/timeout_seconds')
    require(isinstance(p.get('deny',[]),list) and isinstance(p.get('allow',[]),list),pointer='/allow')
    for rule in p.get('allow',[]):
        c.shape(rule,['operation','actors'],['guards','headers'],pointer='/allow')
        require(isinstance(rule['actors'],list) and rule['actors'] and set(rule['actors'])<=set(p['actors']),pointer='/allow/actors')
        headers(rule.get('headers',{}))
        for guard in rule.get('guards',[]):
            c.shape(guard,['pointer','op'],['expected'],pointer='/allow/guards');validate_check(guard,False)

def step_shape(step,pointer):
    c.shape(step,*STEP_FIELDS,pointer=pointer)
    c.ident(step['id'],pointer+'/id')
    require(all(isinstance(step[k],dict) for k in ('params','query','capture')) and isinstance(step['checks'],list) and step['checks'],pointer=pointer)
    require(step.get('response_format','json') in ('json','text'),pointer=pointer+'/response_format')
    headers(step.get('headers',{}))
    for check in step['checks']:validate_check(check)

def validate_check(check,with_id=True):
    c.shape(check,['id','pointer','op'] if with_id else ['pointer','op'],['expected'],pointer='/checks')
    if with_id:c.ident(check['id'],'/checks/id')
    require(check['op'] in c.OPERATORS and isinstance(check['pointer'],str) and check['pointer'].startswith('/'),pointer='/checks')
    c.json_pointer({},check['pointer'])
    require(('expected' in check)==(check['op'] not in ('exists','not_exists')),pointer='/checks/expected')

def bundle(db,facts):
    conventions=[f for f in facts if f['kind']=='convention']
    require(len(conventions)==1,'RELATION_UNRESOLVED',detail='Exactly one current test convention is needed')
    p=conventions[0]['payload'];policy(p);ops=operations(db)
    cases=[];faults=[]
    probes={}
    for fact in [f for f in facts if f['kind']=='scenario']:
        try:
            case=case_definition(db,fact,p,ops)
            if case['mode']=='probe':
                probes[case['question']]=probes.get(case['question'],0)+1
                require(probes[case['question']]<=3 and len(case['steps'])<=2,'BUDGET_EXHAUSTED')
            cases.append(case)
        except Fault as exc:faults.append({'case':fact['name'],'code':exc.code,'pointer':exc.pointer})
    while True:
        ids={case['id'] for case in cases}
        blocked=[case for case in cases if not set(case['depends_on'])<=ids or case['id'] in case['depends_on']]
        if not blocked:break
        names={case['id'] for case in blocked}
        faults += [{'case':case['id'],'code':'RELATION_UNRESOLVED','pointer':'/depends_on'} for case in blocked]
        cases=[case for case in cases if case['id'] not in names]
    pending={case['id']:set(case['depends_on']) for case in cases};ordered=[]
    while pending:
        ready=sorted(k for k,v in pending.items() if not v)
        if not ready:
            faults += [{'case':key,'code':'RELATION_UNRESOLVED','pointer':'/depends_on'} for key in pending]
            break
        ordered+=ready
        for key in ready:pending.pop(key)
        for deps in pending.values():deps.difference_update(ready)
    return {'policy':p,'cases':[next(ca for ca in cases if ca['id']==key) for key in ordered],'faults':faults,
            'fact_ids':[f['id'] for f in facts]}

def case_definition(db,fact,p,ops):
    payload=fact['payload'];known=set(payload['vars'])|{'run_id','operation_intent_id'};producers={};steps=[];ids=set();check_ids=set()
    require(not c.refs(payload['vars']) and not {'run_id','operation_intent_id'}&set(payload['vars']),pointer='/vars')
    for name in payload['vars']:c.ident(name,'/vars')
    for step in payload['steps']:
        step_shape(step,'/steps')
        require(step['id'] not in ids,pointer='/steps/id');ids.add(step['id'])
        require(step['operation'] in ops,'POLICY_DENIED',detail='Undeclared operation')
        op=ops[step['operation']]
        require(step['operation'] not in p.get('deny',[]),'POLICY_DENIED')
        rules=[r for r in p.get('allow',[]) if r['operation']==step['operation']]
        require(not p.get('allow') or rules,'POLICY_DENIED')
        require(step['actor'] in p['actors'] and all(step['actor'] in r['actors'] for r in rules),'POLICY_DENIED')
        require((p['allow_mutations'] and payload.get('mode','test')!='probe') or op['method'] in c.READ_METHODS,'POLICY_DENIED')
        require(set(step['params'])==check_path(op['path']) and (op['method'] not in c.READ_METHODS or step['body'] is None),pointer='/params')
        require(not any(c.SECRET_KEYS.search(k) for k in step['query']),'POLICY_DENIED')
        used=c.refs({k:step.get(k) for k in ('params','query','body','checks','headers')})|c.refs(payload.get('headers',{}))
        require(used<=known,pointer='/steps',detail='Variable used before definition')
        for variable in used&set(producers):
            binding=payload['bindings'].get(variable)
            if not isinstance(binding,dict):raise Fault('RELATION_UNRESOLVED',pointer='/bindings/'+variable)
            c.shape(binding,['source_step','pointer','rationale','citations'],pointer='/bindings')
            require((binding['source_step'],binding['pointer'])==producers[variable],'RELATION_UNRESOLVED')
            require(isinstance(binding['rationale'],str) and binding['rationale'],pointer='/bindings/rationale');citations(db,binding['citations'])
        require(any(check['pointer']=='/status_code' and check['op']=='eq' and type(check.get('expected')) is int and 100<=check['expected']<=599 for check in step['checks']),pointer='/checks',detail='Explicit HTTP status required')
        for check in step['checks']:
            require(check['id'] not in check_ids,pointer='/checks/id');check_ids.add(check['id'])
        for name,pointer in step['capture'].items():
            c.ident(name,'/capture');c.json_pointer({},pointer)
            require(name not in known and pointer.startswith('/') and not c.SECRET_KEYS.search(pointer),'POLICY_DENIED')
            known.add(name);producers[name]=(step['id'],pointer)
        if 'poll' in step:
            c.shape(step['poll'],['attempts','interval_seconds'],pointer='/poll')
            require(op['method'] in c.READ_METHODS and type(step['poll']['attempts']) is int and 1<=step['poll']['attempts']<=6 and type(step['poll']['interval_seconds']) in (int,float) and .05<=step['poll']['interval_seconds']<=2,'POLICY_DENIED')
        if 'reconcile' in step:
            r=step['reconcile'];c.shape(r,['operation','actor','params','query','checks'],pointer='/reconcile')
            require(r['operation'] in ops and ops[r['operation']]['method'] in c.READ_METHODS and r['operation'] not in p.get('deny',[]),'POLICY_DENIED')
            require(r['actor'] in p['actors'] and set(r['params'])==check_path(ops[r['operation']]['path']) and c.refs(r)<=known-set(step['capture']),pointer='/reconcile')
            reconcile_rules=[rule for rule in p.get('allow',[]) if rule['operation']==r['operation']]
            require((not p.get('allow') or reconcile_rules) and all(r['actor'] in rule['actors'] for rule in reconcile_rules),'POLICY_DENIED')
            require(isinstance(r['checks'],list) and r['checks'] and any(x['pointer']!='/status_code' for x in r['checks']),pointer='/reconcile/checks',detail='Conclusive identity/effect check required')
            for check in r['checks']:validate_check(check)
            step=dict(step,reconcile=dict(r,operation_spec=ops[r['operation']]))
        steps.append(dict(step,operation_spec=op,guards=[g for rule in rules for g in rule.get('guards',[])],
                          operation_headers={k:v for rule in rules for k,v in rule.get('headers',{}).items()}))
    return {'id':fact['name'],'title':fact['summary'],'category':payload['category'],'priority':payload['priority'],
            'mode':payload.get('mode','test'),'question':payload.get('question',''),'vars':payload['vars'],
            'headers':payload.get('headers',{}),'depends_on':payload.get('depends_on',[]),'steps':steps,'citations':fact['citations']}
