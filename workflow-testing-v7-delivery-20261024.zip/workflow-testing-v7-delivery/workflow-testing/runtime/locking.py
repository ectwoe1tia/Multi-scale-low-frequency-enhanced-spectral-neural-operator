"""OS-owned local lock; the stable lock file is never unlinked or replaced."""
import contextlib
import os
import time
from pathlib import Path
from .contract import Fault

@contextlib.contextmanager
def exclusive(root,attempts=3):
    path=Path(root)/'system/workspace.lock';path.parent.mkdir(parents=True,exist_ok=True)
    stream=path.open('a+b');acquired=False
    os.set_inheritable(stream.fileno(),False)
    try:
        if path.stat().st_size==0:stream.write(b'0');stream.flush()
        for attempt in range(attempts):
            try:
                stream.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                acquired=True;break
            except OSError:
                if attempt+1<attempts:time.sleep(.05*(attempt+1))
        if not acquired:raise Fault('WORKSPACE_BUSY',scope='WORKSPACE')
        yield
    finally:
        try:
            if acquired:
                stream.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(),fcntl.LOCK_UN)
        finally:stream.close()
