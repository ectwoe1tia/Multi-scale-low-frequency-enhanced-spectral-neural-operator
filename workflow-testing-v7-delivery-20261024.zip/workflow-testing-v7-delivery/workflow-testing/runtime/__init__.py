"""Current v7 workflow testing kernel. No legacy entrypoints."""
VERSION = '7.0.0'
BUILD = '20261024'
