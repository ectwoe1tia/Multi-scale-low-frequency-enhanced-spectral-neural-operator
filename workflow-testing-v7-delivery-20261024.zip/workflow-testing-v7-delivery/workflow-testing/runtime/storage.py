"""Explicit SQLite application/version handling. Fixed migrations, short transactions."""
import contextlib
import json
import sqlite3
import time
import uuid
from pathlib import Path
from .contract import Fault,require
from .common import digest,encoded

IDS={'knowledge':0x57464B37,'run':0x57465237}
CURRENT=2
BASE={
'knowledge':[
 'CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)',
 'CREATE TABLE sources(id TEXT PRIMARY KEY,path TEXT NOT NULL,sha TEXT NOT NULL,copy TEXT NOT NULL,kind TEXT NOT NULL,active INTEGER NOT NULL)',
 'CREATE TABLE chunks(id TEXT PRIMARY KEY,source TEXT NOT NULL REFERENCES sources(id),ordinal INTEGER NOT NULL,location TEXT NOT NULL,text TEXT NOT NULL)',
 'CREATE TABLE reviews(chunk TEXT PRIMARY KEY REFERENCES chunks(id),fingerprint TEXT NOT NULL)',
 'CREATE TABLE facts(id TEXT PRIMARY KEY,name TEXT NOT NULL,kind TEXT NOT NULL,summary TEXT NOT NULL,payload TEXT NOT NULL,citations TEXT NOT NULL,fingerprint TEXT NOT NULL,revision INTEGER NOT NULL,UNIQUE(name,revision))',
 'CREATE TABLE groups(id TEXT PRIMARY KEY,parent TEXT REFERENCES groups(id),name TEXT NOT NULL)',
 'CREATE TABLE memberships(snapshot TEXT NOT NULL,group_id TEXT NOT NULL REFERENCES groups(id),source TEXT NOT NULL REFERENCES sources(id),ordinal INTEGER NOT NULL,PRIMARY KEY(snapshot,group_id,source))',
 'CREATE TABLE source_errors(path TEXT PRIMARY KEY,sha TEXT NOT NULL,code TEXT NOT NULL,detail TEXT NOT NULL)',
 'CREATE TABLE relations(id TEXT PRIMARY KEY,payload TEXT NOT NULL,snapshot TEXT NOT NULL)',
 'CREATE TABLE lineage(intent TEXT NOT NULL,variable TEXT NOT NULL,producer TEXT NOT NULL,pointer TEXT NOT NULL,consumer TEXT NOT NULL,PRIMARY KEY(intent,variable))'],
'run':[
 'CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)',
 'CREATE TABLE tasks(id TEXT PRIMARY KEY,snapshot TEXT NOT NULL,chunks TEXT NOT NULL,status TEXT NOT NULL,packet TEXT NOT NULL)',
 'CREATE TABLE actions(id TEXT PRIMARY KEY,snapshot TEXT NOT NULL,kind TEXT NOT NULL,request TEXT NOT NULL)',
 'CREATE TABLE cases(id TEXT PRIMARY KEY,definition TEXT NOT NULL,signature TEXT NOT NULL,state TEXT NOT NULL,context TEXT NOT NULL)',
 'CREATE TABLE requests(id TEXT PRIMARY KEY,case_id TEXT NOT NULL,step_id TEXT NOT NULL,guard_key TEXT NOT NULL,method TEXT NOT NULL,state TEXT NOT NULL,request TEXT NOT NULL,evidence TEXT,UNIQUE(case_id,step_id))',
 'CREATE TABLE events(seq INTEGER PRIMARY KEY AUTOINCREMENT,intent TEXT NOT NULL,state TEXT NOT NULL,payload TEXT NOT NULL)',
 'CREATE TABLE observations(id TEXT PRIMARY KEY,payload TEXT NOT NULL)',
 'CREATE TABLE recoveries(key TEXT PRIMARY KEY,attempts INTEGER NOT NULL)']}
UPGRADE={'knowledge':['ALTER TABLE facts ADD COLUMN state TEXT NOT NULL DEFAULT \'CANDIDATE\''],
         'run':['CREATE TABLE diagnostics(id TEXT PRIMARY KEY,code TEXT NOT NULL,payload TEXT NOT NULL)']}

def signature(kind):return digest({'base':BASE[kind],'upgrade':UPGRADE[kind]})

def version_manifest():return {kind:{'application_id':IDS[kind],'current':CURRENT,'supported':[1,2],
    'migrations':[{'from':1,'to':2,'checksum':digest(UPGRADE[kind])}]} for kind in IDS}

def raw(path,readonly=False):
    db=None
    try:
        path=Path(path)
        db=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True,timeout=2) if readonly else sqlite3.connect(str(path),timeout=2)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON');db.execute('PRAGMA busy_timeout=2000')
        if not readonly:db.execute('PRAGMA synchronous=FULL')
        return db
    except sqlite3.DatabaseError as exc:
        if db:db.close()
        raise Fault('DB_CORRUPT',detail=type(exc).__name__,scope='WORKSPACE') from exc

def check(db,kind,allow_old=False):
    version=db.execute('PRAGMA user_version').fetchone()[0]
    application=db.execute('PRAGMA application_id').fetchone()[0]
    tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
    if version==0 and tables:raise Fault('UNVERSIONED_WORKSPACE',scope='WORKSPACE')
    require(application==IDS[kind] and version in ((1,2) if allow_old else (2,)),
            'DB_VERSION_UNSUPPORTED',detail={'version':version,'kind':kind})
    # A version integer alone is not proof that the schema/migration is intact.
    rows=db.execute('SELECT version,checksum FROM schema_migrations ORDER BY version').fetchall()
    expected={1:digest(BASE[kind]),2:digest(UPGRADE[kind])}
    require({r['version']:r['checksum'] for r in rows}=={v:expected[v] for v in range(1,version+1)},'DB_CORRUPT')
    return version

def ensure(path,kind):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    db=raw(path)
    try:
        version=db.execute('PRAGMA user_version').fetchone()[0]
        nonempty=db.execute("SELECT 1 FROM sqlite_master WHERE type='table'").fetchone()
        if version==0 and not nonempty:
            db.execute('BEGIN IMMEDIATE')
            for sql in BASE[kind]:db.execute(sql)
            db.execute('CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY,checksum TEXT NOT NULL,tool_build TEXT NOT NULL,backup TEXT,completed_at REAL NOT NULL)')
            db.execute('INSERT INTO schema_migrations VALUES(?,?,?,?,?)',(1,digest(BASE[kind]),'20261024',None,time.time()))
            db.execute('PRAGMA application_id='+str(IDS[kind]));db.execute('PRAGMA user_version=1');db.commit()
        version=check(db,kind,allow_old=True)
        if version==1:
            if kind=='run' and db.execute("SELECT 1 FROM requests WHERE state IN ('INTENT_COMMITTED','SENDING','UNKNOWN')").fetchone():
                raise Fault('RECONCILIATION_REQUIRED',effect='MAY_HAVE_BEEN_SENT',scope='WORKSPACE')
            backup=path.with_name(path.name+'.before-v2-'+uuid.uuid4().hex+'.sqlite')
            target=sqlite3.connect(str(backup))
            try:db.backup(target)
            finally:target.close()
            try:
                db.execute('BEGIN IMMEDIATE')
                for sql in UPGRADE[kind]:db.execute(sql)
                require(not db.execute('PRAGMA foreign_key_check').fetchall(),'DB_MIGRATION_FAILED')
                require(db.execute('PRAGMA quick_check').fetchone()[0]=='ok','DB_MIGRATION_FAILED')
                db.execute('INSERT INTO schema_migrations VALUES(?,?,?,?,?)',(2,digest(UPGRADE[kind]),'20261024',str(backup),time.time()))
                db.execute('PRAGMA user_version=2');db.commit()
            except BaseException as exc:
                db.rollback()
                if isinstance(exc,(KeyboardInterrupt,SystemExit)):raise
                raise Fault('DB_MIGRATION_FAILED',detail=type(exc).__name__) from exc
        check(db,kind)
    except sqlite3.DatabaseError as exc:raise Fault('DB_CORRUPT',detail=type(exc).__name__,scope='WORKSPACE') from exc
    finally:db.close()

@contextlib.contextmanager
def connect(path,kind,write=False):
    db=raw(path,readonly=not write)
    try:
        check(db,kind)
        if write:db.execute('BEGIN IMMEDIATE')
        yield db
        if write:db.commit()
    except sqlite3.DatabaseError as exc:
        if write:db.rollback()
        raise Fault('DB_CORRUPT',detail=type(exc).__name__,scope='WORKSPACE') from exc
    except BaseException:
        if write:db.rollback()
        raise
    finally:db.close()

def meta(db,key,value=None):
    if value is not None:
        db.execute('INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,value));return value
    row=db.execute('SELECT value FROM meta WHERE key=?',(key,)).fetchone()
    return row[0] if row else None

def spend(db,key,limit):
    value=db.execute('SELECT attempts FROM recoveries WHERE key=?',(key,)).fetchone()
    attempts=(value[0] if value else 0)+1
    if attempts>limit:return False
    db.execute('INSERT INTO recoveries VALUES(?,?) ON CONFLICT(key) DO UPDATE SET attempts=excluded.attempts',(key,attempts))
    return True

def event(db,intent,state,payload):
    db.execute('INSERT INTO events(intent,state,payload) VALUES(?,?,?)',(intent,state,encoded(payload)))
