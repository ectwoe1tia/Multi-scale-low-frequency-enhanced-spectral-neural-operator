"""Bounded document extraction, reused from the maintained extractor; no workflow protocol adapters."""
import importlib.util
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
import json
from . import common as rt
MAX_DOCUMENT=32*rt.MAX_BYTES
W="{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
def file_hash(path):return rt.file_hash(path)

EXTENSIONS={'.md','.markdown','.txt','.docx','.pdf','.json','.har','.bpmn','.xml'}

def inventory(source):
    source=Path(source).resolve()
    rt.require(source.exists(),'SOURCE_UNREADABLE')
    entries=[source] if source.is_file() else sorted(source.rglob('*'))
    files=[]
    for entry in entries:
        if not entry.is_file() or entry.suffix.lower() not in EXTENSIONS:continue
        relative=entry.name if source.is_file() else entry.relative_to(source).as_posix()
        if any(p.startswith('.') or p in ('node_modules','__pycache__') for p in Path(relative).parts):continue
        rt.require(source.is_file() or source in entry.resolve().parents,'SOURCE_UNREADABLE',detail='Source symlink leaves group')
        rt.require(entry.stat().st_size<=32*rt.MAX_BYTES,'SOURCE_UNREADABLE',detail='Single source exceeds 32 MiB')
        files.append({'path':relative,'original':str(entry),'sha':file_hash(entry),'size':entry.stat().st_size})
    rt.require(0<len(files)<=500 and sum(f['size'] for f in files)<=256*rt.MAX_BYTES,'SOURCE_UNREADABLE',detail='Group limits')
    return files

def clean(text):
    text=rt.redact(str(text))
    return re.sub(r'(?i)((?:token|password|secret|cookie|authorization|api[_-]?key)\s*[:=：]\s*)[^\s,;]+',r'\1[REDACTED]',text)

def parse_source(path,relative):
    path=Path(path)
    if path.suffix.lower() in ('.md','.markdown','.txt','.docx','.pdf'):
        doc=extract(path,relative)
        blocks=[(b['location'],clean(b['text'])) for b in doc['blocks'] if b['text'].strip()]
        warnings=doc['warnings']
        if not blocks:raise rt.Fault('SOURCE_UNREADABLE')
        for warning in warnings:blocks.append(('extraction-warning',rt.encoded(warning)))
        return 'document',blocks,warnings
    if path.suffix.lower() in ('.bpmn','.xml'):
        raw=path.read_bytes()
        rt.require(b'<!DOCTYPE' not in raw.upper() and b'<!ENTITY' not in raw.upper(),'SOURCE_CORRUPT')
        root=ET.fromstring(raw);nodes=[];edges=[]
        for element in root.iter():
            kind=element.tag.split('}')[-1]
            if kind=='sequenceFlow':edges.append({'id':element.get('id'),'from':element.get('sourceRef'),'to':element.get('targetRef')})
            elif element.get('id'):nodes.append({'id':element.get('id'),'kind':kind,'name':element.get('name','')})
        return 'flow',[('flow-summary',rt.encoded({'nodes':len(nodes),'edges':len(edges),'static_only':True}))],[]
    data=rt.read_json(path,32*rt.MAX_BYTES)
    if isinstance(data,dict) and ('openapi' in data or 'swagger' in data):
        blocks=[('info',clean(rt.encoded(data.get('info',{}))))]
        rt.require(isinstance(data.get('paths',{}),dict),'SOURCE_CORRUPT')
        for name,methods in data.get('paths',{}).items():
            for method,op in methods.items():
                if method.upper() in rt.METHODS:blocks.append(('paths/'+name+'/'+method,clean(method.upper()+' '+name+'\n'+rt.encoded(rt.redact(op)))))
        for name,value in data.get('components',{}).get('schemas',{}).items():blocks.append(('schema/'+name,clean(rt.encoded(rt.redact(value)))))
        return 'document',blocks,[]
    if isinstance(data,dict) and isinstance(data.get('log'),dict) and isinstance(data['log'].get('entries'),list):
        entries=data['log']['entries'];rt.require(len(entries)<=10000,'SOURCE_UNREADABLE')
        rt.require(all(isinstance(e,dict) and isinstance(e.get('request'),dict) and isinstance(e.get('response'),dict) for e in entries),'SOURCE_CORRUPT')
        counts={}
        for entry in entries:
            key=entry['request'].get('method','UNKNOWN');counts[key]=counts.get(key,0)+1
        return 'har',[('har-summary',rt.encoded({'requests':len(entries),'methods':counts,'observations_only':True,'credential_values_omitted':True}))],[]
    if isinstance(data,dict) and isinstance(data.get('steps'),list):
        rt.require(len(data['steps'])<=10000 and all(isinstance(x,dict) and isinstance(x.get('type'),str) for x in data['steps']),'SOURCE_CORRUPT')
        counts={}
        for step in data['steps']:counts[step['type']]=counts.get(step['type'],0)+1
        return 'recorder',[('recorder-summary',rt.encoded({'steps':len(data['steps']),'actions':counts,'values_and_selectors_omitted':True,'browser_execution':False}))],[]
    # Configuration is indexed structurally, never expanded into the LLM packet.
    if isinstance(data,(dict,list)):
        from .relations import configuration_summary
        return 'configuration',[('configuration-summary',rt.encoded(configuration_summary(data)))],[]
    raise rt.Fault('SOURCE_UNREADABLE')
def pdf_backend():
    for name in ('pypdf', 'PyPDF2'):
        if importlib.util.find_spec(name):
            return name
    return None

def xml_text(element):
    pieces = []
    for node in element.iter():
        if node.tag == W + 't':
            pieces.append(node.text or '')
        elif node.tag in (W + 'br', W + 'cr'):
            pieces.append('\n')
        elif node.tag == W + 'tab':
            pieces.append('\t')
    return ''.join(pieces).strip()

def extract(source, relative):
    try:
        return _extract(source, relative)
    except (zipfile.BadZipFile, ET.ParseError) as exc:
        raise rt.ToolError('DOCUMENT_READ_ERROR', 'Word document is not a valid DOCX/XML file') from exc

def _extract(source, relative):
    source = Path(source)
    rt.need(source.stat().st_size <= MAX_DOCUMENT, 'Document exceeds 32 MiB')
    suffix = source.suffix.lower()
    blocks, warnings = [], []
    def add(kind, locator, text='', rows=None):
        block = {'id': 'B' + str(len(blocks) + 1).zfill(5), 'kind': kind, 'location': locator, 'text': text}
        if rows is not None:
            block['rows'] = rows
        blocks.append(block)
    backend = 'stdlib'
    if suffix in ('.md', '.markdown', '.txt'):
        content = source.read_text(encoding='utf-8-sig')
        lines = content.splitlines()
        i = 0
        while i < len(lines):
            if lines[i].lstrip().startswith('|'):
                start, rows = i, []
                while i < len(lines) and lines[i].lstrip().startswith('|'):
                    row = [x.strip() for x in re.split(r'(?<!\\)\|', lines[i].strip().strip('|'))]
                    if not all(re.fullmatch(r':?-+:?', x.replace(' ', '')) for x in row):
                        rows.append(row)
                    i += 1
                add('table', 'lines:' + str(start + 1) + '-' + str(i), '\n'.join(lines[start:i]), rows)
            else:
                if lines[i].strip():
                    add('paragraph', 'line:' + str(i + 1), lines[i])
                i += 1
    elif suffix == '.docx':
        with zipfile.ZipFile(source) as archive:
            rt.need(sum(x.file_size for x in archive.infolist()) <= 64 * rt.MAX_BYTES, 'Expanded DOCX exceeds 64 MiB')
            rt.need('word/document.xml' in archive.namelist(), 'Invalid DOCX: document.xml missing')
            xml = archive.read('word/document.xml')
            rt.need(b'<!DOCTYPE' not in xml.upper() and b'<!ENTITY' not in xml.upper(), 'XML entities are unsupported')
            root = ET.fromstring(xml)
            body = root.find(W + 'body')
            rt.need(body is not None, 'DOCX body missing')
            pcount, tcount = 0, 0
            for child in body:
                if child.tag == W + 'p':
                    pcount += 1
                    value = xml_text(child)
                    if value:
                        add('paragraph', 'paragraph:' + str(pcount), value)
                elif child.tag == W + 'tbl':
                    tcount += 1
                    rows = [[xml_text(cell) for cell in row.findall(W + 'tc')] for row in child.findall(W + 'tr')]
                    add('table', 'table:' + str(tcount), '\n'.join(' | '.join(row) for row in rows), rows)
                    if child.findall('.//' + W + 'vMerge') or child.findall('.//' + W + 'gridSpan'):
                        warnings.append({'code': 'MERGED_CELLS', 'location': 'table:' + str(tcount), 'message': 'Check merged cells and row alignment against original Word document'})
            if root.findall('.//' + W + 'drawing') or root.findall('.//' + W + 'pict'):
                warnings.append({'code': 'IMAGES_NOT_EXTRACTED', 'message': 'Embedded images need visual reading or OCR'})
            if root.findall('.//' + W + 'ins') or root.findall('.//' + W + 'del'):
                warnings.append({'code': 'TRACKED_CHANGES', 'message': 'Resolve tracked changes in the source before confirming cases'})
            if any(name.startswith(('word/header', 'word/footer', 'word/footnotes', 'word/endnotes', 'word/comments')) for name in archive.namelist()):
                warnings.append({'code': 'ANCILLARY_WORD_PARTS', 'message': 'Headers, footers, footnotes and comments are not used as case evidence'})
    elif suffix == '.pdf':
        backend = pdf_backend()
        rt.need(backend, 'PDF requires pypdf or PyPDF2 in the chosen Python environment', 'DEPENDENCY_MISSING')
        module = __import__(backend, fromlist=['PdfReader'])
        try:
            reader = module.PdfReader(str(source))
            rt.need(not reader.is_encrypted, 'Encrypted PDFs require an unlocked copy', 'DOCUMENT_LOCKED')
            rt.need(len(reader.pages) <= 500, 'PDF exceeds 500 pages')
            for number, page in enumerate(reader.pages, 1):
                value = page.extract_text() or ''
                add('page', 'page:' + str(number), value)
                if not value.strip():
                    warnings.append({'code': 'OCR_REQUIRED', 'location': 'page:' + str(number), 'message': 'No text layer found; this page has not been read'})
            warnings.append({'code': 'PDF_LAYOUT_REVIEW', 'message': 'Text extraction does not establish table columns or image contents; check original page layout'})
        except rt.ToolError:
            raise
        except Exception as exc:
            raise rt.ToolError('DOCUMENT_READ_ERROR', 'PDF backend could not read this file') from exc
    else:
        raise rt.ToolError('UNSUPPORTED_FORMAT', 'Supported documents: .md, .txt, .docx, .pdf; convert legacy .doc to .docx first')
    rt.need(len(blocks) <= 30000 and sum(len(b['text']) for b in blocks) <= 8 * rt.MAX_BYTES, 'Extracted text exceeds limits')
    if not any(b['text'].strip() for b in blocks):
        warnings.append({'code': 'NO_TEXT', 'message': 'No readable text; do not confirm cases from this document'})
    return {'document_version': '1.0', 'source': relative, 'source_sha256': file_hash(source), 'format': suffix.lstrip('.'),
            'backend': backend, 'blocks': blocks, 'warnings': warnings, 'extraction_only': True}
