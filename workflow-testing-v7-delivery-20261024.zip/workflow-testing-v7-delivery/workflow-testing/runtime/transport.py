"""Only network port. Curl receives credentials on stdin, never argv or receipts."""
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlencode
from . import common as c
from .contract import Fault,require
from . import compiler

def credentials(policy,cases=()):
    names=set()
    def visit(value):
        if isinstance(value,dict):
            if set(value)=={'env'}:names.add(value['env'])
            else:
                for item in value.values():visit(item)
        elif isinstance(value,list):
            for item in value:visit(item)
    visit(policy.get('headers',{}))
    for spec in policy['actors'].values():visit(spec.get('headers',{}))
    for rule in policy.get('allow',[]):visit(rule.get('headers',{}))
    for case in cases:
        visit(case.get('headers',{}))
        for step in case['steps']:visit(step.get('headers',{}))
    for actor in policy['actors'].values():
        if actor['bearer_token_env']:names.add(actor['bearer_token_env'])
    values={name:os.environ.get(name,'') for name in names}
    require(all(isinstance(v,str) and 1<=len(v)<=4096 and all(32<=ord(ch)<=126 for ch in v) for v in values.values()),'CONNECTION_REQUIRED')
    return values

def prepare(policy,step,context,credential_values,intent,case_headers=None):
    require(shutil.which('curl.exe') or shutil.which('curl'),'CONNECTION_REQUIRED',detail='curl unavailable')
    resolved=c.substitute(step,context);op=step['operation_spec'];path=op['path']
    for name,value in resolved['params'].items():
        require(type(value) in (str,int) and re.fullmatch(r'[A-Za-z0-9_.:-]+',str(value)) and str(value) not in ('.','..'),'POLICY_DENIED')
        path=path.replace('{'+name+'}',str(value))
    require(all(type(v) in (str,int,float,bool) for v in resolved['query'].values()),pointer='/query')
    require(not any(c.SECRET_KEYS.search(k) for k in resolved['query']),'POLICY_DENIED')
    rules=[r for r in policy.get('allow',[]) if r['operation']==step['operation']]
    require(step['operation'] not in policy.get('deny',[]) and (not policy.get('allow') or rules),'POLICY_DENIED')
    require(all(step['actor'] in r['actors'] for r in rules),'POLICY_DENIED')
    for guard in [g for r in rules for g in r.get('guards',[])]:
        require(c.compare(c.json_pointer(resolved,guard['pointer']),guard['op'],guard.get('expected',c.MISSING)),'POLICY_DENIED',pointer='/guards')
    url=policy['base_url'].rstrip('/')+path
    if resolved['query']:url+='?'+urlencode(resolved['query'])
    headers={'content-type':('Content-Type','application/json'),'accept':('Accept','application/json')}
    actor=policy['actors'][step['actor']]
    for layer in (policy.get('headers',{}),actor.get('headers',{}),step.get('operation_headers',{}),case_headers or {},resolved.get('headers',{})):
        for name,value in c.substitute(layer,context).items():
            headers[name.lower()]=(name,credential_values[value['env']] if isinstance(value,dict) else value)
    if actor['bearer_token_env']:headers['authorization']=('Authorization','Bearer '+credential_values[actor['bearer_token_env']])
    headers={name:value for name,value in headers.values()}
    require(all(isinstance(v,str) and len(v)<=4096 and all(32<=ord(ch)<=126 for ch in v) for v in headers.values()),'POLICY_DENIED')
    return {'method':op['method'],'url':url,'path':path,'headers':headers,'body':resolved['body'],
            'safe':c.redact({'method':op['method'],'path':path,'params':resolved['params'],'query':resolved['query'],
                'body':resolved['body'],'headers':{k:'[CONNECTED]' if k.lower()=='authorization' else v for k,v in headers.items()}},credential_values.values()),
            'timeout':policy.get('timeout_seconds',5)}

def send(prepared):
    curl=shutil.which('curl.exe') or shutil.which('curl')
    config=''.join('header = "'+(k+': '+v).replace('\\','\\\\').replace('"','\\"')+'"\n' for k,v in prepared['headers'].items())
    with tempfile.TemporaryDirectory(prefix='workflow-private-http-') as folder:
        args=[curl,'--disable','--silent','--show-error','--globoff','--proto','=http,https','--noproxy','*',
              '--connect-timeout',str(min(5,prepared['timeout'])),'--max-time',str(prepared['timeout']),
              '--max-redirs','0','--request',prepared['method'],'--config','-',
              '--write-out','\n__WF_STATUS__:%{http_code}','--url',prepared['url']]
        if prepared['body'] is not None:
            body=Path(folder)/'body.json';body.write_text(c.encoded(prepared['body']),encoding='utf-8');args+=['--data-binary','@'+str(body)]
        if prepared['method']=='HEAD':args.append('--head')
        process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,shell=False,close_fds=True)
        received=bytearray();overflow=False
        try:
            process.stdin.write(config.encode('utf-8'));process.stdin.close()
            while True:
                block=process.stdout.read(65536)
                if not block:break
                received.extend(block)
                if len(received)>c.MAX_BYTES+100:overflow=True;break
            if overflow:process.kill()
            code=process.wait(timeout=prepared['timeout']+2)
        finally:
            if process.poll() is None:process.kill()
            process.wait();process.stdout.close()
            if not process.stdin.closed:process.stdin.close()
    marker=b'\n__WF_STATUS__:';raw,status=(bytes(received),None)
    if marker in received:
        raw,tail=bytes(received).rsplit(marker,1)
        if tail.isdigit() and 100<=int(tail)<=599:status=int(tail)
    return {'raw':raw,'status_code':status,'transport_ok':code==0 and not overflow and status is not None,
            'transport_code':code,'overflow':overflow,'path':prepared['path']}

def parse(wire,response_format='json'):
    require(wire['transport_ok'],'REQUEST_OUTCOME_UNKNOWN')
    raw=wire['raw']
    if response_format=='text':
        try:body=raw.decode('utf-8')
        except UnicodeError:raise Fault('RESPONSE_INVALID',effect='CONFIRMED') from None
    else:
        try:
            body=json.loads(raw.decode('utf-8')) if raw else None
            c.encoded(body)
        except (ValueError,UnicodeError,RecursionError):raise Fault('RESPONSE_INVALID',effect='CONFIRMED') from None
    return {'status_code':wire['status_code'],'body':body,'request_path':wire['path'],'bytes':len(raw)}
