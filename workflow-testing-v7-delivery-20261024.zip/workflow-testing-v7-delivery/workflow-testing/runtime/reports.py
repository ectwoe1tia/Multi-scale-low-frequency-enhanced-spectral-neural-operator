"""Human reports from immutable run evidence; no transport or expected-value changes."""
import json
from . import common as c
from . import storage as s

def cell(value):return str(value).replace('|','\\|').replace('\n',' ')

CATEGORY_LABELS={'happy_path':'正常场景','boundary':'边界','validation':'参数校验','permission':'权限','transition':'状态流转',
 'parallel':'并行','idempotency':'幂等','concurrency':'并发','recovery':'恢复','integration':'接口集成','timing':'时序',
 'data_consistency':'数据一致性','compatibility':'兼容','performance':'性能'}
STATE_LABELS={'PASS':'通过（PASS）','FAIL':'失败（FAIL）','UNKNOWN':'结果未知（UNKNOWN）','TODO':'未执行（TODO）',
 'BLOCKED':'受阻（BLOCKED）','RECONCILED':'效果已核对，原响应未知（RECONCILED）'}

def generate(kernel):
    from .contract import Fault
    try:_,source_current=kernel.current_sources()
    except (Fault,OSError):source_current=False
    with s.connect(kernel.knowledge,'knowledge') as db:
        from .compiler import valid_facts
        facts=valid_facts(db,kernel.analysis_fingerprint())
        source_errors=[dict(r) for r in db.execute('SELECT path,code FROM source_errors')]
    with s.connect(kernel.run_db,'run') as db:
        cases=[dict(r) for r in db.execute('SELECT * FROM cases ORDER BY id')]
        requests=[dict(r) for r in db.execute('SELECT * FROM requests ORDER BY rowid')]
        diagnostics=[dict(r) for r in db.execute('SELECT * FROM diagnostics')]
    lines=['# '+cell(kernel.system)+' 测试报告','','业务断言、只读探索和未执行分别记录。','',
           '| 编号 | 标题 | 分类 | 优先级 | 类型 | 状态 |','|---|---|---|---|---|---|']
    counts={'PASS':0,'FAIL':0,'UNKNOWN':0,'TODO':0,'BLOCKED':0,'PROBE':0};branches={}
    observed_failures=0
    for row in cases:
        case=json.loads(row['definition']);probe=case['mode']=='probe';state=row['state']
        from .compiler import citations
        try:
            with s.connect(kernel.knowledge,'knowledge') as db:citations(db,case['citations'])
        except Fault:state='BLOCKED'
        if not source_current:state='BLOCKED'
        counts['PROBE' if probe else 'UNKNOWN' if state=='RECONCILED' else state if state in counts else 'TODO']+=1
        if probe:branches.setdefault(case['question'],[]).append({'case':case['id'],'state':state})
        label=STATE_LABELS.get(state,state)
        if probe and state in ('PASS','FAIL'):label='观察判据'+('命中' if state=='PASS' else '未命中')
        lines.append('| '+' | '.join(cell(v) for v in (case['id'],case['title'],CATEGORY_LABELS.get(case['category'],case['category']),case['priority'],'探索' if probe else '业务测试',label))+' |')
    if not cases:
        lines+=['','尚未形成可编译执行场景，当前结果为设计阶段。']
    lines+=['','## 未决问题与资料缺口','']
    if not source_current:lines.append('- 当前来源已变化或不可读，旧执行证据保留，不能作为新资料的通过结论。')
    for fact in facts:
        if fact['kind']=='unknown':lines.append('- '+cell(fact['summary'])+'：'+cell(fact['payload'].get('reason','')))
    for source in source_errors:lines.append('- '+cell(source['path'])+'：'+source['code'])
    for diagnostic in diagnostics:
        info=json.loads(diagnostic['payload']);lines.append('- '+cell(info.get('case','当前任务'))+'：'+diagnostic['code'])
    if not source_errors and not diagnostics and not any(f['kind']=='unknown' for f in facts):lines.append('无已记录的资料缺口。')
    resolutions=[]
    for question,options in branches.items():
        winners=[x for x in options if x['state']=='PASS'];complete=all(x['state'] in ('PASS','FAIL') for x in options)
        resolutions.append({'question':question,'state':'DISCRIMINATED_THIS_RUN' if complete and len(winners)==1 and len(options)>=2 else 'RELATION_UNRESOLVED',
                            'winner':winners[0]['case'] if complete and len(winners)==1 and len(options)>=2 else None,'automatic_binding':False})
    lines+=['','## 分支探索','']+[ '- '+cell(r['question'])+'：'+('本轮证据可区分，命中 '+r['winner']+'；不自动变更业务规则。' if r['state']=='DISCRIMINATED_THIS_RUN' else '关系尚不能确定，保留未知。') for r in resolutions]
    for row in cases:
        case=json.loads(row['definition']);lines+=['','## '+cell(case['id'])+' '+cell(case['title']),'']
        records={r['step_id']:r for r in requests if r['case_id']==case['id']}
        for step in case['steps']:
            record=records.get(step['id']);lines+=['### '+cell(step['id'])+' '+step['operation'],'']
            if not record:
                lines+=['未执行。预期检查：']+['- '+cell(ch['pointer'])+' '+ch['op']+' '+cell(c.encoded(ch.get('expected'))) for ch in step['checks']]
                continue
            lines.append('请求状态：'+record['state']+'；证据：'+str(record['evidence'] or '发送账本'))
            if record['evidence']:
                with s.connect(kernel.run_db,'run') as db:expected=s.meta(db,'proof:'+record['id'])
                from .contract import require
                require(expected and c.file_hash(kernel.root/record['evidence'])==expected,'EVIDENCE_MISMATCH')
                evidence=c.read_json(c.workspace_path(kernel.root,record['evidence'],True),4*c.MAX_BYTES)
                response=evidence.get('response',{'status_code':evidence.get('status_code'),'request_path':evidence.get('path')})
                lines.append('HTTP：'+record['method']+' '+cell(response.get('request_path',step['operation_spec']['path']))+' → '+str(response.get('status_code','未知')))
                if isinstance(response.get('body'),dict) and 'msg' in response['body']:lines.append('服务端消息：'+cell(response['body']['msg']))
                for check in evidence.get('checks',[]):
                    if case['mode']!='probe' and check['status']=='FAIL':observed_failures+=1
                    lines.append('- '+check['status']+' '+cell(check['pointer'])+'；期望 '+cell(c.encoded(check.get('expected')))+'；实际 '+cell(c.encoded(check['actual'])))
                if 'raw_ref' in evidence:lines.append('响应原文已保存在私有证据中；解析尚未完成，未判定通过。')
    if any(r['state'] in ('UNKNOWN','RECONCILED') for r in cases):outcome='UNKNOWN'
    elif counts['FAIL'] or observed_failures:outcome='FAIL'
    elif source_current and counts['PASS'] and not counts['TODO'] and not counts['BLOCKED'] and not source_errors and not diagnostics and not any(f['kind']=='unknown' for f in facts):outcome='PASS'
    else:outcome='NOT_EVALUATED'
    ref='reports/'+kernel.run_id+'.md';c.write_bytes(c.workspace_path(kernel.root,ref),('\n'.join(lines)+'\n').encode('utf-8'))
    summary={'run_id':kernel.run_id,'outcome':outcome,'counts':counts,'source_errors':len(source_errors),'diagnostics':len(diagnostics),
             'branch_resolutions':resolutions,'report_ref':ref,'observed_failure_checks':observed_failures,'logical_requests':len(requests)}
    c.write(c.workspace_path(kernel.root,'reports/'+kernel.run_id+'.json'),summary)
    return summary
