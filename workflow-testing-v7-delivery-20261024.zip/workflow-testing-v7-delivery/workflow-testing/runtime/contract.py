"""Single source of truth for errors, states and editor/tool contracts."""
import json
from pathlib import Path

PROTOCOL = '7.0'
DECISION_SEMANTICS = 'v7-current-1'
STATES = ['RUNNABLE','NEEDS_AGENT','WAITING_BUSINESS','WAITING_SYSTEM','COMPLETED','BLOCKED']
OUTCOMES = ['NOT_EVALUATED','PASS','FAIL','UNKNOWN']
ACTIONS = ['open','advance','submit','inspect','report']
PAYLOAD_FIELDS={
 'convention':(['base_url','environment','allow_mutations','actors'],['headers','allow','deny','timeout_seconds']),
 'scenario':(['category','priority','vars','steps','bindings'],['mode','question','depends_on','headers']),
 'query_strategy':(['goal','first_query','variables','prerequisites'],[]),
 'requirement':([],['reason','next_search','target']),'unknown':([],['reason','next_search','target'])}
STEP_FIELDS=(['id','operation','actor','params','query','body','capture','checks'],['headers','poll','reconcile','response_format'])
ERRORS = {}

def register(code, category, phase, action, retry, human, en, zh):
    ERRORS[code] = dict(code=code,category=category,phase=phase,recovery_action=action,
                        retry_condition=retry,human_target=human,message_en=en,message_zh=zh)

register('SOURCE_CHANGED','INPUT','INGEST','REFRESH_SOURCES','AFTER_REFRESH','NONE','Source membership or content changed.','资料发生变化，将重新处理受影响内容。')
register('SOURCE_CORRUPT','INPUT','INGEST','REPLACE_OR_CONVERT_SOURCE','AFTER_SOURCE_CHANGE','SYSTEM','The source cannot be decoded or parsed.','资料损坏或格式不可读取，请系统方提供可读版本。')
register('SOURCE_UNREADABLE','INPUT','INGEST','REPLACE_OR_CONVERT_SOURCE','AFTER_SOURCE_CHANGE','SYSTEM','The source has no usable text or requires an extractor.','部分资料没有可读文本，需转换或补充文本版本。')
register('DECISION_INVALID','INPUT','ANALYZE','REVISE_DECISION','AFTER_DECISION_CHANGE','NONE','The internal decision does not match the current contract.','内部分析结果需要修正，由 AI 处理。')
register('EVIDENCE_MISMATCH','INPUT','ANALYZE','REFRESH_EVIDENCE','AFTER_DECISION_CHANGE','NONE','A quotation or source version does not match.','引用与当前资料不匹配，需要重新取证。')
register('WORKSPACE_BUSY','CONCURRENCY','LOCK','WAIT_FOR_LOCK','BOUNDED_BACKOFF','NONE','Another local process holds the workspace lock.','已有执行进程，请稍后接续。')
register('DB_MIGRATION_REQUIRED','STORAGE','MIGRATE','MIGRATE_DATABASE','AFTER_MIGRATION','NONE','A supported database migration is required.','需要执行已定义的数据升级。')
register('DB_VERSION_UNSUPPORTED','STORAGE','MIGRATE','USE_MATCHING_TOOL','DO_NOT_RETRY','MAINTAINER','This database version or application ID is unsupported.','工作区版本不受支持，请技术维护者处理。')
register('UNVERSIONED_WORKSPACE','STORAGE','MIGRATE','USE_MATCHING_TOOL','DO_NOT_RETRY','MAINTAINER','A nonempty unversioned database cannot be initialized.','旧工作区没有版本信息，不能直接作为新版执行。')
register('DB_CORRUPT','STORAGE','OPEN','RESTORE_EXECUTION_STATE','DO_NOT_RETRY','MAINTAINER','Database integrity or durable state could not be verified.','数据库状态无法验证，已停止相关执行。')
register('DB_MIGRATION_FAILED','STORAGE','MIGRATE','RESTORE_DATABASE','DO_NOT_RETRY','MAINTAINER','The migration failed; the prior version was retained.','数据升级未完成，已保留原版本与备份。')
register('IO_ERROR','STORAGE','PERSIST','RESTORE_STORAGE','AFTER_STORAGE_CHANGE','SYSTEM','A required durable file could not be read or written.','必要文件读写失败，请系统方检查存储或权限。')
register('CONNECTION_REQUIRED','ENVIRONMENT','PREPARE','CONNECT_TEST_IDENTITY','AFTER_CONNECTION','SYSTEM','Required test identities are not connected.','缺少测试身份连接，设计和静态报告仍可继续。')
register('ENVIRONMENT_UNAVAILABLE','ENVIRONMENT','OPEN','RESTORE_ENVIRONMENT','AFTER_ENVIRONMENT_CHANGE','SYSTEM','Python or another required local runtime is unavailable.','本地运行环境不可用，请系统方检查 Python 或必要程序。')
register('REQUEST_OUTCOME_UNKNOWN','EXECUTION','SEND','RECONCILE_REQUEST','DO_NOT_RESEND','NONE','The request may have been applied; reconcile before continuing.','操作可能已经生效，正在核对，暂不重复提交。')
register('RECONCILIATION_REQUIRED','EXECUTION','RECONCILE','RECONCILE_REQUEST','DO_NOT_RESEND','SYSTEM','No conclusive reconciliation evidence is available.','尚无法核对操作结果，相关分支已暂停。')
register('RESPONSE_INVALID','EXECUTION','PARSE','REPARSE_RESPONSE','LOCAL_REPARSE_ONLY','NONE','A received response needs local parsing; do not resend.','已收到响应，需本地解析，不重复发送请求。')
register('RELATION_UNRESOLVED','ANALYSIS','COMPILE','EXPLORE_RELATION','BOUNDED_EXPLORATION','NONE','The relationship has insufficient evidence.','关系尚不能确定，继续比较证据及受限分支。')
register('BUSINESS_RULE_CONFLICT','BUSINESS','ANALYZE','EXPLAIN_BUSINESS_RULE','AFTER_BUSINESS_EVIDENCE','BUSINESS','Current sources disagree on the business rule.','业务规则存在冲突，请解释冲突的业务含义。')
register('POLICY_DENIED','POLICY','COMPILE','REVISE_DECISION','AFTER_DECISION_CHANGE','NONE','The operation is outside the cited test policy.','该操作超出当前测试规约，已拒绝执行。')
register('BUDGET_EXHAUSTED','CONTROL','ADVANCE','CONTINUE_INDEPENDENT_WORK','DO_NOT_RETRY','NONE','The persisted recovery or exploration budget is exhausted.','该项自动处理预算已用完，将继续其他独立测试。')
register('INTERNAL_ERROR','INTERNAL','KERNEL','INSPECT_DIAGNOSTIC','DO_NOT_RETRY','MAINTAINER','An unexpected kernel fault was recorded.','内核发生异常，已保存最小诊断，请技术维护者处理。')

class Fault(Exception):
    def __init__(self, code, detail=None, effect='NOT_SENT', scope='CURRENT_TASK', ref='', pointer=''):
        if code not in ERRORS: raise ValueError('Unregistered error code')
        if code in ('REQUEST_OUTCOME_UNKNOWN','RECONCILIATION_REQUIRED'):effect='MAY_HAVE_BEEN_SENT'
        if code=='RESPONSE_INVALID':effect='CONFIRMED'
        self.code,self.detail,self.effect,self.scope,self.ref,self.pointer=code,detail,effect,scope,ref,pointer
        super().__init__(ERRORS[code]['message_en'])
    def as_dict(self):
        value=dict(ERRORS[self.code],effect_state=self.effect,blocks={'scope':self.scope,'ref':self.ref})
        if self.pointer:value['pointer']=self.pointer
        if getattr(self,'detail_ref',None):value['detail_ref']=self.detail_ref
        return value

def require(condition, code='DECISION_INVALID', pointer='', detail=None):
    if not condition:raise Fault(code,detail=detail,pointer=pointer)

def response(run_id=None, state='RUNNABLE', outcome='NOT_EVALUATED', fault=None, next_action=None, refs=(), summary_ref=None):
    import uuid
    return dict(contract_version=PROTOCOL,call_id='CALL-'+uuid.uuid4().hex,run_id=run_id,
                workflow_state=state,test_outcome=outcome,error=fault.as_dict() if fault else None,
                next_action=next_action or {'kind':'NONE'},evidence_refs=list(refs),summary_ref=summary_ref)

def exit_code(value):
    if value['error'] and value['error']['category']=='INTERNAL':return 40
    if value['workflow_state']=='BLOCKED':return 30
    if value['workflow_state'] in ('NEEDS_AGENT','WAITING_BUSINESS','WAITING_SYSTEM'):return 20
    return 10 if value['test_outcome']=='FAIL' else 0

def object_schema(properties, optional=()):
    return dict(type='object',additionalProperties=False,properties=properties,required=[k for k in properties if k not in optional])

def validate(value,schema,pointer=''):
    """Validate the closed subset emitted by this module; no external schema resolution."""
    import re
    if 'oneOf' in schema:
        variants=schema['oneOf']
        if isinstance(value,dict) and 'kind' in value:
            selected=[v for v in variants if v.get('properties',{}).get('kind',{}).get('const')==value['kind']]
            if len(selected)==1:return validate(value,selected[0],pointer)
        errors=[];matches=0
        for variant in variants:
            try:validate(value,variant,pointer);matches+=1
            except Fault as exc:errors.append(exc)
        if matches!=1:
            raise Fault('DECISION_INVALID',pointer=pointer,detail={'expected':'exactly one current schema variant','actual_type':type(value).__name__})
        return
    expected=schema.get('type')
    if expected:
        types={'object':dict,'array':list,'string':str,'integer':int,'number':(int,float),'boolean':bool,'null':type(None)}
        allowed=expected if isinstance(expected,list) else [expected]
        ok=any(isinstance(value,types[t]) and not (t in ('integer','number') and isinstance(value,bool)) for t in allowed)
        require(ok,pointer=pointer,detail={'expected_type':expected,'actual_type':type(value).__name__})
    if 'const' in schema:require(value==schema['const'],pointer=pointer,detail={'expected_const':schema['const']})
    if 'enum' in schema:require(value in schema['enum'],pointer=pointer,detail={'expected_enum':schema['enum']})
    if isinstance(value,dict):
        props=schema.get('properties',{});missing=set(schema.get('required',[]))-value.keys()
        require(not missing,pointer=pointer,detail={'missing_fields':sorted(missing)})
        require(len(value)>=schema.get('minProperties',0),pointer=pointer)
        for key,item in value.items():
            path=pointer+'/'+key.replace('~','~0').replace('/','~1')
            if key in props:validate(item,props[key],path)
            elif schema.get('additionalProperties') is False:raise Fault('DECISION_INVALID',pointer=path,detail='Unknown field')
            elif isinstance(schema.get('additionalProperties'),dict):validate(item,schema['additionalProperties'],path)
    if isinstance(value,list):
        require(schema.get('minItems',0)<=len(value)<=schema.get('maxItems',10**9),pointer=pointer)
        if 'items' in schema:
            for i,item in enumerate(value):validate(item,schema['items'],pointer+'/'+str(i))
    if isinstance(value,str):
        require(schema.get('minLength',0)<=len(value)<=schema.get('maxLength',10**9),pointer=pointer)
        if 'pattern' in schema:require(re.search(schema['pattern'],value),pointer=pointer)
    if type(value) in (int,float):require(schema.get('minimum',float('-inf'))<=value<=schema.get('maximum',float('inf')),pointer=pointer)

def schemas():
    text={'type':'string','minLength':1}
    cite=object_schema({'chunk':text,'quote':{'type':'string','minLength':4,'maxLength':800}})
    citations={'type':'array','minItems':1,'maxItems':20,'items':cite}
    check=object_schema({'id':text,'pointer':text,'op':{'enum':['eq','ne','contains','exists','not_exists','gt','gte','lt','lte']},'expected':{}},['expected'])
    header={'type':'object','additionalProperties':{'oneOf':[{'type':'string'},object_schema({'env':text})]}}
    actor=object_schema({'bearer_token_env':{'type':'string'},'headers':header},['headers'])
    step_properties={'id':text,'operation':text,'actor':text,'params':{'type':'object'},'query':{'type':'object'},'body':{},
        'capture':{'type':'object','additionalProperties':text},'checks':{'type':'array','minItems':1,'items':check},
        'headers':header,'poll':object_schema({'attempts':{'type':'integer','minimum':1,'maximum':6},'interval_seconds':{'type':'number','minimum':.05,'maximum':2}}),
        'reconcile':object_schema({'operation':text,'actor':text,'params':{'type':'object'},'query':{'type':'object'},'checks':{'type':'array','minItems':1,'items':check}}),
        'response_format':{'enum':['json','text']}}
    step_schema=object_schema(step_properties,STEP_FIELDS[1])
    binding=object_schema({'source_step':text,'pointer':text,'rationale':text,'citations':citations})
    p={
      'base_url':text,'environment':object_schema({'name':text,'kind':{'enum':['local','test','uat']},'release':text}),
      'allow_mutations':{'type':'boolean'},'actors':{'type':'object','minProperties':1,'additionalProperties':actor},'headers':header,
      'allow':{'type':'array','items':object_schema({'operation':text,'actors':{'type':'array','items':text},'guards':{'type':'array','items':object_schema({'pointer':text,'op':check['properties']['op'],'expected':{}},['expected'])},'headers':header},['guards','headers'])},
      'deny':{'type':'array','items':text},'timeout_seconds':{'type':'number','minimum':1,'maximum':30},
      'category':{'enum':['happy_path','boundary','validation','permission','transition','parallel','idempotency','concurrency','recovery','integration','timing','data_consistency','compatibility','performance']},
      'priority':{'enum':['P0','P1','P2','P3']},'vars':{'type':'object'},'steps':{'type':'array','minItems':1,'maxItems':40,'items':step_schema},
      'bindings':{'type':'object','additionalProperties':binding},'mode':{'enum':['test','probe']},'question':text,'depends_on':{'type':'array','items':text},
      'goal':text,'first_query':text,'variables':{'type':'array','items':text},'prerequisites':{'type':'array','items':text},
      'reason':text,'next_search':text,'target':{'enum':['BUSINESS','SYSTEM','TECHNICAL']}}
    finding={'oneOf':[object_schema({'name':{'type':'string','pattern':'^[A-Za-z][A-Za-z0-9_-]{0,59}$'},
        'kind':{'const':kind},'summary':{'type':'string','minLength':1,'maxLength':800},'citations':citations,
        'payload':object_schema({key:p[key] for key in required+optional},optional)}) for kind,(required,optional) in PAYLOAD_FIELDS.items()]}
    error=object_schema({'code':{'enum':list(ERRORS)},'category':{'enum':sorted({v['category'] for v in ERRORS.values()})},
        'phase':{'enum':sorted({v['phase'] for v in ERRORS.values()})},'message_en':text,'message_zh':text,
        'recovery_action':{'enum':sorted({v['recovery_action'] for v in ERRORS.values()})},
        'retry_condition':{'enum':sorted({v['retry_condition'] for v in ERRORS.values()})},
        'human_target':{'enum':['NONE','BUSINESS','SYSTEM','MAINTAINER']},
        'effect_state':{'enum':['NOT_SENT','MAY_HAVE_BEEN_SENT','CONFIRMED']},
        'blocks':object_schema({'scope':{'enum':['CURRENT_TASK','DEPENDENT_BRANCH','WORKSPACE']},'ref':{'type':'string'}}),
        'pointer':text,'detail_ref':text},['pointer','detail_ref'])
    action={'oneOf':[object_schema({'kind':{'const':'NONE'}})]+[
        object_schema({'kind':{'const':kind},'action_id':text,'request_ref':text})
        for kind in ('KERNEL_ACTION','AGENT_TASK','BUSINESS_QUESTION','SYSTEM_TASK')]}
    result=object_schema({'contract_version':{'const':PROTOCOL},'call_id':text,'run_id':{'type':['string','null']},
        'workflow_state':{'enum':STATES},'test_outcome':{'enum':OUTCOMES},'error':{'oneOf':[{'type':'null'},error]},
        'next_action':action,'evidence_refs':{'type':'array','items':text},'summary_ref':{'type':['string','null']}})
    return {'decision':object_schema({'findings':{'type':'array','maxItems':20,'items':finding}}),'response':result}

def artifacts():
    return {'errors.json':ERRORS,'response.schema.json':dict(schemas()['response'],**{'$schema':'https://json-schema.org/draft/2020-12/schema'}),
        'decision.schema.json':dict(schemas()['decision'],**{'$schema':'https://json-schema.org/draft/2020-12/schema'}),
        'tool-help.json':{'contract_version':PROTOCOL,'actions':{
            'open':{'required':['project','sources'],'optional':['system','execute','new_run'],'effect':'local_state'},
            'advance':{'required':['project'],'optional':[],'effect':'authorized_network_or_local'},
            'submit':{'required':['project','decision'],'optional':['ticket'],'effect':'local_state'},
            'inspect':{'required':['project'],'optional':['topic','search','offset'],'effect':'local_inspect'},
            'report':{'required':['project'],'optional':[],'effect':'local_report'}}}}

def export(package):
    for name,value in artifacts().items():
        (Path(package)/'contracts'/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# Recovery contract (generated)','','Use code/effect_state/recovery_action, never parse message text.','',
           '| code | recovery_action | retry_condition | human_target |','|---|---|---|---|']
    lines += ['| '+' | '.join(v[k] for k in ('code','recovery_action','retry_condition','human_target'))+' |' for v in ERRORS.values()]
    (Path(package)/'docs/RECOVERY.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
