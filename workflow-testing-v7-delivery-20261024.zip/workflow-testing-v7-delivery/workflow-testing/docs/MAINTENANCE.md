# Current package maintenance

The customer bundle has one entrypoint and one current IR. Do not add a wrapper that revives historical session or adapter protocols. Reuse extraction/HTTP primitives only through current runtime boundaries.

Before changing maintained files, record scope, baseline hashes, owner/change ID and a single-writer maintenance claim in an isolated delivery. Preserve other claims and original evidence. Runtime OS locks are unrelated to maintenance ownership.

Runtime contract definitions in runtime/contract.py generate contracts/errors.json, tool-help.json, response.schema.json, decision.schema.json and docs/RECOVERY.md. Payload/step field metadata is shared with runtime validation. runtime/storage.py owns fixed database initializers/migrations and generates migrations/manifest.json. Never have an agent invent migration SQL for a user's workspace.

Analysis reuse is keyed by the generated decision schema and DECISION_SEMANTICS. Change that semantic marker when field meanings change. Compiler/transport code changes rebuild execution artifacts without automatically making the AI re-read every source; completed requests still cannot be replayed. Source parser changes invalidate extraction/location evidence. Report styling and CLI help do not invalidate business analysis.

The run and knowledge database application IDs differ. Current schema2 supports a fixed1→2 migration with SQLite Backup API, transactional DDL and migration checksums. Unknown/future IDs and nonempty unversioned databases are rejected. A run with pending writes cannot upgrade; derived regeneration does not reset its ledger. Damaged execution state requires verified restoration by a maintainer, not automatic deletion/recreation.

Run current tests with `python -X utf8 -m unittest discover -s tests -v`. Release also checks generated contracts, local links, package allowlist, static transport boundaries and Skill format. Record actual failure-injection, real HTTP, process lock/crash and independent AI trial evidence. Do not combine historical test counts into a claim about this kernel.

Only runtime/transport.py may launch curl. Only runtime/kernel.py may coordinate that port. Offline extraction/compile/relations/reporting/storage modules may not import a network client or invoke a subprocess. Do not replace these boundaries with a generic shell, eval, SQL, plugin-import or arbitrary URL action.

The product bundle contains SKILL.md, AGENTS.md, docs/, contracts/, migrations/, runtime/, scripts/ and current tests. Reports, maintainer claims, historical fixtures, temporary workspaces and release logs belong outside the installable skill. Package allowlist and hash manifest must be verified before publishing.
