# Current internal decision contract

The current AI creates these files. Never request them from a business user. Machine fields and findings.kind are English closed enums. Source text remains Chinese or its original language.

## Commands

```powershell
& '<skill>/scripts/Invoke-WorkflowTesting.ps1' -Project '<workspace>' -Action submit -Decision '<workspace>/artifacts/decision.json'
& '<skill>/scripts/Invoke-WorkflowTesting.ps1' -Project '<workspace>' -Action inspect -Topic text -Search '实例编号'
& '<skill>/scripts/Invoke-WorkflowTesting.ps1' -Project '<workspace>' -Action inspect -Topic facts -Offset 0
& '<skill>/scripts/Invoke-WorkflowTesting.ps1' -Project '<workspace>' -Action report
```

Optional -Ticket selects an issued task; omit it for the current task. The kernel binds snapshot/hash automatically. A completed ticket accepts only identical resubmission. Use the next refinement/review task for new findings. Empty findings means reviewed, not covered. Every finding cites at least one chunk from its current packet; additional currently active chunks may be cited.

Each open explicitly selects design mode or Execute mode, including when reusing a workspace. advance follows that persisted mode. When continuing an already-authorized test, the AI passes Execute without requesting the same authorization again. A later design-only open disables network execution for subsequent advances.

The generated [schema](../contracts/decision.schema.json) is the editor contract. Runtime checks also enforce provenance, references, policy and dependencies.

```json
{
  "findings": [{
    "name": "query-expense",
    "kind": "scenario",
    "summary": "查询已存在的报销单返回正确编号和状态",
    "citations": [{"chunk":"C-<packet chunk>","quote":"逐字引用的需求或接口说明，4至800字符"}],
    "payload": {
      "category":"happy_path","priority":"P0","vars":{"expense_id":"EXP-101"},"bindings":{},
      "steps":[{
        "id":"query","operation":"GET /expenses/{expense_id}","actor":"observer",
        "params":{"expense_id":"${expense_id}"},"query":{},"body":null,"capture":{},
        "checks":[
          {"id":"status","pointer":"/status_code","op":"eq","expected":200},
          {"id":"identity","pointer":"/body/id","op":"eq","expected":"${expense_id}"}
        ]
      }]
    }
  }]
}
```

Kinds and payloads:

| kind | Fields |
|---|---|
| requirement | optional reason, next_search, target |
| convention | base_url, environment, allow_mutations, actors; optional headers, allow, deny, timeout_seconds |
| scenario | category, priority, vars, steps, bindings; optional mode, question, depends_on, headers |
| query_strategy | goal, first_query, variables string[], prerequisites string[] |
| unknown | optional reason, next_search, target=BUSINESS/SYSTEM/TECHNICAL |

Exactly one current convention is needed. Example payload for an explicitly documented anonymous local service:

```json
{"base_url":"http://127.0.0.1:19080","environment":{"name":"local-test","kind":"local","release":"v1"},"allow_mutations":false,"actors":{"observer":{"bearer_token_env":""}}}
```

environment.kind permits local/test/uat. Production is rejected; plain HTTP and anonymous actors are local-only. Real roles reference existing environment variable names. The execution process reads identities once; no token in argv, decision, evidence, report or chat. Custom business headers accept literal nonsensitive strings or {"env":"WF_CLIENT_ID"}; Authorization/Host/Cookie framing headers are reserved. Header layers are policy → actor → operation allow-rule → case → step. Environment names cannot replace PATH, proxies or interpreter settings.

allow rules: {operation,actors,guards?,headers?}; deny is an array of exact operation keys and takes precedence. Overlapping allow rules intersect actors and accumulate every guard. A guard is {pointer,op,expected?} evaluated against the actual resolved step before sending. HTTP operations must be declared in the current documents/OpenAPI JSON; recordings never authorize an endpoint or mutation.

Each step needs an explicit eq /status_code check. Operators: eq,ne,contains,exists,not_exists,gt,gte,lt,lte. exists/not_exists omit expected. Variables occupy the whole string. Captures use JSON pointers and cannot overwrite prior variables or capture credentials. Static vars cannot contain template expressions. Across-request bindings require:

```json
{"instance_id":{"source_step":"create","pointer":"/body/id","rationale":"接口说明明确创建id用于查询","citations":[{"chunk":"C-...","quote":"创建响应的id用于按instance_id查询"}]}}
```

The matching capture must precede the consumer. Case dependencies use depends_on=[scenario names], form a DAG, and do not implicitly share runtime variables. A case has at most40 steps and at most100 planned requests including polls; an oversized case returns a bounded refinement task for the AI. A file-group advance handles at most10 new cases/100 planned requests/approximately45 seconds before yielding; request and task states persist for resumption. An in-flight operation may exceed the yield time until its declared timeout; writes are not cancelled and replayed to meet a batch deadline.

For technical exploration, use mode=probe and a shared question across candidates. Probe accepts only declared GET/HEAD, needs cited discriminating checks and never becomes business PASS. The kernel accepts at most3 candidate branches per question and at most2 request steps per branch; batch and actual request records are also bounded. If multiple/no candidates pass, retain RELATION_UNRESOLVED. Historical ID values and recorded statuses are observations.

Optional poll={attempts:1..6,interval_seconds:0.05..2} is read-only. Writes are never polled. Optional response_format=text permits explicitly documented text responses; default JSON failures preserve private raw evidence and reparse locally without a resend.

Optional reconcile on a write step contains operation, actor, params, query, checks. It must use a declared GET/HEAD, current policy and at least one identity/effect check beyond status_code. operation_intent_id is a kernel-provided stable variable; a system may echo it as requestId if documented. Reconciliation checks use the query's actual response. Captures after reconciliation require the queried response to provide the cited fields. A reconciled case is RECONCILED/UNKNOWN for original response coverage; it is never given a fabricated original201 response.

Sources: MD/TXT/DOCX/text PDF/OpenAPI JSON, Recorder/HAR, basic BPMN XML summaries and bounded JSON configuration/AST-read summaries. PDF extraction may need pypdf/PyPDF2. OCR, browser DOM replay, arbitrary JS/Java interpretation and whole-program causal proof are not implemented. Use narrow inspect topics facts/text/operations/relations/groups/lineage/results/errors/help/tasks. Each page is bounded; use offsets rather than dumping a database.
