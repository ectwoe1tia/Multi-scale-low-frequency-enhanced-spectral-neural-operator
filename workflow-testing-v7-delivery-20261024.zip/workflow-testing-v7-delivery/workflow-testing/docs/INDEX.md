# Current contract index

Read SKILL.md and AGENT-KERNEL.md first. Load only the current task's reference; do not search historical releases for parameters. All paths below are relative to this package.

| Need | Current source |
|---|---|
| AI/kernel/business responsibilities | [AGENT-KERNEL.md](AGENT-KERNEL.md) |
| Submit internal findings; scenario, policy, binding or probe | [DECISION.md](DECISION.md); [decision schema](../contracts/decision.schema.json) |
| Error code and fixed recovery | [RECOVERY.md](RECOVERY.md); [error catalog](../contracts/errors.json) |
| Current command fields | [tool help](../contracts/tool-help.json) |
| Machine response shape | [response schema](../contracts/response.schema.json) |
| Database versions supported by this package | [migration manifest](../migrations/manifest.json) |
| Maintaining and validating this package | [MAINTENANCE.md](MAINTENANCE.md) |

Large business inputs remain in the workspace. Use inspect with a narrow topic and search, then read only the returned query file. Error details are separate referenced files. Generated plans and entire databases are not normal context inputs.
