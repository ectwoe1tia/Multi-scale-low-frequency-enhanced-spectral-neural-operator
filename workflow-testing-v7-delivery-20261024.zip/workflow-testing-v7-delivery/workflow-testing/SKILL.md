---
name: workflow-testing
description: 根据已有需求、设计、接口文档和系统规约设计并执行流程测试；可读取 Recorder/HAR、分批调用接口、探查数据关系，使用 SQLite 累积规则和运行证据，输出业务报告。业务方无需编写技术配置。
---

# 流程测试 v7 · 20261024

业务方只提供已有资料、测试目标和必要的业务解释。AI 负责理解与调度，内核负责校验、执行和恢复。内部 JSON、字段绑定、文件组、计划均由 AI 与程序生成，**不要要求业务方填写**。自然语言理解由当前模型完成，无需额外模型 API。

先读 [职责边界](docs/AGENT-KERNEL.md)。细节只按 [当前索引](docs/INDEX.md) 加载，包内文档均服务当前契约。

唯一入口：`scripts/Invoke-WorkflowTesting.ps1`，或 `python -X utf8 scripts/workflow.py`。动作只有 `open / advance / submit / inspect / report`，参数通过数组传递，不拼 inline JSON、curl、SQL 或 shell。

在 PowerShell 中按引用读取小文本时使用 `Get-Content -Encoding UTF8`，避免默认解码制造中文乱码。大文件仍交给程序处理。

```powershell
& '<skill>/scripts/Invoke-WorkflowTesting.ps1' -Project '<系统工作区>' -Action open -Sources '<已有资料目录>' -System '<系统名>'
& '<skill>/scripts/Invoke-WorkflowTesting.ps1' -Project '<系统工作区>' -Action advance
```

用户已授权真实测试且具备测试连接时，open 加 `-Execute`；设计任务默认不发业务请求。缺少连接仍交付静态设计报告。后续用户授权执行，可再次 open 加 Execute，advance 本身不扩大授权。

根据响应推进：

1. `NEEDS_AGENT` 是正常交接。只读取 next_action.request_ref 指向的当前任务和 packet；按 [DECISION](docs/DECISION.md) 生成工作区内的内部 decision，然后 submit。task、snapshot、哈希均由程序绑定，不手抄。技术格式错误由 AI 修复。
2. `RUNNABLE`：继续 advance，程序自动处理刷新、编译、有限批次和接续。只保留当前 run、动作、证据引用；不整份读取 HAR、数据库、计划或响应。
3. `WAITING_SYSTEM / BLOCKED`：按 error.code、effect_state、recovery_action 和 retry_condition 处理；查 [恢复目录](docs/RECOVERY.md)。不从中英文 message 猜重试。自动处理有持久预算，预算耗尽就停止该项，继续独立测试。
4. 技术关系先 inspect 查询相关片段、relations/lineage，再由程序比较与受限只读 probe 分支取证；必要时用仅含小证据包的独立 subagent 复核。相等值、调用顺序、模型意见不自动成为因果或绑定授权。
5. `WAITING_BUSINESS`：仅向业务方解释原文冲突、影响和可理解的选项。字段绑定、锁、数据库升级、账号连接交由 AI/系统接入者处理。
6. `COMPLETED` 或需要阶段交付时调用 report，提供 summary_ref 中的业务报告。完成工具动作不等于测试通过；探测结果、未执行、未知和业务 FAIL 分别报告。

发送意图与真实证据由内核独占。UNKNOWN 请求先用声明的查询核对；不换 run/action ID 重发，不清库、不删锁、不改原 FAIL。已收到响应但解析失败只允许本地重解析。经验库不提供执行授权。

运行后若出现 REVIEW_RUN 任务，查询有限的 results/lineage，总结“先查什么、变量来自哪里、条件何时失效”，提交 query_strategy；无新增结论可提交空 findings。接力只需同一工作区和本包，advance 会恢复任务与账本。
