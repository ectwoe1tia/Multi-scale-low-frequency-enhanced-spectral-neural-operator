[CmdletBinding()]
param(
    [string]$Project,
    [string]$Action='advance',
    [string]$Sources,[string]$System,[string]$Decision,[string]$Ticket,
    [switch]$Execute,[switch]$NewRun,[string]$Topic='facts',[string]$Search='',
    [int]$Offset=0,[string]$Python='python'
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$OutputEncoding=[Console]::OutputEncoding
try {
    $pythonCommand=Get-Command -Name $Python -CommandType Application -ErrorAction Stop | Select-Object -First 1
} catch {
    $packageRoot=Split-Path -Parent $PSScriptRoot
    $catalog=Get-Content -LiteralPath (Join-Path $packageRoot 'contracts/errors.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $entry=$catalog.ENVIRONMENT_UNAVAILABLE
    $entry | Add-Member -NotePropertyName 'effect_state' -NotePropertyValue 'NOT_SENT'
    $entry | Add-Member -NotePropertyName 'blocks' -NotePropertyValue @{scope='WORKSPACE';ref=''}
    $response=@{contract_version='7.0';call_id=('CALL-'+[guid]::NewGuid().ToString('N'));run_id=$null;
        workflow_state='WAITING_SYSTEM';test_outcome='NOT_EVALUATED';error=$entry;next_action=@{kind='NONE'};
        evidence_refs=@();summary_ref=$null}
    [Console]::Out.WriteLine(($response | ConvertTo-Json -Compress -Depth 8))
    exit 20
}
$arguments=@('-X','utf8',(Join-Path $PSScriptRoot 'workflow.py'),'--project',$Project,'--action',$Action)
if ($Sources) {$arguments+=@('--sources',$Sources)}
if ($System) {$arguments+=@('--system',$System)}
if ($Decision) {$arguments+=@('--decision',$Decision)}
if ($Ticket) {$arguments+=@('--ticket',$Ticket)}
if ($Execute) {$arguments+='--execute'}
if ($NewRun) {$arguments+='--new-run'}
if ($Action -eq 'inspect') {
    $arguments+=@('--topic',$Topic,'--offset',"$Offset")
    if ($Search) {$arguments+=@('--search',$Search)}
}
& $pythonCommand.Source @arguments
exit $LASTEXITCODE
