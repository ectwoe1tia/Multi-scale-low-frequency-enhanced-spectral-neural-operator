#!/usr/bin/env python3
"""One current entrypoint; all control output follows the current response schema."""
import argparse
import contextlib
import io
import json
import os
import sys
import uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from runtime import common as c
from runtime import contract
from runtime.kernel import Kernel
from runtime.locking import exclusive

class Parser(argparse.ArgumentParser):
    def error(self,message):raise contract.Fault('DECISION_INVALID',detail='CLI argument mismatch')

def main(argv=None):
    root=None;kernel=None;receipt=None
    try:
        parser=Parser(description=__doc__)
        parser.add_argument('--project',required=True)
        parser.add_argument('--action',choices=contract.ACTIONS,default='advance')
        parser.add_argument('--sources');parser.add_argument('--system');parser.add_argument('--execute',action='store_true')
        parser.add_argument('--new-run',action='store_true');parser.add_argument('--decision');parser.add_argument('--ticket')
        parser.add_argument('--topic',default='facts');parser.add_argument('--search',default='');parser.add_argument('--offset',type=int,default=0)
        args=parser.parse_args(argv);contract.require(bool(args.project.strip()),pointer='/project')
        root=Path(args.project).resolve();kernel=Kernel(root)
        receipt='artifacts/calls/'+uuid.uuid4().hex+'.json'
        require_options(args)
        with contextlib.redirect_stdout(io.StringIO()):
            with contextlib.nullcontext() if args.action in ('inspect','report') else exclusive(root):
                if args.action=='open':value=kernel.open(args.sources,args.system,args.execute,args.new_run)
                elif args.action=='advance':value=kernel.advance()
                elif args.action=='submit':value=kernel.submit(args.decision,args.ticket)
                elif args.action=='inspect':value=kernel.inspect(args.topic,args.search,args.offset)
                else:value=kernel.report()
    except contract.Fault as exc:
        if exc.code=='WORKSPACE_BUSY' and kernel:exc=kernel.note_lock_failure()
        if root and exc.detail is not None:
            ref='artifacts/diagnostics/'+uuid.uuid4().hex+'.json'
            try:c.write(root/ref,{'code':exc.code,'pointer':exc.pointer,'detail':c.redact(exc.detail)});exc.detail_ref=ref
            except (contract.Fault,OSError):pass
        state='WAITING_SYSTEM' if exc.as_dict()['human_target'] in ('SYSTEM','MAINTAINER') else 'WAITING_BUSINESS' if exc.as_dict()['human_target']=='BUSINESS' else 'BLOCKED'
        value=contract.response(kernel.run_id if kernel else None,state,'UNKNOWN' if exc.effect=='MAY_HAVE_BEEN_SENT' else 'NOT_EVALUATED',exc)
    except (KeyboardInterrupt,SystemExit):
        raise
    except OSError as exc:
        value=contract.response(kernel.run_id if kernel else None,'WAITING_SYSTEM',fault=contract.Fault('IO_ERROR',detail=type(exc).__name__))
    except Exception as exc:
        ref='artifacts/diagnostics/'+uuid.uuid4().hex+'.json'
        if root:
            try:c.write(root/ref,{'type':type(exc).__name__,'phase':'KERNEL'})
            except (OSError,contract.Fault):pass
        value=contract.response(kernel.run_id if kernel else None,'BLOCKED',fault=contract.Fault('INTERNAL_ERROR'),refs=[ref] if root else [])
    if root and receipt:
        try:
            c.write(root/receipt,{'control':value,'request':{k:v for k,v in vars(args).items()}})
            value['evidence_refs'].append(receipt)
        except (OSError,contract.Fault):
            value=contract.response(value['run_id'],'WAITING_SYSTEM',fault=contract.Fault('IO_ERROR'))
    try:contract.validate(value,contract.schemas()['response'])
    except contract.Fault:value=contract.response(value.get('run_id'),'BLOCKED',fault=contract.Fault('INTERNAL_ERROR'))
    raw=c.encoded(value)
    if len(raw.encode('utf-8'))>2048:
        # Full detail already has a receipt. Never paste oversized business data into stdout.
        value['evidence_refs']=[receipt] if receipt else []
        if value['error']:value['error'].pop('detail_ref',None)
        raw=c.encoded(value)
    print(raw)
    return contract.exit_code(value)

def require_options(args):
    contract.require(not args.execute or args.action=='open',pointer='/execute')
    contract.require(not args.new_run or args.action=='open',pointer='/new_run')
    contract.require(args.action!='open' or bool(args.sources),pointer='/sources')
    contract.require(args.action!='submit' or bool(args.decision),pointer='/decision')

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
