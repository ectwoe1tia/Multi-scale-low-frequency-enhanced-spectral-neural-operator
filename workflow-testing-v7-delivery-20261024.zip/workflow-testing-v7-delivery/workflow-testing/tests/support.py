"""Synthetic documents and actual loopback HTTP service for observable kernel acceptance."""
import json
import socket
import threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from runtime import common as c
from runtime import storage as s
from runtime.kernel import Kernel

TEXT=('需求与接口说明：POST /instances 创建申请，金额大于零返回201，JSON有id、state和requestId，state初始为manager。'
      'GET /instances/{instance_id} 按创建响应id查询，返回200及相同id和state；instance_id取创建响应的id。'
      'POST /commit-drop 会创建申请但模拟断开响应；POST /slow 延迟响应；POST /non-json 模拟非JSON响应。'
      'GET /by-request/{request_id} 通过创建请求的requestId查询申请，成功返回200及原申请id、requestId、state。'
      'GET /unstable 查询ready，GET /redirect 返回302，GET /target 查询目标，GET /large 返回大数据。'
      'GET /probe/{code} 查询状态，路径200返回200，路径404返回404；不存在提示msg为对象不存在。'
      '测试规约：只在本地测试，使用observer匿名角色，允许这些创建和查询接口；不得删除数据。')

class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self):
        super().__init__(('127.0.0.1',0),Handler);self.calls=[];self.items={};self.polls=0
        self.committed=threading.Event();self.release=threading.Event();self.thread=threading.Thread(target=self.serve_forever,daemon=True)
    def __enter__(self):self.thread.start();return self
    def __exit__(self,*args):self.release.set();self.shutdown();self.server_close();self.thread.join(timeout=3)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def reply(self,status,body,headers=None,raw=False):
        data=body if raw else json.dumps(body).encode('utf-8')
        self.send_response(status);self.send_header('Content-Length',str(len(data)))
        for key,value in (headers or {}).items():self.send_header(key,value)
        self.end_headers()
        try:self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):pass
    def do_POST(self):
        self.server.calls.append((self.command,self.path,dict(self.headers)))
        body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))) or b'{}')
        if self.path in ('/instances','/commit-drop','/slow','/non-json'):
            if self.path=='/instances' and body.get('amount',1)<=0:self.reply(400,{'msg':'金额必须大于零'});return
            iid='instance-'+str(len(self.server.items)+1)
            item=dict(id=iid,state='manager',requestId=body.get('requestId',''),access_token='response-secret-canary')
            self.server.items[iid]=item;self.server.committed.set()
            if self.path=='/slow':self.server.release.wait(8)
            if self.path=='/commit-drop':
                self.connection.shutdown(socket.SHUT_RDWR);self.connection.close();return
            if self.path=='/non-json':self.reply(201,b'<broken-json>',raw=True);return
            self.reply(201,item)
        else:self.reply(404,{'msg':'对象不存在'})
    def do_GET(self):
        self.server.calls.append((self.command,self.path,dict(self.headers)))
        if self.path.startswith('/instances/'):
            item=self.server.items.get(self.path.rsplit('/',1)[-1]);self.reply(200 if item else 404,item or {'msg':'对象不存在'})
        elif self.path.startswith('/by-request/'):
            key=self.path.rsplit('/',1)[-1];item=next((item for item in self.server.items.values() if item['requestId']==key),None)
            self.reply(200 if item else 404,item or {'msg':'对象不存在'})
        elif self.path=='/unstable':self.server.polls+=1;self.reply(200,{'ready':self.server.polls>=3})
        elif self.path=='/redirect':self.reply(302,{},headers={'Location':'/target'})
        elif self.path=='/large':self.reply(200,{'payload':'x'*(1024*1024+500)})
        elif self.path.startswith('/probe/'):
            code=int(self.path.rsplit('/',1)[-1]);self.reply(code,{'msg':'对象不存在' if code==404 else 'ok'})
        else:self.reply(200,{'ready':True})

def step(name,operation,status=200,params=None,body=None,capture=None,checks=None):
    return dict(id=name,operation=operation,actor='observer',params=params or {},query={},body=body,capture=capture or {},
                checks=[dict(id=name+'-http',pointer='/status_code',op='eq',expected=status)]+(checks or []))

class Fixture:
    def __init__(self,base,port=12345):
        self.base=Path(base);self.materials=self.base/'materials';self.materials.mkdir()
        self.root=self.base/'project';self.kernel=Kernel(self.root);self.port=port;self.auto_bindings=True
        (self.materials/'requirements.md').write_text(TEXT,encoding='utf-8')
    def policy(self):return dict(base_url='http://127.0.0.1:'+str(self.port),environment=dict(name='local-test',kind='local',release='v7-fixture'),
        allow_mutations=True,actors={'observer':{'bearer_token_env':''}},timeout_seconds=3)
    def scenario(self):return dict(category='happy_path',priority='P0',vars={'amount':100},bindings={},steps=[
        step('create','POST /instances',201,body={'amount':'${amount}'},capture={'iid':'/body/id'}),
        step('query','GET /instances/{instance_id}',params={'instance_id':'${iid}'},checks=[dict(id='identity',pointer='/body/id',op='eq',expected='${iid}')])])
    def start(self,execute=False):return self.kernel.open(self.materials,'Fixture',execute)
    def packet(self,value):
        action=c.read_json(self.root/value['next_action']['request_ref'])
        return c.read_json(self.root/action['request']['packet_ref'])
    def finding(self,packet,name,kind,payload,summary='创建并查询申请'):
        chunk=next(v for v in packet['chunks'] if v['kind']=='document')
        citations=[{'chunk':chunk['id'],'quote':chunk['text'][:700]}]
        if self.auto_bindings and kind=='scenario' and len(payload.get('steps',[]))>1:
            binding=payload['bindings'].get('iid')
            if binding is None and any('iid' in st.get('capture',{}) for st in payload['steps']):
                payload['bindings']['iid']=dict(source_step=payload['steps'][0]['id'],pointer='/body/id',rationale='创建响应id供查询',
                    citations=[{'chunk':chunk['id'],'quote':'instance_id取创建响应的id'}])
        return dict(name=name,kind=kind,summary=summary,citations=citations,payload=payload)
    def submit(self,value,findings):
        action=c.read_json(self.root/value['next_action']['request_ref']);path=self.root/'artifacts/internal-decision.json'
        c.write(path,{'findings':findings});return self.kernel.submit(path,action['request']['task_id'])
    def prepare(self,execute=False,scenarios=None,policy=None):
        value=self.start(execute);written=False
        while value['workflow_state']=='NEEDS_AGENT':
            packet=self.packet(value)
            findings=[]
            if not written and any(v['kind']=='document' for v in packet['chunks']):
                findings=[self.finding(packet,'environment','convention',policy or self.policy())]
                for name,payload in (scenarios or [('create-query',self.scenario())]):findings.append(self.finding(packet,name,'scenario',payload))
                written=True
            self.submit(value,findings)
            # Stop once all original slices have been reviewed; do not execute during fixture preparation.
            next_task=self.kernel.task()
            if not next_task:break
            value=next_task
        return self.kernel

def create_v1(path,kind):
    import sqlite3,time
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);db=sqlite3.connect(str(path))
    for sql in s.BASE[kind]:db.execute(sql)
    db.execute('CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY,checksum TEXT NOT NULL,tool_build TEXT NOT NULL,backup TEXT,completed_at REAL NOT NULL)')
    db.execute('INSERT INTO schema_migrations VALUES(?,?,?,?,?)',(1,c.digest(s.BASE[kind]),'fixture',None,time.time()))
    db.execute('PRAGMA application_id='+str(s.IDS[kind]));db.execute('PRAGMA user_version=1');db.commit();db.close()
