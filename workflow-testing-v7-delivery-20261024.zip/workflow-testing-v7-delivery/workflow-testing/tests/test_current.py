import copy
import errno
import importlib.util
import io
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
import zipfile
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch
PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE));sys.path.insert(0,str(Path(__file__).parent))
from runtime import common as c,storage as s,contract,intake,compiler,transport,relations
from runtime.kernel import Kernel
from runtime.locking import exclusive
from support import Fixture,Server,step,create_v1,TEXT
spec=importlib.util.spec_from_file_location('workflow_cli',PACKAGE/'scripts/workflow.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)

class CurrentTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def fault(self,code,fn,*args,**kwargs):
        with self.assertRaises(contract.Fault) as caught:fn(*args,**kwargs)
        self.assertEqual(caught.exception.code,code)
        return caught.exception
    def cli(self,*args):
        output=io.StringIO()
        with redirect_stdout(output):exit_code=cli.main(list(args))
        return exit_code,json.loads(output.getvalue())
    def finish_review(self,fixture,value):
        if value['workflow_state']=='NEEDS_AGENT':fixture.submit(value,[])
        return fixture.kernel.advance()

    def test_raw_documents_need_agent_with_no_error(self):
        f=Fixture(self.base);value=f.start()
        self.assertEqual(value['workflow_state'],'NEEDS_AGENT');self.assertIsNone(value['error'])
        self.assertEqual(contract.exit_code(value),20)
        self.assertLess(len(c.encoded(f.packet(value)).encode('utf-8')),8192)
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertGreater(db.execute('SELECT count(*) FROM memberships').fetchone()[0],0)

    def test_no_user_json_is_needed_to_open_powershell_paths(self):
        shell=shutil.which('powershell') or shutil.which('pwsh')
        if not shell:self.skipTest('PowerShell unavailable')
        f=Fixture(self.base);project=self.base/'项目 with spaces'
        run=subprocess.run([shell,'-NoProfile','-File',str(PACKAGE/'scripts/Invoke-WorkflowTesting.ps1'),'-Project',str(project),'-Action','open','-Sources',str(f.materials)],capture_output=True,timeout=20)
        self.assertEqual(run.returncode,20,run.stderr.decode('utf-8',errors='replace'))
        value=json.loads(run.stdout.decode('utf-8-sig'));self.assertEqual(value['workflow_state'],'NEEDS_AGENT');self.assertLess(len(run.stdout),2048)

    def test_structured_cli_parameter_error(self):
        code,value=self.cli('--project',str(self.base/'p'),'--action','old-session')
        self.assertEqual(value['error']['code'],'DECISION_INVALID');self.assertEqual(value['error']['recovery_action'],'REVISE_DECISION')
        self.assertNotEqual(code,0)

    def test_all_catalog_errors_have_closed_recovery(self):
        for name in contract.ERRORS:
            value=contract.Fault(name).as_dict()
            self.assertTrue(value['message_en']);self.assertTrue(value['message_zh']);self.assertIn('retry_condition',value)
            self.assertEqual(value['code'],name)

    def test_message_language_does_not_control_recovery(self):
        before=contract.Fault('SOURCE_CORRUPT').as_dict()
        with patch.dict(contract.ERRORS['SOURCE_CORRUPT'],message_en='Retry everything',message_zh='任意更改文字'):
            after=contract.Fault('SOURCE_CORRUPT').as_dict()
        self.assertEqual({k:v for k,v in before.items() if not k.startswith('message')},{k:v for k,v in after.items() if not k.startswith('message')})

    def test_contract_artifacts_match_generator(self):
        for name,value in contract.artifacts().items():self.assertEqual(c.read_json(PACKAGE/'contracts'/name,4*c.MAX_BYTES),value)
        self.assertEqual(c.read_json(PACKAGE/'migrations/manifest.json'),s.version_manifest())

    def test_corrupt_sources_isolated_and_originals_unchanged(self):
        f=Fixture(self.base);(f.materials/'broken.docx').write_bytes(b'bad-zip');(f.materials/'bad.har').write_text('{broken',encoding='utf-8')
        before={p.name:c.file_hash(p) for p in f.materials.iterdir()};f.start()
        with s.connect(f.kernel.knowledge,'knowledge') as db:
            self.assertEqual(db.execute('SELECT count(*) FROM source_errors').fetchone()[0],2)
            self.assertTrue(all(row['code']=='SOURCE_CORRUPT' for row in db.execute('SELECT code FROM source_errors')))
        self.assertEqual(before,{p.name:c.file_hash(p) for p in f.materials.iterdir()})

    def test_bad_utf8_document_is_source_error(self):
        f=Fixture(self.base);(f.materials/'bad.txt').write_bytes(b'\xff\xfe\x00');f.start()
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertEqual(db.execute('SELECT code FROM source_errors').fetchone()[0],'SOURCE_CORRUPT')

    def test_docx_entity_is_rejected(self):
        path=self.base/'bad.docx'
        with zipfile.ZipFile(path,'w') as z:z.writestr('word/document.xml','<!DOCTYPE a><a/>')
        self.fault('SOURCE_CORRUPT',intake.extract,path,'bad.docx')

    def test_pdf_dependency_gap_is_explicit(self):
        path=self.base/'scan.pdf';path.write_bytes(b'%PDF-1.7')
        with patch.object(intake,'pdf_backend',return_value=None):self.fault('SOURCE_UNREADABLE',intake.extract,path,'scan.pdf')

    def test_source_membership_add_and_remove_refresh_group(self):
        f=Fixture(self.base);f.prepare()
        with s.connect(f.kernel.knowledge,'knowledge') as db:first=s.meta(db,'snapshot');facts=compiler.valid_facts(db,f.kernel.analysis_fingerprint())
        extra=f.materials/'extra.md';extra.write_text('补充规则应单独分析。',encoding='utf-8');value=f.kernel.advance()
        self.assertEqual(value['workflow_state'],'NEEDS_AGENT')
        with s.connect(f.kernel.knowledge,'knowledge') as db:
            self.assertNotEqual(first,s.meta(db,'snapshot'));self.assertEqual(len(compiler.valid_facts(db,f.kernel.analysis_fingerprint())),len(facts))
        extra.unlink();f.kernel.advance()
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertEqual(db.execute('SELECT count(*) FROM sources WHERE active=1').fetchone()[0],1)

    def test_source_changed_during_extract_not_published(self):
        f=Fixture(self.base);original=intake.parse_source
        def alter(*args):
            result=original(*args);(f.materials/'requirements.md').write_text(TEXT+'变化',encoding='utf-8');return result
        with patch.object(intake,'parse_source',side_effect=alter):self.fault('SOURCE_CHANGED',f.start)
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertEqual(db.execute('SELECT count(*) FROM sources').fetchone()[0],0)

    def test_same_input_reuses_extraction_and_reviews(self):
        f=Fixture(self.base);f.prepare()
        with patch.object(intake,'parse_source',side_effect=AssertionError('must not parse again')):value=f.kernel.open(f.materials)
        self.assertEqual(value['workflow_state'],'COMPLETED')

    def test_bad_quotation_does_not_complete_task(self):
        f=Fixture(self.base);value=f.start();packet=f.packet(value);item=f.finding(packet,'rule','requirement',{})
        item['citations'][0]['quote']='并不存在的引用内容'
        self.fault('EVIDENCE_MISMATCH',f.submit,value,[item])
        with s.connect(f.kernel.run_db,'run') as db:self.assertEqual(db.execute('SELECT status FROM tasks').fetchone()[0],'PENDING')

    def test_unknown_decision_field_is_structured(self):
        f=Fixture(self.base);value=f.start();packet=f.packet(value);item=f.finding(packet,'rule','requirement',{});item['execute_shell']='bad'
        self.fault('DECISION_INVALID',f.submit,value,[item])

    def test_empty_decision_generates_bounded_refinement_task(self):
        f=Fixture(self.base);value=f.start();f.submit(value,[])
        first=f.kernel.advance();self.assertEqual(f.packet(first)['purpose'],'REFINE_ANALYSIS');f.submit(first,[])
        second=f.kernel.advance();f.submit(second,[])
        last=f.kernel.advance();self.assertEqual(last['workflow_state'],'BLOCKED')
        with s.connect(f.kernel.run_db,'run') as db:self.assertEqual(db.execute('SELECT max(attempts) FROM recoveries').fetchone()[0],2)

    def test_completed_ticket_idempotent_cannot_silently_replace(self):
        f=Fixture(self.base);value=f.start();f.submit(value,[]);f.submit(value,[])
        packet=f.packet(value);self.fault('DECISION_INVALID',f.submit,value,[f.finding(packet,'late','requirement',{})])

    def test_trace_cannot_define_normative_expected(self):
        f=Fixture(self.base);c.write(f.materials/'r.har',{'log':{'entries':[]}});value=f.start();packet=f.packet(value)
        trace=next(ch for ch in packet['chunks'] if ch['kind']=='har')
        item=dict(name='guessed',kind='requirement',summary='历史成功就算预期',citations=[{'chunk':trace['id'],'quote':trace['text'][:200]}],payload={})
        self.fault('EVIDENCE_MISMATCH',f.submit,value,[item])

    def test_sql_views_closed_and_output_bounded(self):
        f=Fixture(self.base);f.prepare();self.fault('DECISION_INVALID',f.kernel.inspect,'facts;DELETE FROM facts')
        value=f.kernel.inspect('facts');self.assertLess((f.root/value['summary_ref']).stat().st_size,8192)

    def test_configuration_ast_is_static_and_values_omitted(self):
        summary=relations.configuration_summary({'expression':'=amount + tax','other':'=__import__("os").system("bad")','bad':'value\ufffd'})
        self.assertIn('amount',summary['expression_dependencies'][0]['reads']);self.assertTrue(summary['suspicious_locations'])
        self.assertTrue(summary['values_omitted'])

    def test_missing_binding_blocks_only_that_case(self):
        f=Fixture(self.base);f.auto_bindings=False;scenario=f.scenario();scenario['bindings']={}
        f.prepare(scenarios=[('bad',scenario),('good',dict(category='integration',priority='P1',vars={},bindings={},steps=[step('read','GET /probe/{code}',200,{'code':'200'})]))])
        value=f.kernel.advance()
        with s.connect(f.kernel.run_db,'run') as db:
            self.assertEqual(db.execute('SELECT count(*) FROM cases').fetchone()[0],1);self.assertEqual(db.execute('SELECT count(*) FROM diagnostics').fetchone()[0],1)

    def test_probe_rejects_mutation(self):
        f=Fixture(self.base);payload=f.scenario();payload.update(mode='probe',question='哪个字段正确')
        f.prepare(scenarios=[('probe',payload)]);f.kernel.advance()
        with s.connect(f.kernel.run_db,'run') as db:self.assertEqual(db.execute('SELECT code FROM diagnostics').fetchone()[0],'POLICY_DENIED')

    def test_future_db_version_never_writes(self):
        path=self.base/'db.sqlite';s.ensure(path,'knowledge');db=sqlite3.connect(str(path));db.execute('PRAGMA user_version=999');db.commit();db.close();before=c.file_hash(path)
        self.fault('DB_VERSION_UNSUPPORTED',s.ensure,path,'knowledge');self.assertEqual(before,c.file_hash(path))

    def test_unversioned_nonempty_db_not_initialized(self):
        path=self.base/'db.sqlite';db=sqlite3.connect(str(path));db.execute('CREATE TABLE old_data(v TEXT)');db.commit();db.close()
        self.fault('UNVERSIONED_WORKSPACE',s.ensure,path,'knowledge')
        db=sqlite3.connect(str(path));self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],0);db.close()

    def test_wrong_application_id_rejected(self):
        path=self.base/'db.sqlite';s.ensure(path,'knowledge');self.fault('DB_VERSION_UNSUPPORTED',s.ensure,path,'run')

    def test_corrupt_db_does_not_rebuild(self):
        path=self.base/'db.sqlite';path.write_bytes(b'database-corrupt-content');before=path.read_bytes()
        self.fault('DB_CORRUPT',s.ensure,path,'run');self.assertEqual(before,path.read_bytes())

    def test_known_migration_backup_and_version(self):
        path=self.base/'db.sqlite';create_v1(path,'knowledge');s.ensure(path,'knowledge')
        with s.connect(path,'knowledge') as db:self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],2)
        backups=list(self.base.glob('*.before-v2-*.sqlite'));self.assertEqual(len(backups),1)
        db=sqlite3.connect(str(backups[0]));self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],1);db.close()

    def test_migration_failure_rolls_back(self):
        path=self.base/'db.sqlite';create_v1(path,'knowledge')
        with patch.dict(s.UPGRADE,knowledge=['ALTER TABLE not_present ADD COLUMN value TEXT']):self.fault('DB_MIGRATION_FAILED',s.ensure,path,'knowledge')
        db=sqlite3.connect(str(path));self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],1);self.assertEqual(db.execute('SELECT max(version) FROM schema_migrations').fetchone()[0],1);db.close()

    def test_migration_checksum_tamper_rejected(self):
        path=self.base/'db.sqlite';s.ensure(path,'knowledge');db=sqlite3.connect(str(path));db.execute("UPDATE schema_migrations SET checksum='bad' WHERE version=2");db.commit();db.close()
        self.fault('DB_CORRUPT',s.ensure,path,'knowledge')

    def test_pending_execution_prevents_run_migration(self):
        path=self.base/'db.sqlite';create_v1(path,'run');db=sqlite3.connect(str(path))
        db.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?,?)',('r','case','step','key','POST','SENDING','{}',None));db.commit();db.close()
        self.fault('RECONCILIATION_REQUIRED',s.ensure,path,'run')

    def test_os_lock_remains_reacquirable_with_file_present(self):
        with self.assertRaises(RuntimeError):
            with exclusive(self.base):raise RuntimeError('synthetic')
        self.assertTrue((self.base/'system/workspace.lock').exists())
        with exclusive(self.base):pass

    def test_actual_process_lock_competition_and_kill_release(self):
        script="import sys,time;sys.path.insert(0,sys.argv[1]);from runtime.locking import exclusive;from pathlib import Path\nwith exclusive(Path(sys.argv[2])):\n print('READY',flush=True)\n time.sleep(30)"
        process=subprocess.Popen([sys.executable,'-c',script,str(PACKAGE),str(self.base)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            self.assertEqual(process.stdout.readline().strip(),'READY')
            self.fault('WORKSPACE_BUSY',lambda:exclusive_test(self.base))
            process.kill();process.wait(timeout=5)
            with exclusive(self.base):pass
        finally:
            if process.poll() is None:process.kill();process.wait()
            process.stdout.close();process.stderr.close()

    def test_atomic_publish_failure_cleans_temporary_only(self):
        path=self.base/'result.json';c.write(path,{'old':True})
        with patch.object(c.os,'replace',side_effect=OSError(errno.ENOSPC,'disk full')):self.fault('IO_ERROR',c.write,path,{'new':True})
        self.assertEqual(c.read_json(path),{'old':True});self.assertEqual(list(self.base.glob('*.tmp')),[])

    def test_real_http_report_lineage_and_no_resend(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare(True);value=k.advance();self.assertEqual(len(server.calls),2)
            completed=self.finish_review(f,value);self.assertEqual(completed['test_outcome'],'PASS');self.assertEqual(len(server.calls),2)
            k.advance();self.assertEqual(len(server.calls),2)
            with s.connect(k.knowledge,'knowledge') as db:self.assertEqual(db.execute('SELECT variable FROM lineage').fetchone()[0],'iid')
            report=(f.root/completed['summary_ref']).read_text(encoding='utf-8');self.assertIn('POST /instances',report);self.assertIn('实际',report);self.assertNotIn('response-secret-canary',report)

    def test_custom_business_headers_from_environment_once(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);policy=f.policy();policy['headers']={'x-client-id':{'env':'WF_CLIENT_ID'}}
            k=f.prepare(True,policy=policy)
            with patch.dict(os.environ,WF_CLIENT_ID='client-secret-canary'):k.advance()
            self.assertEqual(server.calls[0][2].get('x-client-id'),'client-secret-canary')
            self.assertNotIn('client-secret-canary',(f.root/'reports'/ (k.run_id+'.md')).read_text(encoding='utf-8'))

    def test_no_credentials_still_has_static_report(self):
        f=Fixture(self.base);policy=f.policy();policy['actors']['observer']['bearer_token_env']='WF_TEST_NOT_CONNECTED'
        k=f.prepare(True,policy=policy)
        with patch.dict(os.environ,{},clear=True):value=k.advance()
        self.assertEqual(value['workflow_state'],'WAITING_SYSTEM');self.assertEqual(value['error']['code'],'CONNECTION_REQUIRED');self.assertTrue((f.root/value['summary_ref']).exists())

    def test_explicit_status_and_guard_before_network(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);policy=f.policy();policy['allow']=[{'operation':'POST /instances','actors':['observer'],'guards':[{'pointer':'/body/amount','op':'gt','expected':200}]}]
            k=f.prepare(True,scenarios=[('guarded',dict(category='validation',priority='P0',vars={},bindings={},steps=[step('create','POST /instances',201,body={'amount':100})]))],policy=policy);k.advance()
            self.assertEqual(server.calls,[])

    def test_write_intent_persist_failure_sends_zero_requests(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare(True);original=s.event
            def fail(db,intent,state,payload):
                if state=='INTENT_COMMITTED':raise contract.Fault('IO_ERROR')
                return original(db,intent,state,payload)
            with patch.object(s,'event',side_effect=fail):k.advance()
            self.assertEqual(server.calls,[])
            with s.connect(k.run_db,'run') as db:self.assertEqual(db.execute('SELECT count(*) FROM requests').fetchone()[0],0)

    def test_commit_then_drop_is_not_replayed_or_forked(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);payload=f.scenario();payload['steps'][0]['operation']='POST /commit-drop'
            k=f.prepare(True,scenarios=[('uncertain',payload)]);value=k.advance();self.assertEqual(value['test_outcome'],'UNKNOWN');self.assertEqual(len(server.items),1)
            k.advance();self.assertEqual(len(server.items),1);self.fault('REQUEST_OUTCOME_UNKNOWN',k.open,f.materials,new_run=True)

    def test_received_non_json_reparses_locally_without_resend(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);payload=dict(category='validation',priority='P0',vars={},bindings={},steps=[step('create','POST /non-json',201,body={})])
            k=f.prepare(True,scenarios=[('parse',payload)]);value=k.advance();self.assertEqual(value['error']['code'],'RESPONSE_INVALID')
            k.advance();k.advance();self.assertEqual(len(server.calls),1);self.assertTrue(list((f.root/'private/wire').glob('*.bin')))

    def test_reconciliation_proves_effect_without_fabricating_original_http(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);payload=f.scenario();first=payload['steps'][0];first['operation']='POST /commit-drop';first['body']['requestId']='${operation_intent_id}'
            first['reconcile']=dict(operation='GET /by-request/{request_id}',actor='observer',params={'request_id':'${operation_intent_id}'},query={},checks=[
                dict(id='lookup-status',pointer='/status_code',op='eq',expected=200),dict(id='request-identity',pointer='/body/requestId',op='eq',expected='${operation_intent_id}')])
            k=f.prepare(True,scenarios=[('reconcile',payload)]);k.advance();value=k.advance()
            self.assertEqual(len([x for x in server.calls if x[0]=='POST']),1)
            with s.connect(k.run_db,'run') as db:self.assertEqual(db.execute('SELECT state FROM cases').fetchone()[0],'RECONCILED')
            report=(f.root/'reports'/(k.run_id+'.md')).read_text(encoding='utf-8');self.assertIn('RECONCILED',report)
            self.assertNotEqual(value['test_outcome'],'PASS')

    def test_readonly_poll_budget_and_actual_requests(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);query=step('read','GET /unstable',checks=[dict(id='ready',pointer='/body/ready',op='eq',expected=True)]);query['poll']={'attempts':4,'interval_seconds':.05}
            k=f.prepare(True,scenarios=[('poll',dict(category='timing',priority='P1',vars={},bindings={},steps=[query]))]);k.advance()
            self.assertEqual(server.polls,3)
            with s.connect(k.run_db,'run') as db:self.assertEqual(db.execute('SELECT state FROM cases').fetchone()[0],'PASS')

    def test_branch_observations_never_count_as_business_pass(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);scenarios=[]
            for name,expected in [('first',200),('second',404)]:
                scenarios.append((name,dict(category='integration',priority='P1',vars={},bindings={},mode='probe',question='缺失对象怎么识别',steps=[step('read','GET /probe/{code}',expected,{'code':'404'})])))
            k=f.prepare(True,scenarios=scenarios);k.advance();summary=c.read_json(f.root/'reports'/(k.run_id+'.json'))
            self.assertEqual(summary['counts']['PASS'],0);self.assertEqual(summary['counts']['PROBE'],2);self.assertEqual(summary['branch_resolutions'][0]['state'],'DISCRIMINATED_THIS_RUN')

    def test_failed_dependency_does_not_block_independent_case(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);base=dict(category='integration',priority='P1',vars={},bindings={},steps=[step('read','GET /probe/{code}',200,{'code':'404'})])
            dependent=copy.deepcopy(base);dependent['depends_on']=['first'];independent=copy.deepcopy(base);independent['steps'][0]['checks'][0]['expected']=404
            k=f.prepare(True,scenarios=[('first',base),('second',dependent),('third',independent)]);k.advance()
            with s.connect(k.run_db,'run') as db:self.assertEqual({r['id']:r['state'] for r in db.execute('SELECT * FROM cases')},{'first':'FAIL','second':'BLOCKED','third':'PASS'})
            self.assertEqual(len(server.calls),2)

    def test_parent_killed_after_commit_releases_lock_but_never_resends(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);payload=dict(category='recovery',priority='P0',vars={},bindings={},steps=[step('slow','POST /slow',201,body={})]);k=f.prepare(True,scenarios=[('slow',payload)])
            process=subprocess.Popen([sys.executable,'-X','utf8',str(PACKAGE/'scripts/workflow.py'),'--project',str(f.root),'--action','advance'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:
                self.assertTrue(server.committed.wait(5));process.kill();process.wait(timeout=5)
                with exclusive(f.root):pass
                server.release.set();k.advance();self.assertEqual(len([x for x in server.calls if x[0]=='POST']),1)
            finally:
                server.release.set()
                if process.poll() is None:process.kill();process.wait()
                process.stdout.close();process.stderr.close()

    def test_invalid_submit_budget_survives_new_kernel_instance(self):
        f=Fixture(self.base);value=f.start();packet=f.packet(value);item=f.finding(packet,'bad','requirement',{});item['extra']='invalid'
        self.fault('DECISION_INVALID',f.submit,value,[item]);f.kernel=Kernel(f.root)
        self.fault('DECISION_INVALID',f.submit,value,[item]);self.fault('BUDGET_EXHAUSTED',f.submit,value,[item])

    def test_permission_failure_has_io_contract(self):
        f=Fixture(self.base)
        with patch.object(intake,'parse_source',side_effect=PermissionError('synthetic')):
            code,value=self.cli('--project',str(f.root),'--action','open','--sources',str(f.materials))
        self.assertEqual(value['error']['code'],'IO_ERROR');self.assertEqual(value['workflow_state'],'WAITING_SYSTEM')
        self.assertEqual(value['error']['effect_state'],'NOT_SENT')

    def test_powershell_missing_python_is_structured(self):
        shell=shutil.which('powershell') or shutil.which('pwsh')
        if not shell:self.skipTest('PowerShell unavailable')
        run=subprocess.run([shell,'-NoProfile','-File',str(PACKAGE/'scripts/Invoke-WorkflowTesting.ps1'),'-Project',str(self.base/'p'),'-Python','no-such-workflow-python-xyz'],capture_output=True,timeout=15)
        value=json.loads(run.stdout.decode('utf-8-sig'));self.assertEqual(value['error']['code'],'ENVIRONMENT_UNAVAILABLE');self.assertEqual(run.returncode,20)

    def test_corrupt_only_source_yields_precise_system_action(self):
        materials=self.base/'raw';materials.mkdir();(materials/'broken.har').write_bytes(b'{bad')
        value=Kernel(self.base/'p').open(materials)
        self.assertEqual(value['workflow_state'],'WAITING_SYSTEM');self.assertEqual(value['error']['code'],'SOURCE_CORRUPT')

    def test_cached_good_source_clears_later_corruption(self):
        f=Fixture(self.base);f.prepare();path=f.materials/'requirements.md'
        path.write_bytes(b'\xff');f.kernel.refresh(f.materials)
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertEqual(db.execute('SELECT count(*) FROM source_errors').fetchone()[0],1)
        path.write_text(TEXT,encoding='utf-8');f.kernel.refresh(f.materials)
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertEqual(db.execute('SELECT count(*) FROM source_errors').fetchone()[0],0)

    def test_legacy_workspace_is_not_silently_reinitialized(self):
        f=Fixture(self.base);(f.root/'workbench').mkdir(parents=True);(f.root/'workbench/knowledge.sqlite').write_bytes(b'old')
        self.fault('UNVERSIONED_WORKSPACE',f.start);self.assertFalse((f.root/'system/knowledge.sqlite').exists())

    def test_plan_corruption_is_reported_then_rebuilt_without_resend(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare(True);value=k.advance()
            with s.connect(k.run_db,'run') as db:ref=s.meta(db,'plan_ref')
            (f.root/ref).write_text('{}',encoding='utf-8');self.fault('EVIDENCE_MISMATCH',k.advance)
            k.advance();self.assertEqual(len(server.calls),2)

    def test_internal_source_cache_repaired_from_matching_original(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare(True)
            with s.connect(k.knowledge,'knowledge') as db:ref=db.execute('SELECT copy FROM sources LIMIT 1').fetchone()[0]
            (f.root/ref).write_bytes(b'corrupt cache');k.advance();self.assertEqual(len(server.calls),2)
            self.assertEqual(c.file_hash(f.root/ref),c.file_hash(f.materials/'requirements.md'))

    def test_persist_failure_after_actual_send_remains_unknown(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare(True);original=c.write_bytes
            def fail(path,data):
                if 'private' in Path(path).parts:raise contract.Fault('IO_ERROR')
                return original(path,data)
            with patch.object(c,'write_bytes',side_effect=fail):value=k.advance()
            self.assertEqual(len(server.calls),1);self.assertEqual(value['test_outcome'],'UNKNOWN');k.advance();self.assertEqual(len(server.calls),1)

    def test_received_evidence_tamper_cannot_report_pass(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare(True);k.advance()
            with s.connect(k.run_db,'run') as db:ref=db.execute('SELECT evidence FROM requests LIMIT 1').fetchone()[0]
            (f.root/ref).write_text('{}',encoding='utf-8');self.fault('EVIDENCE_MISMATCH',k.report)

    def test_report_does_not_reuse_pass_after_source_changes(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare(True);k.advance()
            (f.materials/'requirements.md').write_text(TEXT+'规则发生变化。',encoding='utf-8')
            value=k.report();self.assertNotEqual(value['test_outcome'],'PASS');self.assertEqual(len(server.calls),2)

    def test_case_step_headers_and_case_insensitive_overlay(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);payload=f.scenario();payload['headers']={'X-Client-Id':{'env':'WF_CLIENT'}};payload['steps'][0]['headers']={'x-client-id':'overridden'}
            k=f.prepare(True,scenarios=[('headers',payload)])
            with patch.dict(os.environ,WF_CLIENT='private-client'):k.advance()
            self.assertEqual(next(v for k,v in server.calls[0][2].items() if k.lower()=='x-client-id'),'overridden')
            self.assertEqual(next(v for k,v in server.calls[1][2].items() if k.lower()=='x-client-id'),'private-client')

    def test_explicit_authorization_can_follow_design_without_reanalysis(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);k=f.prepare();k.advance();self.assertEqual(server.calls,[])
            k.open(f.materials,execute=True);self.assertEqual(len(server.calls),2)

    def test_probe_question_candidate_budget(self):
        f=Fixture(self.base);scenarios=[]
        for index in range(4):scenarios.append(('probe-'+str(index),dict(category='integration',priority='P1',vars={},bindings={},mode='probe',question='同一关系',steps=[step('read','GET /probe/{code}',200,{'code':'200'})])))
        k=f.prepare(scenarios=scenarios);k.advance()
        with s.connect(k.run_db,'run') as db:
            self.assertEqual(db.execute('SELECT count(*) FROM cases').fetchone()[0],3);self.assertEqual(db.execute('SELECT code FROM diagnostics').fetchone()[0],'BUDGET_EXHAUSTED')

    def har(self,f,name,value,duplicate=False,ambiguous=False,timing=True):
        body={'id':value}
        if ambiguous:body['other_id']=value
        entries=[{'startedDateTime':'2026-10-24T00:00:00Z','time':10,'request':{'method':'POST','url':'https://synthetic.example/instances','headers':[{'name':'Authorization','value':'Bearer never-echo'}]},'response':{'status':201,'content':{'text':json.dumps(body)}}},
                 {'startedDateTime':'2026-10-24T00:00:01Z','time':10,'request':{'method':'GET','url':'https://synthetic.example/instances/'+value},'response':{'status':200,'content':{'text':'{}'}}}]
        if not timing:
            for entry in entries:entry.pop('startedDateTime')
        c.write(f.materials/name,{'log':{'entries':entries}})

    def test_har_distinct_samples_support_but_never_bind(self):
        f=Fixture(self.base);self.har(f,'a.har','record-001');self.har(f,'b.har','record-002');f.start()
        with s.connect(f.kernel.knowledge,'knowledge') as db:rows=[json.loads(r[0]) for r in db.execute('SELECT payload FROM relations')]
        self.assertEqual(rows[0]['state'],'SUPPORTED_OBSERVATION');self.assertFalse(rows[0]['automatic_binding']);self.assertNotIn('record-001',(f.root/'system/knowledge.sqlite').read_bytes().decode('latin-1'))

    def test_duplicate_har_is_not_independent(self):
        f=Fixture(self.base);self.har(f,'a.har','record-001');shutil.copyfile(f.materials/'a.har',f.materials/'b.har');f.start()
        with s.connect(f.kernel.knowledge,'knowledge') as db:row=json.loads(db.execute('SELECT payload FROM relations').fetchone()[0])
        self.assertEqual(row['episodes'],1);self.assertEqual(row['state'],'CANDIDATE')

    def test_har_ambiguous_and_missing_timing(self):
        f=Fixture(self.base);self.har(f,'a.har','record-001',ambiguous=True);f.start()
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertTrue(all(json.loads(r[0])['state']=='AMBIGUOUS' for r in db.execute('SELECT payload FROM relations')))
        self.har(f,'a.har','record-001',timing=False);f.kernel.refresh(f.materials)
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertEqual(db.execute('SELECT count(*) FROM relations').fetchone()[0],0)

    def test_recorder_large_values_never_enter_packets(self):
        f=Fixture(self.base);c.write(f.materials/'recorder.json',{'steps':[{'type':'change','value':'secret-in-record','selectors':[['#private']]} for _ in range(1000)]});f.start()
        with s.connect(f.kernel.knowledge,'knowledge') as db:
            rows=db.execute("SELECT chunks.text FROM chunks JOIN sources ON source=sources.id WHERE kind='recorder'").fetchall()
        self.assertEqual(len(rows),1);self.assertNotIn('secret-in-record',rows[0][0])

    def test_actual_migration_process_crash_rolls_back_and_resumes(self):
        path=self.base/'db.sqlite';create_v1(path,'knowledge')
        script="""import sys,time
sys.path.insert(0,sys.argv[1])
from runtime import storage as s
original=s.raw
def raw(*args,**kwargs):
 db=original(*args,**kwargs)
 def pause():
  print('MIGRATING',flush=True)
  time.sleep(30)
  return 1
 db.create_function('fixture_pause',0,pause)
 return db
s.raw=raw
s.UPGRADE['knowledge']=s.UPGRADE['knowledge']+['SELECT fixture_pause()']
s.ensure(sys.argv[2],'knowledge')
"""
        process=subprocess.Popen([sys.executable,'-c',script,str(PACKAGE),str(path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            self.assertEqual(process.stdout.readline().strip(),'MIGRATING');process.kill();process.wait(timeout=5)
            db=sqlite3.connect(str(path));self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],1)
            self.assertNotIn('state',[r[1] for r in db.execute('PRAGMA table_info(facts)')]);db.close()
            s.ensure(path,'knowledge')
            with s.connect(path,'knowledge') as db:self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0],2)
        finally:
            if process.poll() is None:process.kill();process.wait()
            process.stdout.close();process.stderr.close()

    def test_corrupt_run_with_pending_write_never_creates_clean_replacement(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);payload=dict(category='recovery',priority='P0',vars={},bindings={},steps=[step('write','POST /commit-drop',201,body={})])
            k=f.prepare(True,scenarios=[('pending',payload)]);k.advance();k.run_db.write_bytes(b'broken-run-ledger')
            self.fault('DB_CORRUPT',k.open,f.materials,new_run=True);self.assertEqual(len(server.calls),1);self.assertEqual(k.run_db.read_bytes(),b'broken-run-ledger')

    def test_unknown_branch_allows_independent_read(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);one=dict(category='recovery',priority='P0',vars={},bindings={},steps=[step('write','POST /commit-drop',201,body={})])
            two=dict(category='integration',priority='P1',vars={},bindings={},steps=[step('read','GET /probe/{code}',200,{'code':'200'})])
            k=f.prepare(True,scenarios=[('first',one),('second',two)]);value=k.advance()
            self.assertEqual(value['test_outcome'],'UNKNOWN')
            with s.connect(k.run_db,'run') as db:self.assertEqual({r['id']:r['state'] for r in db.execute('SELECT * FROM cases')},{'first':'UNKNOWN','second':'PASS'})

    def test_batch_case_limit_resumes_with_no_repeated_requests(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);cases=[]
            for i in range(11):cases.append(('case-'+str(i),dict(category='integration',priority='P1',vars={},bindings={},steps=[step('read','GET /probe/{code}',200,{'code':'200'})])))
            k=f.prepare(True,scenarios=cases);value=k.advance();self.assertEqual(value['workflow_state'],'RUNNABLE');self.assertEqual(len(server.calls),10)
            k.advance();self.assertEqual(len(server.calls),11)

    def test_oversized_single_case_gets_refinement_instead_of_infinite_resume(self):
        f=Fixture(self.base);steps=[]
        for index in range(20):
            query=step('poll-'+str(index),'GET /unstable');query['poll']={'attempts':6,'interval_seconds':.05};steps.append(query)
        k=f.prepare(scenarios=[('large',dict(category='timing',priority='P1',vars={},bindings={},steps=steps))]);value=k.advance()
        self.assertEqual(value['workflow_state'],'NEEDS_AGENT');self.assertEqual(f.packet(value)['purpose'],'REFINE_ANALYSIS')
        with s.connect(k.run_db,'run') as db:self.assertEqual(db.execute('SELECT count(*) FROM cases').fetchone()[0],0)

    def test_docx_table_extraction_keeps_merge_warning(self):
        path=self.base/'table.docx'
        xml='''<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:tbl><w:tr><w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr><w:p><w:r><w:t>需求规则</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>'''
        with zipfile.ZipFile(path,'w') as z:z.writestr('word/document.xml',xml)
        doc=intake.extract(path,'table.docx');self.assertEqual(doc['blocks'][0]['rows'],[['需求规则']]);self.assertTrue(any(w['code']=='MERGED_CELLS' for w in doc['warnings']))

    def test_openapi_discovery_uses_document_contract(self):
        f=Fixture(self.base);c.write(f.materials/'openapi.json',{'openapi':'3.0.0','info':{'title':'API'},'paths':{'/expenses/{expense_id}':{'get':{'summary':'查询台账'}}}});f.start()
        with s.connect(f.kernel.knowledge,'knowledge') as db:self.assertIn('GET /expenses/{expense_id}',compiler.operations(db))

    def test_failed_compile_dependency_and_cycle_isolate_independent_cases(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);f.auto_bindings=False;bad=f.scenario();bad['bindings']={}
            valid=dict(category='integration',priority='P1',vars={},bindings={},steps=[step('read','GET /probe/{code}',200,{'code':'200'})])
            dependent=copy.deepcopy(valid);dependent['depends_on']=['bad']
            first=copy.deepcopy(valid);first['depends_on']=['cycle-b'];second=copy.deepcopy(valid);second['depends_on']=['cycle-a']
            k=f.prepare(True,scenarios=[('bad',bad),('dependent',dependent),('cycle-a',first),('cycle-b',second),('independent',valid)]);k.advance()
            self.assertEqual(len(server.calls),1)
            with s.connect(k.run_db,'run') as db:
                self.assertEqual(db.execute('SELECT id FROM cases').fetchone()[0],'independent');self.assertEqual(db.execute('SELECT count(*) FROM diagnostics').fetchone()[0],4)

    def test_analysis_reuse_not_bound_to_reporting_or_compiler_byte_changes(self):
        before=Kernel.analysis_fingerprint()
        with patch.object(c,'fingerprint',return_value='different-code'):self.assertEqual(before,Kernel.analysis_fingerprint())
        with patch.object(contract,'DECISION_SEMANTICS','different-meaning'):self.assertNotEqual(before,Kernel.analysis_fingerprint())

    def test_generated_schema_drives_precise_internal_type_errors(self):
        f=Fixture(self.base);value=f.start();packet=f.packet(value);item=f.finding(packet,'bad-policy','convention',f.policy());item['payload']['base_url']=123
        error=self.fault('DECISION_INVALID',f.submit,value,[item]);self.assertEqual(error.pointer,'/findings/0/payload/base_url')
        self.assertEqual(error.detail['expected_type'],'string')

    def test_all_machine_responses_match_current_generated_schema(self):
        f=Fixture(self.base);code,value=self.cli('--project',str(f.root),'--action','open','--sources',str(f.materials))
        contract.validate(value,contract.schemas()['response']);self.assertEqual(value['workflow_state'],'NEEDS_AGENT')
        for name in contract.ERRORS:contract.validate(contract.response(state='BLOCKED',fault=contract.Fault(name)),contract.schemas()['response'])

    def test_business_env_field_is_not_misread_as_credential_reference(self):
        with Server() as server:
            f=Fixture(self.base,server.server_address[1]);policy=f.policy();policy['allow']=[{'operation':'POST /instances','actors':['observer'],
                'guards':[{'pointer':'/body/metadata','op':'eq','expected':{'env':'business-value'}}]}]
            payload=dict(category='validation',priority='P1',vars={},bindings={},steps=[step('create','POST /instances',201,body={'amount':100,'metadata':{'env':'business-value'}})])
            k=f.prepare(True,scenarios=[('environment-data',payload)],policy=policy);k.advance();self.assertEqual(len(server.calls),1)

def exclusive_test(path):
    with exclusive(path):pass

if __name__=='__main__':unittest.main()
