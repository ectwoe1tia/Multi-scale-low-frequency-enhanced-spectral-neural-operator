# Current v7 package maintenance

- Use SKILL.md and docs/INDEX.md. The only product entrypoint is scripts/workflow.py and its thin PowerShell wrapper.
- An execution agent submits project decisions, never edits the maintained kernel or weakens assertions to hide a failure.
- Maintainers record a change request, snapshot affected files, and acquire their own single-writer maintenance claim before edits. An isolated delivery must not inherit another writer's claim, runtime locks, credentials, or execution journal.
- Preserve original source and execution evidence. Do not erase UNKNOWN or reuse an unverified operation identity to resend an effect.
- Keep runtime validation, generated contracts, current docs, package allowlist and observable tests in sync. Run unittest discovery, contract/package checks and skill validation; network changes require real loopback HTTP and crash recovery evidence.
- Static modules may not call the network port. Only runtime/kernel.py coordinates runtime/transport.py; credentials are read once inside the execution process.
- Maintain a single current interface. Do not ship historical entrypoints, protocol adapters or old routing documents.
- Record actual verification and independent review status, package hashes, remaining limits and next action. Release only the current maintainer's own claim.
- Never modify host execution policy, sandbox, unrelated projects or company systems as a side effect of skill maintenance.
