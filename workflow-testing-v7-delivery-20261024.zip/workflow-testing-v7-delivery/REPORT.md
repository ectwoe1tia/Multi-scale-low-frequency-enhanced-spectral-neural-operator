# v7 当前版实现与验证报告 · 20261024

已按设计完成当前 v7 / runner7.0.0 / contract7.0。需求方安装包只含当前27个文件；维护证据与客户安装包分别交付。原20261020目录的145个基线文件逐一核对哈希未变。

## 已实现

| 用户提出的问题 | 当前交付 |
|---|---|
| 版本兼容负担 | 唯一 open/advance/submit/inspect/report 入口、当前 scenario IR、当前文档索引；不携带旧 session/batch/suite/adapter 外部协议 |
| 机器错误与恢复 | 英文闭集状态/错误码/阶段/副作用状态/恢复动作/重试条件，中文业务解释；NEEDS_AGENT 是正常任务交接 |
| schema 与代码边界 | 同一契约生成 schema/工具帮助/错误目录，内部提交及控制响应按当前 schema 子集验证；只有 kernel 调用 transport |
| SQLite 版本 | 分离运行库和经验库，application_id/user_version/迁移校验和；固定1→2迁移及 Backup API；未来、未版本化和损坏状态明确拒绝 |
| 锁和异常恢复 | OS 持有的本机锁，句柄不继承给 HTTP 子进程；正常异常/强制结束可重新获取；未知请求账本保留 |
| 文件组和上下文 | 版本化成员/顺序/目录树，小分析包、分页查询、独立内部调用文件和持久任务；来源变化失效相关依据 |
| AI 与业务方分工 | 包内独立 AGENT-KERNEL.md；业务方只交资料/业务理解，AI 生成内部配置并处理技术判断 |
| 报告可读性 | 中文分类与状态，用例编号/标题/优先级/状态、逐步 HTTP、期望/实际、服务端 msg、证据引用；探索单列 |

运行身份从当前进程一次读取，业务请求头支持 policy/actor/operation/case/step 五层，值可引用已有环境变量。普通业务数据里的 env 字段不会误当凭据。没有额外 LLM API 依赖，PDF 提取器为可选依赖。

## 实际验收

**75项当前架构测试全部通过**。静态边界覆盖8个模块；当前包白名单、生成契约一致性、本地链接和 Skill 格式检查通过。旧版237项属于历史基线，不计入当前测试数量。

异常验证包括：

- 实际损坏/乱码资料、DOCX实体拒绝、不可读PDF依赖、来源增删改及提取过程中变化。
- 不合法字段/类型/引用、任务重复提交、持久恢复预算、超预算场景、依赖失败与循环隔离。
- 实际双进程锁竞争、持锁进程被终止、父执行进程在HTTP提交后被杀死。
- 实际本地HTTP提交后断连、收到非JSON、只读查询核对、轮询和批次接续；未知写请求不重发，新run也不能清除未决状态。
- SQLite未来版本、应用ID不符、未版本化、损坏、迁移SQL失败回滚、迁移进程被终止后的回滚与再次迁移。
- 意图持久化失败时实际HTTP为0；发送后的存储故障仍保留UNKNOWN；证据篡改拒绝报告通过。

权限拒绝和磁盘写满采用可控故障注入；HTTP、进程终止、OS锁、SQLite文件及迁移使用真实对象。没有调整宿主ACL、执行策略或公司系统。

证据：[实际命令及退出码](verification/published/validation.json)、[75项回归日志](verification/published/regression.stderr.log)、[安装包/边界检查](verification/published/package.stdout.log)。

## 独立AI试用与接续

独立代理只获得当前 Skill 与原始报销资料，生成2条用例、6项断言及业务报告，没有读取共享测试答案，也没有要求业务方补技术配置。该任务明确只做设计，真实HTTP为0。更新后同一运行编号接续成功，资料重新核对后再次生成报告，业务结果保持未评估。

其首次读取中文时遇到 PowerShell 默认解码问题，已在 Skill 增补 Get-Content -Encoding UTF8 指引。最终当前包又由维护者核对了0请求、2用例和正确静态状态。

证据：[独立试用记录](verification/published/independent-trial/workspace/evaluation.md)、[业务报告](verification/published/independent-trial/workspace/business-report.md)、[静态记录](verification/published/independent-trial/workspace/static-validation.md)、[最终核对](verification/published/independent-trial/workspace/final-maintainer-check.json)。这是独立行为试用，不宣称完成全面源码安全审计或企业验收。

## 上下文与文件批处理实测

| 指标 | 实测 |
|---|---:|
| 原始输入 | 6,320,851字节，3文件 |
| HAR/Recorder | 240请求/120步骤 |
| 分析包 | 3个，最大1711字节 |
| 关系/lineage 查询最大输出 | 444字节 |
| CLI/PowerShell调用 | 11次 |
| 终端输出合计/最大单次 | 4256/481字节 |
| 本地真实HTTP | 2次 |
| 重复推进新增HTTP | 0 |
| 同资料再次open新增分析任务 | 0 |
| 常驻Skill与职责说明 | 1342个中文字 |
| 合成演示耗时 | 5.25秒 |

上述大输入演示的语义 decision 是明确标识的合成fixture；自然语言理解另由前述独立AI试用验证。字节与本机耗时不等于模型token计费、语义准确率或公司流程覆盖率。

证据：[指标](verification/published/demo-release/metrics.json)、[调用记录](verification/published/demo-release/calls.json)。

## 实际边界及设计取舍

- 当前是一种受限测试内核，语义由使用Skill的当前模型理解；引用、类型和多分支检验不能证明所有业务解释必然正确。历史观察不自动成为因果或执行授权。
- 单场景最多40步/100计划请求；跨场景依赖不隐式共享变量。超预算与关系不确定由AI有限修正，仍未知则在报告中保留。
- 当前不提供旧版工作区转换执行器。旧/未来数据库明确拒绝；损坏或未决发送账本需验证恢复，不能用重建数据库绕过。迁移完成记录、备份和旧版本足以让中断事务回滚后再次迁移，没有增加通用迁移服务。
- 支持文档文本/OpenAPI JSON/Recorder HAR摘要与关系候选，配置AST仅提取读取依赖；BPMN仅基本结构摘要。没有OCR、浏览器DOM回放、完整Java/JS/UEL分析、全程序因果证明或生产执行。
- 原始资料与私有wire可能含服务端敏感内容，保存在本地用于核对；控制响应、公开证据和业务报告脱敏。交付演示全部为合成数据，无真实公司凭据。
- 历史维护快照留在本地维护目录，不放入客户安装包；审计交付只包含当前设计、代码和发布验证记录。

**企业真实验收尚未执行；未全局安装。**
