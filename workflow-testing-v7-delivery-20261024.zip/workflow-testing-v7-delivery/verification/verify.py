import json,subprocess,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent;skill=here.parent/'workflow-testing';out=here/'published';out.mkdir(exist_ok=True)
checks=[]
commands=[('regression',[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-v']),
 ('package',[sys.executable,'-X','utf8',str(here/'check_package.py')]),
 ('skill-format',[sys.executable,'-X','utf8','C:/Users/jing/.codex/skills/.system/skill-creator/scripts/quick_validate.py',str(skill)])]
for name,cmd in commands:
 start=time.monotonic();result=subprocess.run(cmd,cwd=skill,capture_output=True)
 (out/(name+'.stdout.log')).write_bytes(result.stdout);(out/(name+'.stderr.log')).write_bytes(result.stderr)
 checks.append(dict(check=name,command=cmd,exit_code=result.returncode,seconds=round(time.monotonic()-start,2)))
 print(json.dumps(checks[-1]),flush=True)
(out/'validation.json').write_text(json.dumps({'checks':checks},ensure_ascii=False,indent=2),encoding='utf-8')
raise SystemExit(0 if all(c['exit_code']==0 for c in checks) else 1)
