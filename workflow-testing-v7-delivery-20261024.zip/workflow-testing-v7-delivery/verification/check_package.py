"""Current-only package, generated-contract and architecture acceptance."""
import ast,json,re,sys
from pathlib import Path
skill=Path(__file__).resolve().parents[1]/'workflow-testing'
sys.path.insert(0,str(skill))
from runtime import contract,storage
from runtime import common as c

def check():
    issues=[]
    expected=set(json.loads((Path(__file__).parent/'change-request.json').read_text(encoding='utf-8'))['new_files'])|{'SKILL.md','AGENTS.md'}
    actual={p.relative_to(skill).as_posix() for p in skill.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.coordination' not in p.parts}
    if actual!=expected:issues.append({'code':'PACKAGE_ALLOWLIST','extra':sorted(actual-expected),'missing':sorted(expected-actual)})
    for name,value in contract.artifacts().items():
        if c.read_json(skill/'contracts'/name,4*c.MAX_BYTES)!=value:issues.append({'code':'CONTRACT_DRIFT','file':name})
    if c.read_json(skill/'migrations/manifest.json')!=storage.version_manifest():issues.append({'code':'MIGRATION_DRIFT'})
    static=['common','contract','storage','locking','compiler','intake','relations','reports']
    forbidden={'subprocess','socket','urllib.request','http.client','requests','httpx','ctypes'}
    for module in static:
        path=skill/'runtime'/(module+'.py');tree=ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node,(ast.Import,ast.ImportFrom)):
                names=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module or '']
                if any(any(name==bad or name.startswith(bad+'.') for bad in forbidden) for name in names):issues.append({'code':'STATIC_NETWORK_IMPORT','module':module,'line':node.lineno})
            if isinstance(node,ast.Call):
                call=node.func.id if isinstance(node.func,ast.Name) else node.func.attr if isinstance(node.func,ast.Attribute) else ''
                if call in ('eval','exec','Popen','system','popen','send'):issues.append({'code':'STATIC_EFFECT_CALL','module':module,'line':node.lineno})
    for path in (skill/'runtime').glob('*.py'):
        if path.name not in ('kernel.py','transport.py') and re.search(r'\btransport\b',path.read_text(encoding='utf-8')) and path.stem not in ('contract',):
            # Text in docstrings is harmless; imports/calls are the enforced boundary above.
            tree=ast.parse(path.read_text(encoding='utf-8'))
            if any(isinstance(n,ast.ImportFrom) and any(v.name=='transport' for v in n.names) for n in ast.walk(tree)):issues.append({'code':'TRANSPORT_PORT_BYPASS','file':path.name})
    for path in [skill/'SKILL.md']+list((skill/'docs').glob('*.md')):
        for link in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if not link.startswith(('http:','https:','#')) and not (path.parent/link.split('#')[0]).is_file():issues.append({'code':'BROKEN_LINK','file':path.name,'target':link})
    resident=''.join((skill/name).read_text(encoding='utf-8') for name in ('SKILL.md','docs/AGENT-KERNEL.md'))
    chinese=len(re.findall(r'[\u4e00-\u9fff]',resident))
    if chinese>2500:issues.append({'code':'RESIDENT_CONTEXT_BUDGET','chinese_characters':chinese})
    return {'ok':not issues,'issues':issues,'product_files':len(actual),'static_modules':len(static),'resident_chinese_characters':chinese}

if __name__=='__main__':
    value=check();print(json.dumps(value,ensure_ascii=False));raise SystemExit(0 if value['ok'] else 1)
