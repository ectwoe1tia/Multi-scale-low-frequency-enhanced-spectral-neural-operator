# 报销台账测试资料

需求：按报销单编号查询台账。已存在的 EXP-101 应返回报销单编号 EXP-101、金额800、状态paid。不存在的 EXP-999 返回404，提示msg为“报销单不存在”。产品经理希望分别覆盖正常查询和不存在记录两种情况。

接口：GET /expenses/{expense_id}，expense_id是报销单编号。成功返回200，JSON字段为id、amount、state；不存在返回404，JSON字段msg。不要把查询响应中的amount当作编号。

测试规约：本地模拟环境地址 http://127.0.0.1:19119，环境名ledger-local，环境类型local，发布版本ledger-v1。匿名角色observer无需token，仅允许查询，不允许写请求。本次只生成测试设计、静态验证及报告，不执行HTTP。
