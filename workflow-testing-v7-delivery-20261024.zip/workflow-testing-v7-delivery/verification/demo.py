"""Synthetic file-only performance/effect demo; AI trial is recorded separately."""
import datetime,json,shutil,subprocess,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent;skill=here.parent/'workflow-testing'
sys.path.insert(0,str(skill));sys.path.insert(0,str(skill/'tests'))
from runtime import common as c,contract,storage as s
from support import Fixture,Server
base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here/'published/demo'
assert here.resolve() in base.parents
base.mkdir(parents=True,exist_ok=False)
controls=[];packet_sizes=[]
shell=shutil.which('powershell') or shutil.which('pwsh')
with Server() as server:
    f=Fixture(base,server.server_address[1]);start=time.monotonic()
    events=[]
    for i in range(120):
        stamp=datetime.datetime(2026,10,24,tzinfo=datetime.timezone.utc)+datetime.timedelta(seconds=2*i)
        value='synthetic-record-'+str(i)
        events += [
            {'startedDateTime':stamp.isoformat(),'time':10,'request':{'method':'POST','url':'https://synthetic.example/instances','headers':[{'name':'Authorization','value':'Bearer synthetic-har-canary'}]},
             'response':{'status':201,'content':{'text':json.dumps({'id':value,'settings':{'layout-'+str(j):'配置说明'*30 for j in range(60)}})}}},
            {'startedDateTime':(stamp+datetime.timedelta(seconds=1)).isoformat(),'time':10,'request':{'method':'GET','url':'https://synthetic.example/instances/'+value},'response':{'status':200,'content':{'text':'{}'}}}]
    c.write(f.materials/'recording.har',{'log':{'entries':events}})
    c.write(f.materials/'chrome.json',{'steps':[{'type':'change','value':'omit-private-input','selectors':[['#private']]} for _ in range(120)]})
    def call(action,*extra):
        command=[shell,'-NoProfile','-File',str(skill/'scripts/Invoke-WorkflowTesting.ps1'),'-Project',str(f.root),'-Action',action]+list(extra)
        result=subprocess.run(command,capture_output=True)
        n=len(controls)+1;(base/('call-'+str(n)+'.stdout.json')).write_bytes(result.stdout);(base/('call-'+str(n)+'.stderr.log')).write_bytes(result.stderr)
        value=json.loads(result.stdout.decode('utf-8-sig'));contract.validate(value,contract.schemas()['response'])
        assert result.returncode in (0,20) and value['error'] is None,(value,result.stderr.decode('utf-8',errors='replace'))
        controls.append({'action':action,'exit_code':result.returncode,'stdout_bytes':len(result.stdout)})
        return value
    value=call('open','-Sources',str(f.materials),'-System','合成流程','-Execute')
    written=False
    while value['workflow_state']=='NEEDS_AGENT':
        action=c.read_json(f.root/value['next_action']['request_ref']);packet=c.read_json(f.root/action['request']['packet_ref'])
        packet_sizes.append((f.root/action['request']['packet_ref']).stat().st_size);findings=[]
        if not written and any(ch['kind']=='document' for ch in packet['chunks']):
            findings=[f.finding(packet,'environment','convention',f.policy()),f.finding(packet,'create-query','scenario',f.scenario())];written=True
        elif packet['purpose']=='REVIEW_RUN':
            findings=[f.finding(packet,'query-strategy','query_strategy',dict(goal='查询申请状态',first_query='先创建申请取得响应id，再按id查询',variables=['iid comes from create /body/id'],prerequisites=['创建检查已通过']),summary='先取得创建结果id，再查询状态')]
        decision=f.root/'artifacts/fixture-decision.json';c.write(decision,{'findings':findings})
        call('submit','-Decision',str(decision));value=call('advance')
    assert value['workflow_state']=='COMPLETED' and value['test_outcome']=='PASS'
    before=len(server.calls);call('advance');assert len(server.calls)==before==2
    query=call('inspect','-Topic','relations');query_size=(f.root/query['summary_ref']).stat().st_size
    lineage=call('inspect','-Topic','lineage');lineage_size=(f.root/lineage['summary_ref']).stat().st_size
    with s.connect(f.kernel.root/'runs'/c.read_json(f.root/'system/current.json')['run_id']/'run.sqlite','run') as db:tasks_before=db.execute('SELECT count(*) FROM tasks').fetchone()[0]
    call('open','-Sources',str(f.materials),'-System','合成流程')
    with s.connect(f.root/'system/knowledge.sqlite','knowledge') as db:source_count=db.execute('SELECT count(*) FROM sources WHERE active=1').fetchone()[0]
    with s.connect(f.root/'runs'/c.read_json(f.root/'system/current.json')['run_id']/'run.sqlite','run') as db:tasks_after=db.execute('SELECT count(*) FROM tasks').fetchone()[0]
    assert tasks_after==tasks_before
    metrics=dict(input_bytes=sum(p.stat().st_size for p in f.materials.iterdir()),source_files=source_count,har_events=len(events),recorder_steps=120,
        analysis_packets=len(packet_sizes),packet_max_bytes=max(packet_sizes),query_max_bytes=max(query_size,lineage_size),
        cli_calls=len(controls),stdout_total_bytes=sum(r['stdout_bytes'] for r in controls),stdout_max_bytes=max(r['stdout_bytes'] for r in controls),
        actual_http_requests=len(server.calls),repeated_http_requests=len(server.calls)-before,new_tasks_on_unchanged_open=tasks_after-tasks_before,
        elapsed_seconds=round(time.monotonic()-start,2),semantic_decisions='synthetic fixture; independent AI trial is separate')
    c.write(base/'metrics.json',metrics);c.write(base/'calls.json',controls)
    print(c.encoded(metrics))
