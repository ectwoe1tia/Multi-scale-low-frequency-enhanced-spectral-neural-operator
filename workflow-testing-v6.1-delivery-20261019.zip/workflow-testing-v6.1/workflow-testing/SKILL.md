---
name: workflow-testing
description: 基于需求和接口资料维护流程测试；通过文件引用与强制刷新接续用例，编译项目规则 DSL 和工具描述，静态分析 BPMN/Flowable 定义快照的路径覆盖，对齐 Chrome Recorder/HAR，并保留证据和项目经验。
---

# 流程测试 v6.1 · 20261019

执行项目优先使用 Invoke-WorkflowSession.ps1，只传 -Session（session-spec.json 路径）、-Action 和当前 -CaseId；程序调用注册工具并自动保存请求/回执。静态工具仍可用 toolchain.py 的文件请求与 --control。上下文保留动作、结果码和引用；业务资料留在文件。

当前发布 v6.1 / runner 6.1.0；原会话迁移见 [v6 契约](references/v6.md)。巨量低代码配置先按 [语义索引与组合批处理](references/semantic.md) 在程序中预提取，只查询当前疑点的切片，不全量读取 HAR/配置/图。

## 当前工作入口

1. 执行先读 [文件会话入口](references/managed-session.md) 的命令与 session-spec 格式。新项目配置 execution_mode=file_only 并调用 init；接手已初始化项目调用 status。已有项目可显式 init 迁移，保留证据。不要混用两个 PowerShell 入口的参数。
2. file_only 项目的 prepare/execute 自动执行刷新和诊断；绕过会话入口会被代码拒绝，不退回 raw run。tokens.json 只由 execute 进程读取一次，不读入对话、不粘贴到命令、不让模型注入环境变量。未迁移旧项目仍按 status→context_refresh 接续；不手抄版本/哈希。
3. 不清楚参数时调用 tool_help(name)，只查当前工具；完整 describe/schema 保存在文件。每次只处理当前 case，大输入用 $file 多级引用交给程序；图/规则查询用 artifact_query。
4. 实际执行：session prepare → 检查短诊断 → session execute → status/report。execute 不隐式 prepare，不重试写请求。排查先 diagnose，必要时 evidence_query 定位字段。报告面向人，生成文件后给引用；模型无需全量读取。已完成 attempt 只复用证据；UNKNOWN/INCOMPLETE 先核对，不能改 run_id 重发。
5. 静态分析：规则文件 → rules_codegen；BPMN/Flowable 定义快照和 case/证据绑定 → flow_analysis；Recorder/HAR → trace_align。这些工具不发业务请求、不回放浏览器。
6. 失败/修正留 flow_note 或带适用版本的 knowledge_record，区分假设与确认；当前 focus 只带少量相关经验。交接保留 workspace、版本、status 请求和未决项，不复述大文件。
7. 多文件关系分析：file-set + profile → semantic_compile → semantic_query/diff。需多次调用时用 batch 集合及依赖，按任务预算接续；不在对话里逐个拼大请求。语法不支持、缓存失效和查询截断必须可见。
8. 推断保存为 semantic_propose 候选；相同值/调用顺序不能当因果或业务预期。用户明确确认后才填写 review 并 semantic_promote 成 recipe；不自行写 accept。将 semantic_check 放入批次前置依赖，可阻止本批次在关系检查失败后执行。

## 持续遵守

- ready 用例、角色/权限、guards、每步状态码和业务断言不能削弱；业务依据决定 expected，录制状态码/代码不是自动验收依据。候选规则不能自动启用。
- 原始 FAIL 保留，gate 单独表示处置。写请求不自动重试；不确定状态先查真实副作用并确认旧执行者停止。
- 区分 observed/derived/planned 覆盖；无证据、循环截断或不支持结构如实标明，不能报告虚构实际覆盖。不同定义版本/实例/attempt 不混合。
- 生成的项目工具是受限数据描述，由固定内核执行；不得 import 生成脚本、eval、任意 shell/URL/SQL。凭据不进参数、笔记或报告。
- 执行者不修改公共代码。维护用变更单、snapshot/claim/release；原证据不可覆盖，不清除他人租约。
- 诊断动作码是建议，不是自动重试或执行许可。正常排查不整份读取 plan/results/回执；先依证据指针查询。输出超限就缩小查询，不将大文件拆成多个聊天片段。业务结论要保留来源；结构校验、规约校验、真实执行分别记录。

## 按需加载

| 工作 | 资料 |
|---|---|
| 巨量配置、AST/依赖切片、异常值、候选确认、组合批次 | [语义索引与组合批处理](references/semantic.md)；规则/批次字段见 assets/semantic.schema.json |
| PowerShell 会话、凭据文件、业务头、完整报告 | [文件会话入口](references/managed-session.md)，优先于旧的手工执行说明 |
| 单工具参数、失败排查、字段查询、代码边界 | [诊断与确定性边界](references/diagnostics.md)；保持常驻上下文小，细节按需加载 |
| 刷新、DSL/动态工具、静态覆盖、双输入对齐、查询 | [沿用的静态与刷新契约](references/v5.md)，字段以 assets/v5.schema.json 和请求 schema 为准 |
| 参数文件、attempt/重试/核对/报告 | [文件会话](references/file-workflow.md)；严格模式加上述刷新要求 |
| Word/PDF/Apifox/HAR 接入或需求分析 | [原任务路由](references/v3-routing.md)，只加载当前任务对应资料 |
| HTTP 执行语义 | [HTTP 契约](references/http-contract.md)、[工具入口](references/toolchain.md) |
| 维护接续 | [协作](references/collaboration.md)、[扩展](references/extensions.md) |

生成的项目 Skill 从 references/project-index.json 起步，逐 case 加载。工具参数以 tool_help/导出 schema 为准。交接保存版本、status 请求、当前诊断引用和未决项；本地合成演示不算公司业务验收，生成不等于安装。
