"""Named v5 project-file schemas. Runtime also validates provenance and state."""
def schema():
    text={'type':'string','minLength':1}
    ref={'$ref':'#/$defs/Expression'}
    def obj(props,optional=()):
        return {'type':'object','additionalProperties':False,'required':[k for k in props if k not in optional],'properties':props}
    def refs():return {'type':'array','minItems':1,'items':text}
    expression={'oneOf':[
        obj({'literal':{'type':['null','boolean','number','string','array']}}),obj({'case_var':text}),obj({'step_pointer':text}),
        obj({'op':{'enum':['eq','ne','gt','ge','lt','le','in']},'left':ref,'right':ref}),
        obj({'op':{'enum':['and','or']},'args':{'type':'array','minItems':1,'maxItems':32,'items':ref}}),
        obj({'op':{'enum':['not','exists']},'arg':ref}),
        obj({'op':{'const':'type_is'},'arg':ref,'type':{'enum':['number','string','boolean','array','object','null']}})]}
    definition=obj({'id':text,'key':text,'version':{'type':'integer','minimum':1}})
    scope=obj({'case_ids':refs(),'operations':refs(),'process_key':text,'definition_ref':text},['case_ids','operations','process_key','definition_ref'])
    rule=obj({'dsl_version':{'const':'1.0'},'id':text,'kind':{'enum':['constraint','coverage_obligation']},'scope':scope,
              'when':ref,'require':{'oneOf':[ref,obj({'activities_in_order':refs(),'edges_in_order':refs()},['edges_in_order'])]},'status':{'enum':['confirmed','candidate']},'source_refs':refs()})
    defs={'Expression':expression,'Rule':rule,'RulesSpec':obj({'rules':refs(),'activate':{'type':'boolean'}},['activate']),
          'DefinitionBundle':obj({'format':{'enum':['bpmn_xml','flowable_model']},'file':text,'process_id':text,'definition':definition,
                                  'node_type_map':{'type':'object','additionalProperties':text}},['node_type_map']),
          'FlowAnalysisSpec':obj({'definition_ref':text,'case_binding_ref':text,'obligations_ref':text,'trace_index_ref':text,
                  'aligned_trace_ref':text,'coverage_policy':obj({'loop_bound':{'type':'integer','minimum':0,'maximum':3},
                      'max_depth':{'type':'integer','minimum':1,'maximum':500},'max_paths':{'type':'integer','minimum':1,'maximum':10000}},['loop_bound','max_depth','max_paths'])},
                  ['trace_index_ref','aligned_trace_ref','coverage_policy']),
          'TraceAlignSpec':obj({'session_id':text,'environment':text,'recorder':text,'har':text,'alignment':text,'case_id':text,'attempt':text,
                  'adapter':text,'operation_map':{'type':'object','additionalProperties':refs()},'activity_map':text},
                  ['recorder','har','alignment','case_id','attempt','adapter','operation_map','activity_map']),
          'Query':obj({'kind':{'enum':['case_paths','uncovered_edges','coverage','graph_nodes','rules','tools','trace_matches','lessons']},
                     'case_id':text,'id':text,'offset':{'type':'integer','minimum':0},'limit':{'type':'integer','minimum':1,'maximum':100}},['case_id','id','offset','limit']),
          'Knowledge':obj({'case_id':text,'kind':{'enum':['candidate','confirmed']},'summary':text,'next_action':text,
                           'evidence_refs':refs(),'applies_to':refs(),'supersedes':text},['supersedes'])}
    case_binding=obj({'case_id':text,'activities':refs(),'edges':refs(),'attempt':text},['edges','attempt'])
    defs['CaseBindings']=obj({'definition_id':text,'cases':{'type':'array','items':case_binding}})
    defs['Obligations']=obj({'definition_id':text,'obligations':{'type':'array','items':obj({'id':text,'activities_in_order':refs(),'edges_in_order':refs(),'source_refs':refs()},['edges_in_order'])}})
    defs['ActivityTrace']=obj({'case_id':text,'attempt':text,'definition_id':text,'instance_id':text,
                             'activities':refs(),'edges':{'type':'array','items':text},'evidence_refs':refs(),'scope':text},['scope'])
    defs['ActivityTraceIndex']=obj({'traces':{'type':'array','items':text}})
    defs['AlignmentBinding']=obj({'session_id':text,'environment':text,'links':{'type':'array','items':obj(
        {'ui':text,'http':{'type':'array','items':text},'reason':text,'operation':text,'source_refs':refs()},['operation','source_refs'])}})
    defs['EvidenceQuery']=obj({'artifact':{'enum':['plan','preview','results']},
        'sha256':{'oneOf':[{'type':'string','pattern':'^[a-f0-9]{64}$'},
                          obj({'$file':text,'pointer':{'type':'string','maxLength':240,'pattern':'^/(?:[^~]|~[01])*$'}})]},
        'pointers':{'type':'array','minItems':1,'maxItems':8,'uniqueItems':True,
                    'items':{'type':'string','maxLength':240,'pattern':'^(?:/(?:[^~]|~[01])*)?$'}},
        'mode':{'enum':['structure','value'],'default':'structure'},
        'max_bytes':{'type':'integer','minimum':512,'maximum':8192,'default':2048}},['mode','max_bytes'])
    return {'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':defs,
            'description':'Use a named $defs schema; runtime checks references, source identity and state.'}
