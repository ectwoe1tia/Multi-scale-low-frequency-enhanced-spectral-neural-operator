"""File-only v5 scale/resume demonstration. No HTTP transport or browser replay."""
import argparse
import copy
import json
import subprocess
import sys
import time
from pathlib import Path
from demo_support import make_assets
from file_workflow import request

BPMN='''<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL"><process id="expense">
<startEvent id="start"/><userTask id="manager"/><exclusiveGateway id="decision" default="F-no"/>
<userTask id="director"/><endEvent id="end"/>
<sequenceFlow id="F-start" sourceRef="start" targetRef="manager"/>
<sequenceFlow id="F-decision" sourceRef="manager" targetRef="decision"/>
<sequenceFlow id="F-yes" sourceRef="decision" targetRef="director"/>
<sequenceFlow id="F-no" sourceRef="decision" targetRef="end"/>
<sequenceFlow id="F-end" sourceRef="director" targetRef="end"/>
</process></definitions>'''

def run(out):
    out.mkdir(parents=True,exist_ok=False)
    calls=[];started=time.perf_counter()
    def save(ref,obj):
        path=out/ref;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    def read(ref):return json.loads((out/ref).read_text(encoding='utf-8'))
    def call(label,tool,expected=0,**args):
        req,resp='calls/'+label+'.request.json','replies/'+label+'.json'
        save(req,request(tool,**args))
        result=subprocess.run([sys.executable,'-X','utf8',str(Path(__file__).with_name('toolchain.py')),
             '--workspace',str(out),'--request',str(out/req),'--response-file',resp,'--brief'],capture_output=True,encoding='utf-8',timeout=60)
        (out/('calls/'+label+'.stdout.json')).write_text(result.stdout,encoding='utf-8')
        (out/('calls/'+label+'.stderr.txt')).write_text(result.stderr,encoding='utf-8')
        calls.append({'label':label,'tool':tool,'exit_code':result.returncode,'expected_exit_code':expected,
                      'stdout_bytes':len(result.stdout.encode('utf-8')),'request':req,'response':resp})
        assert result.returncode==expected,(label,result.stdout,result.stderr)
        return read(resp)
    suite,adapter,plan=make_assets(19001)
    originals=copy.deepcopy(suite['cases']),copy.deepcopy(plan['cases'])
    suite['cases'],plan['cases']=[],[]
    payload='FILE-PAYLOAD-CANARY-'+'x'*131072
    (out/'large.txt').write_text(payload,encoding='utf-8')
    save('body.json',{'amount':'${amount}','padding':{'$file':'large.txt','format':'text'}})
    bindings=[];activity_traces=[]
    for i in range(60):
        cid=f'TC-V5-{i+1:03}'
        case=copy.deepcopy(originals[0][i%2]);case['id']=cid;suite['cases'].append(case)
        planned=copy.deepcopy(originals[1][i%2]);planned['case_id']=cid;planned['steps'][0]['body']={'$file':'body.json'};plan['cases'].append(planned)
        nodes=['start','manager','decision']+(['director'] if i%2==0 else [])+['end']
        edges=['F-start','F-decision']+(['F-yes','F-end'] if i%2==0 else ['F-no'])
        bindings.append({'case_id':cid,'activities':nodes,'edges':edges})
        if i<6:
            raw=f'evidence/engine-{i}.json';save(raw,{'fixture':True,'activities':nodes,'edges':edges,'instance_id':f'instance-{i}'})
            ref=f'evidence/trace-{i}.json';save(ref,{'case_id':cid,'attempt':'0001','definition_id':'expense:1:demo',
                'instance_id':f'instance-{i}','activities':nodes,'edges':edges,'evidence_refs':[raw]});activity_traces.append(ref)
    save('suite.json',suite);save('adapter.json',adapter);save('plan.json',plan)
    save('session.json',{'suite':'suite.json','adapter':'adapter.json','plan':'plan.json'})
    call('init','flow_init',spec='session.json',out='project')
    call('runtime','runtime_init',project='project/project.json',out='project/runtime/environment')
    save('requirement.json',{'fixture':True,'text':'金额必须大于0，且超过10000须经总监。'})
    scope={'operations':['create']}
    rule={'dsl_version':'1.0','id':'R-POSITIVE','kind':'constraint','scope':scope,'when':{'literal':True},
          'require':{'op':'gt','left':{'case_var':'amount'},'right':{'literal':0}},'status':'confirmed','source_refs':['requirement.json']}
    save('rule.json',rule);save('rules.json',{'rules':['rule.json'],'activate':True})
    call('codegen','rules_codegen',project='project/project.json',spec='rules.json',out='project/generated/rules')
    save('tool-input.json',{'vars':{'amount':12000}})
    call('project-tool','project_tool_invoke',project='project/project.json',tool_ref='project/generated/rules/tool-R-POSITIVE.json',input_ref='tool-input.json',out='project/generated/evaluation.json')
    r=call('refresh','context_refresh',project='project/project.json',case_id='TC-V5-001',out='project/context/first')['data']
    save('project/contracts/change.json',{'fixture':True,'new_context_requirement':'Read current roles'})
    stale=call('stale-block','flow_prepare',expected=2,**read(r['next_request'])['arguments'])
    assert stale['code']=='CONTEXT_STALE'
    refresh_req=read(stale['data']['refresh_request'])
    r=call('refresh-after-change',**{'tool':refresh_req['tool'],**refresh_req['arguments']})['data']
    prepared=call('prepare','flow_prepare',**read(r['next_request'])['arguments'])['data']
    assert not (out/'runs').exists()
    status=call('resume-fresh-process','flow_status',project='project/project.json')['data']
    assert status['counts']=={'PREPARED':1,'TODO':59}
    resume=read(status['refresh_request'])
    assert resume['arguments']['phase']=='execute'
    # Analyze snapshots only; prepared request is never sent.
    (out/'expense.bpmn').write_text(BPMN,encoding='utf-8')
    save('definition.json',{'format':'bpmn_xml','file':'expense.bpmn','process_id':'expense',
                            'definition':{'id':'expense:1:demo','key':'expense','version':1}})
    save('case-bindings.json',{'definition_id':'expense:1:demo','cases':bindings})
    save('obligations.json',{'definition_id':'expense:1:demo','obligations':[
        {'id':'O-DIRECTOR','activities_in_order':['manager','director'],'edges_in_order':['F-yes'],'source_refs':['requirement.json']},
        {'id':'O-DIRECT','activities_in_order':['manager','end'],'edges_in_order':['F-no'],'source_refs':['requirement.json']}]})
    save('trace-index.json',{'traces':activity_traces})
    save('analysis.json',{'definition_ref':'definition.json','case_binding_ref':'case-bindings.json',
                          'obligations_ref':'obligations.json','trace_index_ref':'trace-index.json'})
    call('flow-analysis','flow_analysis',project='project/project.json',spec='analysis.json',out='project/analysis/current')
    save('recorder.json',{'title':'static fixture','steps':[{'type':'click','selectors':[['#submit']]}]})
    entries=[]
    for i in range(60):
        method,path=('POST','/instances') if i==0 else ('GET','/instances/instance-0')
        entries.append({'startedDateTime':'2026-10-13T00:00:00Z','time':i+1,'request':{'method':method,'url':adapter['base_url']+path,
                        'headers':[{'name':'Authorization','value':'Bearer TEST-SECRET-CANARY'}],
                        'postData':{'mimeType':'application/json','text':json.dumps({'padding':'x'*65536})}},'response':{'status':201 if i==0 else 200}})
    save('har.json',{'log':{'entries':entries}})
    save('alignment.json',{'session_id':'S-V5','environment':'local','links':[
        {'ui':'U00001','http':[f'H{i+1:05}' for i in range(60)],'reason':'Synthetic one action plus subsequent polling'}]})
    save('align.json',{'session_id':'S-V5','environment':'local','recorder':'recorder.json','har':'har.json','alignment':'alignment.json',
                      'case_id':'TC-V5-001','attempt':'0001','adapter':'adapter.json'})
    call('trace-align','trace_align',project='project/project.json',spec='align.json',out='project/normalized/recording')
    save('query.json',{'kind':'case_paths','case_id':'TC-V5-001','limit':2})
    call('query-fresh-process','artifact_query',project='project/project.json',query='query.json',out='project/analysis/query.json')
    save('knowledge.json',{'case_id':'TC-V5-001','kind':'confirmed','summary':'参数文件修改后旧上下文凭据被阻断，先刷新再准备。',
         'next_action':'沿 status 的刷新请求继续；此演示只分析不执行。','evidence_refs':['replies/stale-block.json'],'applies_to':['rule.json','adapter.json']})
    call('knowledge','knowledge_record',project='project/project.json',spec='knowledge.json',out='project/knowledge/K-001.json')
    final=call('final-context','context_refresh',project='project/project.json',case_id='TC-V5-001',phase='execute',out='project/context/final')['data']
    coverage=read('project/analysis/current/coverage.json')
    metrics={'cases':60,'imported_history_traces':6,'fresh_process_calls':len(calls),'business_http_calls':0,
             'browser_replays':0,'har_bytes':(out/'har.json').stat().st_size,'shared_payload_bytes':(out/'large.txt').stat().st_size,
             'prepared_plan_bytes':(out/'project/attempts/TC-V5-001/0001/plan.json').stat().st_size,
             'stdout_total_bytes':sum(x['stdout_bytes'] for x in calls),'stdout_max_bytes':max(x['stdout_bytes'] for x in calls),
             'final_focus_bytes':(out/final['focus']).stat().st_size,'elapsed_seconds':round(time.perf_counter()-started,3),
             'observed_edges':coverage['metrics']['observed']['edges'],'planned_edges':coverage['metrics']['planned']['edges'],
             'scope':'Synthetic imported evidence only; not company acceptance or token billing measurement.'}
    assert not (out/'runs').exists()
    assert metrics['stdout_max_bytes']<2048 and metrics['final_focus_bytes']<=4096
    normalized=''.join(p.read_text(encoding='utf-8') for p in (out/'project/normalized/recording').glob('*'))
    assert 'TEST-SECRET-CANARY' not in normalized
    save('commands.json',calls);save('metrics.json',metrics)
    return metrics

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True)
    args=parser.parse_args();print(json.dumps(run(Path(args.out).resolve()),ensure_ascii=False))
