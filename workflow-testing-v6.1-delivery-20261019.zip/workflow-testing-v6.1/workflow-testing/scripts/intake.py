"""Extract source evidence and import explicitly written cases; no LLM or network."""
import importlib.util
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import http_runner as rt
import suite as suite_tools
from capabilities import file_hash, write_new

MAX_DOCUMENT = 32 * rt.MAX_BYTES
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
ALIASES = {
    'id': ['用例编号', '用例id', '编号', 'caseid', 'id'],
    'title': ['用例名称', '用例标题', '测试场景', '场景', '标题', 'title', 'testcase', 'name'],
    'steps': ['操作步骤', '测试步骤', '执行步骤', '步骤', 'steps', 'action'],
    'expected': ['预期结果', '期望结果', '预期', 'expectedresult', 'expected'],
    'preconditions': ['前置条件', '前提条件', 'preconditions', 'precondition'],
    'actors': ['测试角色', '执行角色', '角色', 'actor', 'actors', 'role'],
    'data': ['测试数据', '输入数据', 'data', 'testdata'],
    'category': ['用例类型', '分类', 'category'],
    'priority': ['优先级', 'priority'],
}


def normalized(value):
    return re.sub(r'[\s_*`：:()（）-]', '', value).lower()


def field_name(value):
    key = normalized(value)
    return next((name for name, aliases in ALIASES.items() if key in aliases), None)


def pdf_backend():
    for name in ('pypdf', 'PyPDF2'):
        if importlib.util.find_spec(name):
            return name
    return None


def xml_text(element):
    pieces = []
    for node in element.iter():
        if node.tag == W + 't':
            pieces.append(node.text or '')
        elif node.tag in (W + 'br', W + 'cr'):
            pieces.append('\n')
        elif node.tag == W + 'tab':
            pieces.append('\t')
    return ''.join(pieces).strip()


def extract(source, relative):
    try:
        return _extract(source, relative)
    except (zipfile.BadZipFile, ET.ParseError) as exc:
        raise rt.ToolError('DOCUMENT_READ_ERROR', 'Word document is not a valid DOCX/XML file') from exc


def _extract(source, relative):
    source = Path(source)
    rt.need(source.stat().st_size <= MAX_DOCUMENT, 'Document exceeds 32 MiB')
    suffix = source.suffix.lower()
    blocks, warnings = [], []
    def add(kind, locator, text='', rows=None):
        block = {'id': 'B' + str(len(blocks) + 1).zfill(5), 'kind': kind, 'location': locator, 'text': text}
        if rows is not None:
            block['rows'] = rows
        blocks.append(block)
    backend = 'stdlib'
    if suffix in ('.md', '.markdown', '.txt'):
        content = source.read_text(encoding='utf-8-sig')
        lines = content.splitlines()
        i = 0
        while i < len(lines):
            if lines[i].lstrip().startswith('|'):
                start, rows = i, []
                while i < len(lines) and lines[i].lstrip().startswith('|'):
                    row = [x.strip() for x in re.split(r'(?<!\\)\|', lines[i].strip().strip('|'))]
                    if not all(re.fullmatch(r':?-+:?', x.replace(' ', '')) for x in row):
                        rows.append(row)
                    i += 1
                add('table', 'lines:' + str(start + 1) + '-' + str(i), '\n'.join(lines[start:i]), rows)
            else:
                if lines[i].strip():
                    add('paragraph', 'line:' + str(i + 1), lines[i])
                i += 1
    elif suffix == '.docx':
        with zipfile.ZipFile(source) as archive:
            rt.need(sum(x.file_size for x in archive.infolist()) <= 64 * rt.MAX_BYTES, 'Expanded DOCX exceeds 64 MiB')
            rt.need('word/document.xml' in archive.namelist(), 'Invalid DOCX: document.xml missing')
            xml = archive.read('word/document.xml')
            rt.need(b'<!DOCTYPE' not in xml.upper() and b'<!ENTITY' not in xml.upper(), 'XML entities are unsupported')
            root = ET.fromstring(xml)
            body = root.find(W + 'body')
            rt.need(body is not None, 'DOCX body missing')
            pcount, tcount = 0, 0
            for child in body:
                if child.tag == W + 'p':
                    pcount += 1
                    value = xml_text(child)
                    if value:
                        add('paragraph', 'paragraph:' + str(pcount), value)
                elif child.tag == W + 'tbl':
                    tcount += 1
                    rows = [[xml_text(cell) for cell in row.findall(W + 'tc')] for row in child.findall(W + 'tr')]
                    add('table', 'table:' + str(tcount), '\n'.join(' | '.join(row) for row in rows), rows)
                    if child.findall('.//' + W + 'vMerge') or child.findall('.//' + W + 'gridSpan'):
                        warnings.append({'code': 'MERGED_CELLS', 'location': 'table:' + str(tcount), 'message': 'Check merged cells and row alignment against original Word document'})
            if root.findall('.//' + W + 'drawing') or root.findall('.//' + W + 'pict'):
                warnings.append({'code': 'IMAGES_NOT_EXTRACTED', 'message': 'Embedded images need visual reading or OCR'})
            if root.findall('.//' + W + 'ins') or root.findall('.//' + W + 'del'):
                warnings.append({'code': 'TRACKED_CHANGES', 'message': 'Resolve tracked changes in the source before confirming cases'})
            if any(name.startswith(('word/header', 'word/footer', 'word/footnotes', 'word/endnotes', 'word/comments')) for name in archive.namelist()):
                warnings.append({'code': 'ANCILLARY_WORD_PARTS', 'message': 'Headers, footers, footnotes and comments are not used as case evidence'})
    elif suffix == '.pdf':
        backend = pdf_backend()
        rt.need(backend, 'PDF requires pypdf or PyPDF2 in the chosen Python environment', 'DEPENDENCY_MISSING')
        module = __import__(backend, fromlist=['PdfReader'])
        try:
            reader = module.PdfReader(str(source))
            rt.need(not reader.is_encrypted, 'Encrypted PDFs require an unlocked copy', 'DOCUMENT_LOCKED')
            rt.need(len(reader.pages) <= 500, 'PDF exceeds 500 pages')
            for number, page in enumerate(reader.pages, 1):
                value = page.extract_text() or ''
                add('page', 'page:' + str(number), value)
                if not value.strip():
                    warnings.append({'code': 'OCR_REQUIRED', 'location': 'page:' + str(number), 'message': 'No text layer found; this page has not been read'})
            warnings.append({'code': 'PDF_LAYOUT_REVIEW', 'message': 'Text extraction does not establish table columns or image contents; check original page layout'})
        except rt.ToolError:
            raise
        except Exception as exc:
            raise rt.ToolError('DOCUMENT_READ_ERROR', 'PDF backend could not read this file') from exc
    else:
        raise rt.ToolError('UNSUPPORTED_FORMAT', 'Supported documents: .md, .txt, .docx, .pdf; convert legacy .doc to .docx first')
    rt.need(len(blocks) <= 30000 and sum(len(b['text']) for b in blocks) <= 8 * rt.MAX_BYTES, 'Extracted text exceeds limits')
    if not any(b['text'].strip() for b in blocks):
        warnings.append({'code': 'NO_TEXT', 'message': 'No readable text; do not confirm cases from this document'})
    return {'document_version': '1.0', 'source': relative, 'source_sha256': file_hash(source), 'format': suffix.lstrip('.'),
            'backend': backend, 'blocks': blocks, 'warnings': warnings, 'extraction_only': True}


def verify_document(root, document):
    rt.shape(document, ['document_version', 'source', 'source_sha256', 'format', 'backend', 'blocks', 'warnings', 'extraction_only'], label='document')
    rt.need(document['document_version'] == '1.0' and document['extraction_only'] is True, 'Unsupported document evidence')
    path = rt.workspace_path(root, document['source'], existing=True)
    rt.need(file_hash(path) == document['source_sha256'], 'Source document changed; import again', 'STALE_SOURCE')
    # Re-extract to bind locations and quotations to the actual file, including table contents.
    rt.need(rt.canonical(extract(path, document['source'])) == rt.canonical(document), 'Document evidence was modified; import again', 'EVIDENCE_CHANGED')


def candidates(document):
    result, pending, last_field = [], None, None
    for block in document['blocks']:
        if block['kind'] == 'table':
            if pending:
                result.append(pending)
                pending, last_field = None, None
            rows = block['rows']
            if not rows:
                continue
            names = [field_name(x) for x in rows[0]]
            if 'title' in names and ('steps' in names or 'expected' in names):
                for index, row in enumerate(rows[1:], 2):
                    fields = {name: row[pos] for pos, name in enumerate(names) if name and pos < len(row)}
                    if fields.get('title'):
                        result.append({'fields': fields, 'blocks': [block], 'location': block['location'] + '/row:' + str(index)})
            # Vertical two-column field/value table.
            elif all(len(row) == 2 for row in rows):
                fields = {field_name(row[0]): row[1] for row in rows if field_name(row[0])}
                if 'title' in fields:
                    result.append({'fields': fields, 'blocks': [block], 'location': block['location']})
            continue
        for line in block['text'].splitlines():
            label = re.match(r'^\s*(?:[-*#]+\s*)?([^:：]{1,24})\s*[:：]\s*(.*)$', line)
            name = field_name(label[1]) if label else None
            if name:
                value = label[2].strip()
                if name in ('id', 'title') and pending and name in pending['fields']:
                    result.append(pending)
                    pending = None
                if pending is None:
                    pending = {'fields': {}, 'blocks': [], 'location': block['location']}
                pending['fields'][name] = value
                if block not in pending['blocks']:
                    pending['blocks'].append(block)
                last_field = name
            elif pending and last_field and line.strip():
                pending['fields'][last_field] += '\n' + line.strip()
                if block not in pending['blocks']:
                    pending['blocks'].append(block)
    if pending:
        result.append(pending)
    return [x for x in result if x['fields'].get('title')]


def split_steps(value):
    return [line.strip() for line in re.split(r'\n|<br\s*/?>', value, flags=re.I) if line.strip()]


def build_cases(root, manifest):
    rt.shape(manifest, ['project', 'platform', 'documents'], label='case import manifest')
    rt.text(manifest['project'], 'project')
    rt.need(manifest['platform'] in suite_tools.PLATFORMS, 'Unknown platform')
    rt.need(isinstance(manifest['documents'], list) and 1 <= len(manifest['documents']) <= 30, 'documents must contain 1..30 entries')
    suite = {'schema_version': '1.0', 'project': manifest['project'], 'platform': manifest['platform'],
             'sources': [], 'requirements': [], 'questions': [], 'cases': [], 'deviations': []}
    analysis, recognized = [], []
    seen_sources = set()
    for entry in manifest['documents']:
        rt.shape(entry, ['document', 'role'], label='document entry')
        rt.need(entry['role'] in ('requirements', 'test_cases'), 'Unknown document role')
        document = rt.read_json(rt.workspace_path(root, entry['document'], existing=True), 16 * rt.MAX_BYTES)
        verify_document(root, document)
        rt.need(document['source'] not in seen_sources, 'Same document imported more than once')
        seen_sources.add(document['source'])
        found = candidates(document)
        analysis.append({'source': document['source'], 'role': entry['role'], 'recognized_cases': len(found), 'warnings': document['warnings'],
                         'next_action': 'Read remaining blocks and synthesize normal, boundary, negative, permission and workflow cases; do not equate import with complete coverage.'})
        for item in found:
            recognized.append((document, item))
        if not found:
            snippets = [b for b in document['blocks'] if b['text'].strip()]
            # Carry unstructured evidence forward without guessing a requirement or passing it.
            recognized.append((document, {'fields': {'title': '待整理：' + Path(document['source']).name},
                                          'blocks': snippets[:1], 'location': 'document', 'unstructured': True}))
    for number, (document, item) in enumerate(recognized, 1):
        fields = item['fields']
        cid, rid, sid, qid = ['%s-IMP-%03d' % (prefix, number) for prefix in ('TC', 'REQ', 'SRC', 'Q')]
        excerpt = '\n'.join(b['text'] for b in item['blocks']).strip() or '文档未能提取文本；需读取原件。'
        suite['sources'].append({'id': sid, 'location': document['source'] + '#' + item['location'] + ' sha256:' + document['source_sha256'], 'excerpt': excerpt})
        missing = [key for key in ('steps', 'expected', 'actors', 'preconditions') if not fields.get(key, '').strip()]
        ambiguous = any(re.search(r'待定|待确认|TBD|TODO', fields.get(k, ''), re.I) for k in ('steps', 'expected', 'actors', 'preconditions'))
        extraction_gap = any(w['code'] in ('OCR_REQUIRED', 'NO_TEXT', 'MERGED_CELLS', 'TRACKED_CHANGES', 'IMAGES_NOT_EXTRACTED') for w in document['warnings'])
        unresolved = bool(missing or ambiguous or extraction_gap or item.get('unstructured'))
        expected = fields.get('expected') or '待从业务资料明确预期结果'
        suite['requirements'].append({'id': rid, 'text': expected, 'status': 'missing' if unresolved else 'explicit', 'source_ids': [sid]})
        if unresolved:
            suite['questions'].append({'id': qid, 'text': '补齐用例字段或核对提取缺口：' + ', '.join(missing or ['文档存在歧义/提取缺口']),
                                       'requirement_ids': [rid], 'status': 'open', 'options': []})
        category = fields.get('category', 'happy_path')
        if category not in suite_tools.CATEGORIES:
            category = 'happy_path'
        priority = fields.get('priority', 'P1').upper()
        if priority not in ('P0', 'P1', 'P2', 'P3'):
            priority = 'P1'
        suite['cases'].append({'id': cid, 'title': fields['title'], 'requirement_ids': [rid], 'category': category, 'priority': priority,
                               'status': 'needs_clarification' if unresolved else 'ready', 'question_ids': [qid] if unresolved else [],
                               'preconditions': split_steps(fields.get('preconditions') or '待确认前置条件'),
                               'actors': split_steps(fields.get('actors') or '待绑定执行身份'),
                               'data': {'source_case_id': fields.get('id', ''), 'document_input': fields.get('data', '')},
                               'steps': split_steps(fields.get('steps') or '待从资料整理测试步骤'),
                               'assertions': [{'id': 'A-RESULT', 'expected': expected, 'status': 'pending' if unresolved else 'defined'}],
                               'automation': {'status': 'unbound', 'reason': '已导入文档依据；需综合需求覆盖并绑定真实接口、身份和测试数据'}})
    # Same named scenario with divergent expected results must remain unresolved, never last-writer-wins.
    groups = {}
    for case in suite['cases']:
        groups.setdefault(normalized(case['title']), []).append(case)
    rules = {r['id']: r for r in suite['requirements']}
    for cases in groups.values():
        if len({normalized(c['assertions'][0]['expected']) for c in cases}) > 1:
            for case in cases:
                rule = rules[case['requirement_ids'][0]]
                rule['status'] = 'conflicting'
                qid = 'Q-CONFLICT-' + case['id']
                suite['questions'].append({'id': qid, 'text': '多个文档中同名场景的预期冲突；核对适用版本和条件。',
                                           'requirement_ids': case['requirement_ids'], 'status': 'open',
                                           'options': list(dict.fromkeys(c['assertions'][0]['expected'] for c in cases))})
                case['question_ids'].append(qid)
                case['status'] = 'needs_clarification'
                case['assertions'][0]['status'] = 'pending'
    errors, warnings = suite_tools.validate(suite)
    rt.need(not errors, 'Imported suite failed validation: ' + '; '.join(errors))
    return suite, {'documents': analysis, 'cases': len(suite['cases']), 'warnings': warnings, 'coverage_complete': False,
                   'semantic_review': 'required', 'business_tests_executed': False}


def dispatch(root, tool, args):
    if tool == 'document_import':
        document = extract(rt.workspace_path(root, args['source'], existing=True), args['source'])
        write_new(rt.workspace_path(root, args['out']), document)
        return {'document': args['out'], 'blocks': len(document['blocks']), 'warnings': document['warnings'], 'backend': document['backend']}
    manifest = rt.read_json(rt.workspace_path(root, args['manifest'], existing=True))
    suite, report = build_cases(root, manifest)
    target = rt.workspace_path(root, args['out'])
    target.mkdir(parents=True, exist_ok=False)
    write_new(target / 'suite.json', suite)
    write_new(target / 'import-report.json', report)
    return {'suite': args['out'].replace('\\', '/').rstrip('/') + '/suite.json', **report}
