"""Offline Recorder/HAR association. Candidates never become replay defaults."""
import datetime
import json
from urllib.parse import urlsplit
import http_runner as rt
import trace_tools as legacy
import v5_common as c

def align(root,args):
    project,_=c.project(root,args['project'])
    spec=c.read(root,args['spec'])
    rt.shape(spec,['session_id','environment'],['recorder','har','alignment','case_id','attempt','adapter','operation_map','activity_map'],label='trace alignment spec')
    rt.ident(spec['session_id'],'session id')
    rt.need(isinstance(spec['environment'],str) and spec['environment'],'Environment required')
    rt.need('recorder' in spec or 'har' in spec,'At least one trace source required')
    rt.need(('case_id' in spec)==('attempt' in spec),'case_id and attempt must be supplied together')
    if 'case_id' in spec:
        rt.need(spec['case_id'] in project['cases'] and isinstance(spec['attempt'],str) and spec['attempt'],'Unknown case or attempt')
    inputs=[args['spec'],args['project']]
    ui=[]; http=[]
    if 'recorder' in spec:
        c.remember(root,spec['recorder'])
        normalized=legacy.import_trace(rt.workspace_path(root,spec['recorder'],existing=True),spec['recorder'])
        rt.need(normalized['kind']=='chrome-recorder','recorder input is not Recorder')
        ui=[{'id':'U'+str(i+1).zfill(5),'order':i,'action':entry['action'],'origin':entry.get('origin'),
             'path':entry.get('path'),'source_location':entry['location'],'issues':entry['issues']} for i,entry in enumerate(normalized['entries'])]
        inputs.append(spec['recorder'])
    if 'har' in spec:
        c.remember(root,spec['har'])
        normalized=legacy.import_trace(rt.workspace_path(root,spec['har'],existing=True),spec['har'])
        rt.need(normalized['kind']=='har','har input is not HAR')
        raw=c.read(root,spec['har'])
        for i,entry in enumerate(normalized['entries']):
            original=raw['log']['entries'][i]
            started=original.get('startedDateTime')
            if started:
                try:
                    stamp=datetime.datetime.fromisoformat(started.replace('Z','+00:00'))
                    rt.need(stamp.tzinfo is not None,'HAR timestamp needs timezone')
                except ValueError: raise rt.ToolError('INVALID_TRACE','Invalid HAR timestamp')
            duration=original.get('time')
            rt.need(duration is None or type(duration) in (int,float) and duration>=0,'Invalid HAR duration')
            if entry['kind']!='http':continue
            http.append({'id':'H'+str(i+1).zfill(5),'order':i,'method':entry['method'],'origin':entry['origin'],
                         'path':entry['path'],'status':entry['observed_status'],'started_at':started,'duration_ms':duration,
                         'page_ref':original.get('pageref'),'source_location':entry['location'],'issues':entry['issues'],
                         'classification':'read' if entry['method'] in ('GET','HEAD') else 'mutation_observation'})
        inputs.append(spec['har'])
    uid={x['id']:x for x in ui}; hid={x['id']:x for x in http}
    operations={}
    if 'adapter' in spec:
        from capabilities import load_adapter
        adapter=load_adapter(root,rt.workspace_path(root,spec['adapter'],existing=True));inputs.append(spec['adapter'])
        for event in http:
            entry={'kind':'http','issues':event['issues'],'origin':event['origin'],'method':event['method'],'path':event['path']}
            operations[event['id']]=[x['operation'] for x in legacy.matches(entry,adapter)]
    opmap=spec.get('operation_map',{})
    rt.need(isinstance(opmap,dict) and all(k in uid and isinstance(v,list) and all(isinstance(x,str) for x in v) for k,v in opmap.items()),'Invalid UI operation map')
    rt.need(not opmap or 'adapter' in spec,'operation_map requires registered adapter')
    links=[]; used_ui=set(); used_http=set(); issues=[]
    if 'alignment' in spec:
        binding=c.read(root,spec['alignment']);inputs.append(spec['alignment'])
        rt.shape(binding,['session_id','environment','links'],label='alignment binding')
        rt.need(binding['session_id']==spec['session_id'] and binding['environment']==spec['environment'],'Recording sessions/environments do not match','TRACE_SESSION_MISMATCH')
        rt.need(isinstance(binding['links'],list) and len(binding['links'])<=10000,'Alignment link limit')
        for link in binding['links']:
            rt.shape(link,['ui','http','reason'],['operation','source_refs'],label='explicit alignment link')
            rt.need(link['ui'] in uid and isinstance(link['http'],list) and all(x in hid for x in link['http']),'Unknown alignment event')
            rt.need(link['ui'] not in used_ui and not used_http.intersection(link['http']) and len(set(link['http']))==len(link['http']),'Overlapping explicit alignment')
            rt.need(isinstance(link['reason'],str) and link['reason'],'Explicit alignment requires reason')
            for ref in link.get('source_refs',[]):inputs.append(ref);c.hash_file(root,ref)
            origins={hid[x]['origin'] for x in link['http']}
            rt.need(not uid[link['ui']].get('origin') or all(x==uid[link['ui']]['origin'] for x in origins),'Cross-origin alignment not permitted')
            links.append({**link,'status':'confirmed','basis':'explicit_mapping','causality_proven':False})
            used_ui.add(link['ui']);used_http.update(link['http'])
    # Navigation anchors yield candidates only. Recorder has no reliable absolute timestamps.
    for action in ui:
        if action['id'] in used_ui:continue
        candidates=[event['id'] for event in http if event['id'] not in used_http and (
                    action['id'] in opmap and set(opmap[action['id']]).intersection(operations.get(event['id'],[])) or
                    action.get('origin')==event['origin'] and action.get('path')==event['path'] and action['action']=='navigate')]
        if candidates:
            links.append({'ui':action['id'],'http':candidates,'status':'candidate' if len(candidates)==1 else 'ambiguous',
                          'basis':'navigation_origin_path','causality_proven':False})
        else:links.append({'ui':action['id'],'http':[],'status':'unmatched','basis':'insufficient_anchors','causality_proven':False})
    unmatched=[x['id'] for x in http if x['id'] not in used_http]
    for event in http:
        if event['issues']:issues.append({'http':event['id'],'issues':event['issues']})
    events=[{'kind':'ui_observation',**x} for x in ui]+[{'kind':'http_observation',**x,'operations':operations.get(x['id'],[])} for x in http]
    anchors=[]
    if 'activity_map' in spec:
        mapping=c.read(root,spec['activity_map']);inputs.append(spec['activity_map'])
        rt.shape(mapping,['definition_id','operations'],label='operation activity mapping')
        rt.need(isinstance(mapping['operations'],dict),'Invalid activity map')
        for event in http:
            possible=[mapping['operations'][op] for op in operations.get(event['id'],[]) if op in mapping['operations']]
            rt.need(all(isinstance(x,str) and x for x in possible),'Activity mapping values must be IDs')
            if possible:
                anchors.append({'http':event['id'],'case_id':spec.get('case_id'),'attempt':spec.get('attempt'),
                    'definition_id':mapping['definition_id'],'activities':possible,'basis':'derived',
                    'status':'candidate' if len(possible)==1 else 'ambiguous','reason':'operation_to_activity is a hypothesis, not engine history'})
    meta={'trace_version':'2.0','session_id':spec['session_id'],'environment':spec['environment'],
          'case_id':spec.get('case_id'),'attempt':spec.get('attempt'),'observations_only':True,
          'ui_count':len(ui),'http_count':len(http),'unassigned_to_case':'case_id' not in spec,
          'unmatched_http':unmatched,'time_alignment':'Unavailable unless independently supplied; no fabricated timestamps.',
          'network_executed':False}
    return c.publish(root,args['project'],'trace',args['out'],{'trace.meta.json':meta,'trace.events.json':events,
           'alignment.json':links,'activity-anchors.json':anchors,
           'test-trace.jsonl':'\n'.join(json.dumps(e,ensure_ascii=False) for e in events)+'\n','issues.json':issues},inputs)
