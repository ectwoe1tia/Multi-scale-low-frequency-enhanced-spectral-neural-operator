"""Bounded files and provenance shared by offline tools; no network capability."""
import contextlib
import hashlib
import json
import uuid
import contextvars
from pathlib import Path
import http_runner as rt
import file_workflow as fw

LIMIT = 32 * rt.MAX_BYTES
READS=contextvars.ContextVar('workflow_v5_reads',default=None)

def generator_digest():
    scripts=Path(__file__).resolve().parent
    return rt.digest({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(scripts.glob('*.py'))})

@contextlib.contextmanager
def capture():
    token=READS.set({})
    try:yield
    finally:READS.reset(token)

def remember(root,ref):
    digest=hash_file(root,ref)
    reads=READS.get()
    if reads is not None:
        rt.need(ref not in reads or reads[ref]==digest,'Input changed during tool operation: '+ref,'STALE_INPUT')
        reads[ref]=digest
    return digest

def read(root, ref):
    before=remember(root,ref)
    value=rt.read_json(rt.workspace_path(root, ref, existing=True), LIMIT)
    rt.need(hash_file(root,ref)==before,'Input changed while reading','STALE_INPUT')
    return value

def hash_file(root, ref):
    digest=hashlib.sha256()
    with rt.workspace_path(root,ref,existing=True).open('rb') as stream:
        for block in iter(lambda:stream.read(rt.MAX_BYTES),b''):digest.update(block)
    return digest.hexdigest()

def relative(root, path):
    return path.relative_to(root).as_posix()

def project(root, ref):
    expected=read(root,ref)
    result=fw.project(root, ref)
    rt.need(result[0]==expected,'Project changed while reading','STALE_INPUT')
    return result

def write(root, ref, value):
    fw.write(rt.workspace_path(root, ref), value)

def replace(root, ref, value):
    path = rt.workspace_path(root, ref)
    path.parent.mkdir(parents=True, exist_ok=True)
    fw.replace_text(path, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

@contextlib.contextmanager
def lock(root, directory, name):
    path = rt.workspace_path(root, relative(root, directory / ('runtime/' + name + '.lock')))
    path.parent.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex
    try:
        with path.open('x', encoding='ascii') as f:
            f.write(token)
    except FileExistsError as exc:
        raise rt.ToolError('PROJECT_BUSY', 'Project writer active/interrupted; do not remove its lock without confirming it stopped') from exc
    try:
        yield
    finally:
        if path.is_file() and path.read_text(encoding='ascii') == token:
            path.unlink()

def publish(root, pref, kind, out, products, inputs):
    """Immutable artifact + checksums, then a bounded project catalog update."""
    _, directory = project(root, pref)
    target = rt.workspace_path(root, out)
    rt.need(directory in target.parents,'Derived output must stay inside project directory')
    with lock(root, directory, 'artifacts'):
        hashes = {}
        for ref in sorted(set(inputs)):
            current=hash_file(root,ref)
            expected=(READS.get() or {}).get(ref,current)
            rt.need(current==expected,'Input changed before publication: '+ref,'STALE_INPUT')
            hashes[ref]=current
        target.mkdir(parents=True, exist_ok=False)
        for name, value in products.items():
            rt.need('/' not in name and '\\' not in name, 'Artifact product must be a basename')
            path = rt.workspace_path(root, out + '/' + name)
            if name.endswith(('.md','.mmd','.jsonl')):
                rt.need(isinstance(value, str) and len(value.encode('utf-8')) <= LIMIT, 'Text output too large')
                with path.open('x', encoding='utf-8') as f:
                    f.write(value)
            else:
                fw.write(path, value)
        manifest = {'artifact_version':'1.0','kind':kind,'project':pref,'inputs':hashes,
                    'products':{name:hash_file(root, out+'/'+name) for name in products},
                    'generator_version':rt.VERSION,'generator_digest':generator_digest(),'created_at':rt.utc_now()}
        for ref,h in hashes.items():
            rt.need(hash_file(root,ref)==h,'Input changed while saving artifact','STALE_INPUT')
        write(root, out+'/manifest.json',manifest)
        index_ref = relative(root, directory/'runtime/artifacts.json')
        index = read(root,index_ref) if rt.workspace_path(root,index_ref).exists() else {}
        index[kind] = {'manifest':out+'/manifest.json','manifest_hash':hash_file(root,out+'/manifest.json')}
        replace(root,index_ref,index)
    return {'artifact':out,'manifest':out+'/manifest.json','network_executed':False}

def artifact(root, pref, kind):
    _, directory = project(root,pref)
    index = read(root,relative(root,directory/'runtime/artifacts.json'))
    rt.need(kind in index,'No artifact for '+kind,'ARTIFACT_MISSING')
    item=index[kind]
    rt.need(hash_file(root,item['manifest'])==item['manifest_hash'],'Manifest modified','EVIDENCE_CHANGED')
    m=read(root,item['manifest'])
    rt.need(m['project']==pref and m['generator_version']==rt.VERSION and m.get('generator_digest')==generator_digest(),'Artifact identity/version/code changed','STALE_ARTIFACT')
    for ref,h in m['inputs'].items():
        rt.need(hash_file(root,ref)==h,'Artifact input changed: '+ref,'STALE_ARTIFACT')
    base=item['manifest'].rsplit('/',1)[0]
    for name,h in m['products'].items():
        rt.need(hash_file(root,base+'/'+name)==h,'Artifact product changed','EVIDENCE_CHANGED')
    return m,base
