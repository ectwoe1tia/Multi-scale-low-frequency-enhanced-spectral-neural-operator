"""Human reports from sealed evidence. Detailed values remain report files, not stdout."""
import html
import hashlib
import json
from pathlib import Path
import http_runner as rt


def load(root,ref):
    path=rt.workspace_path(root,ref,existing=True)
    checksum=path.with_suffix('.sha256')
    rt.need(checksum.is_file(),'Run is not sealed','EVIDENCE_CHANGED')
    expected=checksum.read_text(encoding='ascii').strip()
    rt.need(hashlib.sha256(path.read_bytes()).hexdigest()==expected,'Run evidence changed','EVIDENCE_CHANGED')
    result=rt.read_json(path,max_bytes=16*rt.MAX_BYTES)
    rt.need(hashlib.sha256(path.read_bytes()).hexdigest()==expected,'Run changed during report read','EVIDENCE_CHANGED')
    rt.need(result.get('finished_at') and result.get('status') in ('PASS','FAIL','ERROR'),'Run is incomplete','EVIDENCE_CHANGED')
    return result


def cell(value,limit=1000):
    value=rt.redact(value)
    text=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,allow_nan=False)
    if len(text)>limit:text=text[:limit]+'…〔已截短，完整值见证据 JSON〕'
    return html.escape(text,quote=False).replace('|','&#124;').replace('\r','').replace('\n','<br>')


def reason(case):
    status=case.get('execution_status','UNKNOWN')
    if status=='PASS':
        checks=sum(len(a.get('checks',[])) for s in case.get('steps',[]) for a in s.get('attempts',[]))
        return '全部步骤完成，最终断言通过；共记录 %d 次断言检查（含轮询历史）。'%checks
    if status=='FAIL':return '%d 个最终断言未满足；后续未执行步骤 %d 个。'%(len(case.get('failures',[])),len(case.get('unexecuted_steps',[])))
    if status=='ERROR':return '执行异常：'+case.get('error',{}).get('code','EXECUTION_ERROR')+'；不能推断未发生副作用。'
    return '未获得完整封存执行结果；不能判为通过。'


def table(head,rows):
    return ['| '+' | '.join(head)+' |','|'+'|'.join('---' for _ in head)+'|']+[
        '| '+' | '.join(cell(v) for v in row)+' |' for row in rows]


def case_lines(case,source,index):
    meta=case.get('metadata',{})
    cid=case['case_id']
    lines=['', '### '+cell(cid)+' — '+cell(meta.get('title','历史证据未保存标题')), '',
           '状态：'+cell(case.get('execution_status'))+'；处置：'+cell(case.get('gate','未知'))+'。'+cell(reason(case)),
           '', '证据：`'+source+'#/cases/'+str(index)+'`','']
    origin='经哈希验证的准备来源' if case.get('metadata_origin')=='verified_preparation_source' else '执行时快照' if meta else '历史证据未保存'
    lines+=['用例信息来源：'+origin+'。','']
    if case.get('error'):lines+=['执行错误：'+cell(case['error']), '']
    if case.get('failures'):
        lines+=['最终失败断言：','']+table(['步骤','检查 / 业务断言','位置 / 操作符','期望值','实际值'],[
            [f.get('step_id'),str(f.get('check_id'))+' / '+str(f.get('assertion_id') or 'HTTP/技术检查'),
             str(f.get('pointer'))+' / '+str(f.get('op')),f.get('expected'),f.get('actual')]
            for f in case['failures']])+['']
    for j,step in enumerate(case.get('steps',[])):
        lines+=['#### '+cell(step['step_id'])+' · '+cell(step.get('operation','')),'',
                'HTTP：'+cell(step.get('method','未知'))+' '+cell(step.get('path_template','未知'))+
                '；角色：'+cell(step.get('actor','未知'))+'；请求状态：'+cell(step.get('request_state','未知'))+'。','']
        observations=step.get('attempts',[])
        if not observations:
            lines+=['未保存 HTTP 响应；状态码与服务端消息未知。','']
        for k,observation in enumerate(observations):
            response=observation.get('response',{})
            body=response.get('body')
            msg=next((body[key] for key in ('msg','message') if key in body), '未返回 msg/message') if isinstance(body,dict) else '非 JSON 或空响应'
            lines+=['第 '+str(observation.get('attempt',k+1))+' 次请求：'+cell(step.get('method','未知'))+' '+
                    cell(response.get('request_path',step.get('path_template','未知')))+'；响应码 **'+
                    cell(response.get('status_code','未知'))+'**；服务端消息：'+cell(msg),'',
                    '证据位置：`'+source+'#/cases/%d/steps/%d/attempts/%d`'%(index,j,k),'']
            lines+=table(['检查','业务断言','字段 / 比较','期望','实际','结果'],[
                [a['check_id'],a.get('assertion_id') or 'HTTP/技术检查',str(a['pointer'])+' / '+str(a['op']),
                 a.get('expected','无需期望值'),a.get('actual'),a['status']] for a in observation.get('checks',[])])+['']
    if case.get('unexecuted_steps'):lines+=['未执行步骤：'+cell(case['unexecuted_steps']), '']
    return lines


def run_lines(result,source):
    lines=['## 运行 '+cell(result['run_id']),'',
           '原始结果：**'+cell(result['status'])+'**；处置 gate：'+cell(result['gate'])+'。',
           'PASS=断言通过；FAIL=断言失败；ERROR=执行异常。gate 不会把 FAIL 改写为 PASS。','']
    lines+=table(['编号','标题','分类','优先级','设计状态','执行状态','原因'],[
        [case['case_id'],case.get('metadata',{}).get('title','历史证据未保存'),
         case.get('metadata',{}).get('category','未知'),case.get('metadata',{}).get('priority','未知'),
         case.get('metadata',{}).get('status','未知'),case['execution_status'],reason(case)] for case in result['cases']])
    for i,case in enumerate(result['cases']):lines+=case_lines(case,source,i)
    return lines


def write(path,lines):
    text='\n'.join(lines)+'\n'
    rt.need(len(text.encode('utf-8'))<=32*rt.MAX_BYTES,'Report exceeds 32 MiB; split report scope')
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as out:out.write(text)
