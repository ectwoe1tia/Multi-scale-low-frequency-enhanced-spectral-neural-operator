"""Explicit effects for every registered tool; parameter schema stays in TOOLS."""
GROUPS = {
    'inspect': ('describe', 'tool_help', 'suite_validate', 'plan_validate', 'plan_preview',
                'snapshot', 'flow_focus'),
    'local_diagnostic': ('doctor', 'flow_status', 'flow_report', 'report', 'flow_diagnose',
                         'evidence_query', 'artifact_query', 'context_refresh', 'semantic_query','semantic_diff','semantic_check'),
    'compile': ('document_import', 'cases_build', 'api_discover', 'adapter_build',
                'trace_import', 'trace_match', 'plan_from_trace', 'suite_render',
                'skill_build', 'request_compose', 'rules_codegen', 'project_tool_invoke',
                'flow_analysis', 'trace_align','semantic_compile','semantic_propose','semantic_promote'),
    'local_state': ('flow_init', 'flow_prepare', 'flow_note', 'flow_reconcile',
                    'flow_cancel', 'runtime_init', 'knowledge_record', 'claim', 'release'),
    'execute': ('run', 'flow_execute'),
}
EFFECTS = {name: group for group, names in GROUPS.items() for name in names}


def effect(name):
    if name not in EFFECTS:
        raise ValueError('Registered tool lacks an explicit effect contract')
    group = EFFECTS[name]
    return {'category': group, 'business_network': group == 'execute',
            'local_writes': group != 'inspect', 'automatic_write_retry': False}


def describe(name, registry):
    required, optional = registry[name]
    template = {key: (['<relative_file>'] if key == 'files' else
                     {'<relative_file>': '<sha256>'} if key == 'base_hashes' else '<' + key + '>')
                for key in required}
    return {'tool': name, 'protocol_version': '1.0', 'effects': effect(name),
            'arguments': {'required': required, 'optional': optional,
                          'paths': 'Workspace-relative; input documents remain files.'},
            'response': 'Complete receipt on disk; control view contains decisions and references only.',
            'contract_ref': 'references/diagnostics.md' if name in ('tool_help', 'flow_diagnose', 'evidence_query')
                            else 'references/toolchain.md',
            'request_template': {'protocol_version': '1.0', 'tool': name,
                                 'arguments': template}}
