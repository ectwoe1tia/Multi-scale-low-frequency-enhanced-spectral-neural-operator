"""Offline BPMN XML/Flowable model snapshots -> graph. Never evaluates BPMN code."""
import xml.etree.ElementTree as ET
import re
import http_runner as rt
import v5_common as c

NODE_TYPES={'startEvent','endEvent','userTask','serviceTask','task','manualTask','receiveTask','sendTask',
            'scriptTask','businessRuleTask','exclusiveGateway','parallelGateway','inclusiveGateway','eventBasedGateway',
            'subProcess','callActivity','boundaryEvent','intermediateCatchEvent','intermediateThrowEvent'}
OPAQUE={'subProcess','callActivity','boundaryEvent','inclusiveGateway','eventBasedGateway','scriptTask'}

def local(tag): return tag.rsplit('}',1)[-1]

def load(root,ref):
    bundle=c.read(root,ref)
    rt.shape(bundle,['format','file','process_id','definition'],['node_type_map'],label='definition bundle')
    rt.shape(bundle['definition'],['id','key','version'],label='definition metadata')
    rt.need(isinstance(bundle['definition']['id'],str) and isinstance(bundle['definition']['key'],str) and
            type(bundle['definition']['version']) is int and bundle['definition']['version']>0,'Invalid definition identity')
    path=rt.workspace_path(root,bundle['file'],existing=True)
    before=c.remember(root,bundle['file'])
    rt.need(path.stat().st_size<=16*rt.MAX_BYTES,'Definition too large')
    nodes,edges=[],[]
    if bundle['format']=='bpmn_xml':
        raw=path.read_bytes()
        rt.need(not re.search(br'<!\s*(DOCTYPE|ENTITY)',raw,re.I) and b'\x00' not in raw,'DTD/entities/UTF16 XML unsupported')
        try: document=ET.fromstring(raw)
        except ET.ParseError as exc: raise rt.ToolError('INVALID_BPMN','Invalid XML') from exc
        rt.need(document.tag=='{http://www.omg.org/spec/BPMN/20100524/MODEL}definitions','Expected BPMN 2.0 definitions namespace','INVALID_BPMN')
        count=0
        def limits(el,depth=0):
            nonlocal count
            count+=1
            rt.need(count<=20000 and depth<=64,'XML structural limit exceeded')
            for child in el: limits(child,depth+1)
        limits(document)
        found=[p for p in document.iter() if local(p.tag)=='process' and p.get('id')==bundle['process_id']]
        rt.need(len(found)==1,'Select exactly one BPMN process')
        def walk(container,scope):
            for el in container:
                kind=local(el.tag)
                if kind in NODE_TYPES:
                    rt.need(el.get('id'),'BPMN node lacks id')
                    node={'id':el.get('id'),'name':el.get('name',''),'type':kind,'scope':scope,
                          'default':el.get('default'),'opaque':kind in OPAQUE,
                          'source_location':'//*[@id="'+el.get('id')+'"]'}
                    if any(local(x.tag)=='multiInstanceLoopCharacteristics' for x in el):
                        node['opaque']=True; node['multi_instance']=True
                    nodes.append(node)
                    if kind=='subProcess': walk(el,scope+'/'+el.get('id'))
                elif kind=='sequenceFlow':
                    condition=next((x.text or '' for x in el if local(x.tag)=='conditionExpression'),None)
                    edges.append({'id':el.get('id'),'source':el.get('sourceRef'),'target':el.get('targetRef'),
                                  'scope':scope,'condition':condition,'condition_evaluated':False})
        walk(found[0],bundle['process_id'])
    elif bundle['format']=='flowable_model':
        raw=c.read(root,bundle['file'])
        rt.need(isinstance(raw,dict) and isinstance(raw.get('processes'),list),'Unsupported Flowable model envelope')
        selected=[p for p in raw['processes'] if p.get('id')==bundle['process_id']]
        rt.need(len(selected)==1,'Select exactly one Flowable model process')
        mapping=bundle.get('node_type_map',{})
        rt.need(isinstance(mapping,dict) and all(v in NODE_TYPES for v in mapping.values()),'Invalid node_type_map')
        def walk_model(container,scope,depth=0):
            rt.need(depth<=32,'Model nesting too deep')
            rt.need(isinstance(container.get('flowElements',[]),list),'flowElements must be an array')
            for el in container.get('flowElements',[]):
                rt.need(isinstance(el,dict) and isinstance(el.get('id'),str),'Invalid Flowable element')
                sid,tid=el.get('sourceRef'),el.get('targetRef')
                if sid is not None or tid is not None:
                    rt.need(isinstance(sid,str) and isinstance(tid,str),'Unsupported model edge references')
                    edges.append({'id':el['id'],'source':sid,'target':tid,'scope':scope,
                                  'condition':el.get('conditionExpression'),'condition_evaluated':False})
                else:
                    rawkind=el.get('type',mapping.get(el['id'],'unknown'))
                    kind=rawkind[:1].lower()+rawkind[1:] if isinstance(rawkind,str) else 'unknown'
                    if kind not in NODE_TYPES: kind='unknown'
                    nodes.append({'id':el['id'],'name':el.get('name',''),'type':kind,'scope':scope,
                                  'default':el.get('defaultFlow'),'opaque':kind in OPAQUE or kind=='unknown',
                                  'source_location':'flowElements/'+el['id']})
                    if kind=='subProcess': walk_model(el,scope+'/'+el['id'],depth+1)
        walk_model(selected[0],bundle['process_id'])
    else: raise rt.ToolError('UNSUPPORTED_FORMAT','Expected bpmn_xml or flowable_model snapshot')
    rt.need(1<=len(nodes)<=10000 and len(edges)<=20000,'Graph size limit exceeded')
    ids=[n['id'] for n in nodes]+[e['id'] for e in edges]
    rt.need(all(isinstance(x,str) and 1<=len(x)<=200 for x in ids) and len(set(ids))==len(ids),'Missing/duplicate/oversized BPMN IDs')
    byid={n['id']:n for n in nodes}
    for e in edges:
        rt.need(e['source'] in byid and e['target'] in byid,'Dangling sequence flow')
        rt.need(byid[e['source']]['scope']==e['scope'] and byid[e['target']]['scope']==e['scope'],'Cross-scope sequence flow unsupported')
    for n in nodes:
        if n['default']:
            rt.need(any(e['id']==n['default'] and e['source']==n['id'] for e in edges),'Invalid default flow')
    rt.need(c.hash_file(root,bundle['file'])==before,'Definition changed while parsing','STALE_INPUT')
    return {'graph_version':'1.0','process_id':bundle['process_id'],'definition':bundle['definition'],
            'nodes':nodes,'edges':edges,'opaque_nodes':[n['id'] for n in nodes if n['opaque']]},[ref,bundle['file']]

def paths(graph,policy):
    """Structural bounded paths only, never claims condition feasibility."""
    rt.shape(policy,[],['loop_bound','max_depth','max_paths'],label='coverage policy')
    limits={'loop_bound':1,'max_depth':200,'max_paths':5000,**policy}
    for k,lo,hi in [('loop_bound',0,3),('max_depth',1,500),('max_paths',1,10000)]:
        rt.need(type(limits[k]) is int and lo<=limits[k]<=hi,'Invalid path bound')
    # Concurrent branches cannot be treated as alternative complete paths.
    implicit_parallel=any(n['type']!='exclusiveGateway' and sum(e['source']==n['id'] for e in graph['edges'])>1 for n in graph['nodes'])
    if graph['opaque_nodes'] or any(n['type']=='parallelGateway' for n in graph['nodes']) or implicit_parallel:
        return {'paths':[],'complete':False,'reason':'opaque_or_concurrent_structure','bounds':limits,'basis':'structural_not_feasibility'}
    outgoing={n['id']:[] for n in graph['nodes']}
    for e in graph['edges']: outgoing[e['source']].append(e)
    nodes={n['id']:n for n in graph['nodes']}
    starts=[n['id'] for n in graph['nodes'] if n['type']=='startEvent' and n['scope']==graph['process_id']]
    result=[]; reasons=set(); cycle_seen=False; visited_states=0; output_bytes=0
    def visit(node,route,flows,counts):
        nonlocal cycle_seen,visited_states,output_bytes
        if visited_states>=50000:reasons.add('state_budget');return
        visited_states+=1
        if len(result)>=limits['max_paths']: reasons.add('max_paths'); return
        if len(route)>limits['max_depth']: reasons.add('max_depth'); return
        if nodes[node]['type']=='endEvent':
            estimate=sum(len(x.encode('utf-8'))+8 for x in route+flows)+128
            if output_bytes+estimate>8*rt.MAX_BYTES:reasons.add('path_output_budget');return
            output_bytes+=estimate
            result.append({'id':rt.digest(flows)[:16],'nodes':route,'edges':flows}); return
        if not outgoing[node]:reasons.add('dead_end')
        for e in outgoing[node]:
            if visited_states>=50000:reasons.add('state_budget');break
            if output_bytes>=8*rt.MAX_BYTES:reasons.add('path_output_budget');break
            nxt=e['target']; seen=counts.get(nxt,0)
            if seen: cycle_seen=True
            if seen>=limits['loop_bound']+1: reasons.add('loop_bound'); continue
            visit(nxt,route+[nxt],flows+[e['id']],{**counts,nxt:seen+1})
    for start in starts: visit(start,[start],[],{start:1})
    if not starts: reasons.add('no_start')
    return {'paths':result,'complete':not reasons and not cycle_seen,'reason':','.join(sorted(reasons)) or None,
            'bounds':limits,'basis':'structural_not_feasibility','bounded':cycle_seen,
            'visited_states':visited_states,'state_budget':50000,'path_output_budget_bytes':8*rt.MAX_BYTES}
