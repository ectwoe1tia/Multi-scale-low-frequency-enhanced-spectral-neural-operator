[CmdletBinding()]
param(
    [Alias('SessionSpec')][string]$Session,
    [ValidateSet('init', 'status', 'prepare', 'diagnose', 'execute', 'report')]
    [string]$Action = 'status',
    [Alias('Case')][string]$CaseId,
    [string]$Attempt,
    [string]$RetryNote,
    [string]$Python = 'python'
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
try {
    if (-not $Session) {
        [Console]::Out.WriteLine('{"protocol_version":"1.0","tool":"session","ok":false,"code":"SESSION_REQUIRED","message":"Use -Session <session-spec.json path> -Action <init|status|prepare|diagnose|execute|report>."}')
        exit 2
    }
    $sessionPath = (Resolve-Path -LiteralPath $Session -ErrorAction Stop).Path
    $pythonCommand = Get-Command -Name $Python -CommandType Application -ErrorAction Stop | Select-Object -First 1
    $entry = Join-Path $PSScriptRoot 'session_cli.py'
    $toolArguments = @('-X', 'utf8', $entry, '--session', $sessionPath, '--action', $Action.ToLowerInvariant())
    if ($CaseId) { $toolArguments += @('--case-id', $CaseId) }
    if ($Attempt) { $toolArguments += @('--attempt', $Attempt) }
    if ($RetryNote) { $toolArguments += @('--retry-note', $RetryNote) }
    & $pythonCommand.Source @toolArguments
    exit $LASTEXITCODE
}
catch {
    [Console]::Out.WriteLine('{"protocol_version":"1.0","tool":"session","ok":false,"code":"ENVIRONMENT_ERROR","message":"Check Python and the session file path; no inline JSON or token arguments are accepted."}')
    exit 12
}
