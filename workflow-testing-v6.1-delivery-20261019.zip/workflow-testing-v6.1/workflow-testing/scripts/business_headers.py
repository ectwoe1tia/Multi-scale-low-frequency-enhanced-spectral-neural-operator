"""Explicit business headers; transport/auth headers remain runner-owned."""
import os
import re
import http_runner as rt

RESERVED = {'authorization','proxy-authorization','cookie','host','content-type','content-length',
            'accept','transfer-encoding','connection','te','trailer','upgrade','expect'}


def validate(headers, adapter, templates=False, max_entries=32):
    rt.need(isinstance(headers,dict) and len(headers)<=max_entries,'Too many business headers or invalid header object')
    seen=set()
    for name,value in headers.items():
        rt.need(isinstance(name,str) and re.fullmatch(r'[A-Za-z][A-Za-z0-9-]{0,63}',name),'Invalid business header name')
        lower=name.lower()
        rt.need(lower not in seen,'Duplicate case-insensitive header')
        seen.add(lower)
        rt.need(lower not in RESERVED and lower!=adapter.get('idempotency_header','').lower(),'Reserved transport/auth header')
        if isinstance(value,dict):
            rt.shape(value,['env'],label='header env reference')
            rt.need(isinstance(value['env'],str) and re.fullmatch('[A-Za-z_][A-Za-z0-9_]*',value['env']), 'Invalid header env reference')
        else:
            rt.need(isinstance(value,str) and 1<=len(value)<=4096 and all(32<=ord(x)<=126 for x in value),
                    'Business header value must be nonempty printable ASCII, at most 4096 characters')
            rt.need(templates or not rt.refs(value),'Header variables are allowed only on plan cases and steps')
            rt.need(not rt.SECRET_KEYS.search(name),'Sensitive headers require env references, not literals')


def overlay(case_headers,step_headers):
    return {k.lower():v for layer in (case_headers or {},step_headers or {}) for k,v in layer.items()}


def merged(adapter,op,actor,step_headers=None):
    result={}
    for layer in (adapter.get('headers',{}),adapter['actors'][actor].get('headers',{}),
                  op.get('headers',{}),step_headers or {}):
        validate(layer,adapter,templates=True,max_entries=64)
        result.update({k.lower():v for k,v in layer.items()})
    rt.need(len(result)<=64,'Too many effective business headers')
    return result


def env_names(adapter,plan):
    names=set()
    for case in plan['cases']:
        for step in case['steps']:
            token=adapter['actors'][step['actor']]['bearer_token_env']
            if token:names.add(token)
            for value in merged(adapter,adapter['operations'][step['operation']],step['actor'],
                                overlay(case.get('headers'),step.get('headers'))).values():
                if isinstance(value,dict):names.add(value['env'])
    return names


def resolve(adapter,op,actor,step_headers,secrets):
    headers=merged(adapter,op,actor,step_headers)
    result={}
    for name,value in headers.items():
        if isinstance(value,dict):
            value=os.environ.get(value['env'],'')
            rt.need(bool(value) and len(value)<=4096 and all(32<=ord(x)<=126 for x in value),
                    'Missing or invalid business header environment value','ENVIRONMENT_ERROR')
            if value not in secrets:secrets.append(value)
        rt.need(not rt.refs(value),'Unresolved header variable')
        result[name]=value
    return result
