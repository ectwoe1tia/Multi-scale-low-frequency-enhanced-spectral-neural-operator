"""One batch file -> persisted task receipts -> small control response."""
import argparse
import json
from pathlib import Path
import http_runner as rt
import batch_session

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--batch',required=True);p.add_argument('--state',required=True)
    args=p.parse_args(argv);spec=Path(args.batch).resolve();root=spec.parent
    try:
        result=batch_session.run(root,spec.name,args.state)
        value={'ok':result['status'] in ('COMPLETE','PAUSED_BUDGET'),'code':result['status'],**result}
    except rt.ToolError as e:value={'ok':False,'code':e.code,'automatic_retry':False}
    except (OSError,ValueError):value={'ok':False,'code':'ENVIRONMENT_ERROR','automatic_retry':False}
    print(json.dumps(value,ensure_ascii=True))
    return 0 if value['ok'] else 2

if __name__=='__main__':raise SystemExit(main())
