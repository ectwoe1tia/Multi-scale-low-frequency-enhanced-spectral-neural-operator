"""Named file contracts for deterministic semantic and batch tools."""
def schema():
    text={'type':'string','minLength':1}
    def obj(properties,optional=()):return {'type':'object','additionalProperties':False,'properties':properties,'required':[k for k in properties if k not in optional]}
    def arr(items,max_items=100):return {'type':'array','items':items,'maxItems':max_items}
    def integer(low,high):return {'type':'integer','minimum':low,'maximum':high}
    version={'const':'1.0'};loc=obj({'file':text,'pointer':{'type':'string'}})
    source=obj({'id':text,'path':text,'kind':{'enum':['json','har','recorder']}})
    rule=obj({'file':text,'select':{'type':'string'},'kind':{'enum':['define','reference','expression','expect']},
              'namespace':text,'prefix':{'type':'string'},'dialect':{'const':'python_subset'},
              'type':{'enum':['string','number','boolean','object','array','null']},'min':{'type':'number'},'max':{'type':'number'},'enum':arr({})},
             ['namespace','prefix','dialect','type','min','max','enum'])
    hypothesis=obj({'from':loc,'to':loc,'predicate':{'enum':['equal','same_type','depends_on','co_occurs']},'evidence':arr(text,16)})
    task=obj({'id':text,'depends_on':arr(text),'request':text,'session':text,
              'action':{'enum':['status','prepare','diagnose','execute','report']},'case_id':text},['request','session','action','case_id'])
    return {'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':{
     'FileSet':obj({'version':version,'files':arr(source,256),'includes':arr(text,64)},['includes']),
     'Profile':obj({'version':version,'rules':arr(rule,128),'embedded_json':{'type':'boolean'},'templates':{'type':'boolean'}},['embedded_json','templates']),
     'Compile':obj({'file_set':text,'profile':text,'cache':text},['cache']),
     'Query':obj({'kind':{'enum':['summary','nodes','issues','dependencies','impact']},'file':text,'pointer':{'type':'string'},
                  'node':loc,'depth':integer(1,6),'offset':integer(0,200000),'limit':integer(1,100),'max_bytes':integer(512,8192),'code':text},
                 ['file','pointer','node','depth','offset','limit','max_bytes','code']),
     'Propose':{'oneOf':[obj({'hypotheses':arr(hypothesis)}),obj({'seeds':{**arr(loc,16),'minItems':1}})]},
     'Review':obj({'proposals_sha256':text,'reviewer':text,'decisions':arr(obj({'id':text,'decision':{'enum':['accept','reject']}}))}),
     'Batch':obj({'version':version,'tasks':arr(task,1000),'includes':arr(text,64),'max_tasks':integer(1,100),
                  'max_seconds':integer(1,300),'parallel_queries':integer(1,4),'allow_execute':{'type':'boolean'}},
                 ['includes','max_tasks','max_seconds','parallel_queries','allow_execute'])}}
