"""Read HAR/Chrome Recorder as untrusted observations; bind fresh HTTP tests explicitly."""
import json
import re
from pathlib import Path
from urllib.parse import parse_qsl, unquote, urlsplit

import http_runner as rt
from capabilities import file_hash, load_adapter, write_new


def origin_url(url):
    rt.text(url, 'trace URL')
    parsed = urlsplit(url)
    rt.need(parsed.scheme in ('http', 'https') and parsed.hostname and not parsed.username and not parsed.password, 'Unsupported trace URL')
    return parsed, parsed.scheme + '://' + parsed.netloc


def clean_text(value):
    """Freeform observations are never interpreted as tool instructions."""
    return re.sub(r'(?i)(bearer\s+)[A-Za-z0-9._~+/-]+=*', r'\1[REDACTED]', str(value))


def collect_secrets(value, secrets, sensitive=False):
    if isinstance(value, dict):
        for key, item in value.items():
            collect_secrets(item, secrets, sensitive or bool(rt.SECRET_KEYS.search(key)))
    elif isinstance(value, list):
        for item in value:
            collect_secrets(item, secrets, sensitive)
    elif sensitive and isinstance(value, str) and value:
        secrets.append(value)


def safe_query(url):
    parsed, _ = origin_url(url)
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    result, duplicate = {}, []
    for key, value in pairs:
        if key in result:
            duplicate.append(key)
        result[key] = '[REDACTED]' if rt.SECRET_KEYS.search(key) else value
    return result, duplicate


def import_trace(source, relative):
    raw = rt.read_json(source, 32 * rt.MAX_BYTES)
    entries, warnings = [], []
    secrets = []
    if isinstance(raw, dict) and isinstance(raw.get('log'), dict) and isinstance(raw['log'].get('entries'), list):
        kind = 'har'
        events = raw['log']['entries']
        rt.need(len(events) <= 10000, 'HAR exceeds 10000 entries')
        for index, event in enumerate(events, 1):
            entry_id = 'E' + str(index).zfill(5)
            rt.need(isinstance(event, dict), 'Invalid HAR entry')
            request, response = event.get('request', {}), event.get('response', {})
            rt.need(isinstance(request, dict) and isinstance(response, dict), 'Invalid HAR request or response')
            for header in request.get('headers', []) + request.get('cookies', []):
                if isinstance(header, dict) and rt.SECRET_KEYS.search(str(header.get('name', ''))):
                    value = header.get('value')
                    if isinstance(value, str) and value:
                        secrets.append(value)
                        if value.lower().startswith('bearer '):
                            secrets.append(value[7:])
            issues = []
            try:
                url, origin = origin_url(request.get('url'))
                path = url.path or '/'
                for name, value in parse_qsl(url.query, keep_blank_values=True):
                    if rt.SECRET_KEYS.search(name) and value:
                        secrets.append(value)
                query, duplicate = safe_query(request['url'])
                if duplicate:
                    issues.append('DUPLICATE_QUERY_KEYS')
            except (rt.ToolError, ValueError):
                entries.append({'id': entry_id, 'kind': 'unsupported', 'issues': ['NON_HTTP_URL'], 'location': 'log.entries[' + str(index - 1) + ']'})
                continue
            method = request.get('method', '')
            if method not in ('GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE'):
                issues.append('UNSUPPORTED_METHOD')
            body = None
            post = request.get('postData')
            if isinstance(post, dict):
                mime = post.get('mimeType', '').split(';')[0].lower()
                if mime == 'application/json' or mime.endswith('+json'):
                    try:
                        body = json.loads(post.get('text', ''))
                        rt.canonical(body)
                    except (ValueError, TypeError, RecursionError):
                        issues.append('INVALID_JSON_BODY')
                else:
                    issues.append('UNSUPPORTED_REQUEST_BODY')
            # Never persist recorded credentials, cookies, response bodies or arbitrary headers.
            # Request examples retain non-secret fields only and are NOT replay defaults.
            collect_secrets(body, secrets)
            body = rt.redact(body)
            status = response.get('status')
            if type(status) is not int or not 100 <= status <= 599:
                status = None
                issues.append('NO_HTTP_RESPONSE')
            entries.append({'id': entry_id, 'kind': 'http', 'method': method, 'origin': origin, 'path': path,
                            'query_example': query, 'body_example': body, 'observed_status': status,
                            'issues': issues, 'location': 'log.entries[' + str(index - 1) + ']'})
        warnings.append('Recorded statuses are observations, not expected results; identity and fresh data must come from the test binding.')
    elif isinstance(raw, dict) and isinstance(raw.get('steps'), list):
        kind = 'chrome-recorder'
        rt.need(len(raw['steps']) <= 10000, 'Recorder exceeds 10000 steps')
        for index, step in enumerate(raw['steps'], 1):
            rt.need(isinstance(step, dict) and isinstance(step.get('type'), str), 'Invalid Recorder step')
            event = {'id': 'E' + str(index).zfill(5), 'kind': 'ui', 'action': step['type'],
                     'location': 'steps[' + str(index - 1) + ']', 'issues': []}
            # Input values, selectors, expression bodies and key presses may contain credentials.
            # Preserve only structural metadata; consult the original locally when binding.
            event['selector_count'] = len(step.get('selectors', [])) if isinstance(step.get('selectors'), list) else 0
            event['input_value_omitted'] = 'value' in step
            if step.get('url'):
                try:
                    url, origin = origin_url(step['url'])
                    event.update({'origin': origin, 'path': url.path or '/'})
                except (rt.ToolError, ValueError):
                    event['issues'].append('NON_HTTP_URL')
            if step['type'] not in ('navigate', 'click', 'doubleClick', 'change', 'keyDown', 'keyUp', 'scroll', 'setViewport', 'waitForElement', 'waitForExpression', 'close'):
                event['issues'].append('UNKNOWN_RECORDER_ACTION')
            if step['type'] == 'waitForExpression':
                event['issues'].append('EXPRESSION_NOT_EXECUTED')
            entries.append(event)
        warnings.append('Recorder evidence supplies action order only. Binding runs registered HTTP operations; no DOM/browser replay or visual assertion is implemented.')
    else:
        raise rt.ToolError('UNSUPPORTED_FORMAT', 'Expected a HAR log or Chrome Recorder JSON export')
    rt.need(entries, 'Trace contains no entries')
    return {'trace_version': '1.0', 'source': relative, 'source_sha256': file_hash(source), 'kind': kind,
            'entries': rt.redact(entries, secrets), 'warnings': warnings, 'observations_only': True}


def verify_trace(root, trace):
    rt.shape(trace, ['trace_version', 'source', 'source_sha256', 'kind', 'entries', 'warnings', 'observations_only'], label='trace')
    rt.need(trace['trace_version'] == '1.0' and trace['observations_only'] is True, 'Unsupported trace version')
    source = rt.workspace_path(root, trace['source'], existing=True)
    rt.need(file_hash(source) == trace['source_sha256'], 'Trace source changed; import again', 'STALE_SOURCE')
    rt.need(rt.canonical(import_trace(source, trace['source'])) == rt.canonical(trace), 'Trace evidence changed; import again', 'EVIDENCE_CHANGED')


def path_match(template, path):
    names, chunks, last = [], [], 0
    for match in re.finditer(r'\{([A-Za-z][A-Za-z0-9_-]*)\}', template):
        names.append(match[1])
        chunks.extend([re.escape(template[last:match.start()]), r'([^/]+)'])
        last = match.end()
    chunks.append(re.escape(template[last:]))
    match = re.fullmatch(''.join(chunks), path)
    if not match:
        return None
    return dict(zip(names, [unquote(x) for x in match.groups()]))


def matches(entry, adapter):
    if entry['kind'] != 'http' or entry.get('issues'):
        return []
    if entry['origin'].rstrip('/') != adapter['base_url'].rstrip('/'):
        return []
    found = []
    for oid, op in adapter['operations'].items():
        params = path_match(op['path'], entry['path'])
        if op['method'] == entry['method'] and params is not None:
            found.append({'operation': oid, 'observed_params': params})
    return found


def build_plan(root, suite, adapter, trace, binding):
    verify_trace(root, trace)
    rt.shape(binding, ['binding_version', 'plan_id', 'cases'], label='trace binding')
    rt.need(binding['binding_version'] == '1.0', 'Unsupported binding version')
    rt.need(isinstance(binding['cases'], list) and binding['cases'], 'Binding cases required')
    entries = {e['id']: e for e in trace['entries']}
    plan = {'schema_version': '1.0', 'plan_id': binding['plan_id'], 'adapter_id': adapter['adapter_id'], 'cases': []}
    links = []
    for case in binding['cases']:
        rt.shape(case, ['case_id', 'vars', 'steps'], label='case binding')
        rt.need(isinstance(case['steps'], list) and case['steps'], 'Binding steps required')
        planned = {'case_id': case['case_id'], 'vars': case['vars'], 'steps': []}
        for number, step in enumerate(case['steps'], 1):
            rt.shape(step, ['entry_id', 'actor', 'params', 'query', 'body', 'capture', 'checks'], ['operation', 'poll'], 'trace step binding')
            rt.need(step['entry_id'] in entries, 'Unknown trace entry')
            entry = entries[step['entry_id']]
            rt.need(not entry.get('issues'), 'Trace entry has unresolved import issues', 'UNSUPPORTED_TRACE_ENTRY')
            if entry['kind'] == 'http':
                found = matches(entry, adapter)
                if 'operation' in step:
                    found = [item for item in found if item['operation'] == step['operation']]
                rt.need(len(found) == 1, 'HTTP trace must match exactly one permitted operation on the same origin', 'CAPABILITY_MISMATCH')
                operation = found[0]['operation']
            else:
                rt.need(entry['kind'] == 'ui' and entry['action'] in ('click', 'doubleClick', 'change', 'navigate'),
                        'This Recorder event cannot be mapped to a business HTTP action', 'UNSUPPORTED_TRACE_ENTRY')
                operation = step.get('operation')
                rt.need(operation in adapter['operations'], 'Recorder requires explicit registered HTTP operation binding', 'CAPABILITY_MISMATCH')
            # Parameters/body/checks come from binding, never silently copied from historical traffic.
            built = {key: step[key] for key in ('actor', 'params', 'query', 'body', 'capture', 'checks')}
            built.update({'id': 'step_' + str(number).zfill(3), 'operation': operation})
            if 'poll' in step:
                built['poll'] = step['poll']
            planned['steps'].append(built)
            links.append({'case_id': case['case_id'], 'step_id': built['id'], 'entry_id': entry['id'], 'operation': operation})
        plan['cases'].append(planned)
    preview = rt.validate_bundle(suite, adapter, plan)
    return plan, {'trace_source': trace['source'], 'trace_sha256': trace['source_sha256'], 'links': links,
                  'execution_mode': 'http', 'browser_executed': False, 'preview': preview}


def dispatch(root, tool, args):
    if tool == 'trace_import':
        trace = import_trace(rt.workspace_path(root, args['source'], existing=True), args['source'])
        write_new(rt.workspace_path(root, args['out']), trace)
        return {'trace': args['out'], 'kind': trace['kind'], 'entries': len(trace['entries']), 'warnings': trace['warnings']}
    trace = rt.read_json(rt.workspace_path(root, args['trace'], existing=True), 16 * rt.MAX_BYTES)
    verify_trace(root, trace)
    adapter = load_adapter(root, rt.workspace_path(root, args['adapter'], existing=True))
    if tool == 'trace_match':
        result = {'trace_source': trace['source'], 'matches': [{'entry_id': e['id'], 'candidates': matches(e, adapter), 'issues': e.get('issues', [])} for e in trace['entries']],
                  'network_executed': False, 'manual_http_binding_required': trace['kind'] == 'chrome-recorder'}
        write_new(rt.workspace_path(root, args['out']), result)
        return {'output': args['out'], 'matched_entries': sum(bool(m['candidates']) for m in result['matches'])}
    suite = rt.read_json(rt.workspace_path(root, args['suite'], existing=True))
    binding = rt.read_json(rt.workspace_path(root, args['binding'], existing=True))
    plan, report = build_plan(root, suite, adapter, trace, binding)
    target = rt.workspace_path(root, args['out'])
    target.mkdir(parents=True, exist_ok=False)
    write_new(target / 'plan.json', plan)
    write_new(target / 'trace-bindings.json', report)
    return {'plan': args['out'].replace('\\', '/').rstrip('/') + '/plan.json', **report}
