"""File-only orchestration over registered tools. No automatic replay."""
import contextlib
import contextvars
import os
import re
import threading
import uuid
from pathlib import Path
import http_runner as rt
import file_workflow as fw
import business_headers

ACTIVE=contextvars.ContextVar('workflow_managed_session',default=None)
ENV_LOCK=threading.Lock()
ACTIONS=('init','status','prepare','diagnose','execute','report')


def validate_spec(root,spec,managed=False):
    rt.shape(spec,['suite','adapter','plan'],['project_dir','credentials_file','execution_mode'],label='session spec')
    for key in ('suite','adapter','plan'):rt.workspace_path(root,spec[key],existing=True)
    enabled=spec.get('execution_mode')=='file_only'
    rt.need('execution_mode' not in spec or enabled,'Unknown session execution_mode')
    if managed or enabled:
        rt.need(enabled and all(k in spec for k in ('project_dir','credentials_file')),
                'Managed session requires execution_mode=file_only, project_dir and credentials_file','SESSION_REQUIRED')
        project=rt.workspace_path(root,spec['project_dir'])
        credentials=rt.workspace_path(root,spec['credentials_file'])
        rt.need(credentials!=project and project not in credentials.parents,'Keep credentials outside generated project artifacts')
        rt.need(credentials not in [rt.workspace_path(root,spec[k]) for k in ('suite','adapter','plan')],
                'Credentials must be a separate private file')
    return enabled


def guard(root,pref):
    binding=fw.read(root,'.workflow-runtime.json').get('sessions',{}).get(pref)
    if not binding:return
    state=ACTIVE.get()
    rt.need(state and state[:3]==(str(Path(root).resolve()),pref,binding),
            'Use the session-spec file entrypoint; direct execution is disabled for this project','SESSION_REQUIRED')
    rt.need(fw.sha(rt.workspace_path(root,binding,existing=True))==state[3],'Session spec changed during action','CONTEXT_STALE')


@contextlib.contextmanager
def credentials(root,ref,adapter,plan):
    """Read once, inject only required names, restore even on failure."""
    rt.need(ENV_LOCK.acquire(blocking=False),'Another credential scope is active','SESSION_BUSY')
    previous={}
    try:
        names=business_headers.env_names(adapter,plan)
        try:
            tokens=rt.read_json(rt.workspace_path(root,ref,existing=True),max_bytes=65536)
            rt.shape(tokens,['version','env'],label='credentials')
            rt.need(tokens['version']=='1.0' and isinstance(tokens['env'],dict),'Invalid credentials format')
            rt.need(names<=tokens['env'].keys(),'Missing credential name')
            values={name:tokens['env'][name] for name in names}
            for name,value in values.items():
                rt.need(re.fullmatch('[A-Za-z_][A-Za-z0-9_]*',name) and
                        name.upper() not in {'PATH','HOME','USERPROFILE','SYSTEMROOT','COMSPEC','TEMP','TMP','PATHEXT','CODEX_HOME'}
                        and not name.upper().startswith(('LD_','DYLD_','PYTHON','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY')),'Reserved environment name')
                rt.need(isinstance(value,str) and 1<=len(value)<=4096 and all(32<=ord(x)<=126 for x in value),'Invalid credential value')
        except (rt.ToolError,OSError,ValueError,TypeError):
            raise rt.ToolError('CREDENTIALS_INVALID','Check the local tokens file format and required names; values are never printed') from None
        for name,value in values.items():
            previous[name]=os.environ.get(name)
            os.environ[name]=value
        yield
    finally:
        for name,value in previous.items():
            if value is None:os.environ.pop(name,None)
            else:os.environ[name]=value
        ENV_LOCK.release()


def perform(root,spec_ref,action,case_id=None,attempt=None,retry_note=None):
    import toolchain as tc
    import freshness
    import capabilities
    root=Path(root).resolve()
    spec=fw.read(root,spec_ref)
    validate_spec(root,spec,managed=True)
    rt.need(action in ACTIONS,'Unknown session action')
    rt.need(action in ('prepare','diagnose','execute') or (case_id is None and attempt is None and retry_note is None),'Invalid case options for action')
    rt.need(attempt is None or action=='diagnose','Attempt selection is for diagnosis only')
    rt.need(retry_note is None or action=='prepare','retry_note is valid only for prepare')
    project=spec['project_dir'].replace('\\','/').rstrip('/')+'/project.json'
    call_dir='.session-calls/'+uuid.uuid4().hex
    logs=[]
    def call(tool,**arguments):
        req=fw.request(tool,**arguments)
        index=str(len(logs)+1).zfill(2)
        request_ref=call_dir+'/'+index+'.request.json'
        response_ref=call_dir+'/'+index+'.response.json'
        fw.write(rt.workspace_path(root,request_ref),req)
        try:response=tc.dispatch(root,req)
        except rt.ToolError as exc:
            fw.write(rt.workspace_path(root,response_ref),tc.envelope(tool,exc.code,getattr(exc,'details',None),str(exc)))
            raise
        fw.write(rt.workspace_path(root,response_ref),response)
        logs.append({'tool':tool,'request':request_ref,'response':response_ref,'code':response['code']})
        return response
    token=ACTIVE.set((str(root),project,spec_ref,fw.sha(rt.workspace_path(root,spec_ref,existing=True))))
    try:
        if action=='init':
            if not rt.workspace_path(root,project).exists():call('flow_init',spec=spec_ref,out=spec['project_dir'])
            p,d=fw.project(root,project)
            rt.need(p.get('session_spec') in (None,spec_ref) and p['suite']==spec['suite'] and p['adapter']==spec['adapter'],
                    'Existing project belongs to another session','SESSION_REQUIRED')
            original=fw.read(root,spec['plan'])
            rt.need(original['plan_id']==p['plan_id'] and original['adapter_id']==p['adapter_id'] and
                    {x['case_id'] for x in original['cases']}==set(p['cases']),'Session plan identity differs from project','SESSION_REQUIRED')
            if not p.get('session_spec'):
                for cid in p['cases']:
                    nums=fw.attempts(root,d,cid)
                    if nums:
                        rt.need(fw.evidence(root,d,cid,nums[-1])['status'] not in ('PREPARED','UNKNOWN','INCOMPLETE'),
                                'Finish, cancel or reconcile pending attempts before migration','ATTEMPT_BLOCKED')
                p['session_spec']=spec_ref
                fw.replace_text(rt.workspace_path(root,project),json_text(p))
            if not freshness.strict(root) or project not in fw.read(root,freshness.POLICY)['projects']:
                call('runtime_init',project=project,out=spec['project_dir']+'/runtime/session-init-'+uuid.uuid4().hex)
            else:
                import v5_common as common
                with common.lock(root,root,'init'):
                    policy=fw.read(root,freshness.POLICY)
                    rt.need(policy.get('sessions',{}).get(project) in (None,spec_ref),'Session policy already bound','SESSION_REQUIRED')
                    policy.setdefault('sessions',{})[project]=spec_ref
                    common.replace(root,freshness.POLICY,policy)
            result=call('flow_status',project=project)
        else:
            p,d=fw.project(root,project)
            rt.need(p.get('session_spec')==spec_ref and p['suite']==spec['suite'] and p['adapter']==spec['adapter'],
                    'Session/project binding changed','SESSION_REQUIRED')
            rt.need(freshness.strict(root) and fw.read(root,freshness.POLICY).get('sessions',{}).get(project)==spec_ref,
                    'Initialize the managed session first','SESSION_REQUIRED')
            if action=='status':result=call('flow_status',project=project)
            elif action=='report':result=call('flow_report',project=project,out=spec['project_dir']+'/reports/'+uuid.uuid4().hex+'.md')
            else:
                rt.need(case_id in p['cases'],'Specify one selected case_id')
                if action=='prepare':
                    refreshed=call('context_refresh',project=project,case_id=case_id,phase='prepare',out=spec['project_dir']+'/context/'+uuid.uuid4().hex)['data']
                    args=fw.read(root,refreshed['next_request'])['arguments']
                    if retry_note:args['retry_note']=retry_note
                    result=call('flow_prepare',**args)
                    diagnosis=call('flow_diagnose',project=project,case_id=case_id,out=spec['project_dir']+'/inspect/'+uuid.uuid4().hex+'.json')
                    result['data']['diagnosis']=diagnosis['data']['result']
                elif action=='diagnose':
                    args={'project':project,'case_id':case_id,'out':spec['project_dir']+'/inspect/'+uuid.uuid4().hex+'.json'}
                    if attempt:args['attempt']=attempt
                    result=call('flow_diagnose',**args)
                else:
                    nums=fw.attempts(root,d,case_id)
                    rt.need(nums,'Prepare case before execute','ATTEMPT_BLOCKED')
                    state=fw.evidence(root,d,case_id,nums[-1])
                    if state['status'] in ('PASS','FAIL','ERROR'):
                        result=call('flow_execute',project=project,case_id=case_id,attempt=nums[-1])
                    else:
                        rt.need(state['status']=='PREPARED','Uncertain/cancelled attempt cannot execute','ATTEMPT_BLOCKED')
                        call('flow_diagnose',project=project,case_id=case_id,out=spec['project_dir']+'/inspect/'+uuid.uuid4().hex+'.json')
                        refreshed=call('context_refresh',project=project,case_id=case_id,phase='execute',out=spec['project_dir']+'/context/'+uuid.uuid4().hex)['data']
                        args=fw.read(root,refreshed['next_request'])['arguments']
                        plan=fw.read(root,fw.rel(root,fw.attempt_dir(root,d,case_id,nums[-1])/'plan.json'))
                        adapter=capabilities.load_adapter(root,rt.workspace_path(root,p['adapter'],existing=True))
                        with credentials(root,spec['credentials_file'],adapter,plan):result=call('flow_execute',**args)
        result['data']['session_log']=call_dir+'/index.json'
        fw.write(rt.workspace_path(root,call_dir+'/index.json'),{'action':action,'calls':logs,'credentials_persisted':False})
        return result
    finally:ACTIVE.reset(token)


def json_text(value):
    import json
    return json.dumps(value,ensure_ascii=False,indent=2)+'\n'
