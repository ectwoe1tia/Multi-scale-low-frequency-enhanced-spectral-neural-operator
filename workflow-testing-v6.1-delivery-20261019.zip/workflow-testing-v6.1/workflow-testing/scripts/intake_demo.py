"""Reproducible local intake -> policy -> fresh HAR binding -> workflow execution demo."""
import argparse
import copy
import json
import os
import sys
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import capabilities as cap
import intake
import toolchain
from demo_support import DemoServer, make_assets

AUTH = {'WF_DEMO_APPLICANT': 'demo-applicant', 'WF_DEMO_MANAGER': 'demo-manager', 'WF_DEMO_DIRECTOR': 'demo-director'}


def word_file(path, rows, paragraphs=()):
    paragraph = lambda text: '<w:p><w:r><w:t xml:space="preserve">' + escape(text) + '</w:t></w:r></w:p>'
    table = '<w:tbl>' + ''.join('<w:tr>' + ''.join('<w:tc>' + paragraph(value) + '</w:tc>' for value in row) + '</w:tr>' for row in rows) + '</w:tbl>'
    xml = '<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + ''.join(paragraph(x) for x in paragraphs) + table + '</w:body></w:document>'
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        archive.writestr('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        archive.writestr('word/document.xml', xml)


def pdf_file(path, lines):
    """Small valid PDF fixture written without a PDF generation dependency."""
    def literal(value):
        return value.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')
    content = ('BT /F1 11 Tf 50 760 Td 14 TL ' + ' T* '.join('(' + literal(x) + ') Tj' for x in lines) + ' ET').encode('ascii')
    objects = [b'<< /Type /Catalog /Pages 2 0 R >>', b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
               b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
               b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>', b'<< /Length ' + str(len(content)).encode() + b' >>\nstream\n' + content + b'\nendstream']
    data, offsets = bytearray(b'%PDF-1.4\n'), [0]
    for i, obj in enumerate(objects, 1):
        offsets.append(len(data))
        data.extend(str(i).encode() + b' 0 obj\n' + obj + b'\nendobj\n')
    start = len(data)
    data.extend(b'xref\n0 6\n0000000000 65535 f \n')
    for offset in offsets[1:]:
        data.extend(('%010d 00000 n \n' % offset).encode())
    data.extend(('trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n' % start).encode())
    with Path(path).open('xb') as handle:
        handle.write(data)


def fixture_inputs(root, port):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    suite, adapter, plan = make_assets(port)
    api = '# 采购流程接口（示例 Apifox 导出布局）\n\n'
    for operation in adapter['operations'].values():
        api += '# ' + operation['method'] + ' ' + operation['path'] + '\n\n' + operation['method'] + ' ' + operation['path'] + '\n\n'
    api += '# DELETE 管理员清理\n\nDELETE /admin/instances/{instance_id}\n\n```shell\nPOST /examples/must-not-discover\n```\n'
    (root / 'apifox.md').write_text(api, encoding='utf-8')
    policy = {key: copy.deepcopy(value) for key, value in adapter.items() if key not in ('schema_version', 'operations')}
    policy.update({'policy_version': '1.0', 'allow': [
        {'methods': ['POST'], 'path_prefix': '/instances', 'actors': ['applicant'], 'request_guards': [{'target': 'body', 'pointer': '/tenant', 'op': 'eq', 'expected': 'qa'}]},
        {'methods': ['GET'], 'path_prefix': '/instances', 'actors': ['applicant', 'manager', 'director'], 'request_guards': []},
        {'methods': ['POST'], 'path_prefix': '/tasks', 'actors': ['applicant', 'manager', 'director'], 'request_guards': [{'target': 'body', 'pointer': '/decision', 'op': 'in', 'expected': ['approve']}]}],
        'deny': [{'methods': ['DELETE', 'POST', 'PUT', 'PATCH'], 'path_prefix': '/admin'}]})
    cap.write_new(root / 'policy.json', policy)
    headers = ['用例编号', '用例名称', '前置条件', '角色', '步骤', '预期结果', '分类', '优先级', '测试数据']
    rows = [headers]
    for case in suite['cases']:
        rows.append([case['id'], case['title'], '本地演示服务已启动', '\n'.join(case['actors']), case['steps'][0],
                     case['assertions'][0]['expected'], case['category'], case['priority'], json.dumps(case['data'])])
    word_file(root / 'cases.docx', rows)
    pdf_file(root / 'supplement.pdf', ['Title: Timeout scenario', 'Preconditions: Local test server running',
                                      'Actors: applicant', 'Steps: Wait for approval timeout', 'Expected: TBD'])
    historical, binding_cases = [], []
    for index, case in enumerate(plan['cases'], 1):
        bound = {'case_id': 'TC-IMP-%03d' % index, 'vars': case['vars'], 'steps': []}
        for step in case['steps']:
            operation = adapter['operations'][step['operation']]
            oldpath = re_sub_path(operation['path'])
            request = {'method': operation['method'], 'url': adapter['base_url'] + oldpath,
                       'headers': [{'name': 'Authorization', 'value': 'Bearer historical-token-do-not-copy'}], 'cookies': []}
            if step['body'] is not None:
                request['postData'] = {'mimeType': 'application/json', 'text': json.dumps({'historical': True, 'token': 'historical-body-token'})}
            historical.append({'request': request, 'response': {'status': 200, 'headers': [], 'content': {'text': 'old-observed-output'}}})
            mapped = {k: copy.deepcopy(step[k]) for k in ('actor', 'params', 'query', 'body', 'capture', 'checks')}
            mapped['entry_id'] = 'E%05d' % len(historical)
            if step['operation'] == 'create':
                mapped['body']['tenant'] = 'qa'
            bound['steps'].append(mapped)
        binding_cases.append(bound)
    cap.write_new(root / 'session.har', {'log': {'version': '1.2', 'creator': {'name': 'synthetic-demo', 'version': '1'}, 'entries': historical}})
    cap.write_new(root / 'binding.json', {'binding_version': '1.0', 'plan_id': 'intake-demo', 'cases': binding_cases})
    cap.write_new(root / 'recorder.json', {'title': '示例操作记录', 'steps': [{'type': 'navigate', 'url': adapter['base_url'] + '/app'},
        {'type': 'change', 'selectors': [['#amount']], 'value': '12000'}, {'type': 'click', 'selectors': [['#submit']]}]})
    return suite, adapter, plan


def re_sub_path(path):
    import re
    return re.sub(r'\{[^}]+\}', 'old-recorded-id', path)


def run_demo(root, run_id):
    root = Path(root).resolve()
    def call(tool, **arguments):
        request = {'protocol_version': '1.0', 'tool': tool, 'arguments': arguments}
        n = len(list((root / 'requests').glob('*.json'))) + 1
        cap.write_new(root / 'requests' / ('%02d-%s.json' % (n, tool)), request)
        response = toolchain.dispatch(root, request)
        cap.write_new(root / 'responses' / ('%02d-%s.json' % (n, tool)), response)
        if not response['ok']:
            raise RuntimeError(response['code'])
        return response['data']
    root.mkdir(parents=True, exist_ok=False)
    (root / 'requests').mkdir()
    previous = {key: os.environ.get(key) for key in AUTH}
    try:
        with DemoServer() as server:
            os.environ.update(AUTH)
            fixture_inputs(root / 'inputs', server.server_address[1])
            call('doctor')
            call('api_discover', source='inputs/apifox.md', out='catalog.json')
            call('adapter_build', catalog='catalog.json', policy='inputs/policy.json', out='adapter')
            call('document_import', source='inputs/cases.docx', out='word.json')
            call('document_import', source='inputs/supplement.pdf', out='pdf.json')
            cap.write_new(root / 'manifest.json', {'project': '文档和轨迹接入演示', 'platform': 'custom', 'documents': [
                {'document': 'word.json', 'role': 'test_cases'}, {'document': 'pdf.json', 'role': 'requirements'}]})
            call('cases_build', manifest='manifest.json', out='design')
            call('suite_validate', suite='design/suite.json')
            call('trace_import', source='inputs/session.har', out='trace.json')
            call('trace_import', source='inputs/recorder.json', out='recorder-trace.json')
            call('trace_match', trace='trace.json', adapter='adapter/adapter.json', out='matches.json')
            call('plan_from_trace', trace='trace.json', adapter='adapter/adapter.json', suite='design/suite.json', binding='inputs/binding.json', out='execution')
            arguments = {'suite': 'design/suite.json', 'adapter': 'adapter/adapter.json', 'plan': 'execution/plan.json'}
            preview = call('plan_preview', **arguments)
            result = call('run', **arguments, expected_fingerprint=preview['fingerprint'], run_id=run_id)
            call('report', run_id=run_id, out='execution-report.md')
            call('suite_render', suite='design/suite.json', out='design-report')
            result.update({'http_calls': len(server.calls), 'document_cases': 3, 'pending_cases': ['TC-IMP-003'], 'live_business_system_tested': False})
            cap.write_new(root / 'verification.json', result)
            return result
    finally:
        for key, old in previous.items():
            if old is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = old


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True)
    parser.add_argument('--run-id', default='INTAKE-DEMO')
    args = parser.parse_args()
    print(json.dumps(run_demo(args.out, args.run_id), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
