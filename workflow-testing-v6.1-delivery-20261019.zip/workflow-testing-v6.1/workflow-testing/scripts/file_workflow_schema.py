"""Named input schemas for editor completion; runtime also checks semantics."""
def schema():
    text = {'type': 'string', 'minLength': 1}
    def obj(properties, optional=()):
        return {'type': 'object', 'additionalProperties': False,
                'required': [x for x in properties if x not in optional], 'properties': properties}
    def record(fields):
        return obj({**{f: {'type': 'string', 'minLength': 1, 'maxLength': 1000} for f in fields},
                    'evidence': {'type': 'array', 'minItems': 1, 'maxItems': 10, 'items': text}})
    defs = {
        'FileReference': obj({'$file': text, 'pointer': {'type': 'string'}, 'format': {'enum': ['json', 'text']}}, ['pointer', 'format']),
        'SessionSpec': obj({**{k: text for k in ('suite', 'adapter', 'plan','project_dir','credentials_file')},
                            'execution_mode':{'const':'file_only'}},['project_dir','credentials_file','execution_mode']),
        'Note': record(['case_id', 'kind', 'summary', 'next_action']),
        'RetryNote': record(['case_id', 'previous_attempt', 'reason', 'change', 'side_effects', 'authorization']),
        'ReconcileRecord': record(['case_id', 'attempt', 'reason', 'side_effects', 'authorization', 'writer_stopped']),
    }
    defs['Note']['properties']['kind'] = {'enum': ['confirmed', 'hypothesis']}
    defs['ReconcileRecord']['properties']['writer_stopped'] = {'const': 'confirmed'}
    for name, field in [('RetryNote', 'previous_attempt'), ('ReconcileRecord', 'attempt')]:
        defs[name]['properties'][field] = {'type': 'string', 'pattern': '^(?!0000)[0-9]{4}$'}
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$defs': defs,
            'description': 'Use an individual $defs schema. Runtime validates file existence, fingerprints, guards and state.'}
