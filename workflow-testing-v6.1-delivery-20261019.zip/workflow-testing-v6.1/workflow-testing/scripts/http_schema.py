"""Editor contracts; runtime validates reference, auth and operation semantics too."""
def headers():
    return {'type':'object','maxProperties':32,'propertyNames':{'pattern':'^[A-Za-z][A-Za-z0-9-]{0,63}$'},
            'additionalProperties':{'oneOf':[{'type':'string','minLength':1,'maxLength':4096,'pattern':'^[ -~]+$'},
                {'type':'object','additionalProperties':False,'required':['env'],
                 'properties':{'env':{'type':'string','pattern':'^[A-Za-z_][A-Za-z0-9_]*$'}}}]}}


def schema():
    text={'type':'string','minLength':1}
    def obj(props,optional=()):
        return {'type':'object','additionalProperties':False,'properties':props,'required':[k for k in props if k not in optional]}
    def arr(item):return {'type':'array','items':item,'minItems':1}
    actor=obj({'bearer_token_env':{'type':'string','pattern':'^(?:[A-Za-z_][A-Za-z0-9_]*)?$'},'headers':headers()},['headers'])
    check=obj({'id':text,'pointer':text,'op':{'enum':['eq','ne','contains','exists','not_exists','gt','gte','lt','lte']},
               'expected':{},'assertion_id':text},['expected','assertion_id'])
    import intake_schema
    guard=intake_schema.schema()['$defs']['policy']['properties']['allow']['items']['properties']['request_guards']['items']
    op=obj({'method':{'enum':['GET','HEAD','POST','PUT','PATCH','DELETE']},'path':text,'actors':arr(text),
            'request_guards':{'type':'array','items':guard,'maxItems':100},'headers':headers()},['request_guards','headers'])
    step=obj({'id':text,'operation':text,'actor':text,'params':{'type':'object'},'query':{'type':'object'},'body':{},
              'capture':{'type':'object','additionalProperties':text},'checks':arr(check),'headers':headers(),
              'poll':obj({'attempts':{'type':'integer','minimum':1,'maximum':20},
                          'interval_seconds':{'type':'number','minimum':0.05,'maximum':5}})},['headers','poll'])
    env=obj({'name':text,'kind':{'enum':['local','test','uat']},'release':text})
    adapter=obj({'schema_version':{'const':'1.0'},'adapter_id':text,'platform':{'enum':['custom','flowable','lowcode']},
                 'base_url':text,'environment':env,'allow_mutations':{'type':'boolean'},
                 'timeout_seconds':{'type':'number','minimum':1,'maximum':30},
                 'max_duration_seconds':{'type':'number','minimum':1,'maximum':300},
                 'actors':{'type':'object','minProperties':1,'additionalProperties':actor},
                 'operations':{'type':'object','minProperties':1,'additionalProperties':op},'headers':headers(),
                 'idempotency_header':text,
                 'provenance':obj({'catalog':text,'catalog_sha256':text,'policy':text,'policy_sha256':text})},
                ['headers','idempotency_header','provenance'])
    case=obj({'case_id':text,'vars':{'type':'object'},'steps':arr(step),'headers':headers()},['headers'])
    plan=obj({'schema_version':{'const':'1.0'},'plan_id':text,'adapter_id':text,'cases':arr(case)})
    return {'$schema':'https://json-schema.org/draft/2020-12/schema',
            '$defs':{'Headers':headers(),'Actor':actor,'Adapter':adapter,'Step':step,'Case':case,'Plan':plan,
                     'Tokens':obj({'version':{'const':'1.0'},'env':{'type':'object','additionalProperties':text}})}}
