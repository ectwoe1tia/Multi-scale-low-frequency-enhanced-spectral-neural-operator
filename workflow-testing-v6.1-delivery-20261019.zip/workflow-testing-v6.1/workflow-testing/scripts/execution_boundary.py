"""Cooperating-code capability boundary; never an OS or hostile-code sandbox."""
from contextlib import contextmanager
from contextvars import ContextVar

_NETWORK = ContextVar('workflow_network_capability', default=None)


@contextmanager
def scope(network):
    # A nested call may narrow authority but cannot promote a static parent.
    parent = _NETWORK.get()
    token = _NETWORK.set(bool(network) and parent is not False)
    try:
        yield
    finally:
        _NETWORK.reset(token)


def check_transport():
    # Preserve legacy direct Python use. Registered calls always establish scope.
    if _NETWORK.get() is False:
        import http_runner
        raise http_runner.ToolError('EFFECT_DENIED', 'Static tool cannot enter HTTP execution or transport')
