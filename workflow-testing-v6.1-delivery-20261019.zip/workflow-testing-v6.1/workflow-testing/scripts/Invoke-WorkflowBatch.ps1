[CmdletBinding()]
param([string]$Batch,[string]$State='batch-state',[string]$Python='python')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$OutputEncoding=[Console]::OutputEncoding
try {
    if (-not $Batch) { [Console]::Out.WriteLine('{"ok":false,"code":"BATCH_REQUIRED"}'); exit 2 }
    $batchPath=(Resolve-Path -LiteralPath $Batch).Path
    $entry=Join-Path $PSScriptRoot 'batch_cli.py'
    $pythonCommand=Get-Command -Name $Python -CommandType Application -ErrorAction Stop | Select-Object -First 1
    $toolArguments=@('-X','utf8',$entry,'--batch',$batchPath,'--state',$State)
    & $pythonCommand.Source @toolArguments
    exit $LASTEXITCODE
} catch { [Console]::Out.WriteLine('{"ok":false,"code":"ENVIRONMENT_ERROR"}'); exit 12 }
