"""Bounded JSON/embedded-JSON front end and restricted expression AST. Never evaluates code."""
import ast
import hashlib
import json
import math
import re
import sqlite3
import http_runner as rt
import v5_common as common

MAX_FILE=32*rt.MAX_BYTES
MAX_NODES=200000
MAX_DEPTH=80
SYMBOL=r'^[A-Za-z_][A-Za-z0-9_.\[\]-]{0,199}$'


def symbol(value):return isinstance(value,str) and re.fullmatch(SYMBOL,value)


def fingerprint(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')).hexdigest()


def load(root,ref):
    try:
        return common.read(root,ref)
    except (UnicodeError,ValueError,RecursionError,rt.ToolError) as exc:
        if isinstance(exc,rt.ToolError) and exc.code=='STALE_INPUT':raise
        raise rt.ToolError('INVALID_SEMANTIC_INPUT','Invalid or oversized JSON input; inspect source locally') from None


def pointer(path):
    rt.need(isinstance(path,str) and len(path)<=2048 and (path=='' or path.startswith('/'))
            and not re.search(r'~(?![01])',path),'Invalid selector pointer')
    return [] if path=='' else [x.replace('~1','/').replace('~0','~') for x in path[1:].split('/')]


def matches(pattern,path):
    a,b=pointer(pattern),pointer(path)
    return len(a)==len(b) and all(x=='*' or x==y for x,y in zip(a,b))


def profile(value):
    rt.shape(value,['version','rules'],['embedded_json','templates'],label='semantic profile')
    rt.need(value['version']=='1.0' and isinstance(value['rules'],list) and len(value['rules'])<=128,'Invalid profile')
    for name in ('embedded_json','templates'):
        rt.need(type(value.get(name,False)) is bool,'Profile flags must be boolean')
    for rule in value['rules']:
        rt.shape(rule,['file','select','kind'],['namespace','prefix','dialect','type','min','max','enum'],label='semantic rule')
        rt.need(rule['file']=='*' or symbol(rule['file']),'Invalid file selector')
        pointer(rule['select'])
        rt.need(rule['kind'] in ('define','reference','expression','expect'),'Unknown semantic rule')
        if rule['kind'] in ('define','reference','expression'):
            rt.need(symbol(rule.get('namespace')),'Namespace required')
        rt.need(isinstance(rule.get('prefix',''),str) and len(rule.get('prefix',''))<=100,'Invalid symbol prefix')
        if rule['kind']=='expression':rt.need(rule.get('dialect')=='python_subset','Only explicit python_subset supported; other code remains opaque')
        if rule['kind']=='expect':
            rt.need(rule.get('type') in ('string','number','boolean','object','array','null'),'Expected type required')
            for key in ('min','max'):
                if key in rule:rt.need(type(rule[key]) in (int,float) and math.isfinite(rule[key]),'Invalid bound')
            rt.need('min' not in rule or 'max' not in rule or rule['min']<=rule['max'],'Reversed range')
            if 'enum' in rule:rt.need(isinstance(rule['enum'],list) and len(rule['enum'])<=100,'Enum limit')
    return value


def expression(text):
    """Returns symbol reads + node kinds, with constants omitted from persisted AST."""
    rt.need(isinstance(text,str) and len(text)<=4096,'Expression size limit','OPAQUE_EXPRESSION')
    try:tree=ast.parse(text,mode='eval')
    except (SyntaxError,ValueError,RecursionError):raise rt.ToolError('OPAQUE_EXPRESSION','Unsupported expression') from None
    nodes=list(ast.walk(tree))
    allowed=(ast.Expression,ast.BoolOp,ast.BinOp,ast.UnaryOp,ast.Compare,ast.IfExp,ast.Name,ast.Attribute,
             ast.Subscript,ast.Constant,ast.Load,ast.And,ast.Or,ast.Not,ast.Add,ast.Sub,ast.Mult,ast.Div,
             ast.Mod,ast.USub,ast.UAdd,ast.Eq,ast.NotEq,ast.Lt,ast.LtE,ast.Gt,ast.GtE,ast.In,ast.NotIn,
             ast.List,ast.Tuple)
    rt.need(len(nodes)<=256 and all(isinstance(n,allowed) for n in nodes),'Expression syntax not in restricted subset','OPAQUE_EXPRESSION')
    rt.need(all(not isinstance(n,ast.Constant) or type(n.value) in (str,int,float,bool,type(None))
                and (type(n.value) is not float or math.isfinite(n.value)) for n in nodes),'Unsupported literal','OPAQUE_EXPRESSION')
    def name(n):
        if isinstance(n,ast.Name):return n.id
        if isinstance(n,ast.Attribute):return name(n.value)+'.'+n.attr
        if isinstance(n,ast.Subscript) and isinstance(n.slice,ast.Constant) and type(n.slice.value) in (str,int):
            return name(n.value)+(('.'+n.slice.value) if isinstance(n.slice.value,str) else '['+str(n.slice.value)+']')
        raise rt.ToolError('OPAQUE_EXPRESSION','Dynamic or computed access remains opaque')
    reads=set()
    def visit(n):
        if isinstance(n,(ast.Name,ast.Attribute,ast.Subscript)):
            value=name(n)
            rt.need(symbol(value) and '__' not in value,'Unsupported member path','OPAQUE_EXPRESSION')
            reads.add(value);return
        for child in ast.iter_child_nodes(n):visit(child)
    visit(tree)
    def ir(n):
        result={'kind':type(n).__name__}
        if isinstance(n,ast.Constant):
            result.update(literal_type=type(n.value).__name__,literal_hash=fingerprint(n.value));return result
        if isinstance(n,(ast.Name,ast.Attribute,ast.Subscript)):
            result['symbol_hash']=fingerprint(name(n));return result
        for field,value in ast.iter_fields(n):
            if isinstance(value,ast.AST):result[field]=ir(value)
            elif isinstance(value,list):result[field]=[ir(x) for x in value if isinstance(x,ast.AST)]
        return result
    return sorted(reads),ir(tree)


def connect(path,create=False):
    db=sqlite3.connect(str(path) if create else path.as_uri()+'?mode=ro',uri=not create)
    db.row_factory=sqlite3.Row
    if create:
        db.executescript('''
        CREATE TABLE nodes(id TEXT PRIMARY KEY,file TEXT,pointer TEXT,kind TEXT,size INTEGER,value_hash TEXT,ast TEXT);
        CREATE TABLE edges(id TEXT PRIMARY KEY,src TEXT,dst TEXT,kind TEXT,status TEXT,basis TEXT);
        CREATE TABLE symbols(namespace TEXT,symbol TEXT,node TEXT,role TEXT);
        CREATE TABLE issues(id TEXT PRIMARY KEY,node TEXT,code TEXT,severity TEXT);
        CREATE INDEX node_location ON nodes(file,pointer);
        CREATE INDEX value_lookup ON nodes(value_hash,kind);
        CREATE INDEX incoming ON edges(dst,kind);
        CREATE INDEX outgoing ON edges(src,kind);
        CREATE INDEX symbol_lookup ON symbols(namespace,symbol,role);
        CREATE INDEX issue_code ON issues(code);
        ''')
    return db


def issue(db,node,code,severity='warning'):
    db.execute('INSERT OR IGNORE INTO issues VALUES(?,?,?,?)',(fingerprint([node,code]),node,code,severity))


def edge(db,src,dst,kind,status='derived',basis='syntax'):
    eid=fingerprint([src,dst,kind,status,basis])
    db.execute('INSERT OR IGNORE INTO edges VALUES(?,?,?,?,?,?)',(eid,src,dst,kind,status,basis))
    return eid


def kind(value):
    if value is None:return 'null'
    if type(value) is bool:return 'boolean'
    if isinstance(value,dict):return 'object'
    if isinstance(value,list):return 'array'
    if isinstance(value,str):return 'string'
    return 'number'


def collect(root,ref):
    """Composable file sets, explicit source IDs, paths relative to workspace."""
    inputs={};files={};seen_paths=set();active=set();done=set()
    def walk(current,depth):
        rt.need(depth<=12 and len(done)+len(active)<128,'File-set include budget exceeded')
        rt.need(current not in active,'File-set include cycle')
        if current in done:return
        active.add(current);data=load(root,current);inputs[current]=common.hash_file(root,current)
        rt.shape(data,['version','files'],['includes'],label='file set')
        rt.need(data['version']=='1.0' and isinstance(data['files'],list),'Invalid file set')
        rt.need(isinstance(data.get('includes',[]),list) and len(data.get('includes',[]))<=64,'Include budget')
        for inc in data.get('includes',[]):walk(inc,depth+1)
        for item in data['files']:
            rt.shape(item,['id','path','kind'],label='source file')
            rt.ident(item['id'],'file id')
            rt.need(item['kind'] in ('json','har','recorder'),'Unsupported source kind')
            resolved=rt.workspace_path(root,item['path'],existing=True)
            rt.need(item['id'] not in files and resolved not in seen_paths,'Duplicate source id/path')
            rt.need(resolved.stat().st_size<=MAX_FILE,'Source exceeds 32 MiB','BUDGET_EXCEEDED')
            rt.need(not re.search(r'(^|[/\\])(tokens|credentials)(\.|[/\\])',item['path'],re.I),'Credential files are not semantic sources')
            files[item['id']]=item;seen_paths.add(resolved)
            rt.need(len(files)<=256,'File count budget exceeded')
        active.remove(current);done.add(current)
    walk(ref,0)
    rt.need(files,'File set is empty')
    rt.need(sum(rt.workspace_path(root,x['path'],True).stat().st_size for x in files.values())<=256*rt.MAX_BYTES,'File set exceeds 256 MiB','BUDGET_EXCEEDED')
    for item in files.values():inputs[item['path']]=common.remember(root,item['path'])
    return files,inputs


def extract(root,item,config,db):
    data=load(root,item['path']);fid=item['id'];count=0;hit=[0]*len(config['rules'])
    if item['kind']=='har':rt.need(isinstance(data,dict) and isinstance(data.get('log',{}).get('entries'),list),'Invalid HAR')
    if item['kind']=='recorder':rt.need(isinstance(data,dict) and isinstance(data.get('steps'),list),'Invalid Recorder')
    stack=[('',data,None,False,0)]
    while stack:
        ptr,value,parent,hidden,depth=stack.pop();count+=1
        rt.need(count<=MAX_NODES and depth<=MAX_DEPTH,'JSON node/depth budget exceeded','BUDGET_EXCEEDED')
        rt.need(len(ptr)<=2048,'Pointer budget exceeded','BUDGET_EXCEEDED')
        nid=fingerprint([fid,ptr]);k=kind(value)
        hidden=hidden or bool(rt.SECRET_KEYS.search(ptr))
        if isinstance(value,dict) and isinstance(value.get('name'),str) and rt.SECRET_KEYS.search(value['name']):hidden=True
        size=len(value) if k in ('string','array','object') else 1
        vh=fingerprint(value) if not hidden and k not in ('array','object') else None
        db.execute('INSERT INTO nodes VALUES(?,?,?,?,?,?,?)',(nid,fid,ptr,'redacted' if hidden else k,size,vh,None))
        if parent:edge(db,parent,nid,'contains')
        if hidden:continue
        if item['kind']=='har' and isinstance(value,dict) and value.get('encoding')=='base64':
            issue(db,nid,'ENCODED_BODY_UNSUPPORTED')
        if isinstance(value,str):
            if '\ufffd' in value:issue(db,nid,'REPLACEMENT_CHARACTER','error')
            if any(0xD800<=ord(x)<=0xDFFF for x in value):issue(db,nid,'UNPAIRED_SURROGATE','error')
            if any(ord(x)<32 and x not in '\n\r\t' for x in value):issue(db,nid,'CONTROL_CHARACTER','error')
            if any(x in value for x in ('Ã','Â','â€','锟斤拷')):issue(db,nid,'POSSIBLE_MOJIBAKE')
        for i,rule in enumerate(config['rules']):
            if rule['file'] not in ('*',fid) or not matches(rule['select'],ptr):continue
            hit[i]+=1;rkind=rule['kind']
            if rkind=='expect':
                if k!=rule['type']:issue(db,nid,'TYPE_MISMATCH','error')
                if k=='number' and (('min' in rule and value<rule['min']) or ('max' in rule and value>rule['max'])):issue(db,nid,'OUT_OF_RANGE','error')
                if 'enum' in rule and not any(type(value) is type(x) and value==x for x in rule['enum']):issue(db,nid,'OUTSIDE_ENUM','error')
                continue
            if rkind=='expression':
                try:
                    reads,syntax=expression(value)
                    db.execute('UPDATE nodes SET ast=? WHERE id=?',(json.dumps(syntax),nid))
                except rt.ToolError:issue(db,nid,'OPAQUE_EXPRESSION');continue
            else:
                if not isinstance(value,str) or not symbol(rule.get('prefix','')+value):
                    issue(db,nid,'INVALID_SYMBOL','error');continue
                reads=[rule.get('prefix','')+value]
            for name in reads:
                db.execute('INSERT INTO symbols VALUES(?,?,?,?)',(rule['namespace'],fingerprint(name),nid,'define' if rkind=='define' else 'read'))
        if count%1000==0:
            rt.need(db.execute('SELECT COUNT(*) FROM symbols').fetchone()[0]<=500000,'Symbol budget exceeded','BUDGET_EXCEEDED')
        if isinstance(value,(dict,list)):
            entries=list(value.items()) if isinstance(value,dict) else list(enumerate(value))
            for key,child in reversed(entries):
                part=str(key).replace('~','~0').replace('/','~1')
                if any(0xD800<=ord(x)<=0xDFFF for x in part):raise rt.ToolError('INVALID_SEMANTIC_INPUT','Invalid surrogate in key')
                child_id=fingerprint([fid,ptr+'/'+part])
                if '\ufffd' in part:issue(db,child_id,'REPLACEMENT_IN_KEY','error')
                if any(ord(x)<32 for x in part):issue(db,child_id,'CONTROL_IN_KEY','error')
                if any(x in part for x in ('\u202e','\u202d','\u2066','\u2067','\u2068','\u2069')):issue(db,child_id,'BIDI_CONTROL_IN_KEY')
                stack.append((ptr+'/'+part,child,nid,False,depth+1))
        elif isinstance(value,str):
            if config.get('embedded_json') and value.lstrip().startswith(('{','[')):
                try:
                    def pairs(items):
                        result={}
                        for key,v in items:
                            if key in result:raise ValueError()
                            result[key]=v
                        return result
                    embedded=json.loads(value,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
                    stack.append((ptr+'/$json',embedded,nid,False,depth+1))
                except (ValueError,RecursionError):issue(db,nid,'INVALID_EMBEDDED_JSON','error')
            if config.get('templates'):
                for token in re.findall(r'\$\{([^{}]{1,4096})\}',value[:65536]):
                    if symbol(token):db.execute('INSERT INTO symbols VALUES(?,?,?,?)',('template',fingerprint(token),nid,'read'))
                    else:issue(db,nid,'OPAQUE_TEMPLATE')
                if len(value)>65536 and '${' in value:issue(db,nid,'TEMPLATE_SCAN_TRUNCATED')
    return hit


def link(db):
    for row in db.execute("SELECT DISTINCT namespace,symbol,node FROM symbols WHERE role='read'").fetchall():
        targets=[r[0] for r in db.execute("SELECT DISTINCT node FROM symbols WHERE namespace=? AND symbol=? AND role='define'",(row['namespace'],row['symbol']))]
        if len(targets)==1:edge(db,row['node'],targets[0],'reads_from',basis='declared_profile')
        else:issue(db,row['node'],'UNRESOLVED_SYMBOL' if not targets else 'AMBIGUOUS_SYMBOL')
    for row in db.execute("SELECT namespace,symbol FROM symbols WHERE role='define' GROUP BY namespace,symbol HAVING COUNT(DISTINCT node)>1").fetchall():
        for n in db.execute("SELECT node FROM symbols WHERE namespace=? AND symbol=? AND role='define'",tuple(row)):
            issue(db,n[0],'DUPLICATE_DEFINITION','error')
