"""Reproducible loopback-only volume/resume experiment; never accepts a remote URL."""
import argparse
import copy
import json
import os
import subprocess
import sys
from pathlib import Path

from demo_support import DemoServer, make_assets
from file_workflow import request


def run_demo(out):
    out.mkdir(parents=True, exist_ok=False)
    receipts = []

    def save(ref, value):
        path = out / ref
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

    def call(label, tool, **args):
        req = 'calls/' + label + '.request.json'
        resp = 'calls/' + label + '.response.json'
        save(req, request(tool, **args))
        result = subprocess.run([sys.executable, '-X', 'utf8', str(Path(__file__).with_name('toolchain.py')),
                                 '--workspace', str(out), '--request', str(out / req),
                                 '--response-file', resp, '--brief'], capture_output=True, encoding='utf-8', env=env, timeout=60)
        (out / ('calls/' + label + '.stdout.json')).write_text(result.stdout, encoding='utf-8')
        (out / ('calls/' + label + '.stderr.txt')).write_text(result.stderr, encoding='utf-8')
        receipts.append({'label': label, 'exit_code': result.returncode, 'stdout_bytes': len(result.stdout.encode('utf-8')), 'request': req, 'response': resp})
        if result.returncode:
            raise RuntimeError('Demo command failed; inspect ' + str(out / resp))
        return json.loads((out / resp).read_text(encoding='utf-8'))['data']

    env = dict(os.environ, WF_DEMO_APPLICANT='demo-applicant', WF_DEMO_MANAGER='demo-manager', WF_DEMO_DIRECTOR='demo-director')
    with DemoServer() as server:
        suite, adapter, plan = make_assets(server.server_port)
        original_suite, original_plan = copy.deepcopy(suite['cases']), copy.deepcopy(plan['cases'])
        suite['cases'], plan['cases'] = [], []
        (out / 'large-text.txt').write_text('DEMO-PAYLOAD-' + 'x' * 131072, encoding='utf-8')
        save('body.json', {'amount': '${amount}', 'padding': {'$file': 'large-text.txt', 'format': 'text'}})
        for n in range(30):
            cid = f'TC-VOLUME-{n + 1:03}'
            case = copy.deepcopy(original_suite[n % 2])
            step = copy.deepcopy(original_plan[n % 2])
            case['id'], step['case_id'] = cid, cid
            step['steps'][0]['body'] = {'$file': 'body.json'}
            suite['cases'].append(case)
            plan['cases'].append(step)
        save('suite.json', suite)
        save('adapter.json', adapter)
        save('plan.json', plan)
        save('session.json', {'suite': 'suite.json', 'adapter': 'adapter.json', 'plan': 'plan.json'})
        call('doctor', 'doctor')
        call('init', 'flow_init', spec='session.json', out='project')
        for n, case in enumerate(plan['cases']):
            cid = case['case_id']
            call(f'{n + 1:02}-prepare', 'flow_prepare', project='project/project.json', case_id=cid)
            call(f'{n + 1:02}-execute', 'flow_execute', project='project/project.json', case_id=cid, attempt='0001')
            if n == 14:
                halfway = call('resume-fresh-process', 'flow_status', project='project/project.json')
                assert halfway['counts'] == {'PASS': 15, 'TODO': 15}, halfway
                save('halfway-checkpoint.json', json.loads((out / 'project/NEXT.json').read_text(encoding='utf-8')))
        before = len(server.calls)
        repeat = call('duplicate', 'flow_execute', project='project/project.json', case_id='TC-VOLUME-001', attempt='0001')
        assert repeat['reused_evidence'] and len(server.calls) == before
        final = call('final-status', 'flow_status', project='project/project.json')
        assert final['counts'] == {'PASS': 30}, final
        call('report', 'flow_report', project='project/project.json', out='session-report.md')
        expanded_bytes = sum(p.stat().st_size for p in (out / 'project/attempts').rglob('plan.json'))
        evidence_bytes = sum(p.stat().st_size for p in (out / 'runs').rglob('results.json'))
        metrics = {'case_count': 30, 'http_calls': len(server.calls), 'expected_http_calls': 105,
                   'duplicate_additional_http_calls': len(server.calls) - before,
                   'all_selected_passed': True, 'fresh_process_calls': len(receipts),
                   'expanded_plan_bytes': expanded_bytes, 'result_evidence_bytes': evidence_bytes,
                   'receipt_stdout_bytes': sum(r['stdout_bytes'] for r in receipts),
                   'max_receipt_stdout_bytes': max(r['stdout_bytes'] for r in receipts),
                   'next_context_bytes': (out / 'project/NEXT.json').stat().st_size,
                   'note': 'Observed filesystem/stdout bytes, not token billing or model retention measurement. Loopback demo only.'}
        assert metrics['http_calls'] == 105
        save('commands.json', receipts)
        save('metrics.json', metrics)
        save('http-calls.json', server.calls)
        return metrics


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    print(json.dumps(run_demo(Path(args.out).resolve()), ensure_ascii=False))
