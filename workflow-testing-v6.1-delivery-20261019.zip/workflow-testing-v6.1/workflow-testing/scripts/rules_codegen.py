"""Finite JSON DSL compiled to immutable project data. No eval or generated imports."""
import copy
import http_runner as rt
import v5_common as c

UNKNOWN=object()
COMPARE={'eq','ne','gt','ge','lt','le','in'}

def typed_equal(a,b):
    if type(a)!=type(b) and not (type(a) in (int,float) and type(b) in (int,float)):return False
    if isinstance(a,list):return len(a)==len(b) and all(typed_equal(x,y) for x,y in zip(a,b))
    if isinstance(a,dict):return set(a)==set(b) and all(typed_equal(a[k],b[k]) for k in a)
    return a==b

def expression(expr,depth=0):
    rt.need(depth<=24 and isinstance(expr,dict),'Invalid/deep DSL expression')
    if 'literal' in expr:
        rt.shape(expr,['literal'],label='literal')
        rt.need(expr['literal'] is None or type(expr['literal']) in (bool,int,float,str,list),'Unsupported literal')
        rt.need(not isinstance(expr['literal'],str) or len(expr['literal'])<=4096,'Literal too long')
        return
    if 'case_var' in expr:
        rt.shape(expr,['case_var'],label='case variable'); rt.ident(expr['case_var'],'case variable'); return
    if 'step_pointer' in expr:
        rt.shape(expr,['step_pointer'],label='step pointer')
        rt.need(isinstance(expr['step_pointer'],str) and expr['step_pointer'].startswith('/'),'Invalid step pointer'); return
    op=expr.get('op')
    if op in COMPARE:
        rt.shape(expr,['op','left','right'],label='comparison')
        expression(expr['left'],depth+1); expression(expr['right'],depth+1)
    elif op in ('and','or'):
        rt.shape(expr,['op','args'],label='boolean')
        rt.need(isinstance(expr['args'],list) and 1<=len(expr['args'])<=32,'Boolean args limit')
        for x in expr['args']: expression(x,depth+1)
    elif op=='type_is':
        rt.shape(expr,['op','arg','type'],label='type check')
        rt.need(expr['type'] in ('number','string','boolean','array','object','null'),'Unknown DSL type')
        expression(expr['arg'],depth+1)
    elif op in ('not','exists'):
        rt.shape(expr,['op','arg'],label='unary'); expression(expr['arg'],depth+1)
    else:
        raise rt.ToolError('INVALID_DSL','Unknown DSL operator; function calls and scripts are prohibited')

def evaluate(expr,variables,step=None):
    if 'literal' in expr: return expr['literal']
    if 'case_var' in expr: return variables.get(expr['case_var'],UNKNOWN)
    if 'step_pointer' in expr:
        value=rt.json_pointer(step or {},expr['step_pointer'])
        return UNKNOWN if value is rt.MISSING or isinstance(value,str) and rt.refs(value) else value
    op=expr['op']
    if op=='type_is':
        x=evaluate(expr['arg'],variables,step)
        if x is UNKNOWN:return UNKNOWN
        types={'number':(int,float),'string':(str,),'boolean':(bool,),'array':(list,),'object':(dict,),'null':(type(None),)}
        return type(x) in types[expr['type']]
    if op=='exists': return evaluate(expr['arg'],variables,step) is not UNKNOWN
    if op=='not':
        x=evaluate(expr['arg'],variables,step)
        rt.need(x is UNKNOWN or type(x) is bool,'Boolean type mismatch','RULE_TYPE_ERROR')
        return UNKNOWN if x is UNKNOWN else not x
    if op in ('and','or'):
        xs=[evaluate(x,variables,step) for x in expr['args']]
        rt.need(all(x is UNKNOWN or type(x) is bool for x in xs),'Boolean type mismatch','RULE_TYPE_ERROR')
        if op=='and': return False if any(x is False for x in xs) else UNKNOWN if UNKNOWN in xs else True
        return True if any(x is True for x in xs) else UNKNOWN if UNKNOWN in xs else False
    a,b=evaluate(expr['left'],variables,step),evaluate(expr['right'],variables,step)
    if a is UNKNOWN or b is UNKNOWN: return UNKNOWN
    if op=='in':
        rt.need(isinstance(b,list),'in requires array','RULE_TYPE_ERROR')
        return any(typed_equal(a,x) for x in b)
    rt.need(type(a)==type(b) or type(a) in (int,float) and type(b) in (int,float),'Comparison type mismatch','RULE_TYPE_ERROR')
    if op in ('gt','ge','lt','le'):
        rt.need(type(a) in (int,float) and type(b) in (int,float),'Ordered comparisons require numbers','RULE_TYPE_ERROR')
    return {'eq':lambda:typed_equal(a,b),'ne':lambda:not typed_equal(a,b),'gt':lambda:a>b,'ge':lambda:a>=b,'lt':lambda:a<b,'le':lambda:a<=b}[op]()

def validate_rule(root,r):
    rt.shape(r,['dsl_version','id','kind','scope','when','require','status','source_refs'],label='rule')
    rt.ident(r['id'],'rule id')
    rt.need(r['dsl_version']=='1.0' and r['kind'] in ('constraint','coverage_obligation'),'Unsupported rule version/kind')
    rt.shape(r['scope'],[],['case_ids','operations','process_key','definition_ref'],label='scope')
    if r['kind']=='constraint':
        rt.need(not set(r['scope']).intersection({'process_key','definition_ref'}),'Constraints use case_ids/operations scope; process scope belongs to coverage rules')
    for key in ('case_ids','operations'):
        if key in r['scope']:
            rt.need(isinstance(r['scope'][key],list) and all(isinstance(x,str) for x in r['scope'][key]),'Invalid scope list')
    rt.need(r['status'] in ('confirmed','candidate'),'Invalid rule status')
    rt.need(isinstance(r['source_refs'],list) and 1<=len(r['source_refs'])<=20,'Rule requires source evidence')
    for ref in r['source_refs']: c.hash_file(root,ref)
    expression(r['when'])
    static_when=evaluate(r['when'],{})
    rt.need(static_when is UNKNOWN or type(static_when) is bool,'when must evaluate to boolean','INVALID_DSL')
    if r['kind']=='constraint':
        expression(r['require'])
        static_required=evaluate(r['require'],{})
        rt.need(static_required is UNKNOWN or type(static_required) is bool,'require must evaluate to boolean','INVALID_DSL')
    else:
        rt.shape(r['require'],['activities_in_order'],['edges_in_order'],label='coverage requirement')
        rt.need(isinstance(r['require']['activities_in_order'],list) and 1<=len(r['require']['activities_in_order'])<=100 and
                all(isinstance(x,str) and x for x in r['require']['activities_in_order']),'Invalid activity requirement')
        rt.need(isinstance(r['require'].get('edges_in_order',[]),list) and all(isinstance(x,str) and x for x in r['require'].get('edges_in_order',[])),'Invalid required edges')

def generate(root,args):
    project,_=c.project(root,args['project'])
    from capabilities import load_adapter
    adapter=load_adapter(root,rt.workspace_path(root,project['adapter'],existing=True))
    spec=c.read(root,args['spec'])
    rt.shape(spec,['rules'],['activate'],label='rule generation spec')
    rt.need(type(spec.get('activate',False)) is bool,'activate must be boolean')
    rt.need(isinstance(spec['rules'],list) and 1<=len(spec['rules'])<=500,'Expected 1..500 rule files')
    rules=[c.read(root,ref) for ref in spec['rules']]
    rt.need(len({r.get('id') for r in rules})==len(rules),'Duplicate rule IDs')
    inputs=[args['spec'],args['project'],project['adapter']]+spec['rules']
    for r in rules:
        validate_rule(root,r); inputs+=r['source_refs']
        rt.need(set(r['scope'].get('case_ids',[]))<=set(project['cases']),'Rule scope contains unknown case','CAPABILITY_MISMATCH')
        rt.need(set(r['scope'].get('operations',[]))<=set(adapter['operations']),'Rule scope contains unregistered operation','CAPABILITY_MISMATCH')
        if 'definition_ref' in r['scope']: inputs.append(r['scope']['definition_ref'])
    if spec.get('activate'):
        rt.need(all(r['status']=='confirmed' for r in rules),'Candidates cannot be activated','UNCONFIRMED_RULE')
    # Detect structurally contradictory requirements sharing the same condition/scope.
    pairs={}
    for r in rules:
        key=rt.digest({'kind':r['kind'],'scope':r['scope'],'when':r['when']})
        prior=pairs.get(key,[])
        if r['kind']=='constraint':
            new=r['require']
            for old in prior:
                incompatible=('literal' in old and 'literal' in new and type(old['literal']) is bool and type(new['literal']) is bool and old['literal']!=new['literal'])
                incompatible=incompatible or (old.get('op')==new.get('op')=='eq' and old['left']==new['left'] and
                    'literal' in old['right'] and 'literal' in new['right'] and old['right']!=new['right'])
                rt.need(not incompatible,'Conflicting constant/equality requirements','RULE_CONFLICT')
        pairs.setdefault(key,[]).append(r['require'])
    ir={'dsl_version':'1.0','rules':rules,'semantic_hash':rt.digest(rules)}
    descriptors=[{'descriptor_version':'1.0','id':r['id'],'kind':'rule_evaluate','rule_id':r['id'],
                  'input_schema':{'type':'object','required':['vars'],'additionalProperties':False,
                                  'properties':{'vars':{'type':'object'},'step':{'type':'object'}}},
                  'network':False,'source_refs':r['source_refs']} for r in rules]
    products={'rules.ir.json':ir,'rules.index.json':[
        {'id':r['id'],'kind':r['kind'],'status':r['status'],'scope':r['scope']} for r in rules],
        'tools.json':descriptors,'diagnostics.json':{'candidate_ids':[r['id'] for r in rules if r['status']=='candidate'],
                                                 'conflict_detection':'Constant/equality contradictions only; other constraints accumulate. No general theorem prover.'}}
    for descriptor in descriptors:
        products['tool-'+descriptor['id']+'.json']=descriptor
        products['invoke-'+descriptor['id']+'.request.json']={'protocol_version':rt.PROTOCOL,'tool':'project_tool_invoke',
            'arguments':{'project':args['project'],'tool_ref':args['out']+'/tool-'+descriptor['id']+'.json',
                         'input_ref':'inputs/'+descriptor['id']+'.json','out':'replies/'+descriptor['id']+'.json'}}
    result=c.publish(root,args['project'],'rules',args['out'],products,inputs)
    if spec.get('activate'):
        _,d=c.project(root,args['project'])
        c.replace(root,c.relative(root,d/'runtime/active-rules.json'),{'manifest':result['manifest'],
                  'manifest_hash':c.hash_file(root,result['manifest']),'semantic_hash':ir['semantic_hash']})
    return {**result,'rule_count':len(rules),'activated':spec.get('activate',False)}

def active(root,pref):
    _,d=c.project(root,pref)
    ref=c.relative(root,d/'runtime/active-rules.json')
    if not rt.workspace_path(root,ref).exists(): return []
    pointer=c.read(root,ref)
    rt.need(c.hash_file(root,pointer['manifest'])==pointer['manifest_hash'],'Active rules manifest changed','EVIDENCE_CHANGED')
    m=c.read(root,pointer['manifest'])
    rt.need(m['project']==pref and m['kind']=='rules' and m['generator_version']==rt.VERSION and m.get('generator_digest')==c.generator_digest(),'Active rules identity/version/code changed','STALE_RULES')
    for ref,h in m['inputs'].items(): rt.need(c.hash_file(root,ref)==h,'Recompile changed rule inputs','STALE_RULES')
    base=pointer['manifest'].rsplit('/',1)[0]
    for name,h in m['products'].items(): rt.need(c.hash_file(root,base+'/'+name)==h,'Rules output modified','EVIDENCE_CHANGED')
    ir=c.read(root,base+'/rules.ir.json')
    rt.need(ir['semantic_hash']==pointer['semantic_hash'],'Active rule semantic mismatch','EVIDENCE_CHANGED')
    return ir['rules']

def applies(r,cid,operation=None):
    scope=r['scope']
    return (not scope.get('case_ids') or cid in scope['case_ids']) and (operation is None or not scope.get('operations') or operation in scope['operations'])

def enforce(root,pref,plan,actual_step=None,actual_vars=None,case_id=None):
    for case in plan['cases']:
        if case_id and case['case_id']!=case_id: continue
        for step in ([actual_step] if actual_step else case['steps']):
            variables=actual_vars if actual_vars is not None else case['vars']
            for r in active(root,pref):
                if r['kind']!='constraint' or not applies(r,case['case_id'],step['operation']): continue
                when=evaluate(r['when'],variables,step)
                required=evaluate(r['require'],variables,step) if when is True else True
                if actual_step is None and ('step_pointer' in str(r['when']) or 'step_pointer' in str(r['require'])) and (when is UNKNOWN or required is UNKNOWN):
                    continue  # Concrete runtime/capture values checked again before transport.
                rt.need(when is not UNKNOWN and type(when) is bool,'Rule condition unresolved: '+r['id'],'RULE_UNRESOLVED')
                rt.need(required is not UNKNOWN and type(required) is bool,'Rule requirement unresolved: '+r['id'],'RULE_UNRESOLVED')
                rt.need(required,'Rule violated: '+r['id'],'RULE_VIOLATION')

def invoke(root,args):
    m,base=c.artifact(root,args['project'],'rules')
    tool=c.read(root,args['tool_ref'])
    rt.shape(tool,['descriptor_version','id','kind','rule_id','input_schema','network','source_refs'],label='descriptor')
    descriptors=c.read(root,base+'/tools.json')
    rt.need(tool in descriptors and tool['network'] is False and tool['kind']=='rule_evaluate','Unregistered or altered project tool','CAPABILITY_MISMATCH')
    value=c.read(root,args['input_ref']); rt.shape(value,['vars'],['step'],label='project tool input')
    rt.need(isinstance(value['vars'],dict) and isinstance(value.get('step',{}),dict),'Invalid evaluation input')
    rule=next(r for r in c.read(root,base+'/rules.ir.json')['rules'] if r['id']==tool['rule_id'])
    when=evaluate(rule['when'],value['vars'],value.get('step'))
    required=evaluate(rule['require'],value['vars'],value.get('step')) if rule['kind']=='constraint' else None
    out={'rule_id':rule['id'],'when':'UNKNOWN' if when is UNKNOWN else when,
         'requirement':'UNKNOWN' if required is UNKNOWN else required,'status':rule['status'],'source_refs':rule['source_refs']}
    c.write(root,args['out'],out)
    return {'result':args['out'],'network_executed':False}
