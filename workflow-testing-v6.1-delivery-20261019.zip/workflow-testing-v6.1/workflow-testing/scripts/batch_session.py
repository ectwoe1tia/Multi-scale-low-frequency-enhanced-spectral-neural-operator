"""File-composed resumable DAG. Only independent static queries run concurrently."""
import concurrent.futures
import time
import uuid
import http_runner as rt
import v5_common as c
import semantic_core as s
import managed_session

STATIC={'semantic_compile','semantic_query','semantic_diff','semantic_propose','semantic_check',
        'flow_analysis','trace_align','rules_codegen','artifact_query','tool_help'}
PARALLEL={'semantic_query','tool_help'}


def plan(root,spec_ref):
    top=s.load(root,spec_ref)
    rt.shape(top,['version','tasks'],['includes','max_tasks','max_seconds','parallel_queries','allow_execute'],label='batch spec')
    limits={'max_tasks':top.get('max_tasks',10),'max_seconds':top.get('max_seconds',30),'parallel_queries':top.get('parallel_queries',1)}
    for k,high in (('max_tasks',100),('max_seconds',300),('parallel_queries',4)):
        rt.need(type(limits[k]) is int and 1<=limits[k]<=high,'Invalid batch budget')
    rt.need(type(top.get('allow_execute',False)) is bool,'allow_execute must be boolean')
    tasks={};active=set();done=set();inputs={};outputs=[]
    def walk(ref,depth):
        rt.need(depth<=12 and len(done)+len(active)<128,'Batch include limit')
        rt.need(ref not in active,'Batch include cycle')
        if ref in done:return
        active.add(ref);data=s.load(root,ref);inputs[ref]=c.hash_file(root,ref)
        rt.shape(data,['version','tasks'],['includes','max_tasks','max_seconds','parallel_queries','allow_execute'],label='batch collection')
        rt.need(data['version']=='1.0' and isinstance(data['tasks'],list),'Invalid batch collection')
        rt.need(isinstance(data.get('includes',[]),list) and len(data.get('includes',[]))<=64,'Batch include limit')
        for inc in data.get('includes',[]):walk(inc,depth+1)
        for task in data['tasks']:
            rt.shape(task,['id','depends_on'],['request','session','action','case_id'],label='batch task')
            rt.ident(task['id'],'task id');rt.need(task['id'] not in tasks,'Duplicate task')
            rt.need(isinstance(task['depends_on'],list) and len(task['depends_on'])<=100 and all(isinstance(x,str) for x in task['depends_on']),'Dependency limit')
            rt.need(('request' in task)!=('session' in task),'Choose file request or managed session')
            if 'request' in task:
                rt.need(not {'action','case_id'} & task.keys(),'Request task cannot have session fields')
                import toolchain
                req=s.load(root,task['request']);tool,args=toolchain.validate_request(req)
                rt.need(tool in STATIC,'Batch tool is not in the static allowlist','EFFECT_DENIED')
                inputs[task['request']]=c.hash_file(root,task['request'])
                if tool=='semantic_compile':
                    compile_spec=s.load(root,args['spec'])
                    _,source_inputs=s.collect(root,compile_spec['file_set'])
                    inputs.update(source_inputs)
                    inputs[compile_spec['profile']]=c.hash_file(root,compile_spec['profile'])
                # Request dependencies/specs are pinned too. Outputs need not exist yet.
                for k,v in args.items():
                    if k in ('out','name'):continue
                    p=rt.workspace_path(root,v)
                    if p.is_file():inputs[v]=c.hash_file(root,v)
                if 'out' in args:outputs.append(rt.workspace_path(root,args['out']))
                task={**task,'tool':tool}
            else:
                rt.need(task.get('action') in ('status','prepare','diagnose','execute','report'),'Unsupported batch session action')
                if task['action']=='execute':rt.need(top.get('allow_execute',False),'Batch execute requires explicit allow_execute','EFFECT_DENIED')
                sp=s.load(root,task['session']);managed_session.validate_spec(root,sp,managed=True)
                inputs[task['session']]=c.hash_file(root,task['session'])
                for k in ('suite','adapter','plan'):inputs[sp[k]]=c.hash_file(root,sp[k])
                task={**task,'tool':'session'}
            tasks[task['id']]=task
            rt.need(len(tasks)<=1000,'Batch task budget exceeded')
        active.remove(ref);done.add(ref)
    walk(spec_ref,0)
    rt.need(tasks,'Empty batch')
    # Generated prerequisite outputs are verified by their own tools, not frozen before creation.
    inputs={r:h for r,h in inputs.items() if not any(rt.workspace_path(root,r)==p or p in rt.workspace_path(root,r).parents for p in outputs)}
    for a in outputs:
        rt.need(all(a!=b and a not in b.parents and b not in a.parents for b in outputs if b is not a),'Batch outputs overlap')
        rt.need(all(a!=rt.workspace_path(root,r) and a not in rt.workspace_path(root,r).parents for r in inputs),'Batch output overwrites an input')
    for t in tasks.values():rt.need(all(x in tasks and x!=t['id'] for x in t['depends_on']),'Unknown/self dependency')
    order=[];remaining=set(tasks)
    while remaining:
        ready=sorted(x for x in remaining if set(tasks[x]['depends_on'])<=set(order))
        rt.need(ready,'Batch dependency cycle')
        order+=ready;remaining.difference_update(ready)
    return tasks,order,inputs,limits


def run(root,spec_ref,state_ref):
    import toolchain
    root=root.resolve();tasks,order,inputs,limits=plan(root,spec_ref)
    target=rt.workspace_path(root,state_ref)
    rt.need(all(target!=rt.workspace_path(root,r) and target not in rt.workspace_path(root,r).parents for r in inputs),'State overlaps inputs')
    target.mkdir(parents=True,exist_ok=True)
    ref=state_ref+'/state.json';signature=s.fingerprint([inputs,c.generator_digest()])
    with c.lock(root,target,'batch'):
        if rt.workspace_path(root,ref).exists():
            state=s.load(root,ref);rt.need(state['signature']==signature,'Batch plan/code changed; create a new reviewed batch','STALE_BATCH')
        else:
            state={'version':'1.0','signature':signature,'inputs':inputs,'tasks':{k:{'status':'TODO'} for k in tasks}}
            c.write(root,ref,state)
        for entry in state['tasks'].values():
            if entry['status'] in ('DONE','FAILED'):
                rt.need(c.hash_file(root,entry['receipt'])==entry['receipt_sha256'],'Batch receipt changed','EVIDENCE_CHANGED')
        if any(v['status']=='FAILED' for v in state['tasks'].values()):
            return {'result':ref,'status':'BLOCKED_FAILED','automatic_retry':False}
        if any(v['status'] in ('RUNNING','UNKNOWN') for v in state['tasks'].values()):
            for v in state['tasks'].values():
                if v['status']=='RUNNING':v['status']='UNKNOWN'
            c.replace(root,ref,state)
            return {'result':ref,'status':'BLOCKED_UNKNOWN','automatic_retry':False}
        started=time.monotonic();executed=0
        def perform(t):
            if 'request' in t:return toolchain.dispatch(root,s.load(root,t['request']))
            return managed_session.perform(root,t['session'],t['action'],case_id=t.get('case_id'))
        while executed<limits['max_tasks'] and time.monotonic()-started<limits['max_seconds']:
            for path,digest in inputs.items():rt.need(c.hash_file(root,path)==digest,'Batch inputs changed during execution','STALE_BATCH')
            ready=[tasks[x] for x in order if state['tasks'][x]['status']=='TODO' and all(state['tasks'][p]['status']=='DONE' for p in tasks[x]['depends_on'])]
            if not ready:break
            selected=[ready[0]]
            if ready[0]['tool'] in PARALLEL:
                selected=[t for t in ready if t['tool'] in PARALLEL][:min(limits['parallel_queries'],limits['max_tasks']-executed)]
            for t in selected:
                state['tasks'][t['id']]={'status':'RUNNING','receipt':state_ref+'/receipts/'+t['id']+'-'+uuid.uuid4().hex+'.json'}
            c.replace(root,ref,state)  # Persist before any task, including writes.
            def safe(t):
                try:
                    # Recheck at the task boundary; credentials are intentionally not hashed.
                    for path,digest in inputs.items():rt.need(c.hash_file(root,path)==digest,'Batch inputs changed','STALE_BATCH')
                    return perform(t)
                except rt.ToolError as e:return toolchain.envelope(t['tool'],code=e.code,message='Inspect task inputs and contract')
                except Exception:return toolchain.envelope(t['tool'],code='INTERRUPTED',message='Uncertain task result; inspect evidence before any retry')
            if len(selected)>1:
                with concurrent.futures.ThreadPoolExecutor(max_workers=len(selected)) as pool:results=list(pool.map(safe,selected))
            else:results=[safe(selected[0])]
            for t,result in zip(selected,results):
                info=state['tasks'][t['id']];c.write(root,info['receipt'],result)
                info['receipt_sha256']=c.hash_file(root,info['receipt']);info['code']=result['code']
                semantic_status=(result.get('data') or {}).get('status')
                info['status']='UNKNOWN' if result['code']=='INTERRUPTED' else 'DONE' if result['ok'] and semantic_status not in ('FAIL','UNKNOWN') else 'FAILED'
                executed+=1
            c.replace(root,ref,state)
            if any(state['tasks'][t['id']]['status']!='DONE' for t in selected):break
        counts={key:sum(v['status']==key for v in state['tasks'].values()) for key in ('TODO','DONE','FAILED','UNKNOWN','RUNNING')}
        status='BLOCKED' if counts['UNKNOWN'] or counts['FAILED'] else 'COMPLETE' if counts['TODO']==0 else 'PAUSED_BUDGET'
        return {'result':ref,'status':status,'counts':counts,'executed_now':executed,'automatic_retry':False}
