"""Static semantic indexing, bounded slices, human-reviewed executable data recipes."""
import contextlib
import json
import shutil
import sqlite3
import uuid
from pathlib import Path
import http_runner as rt
import v5_common as c
import semantic_core as s

TOOLS={
 'semantic_compile':(['spec','out'],[]),
 'semantic_query':(['index','query','out'],[]),
 'semantic_diff':(['before','after','out'],[]),
 'semantic_propose':(['index','spec','out'],[]),
 'semantic_promote':(['index','proposals','review','out'],[]),
 'semantic_check':(['index','recipe','out'],[]),
}


def write(root,ref,value):c.write(root,ref,value)


def bounded(root,out,value,budget=8192):
    # Match the actual UTF-8 file representation, including formatting and final newline.
    rt.need(len((json.dumps(value,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode('utf-8'))<=budget,
            'Narrow the semantic query','QUERY_TOO_LARGE')
    write(root,out,value)
    return {'result':out,'network_executed':False}


def compile_index(root,args):
    spec=s.load(root,args['spec'])
    rt.shape(spec,['file_set','profile'],['cache'],label='compile spec')
    files,inputs=s.collect(root,spec['file_set'])
    config=s.profile(s.load(root,spec['profile']))
    inputs.update({x:c.remember(root,x) for x in (args['spec'],spec['profile'])})
    code=c.generator_digest();out=rt.workspace_path(root,args['out'])
    rt.need(not out.exists(),'Output already exists','OUTPUT_EXISTS')
    rt.need(all(out!=rt.workspace_path(root,r) and out not in rt.workspace_path(root,r).parents for r in inputs),'Output overlaps input')
    cache=rt.workspace_path(root,spec.get('cache','.semantic-cache'))
    rt.need(cache!=out and cache not in out.parents and out not in cache.parents,'Cache/output overlap')
    out.mkdir(parents=True)
    hits=[0]*len(config['rules']);cached=0;parsed=0
    with contextlib.closing(s.connect(out/'index.sqlite',True)) as db:
        for fid,item in sorted(files.items()):
            key=s.fingerprint([code,item,inputs[item['path']],config])
            shard=cache/(key+'.sqlite');meta=cache/(key+'.json')
            with c.lock(root,cache,key):
                if shard.exists() or meta.exists():
                    rt.need(shard.is_file() and meta.is_file(),'Incomplete cache; use a new cache directory','CACHE_INVALID')
                    info=s.load(root,c.relative(root,meta))
                    rt.need(info['sha256']==c.hash_file(root,c.relative(root,shard)),'Cache changed','CACHE_INVALID')
                    cached+=1
                else:
                    cache.mkdir(parents=True,exist_ok=True)
                    temp=cache/(key+'.'+uuid.uuid4().hex+'.tmp')
                    with contextlib.closing(s.connect(temp,True)) as part:
                        found=s.extract(root,item,config,part);part.commit()
                    rt.need(c.hash_file(root,item['path'])==inputs[item['path']],'Input changed during parse','STALE_INPUT')
                    temp.rename(shard)
                    info={'sha256':c.hash_file(root,c.relative(root,shard)),'hits':found}
                    write(root,c.relative(root,meta),info);parsed+=1
                with contextlib.closing(s.connect(shard)) as part:
                    for table in ('nodes','edges','symbols','issues'):
                        rows=part.execute('SELECT * FROM '+table)
                        width=len(rows.description)
                        db.executemany('INSERT INTO '+table+' VALUES('+','.join(['?']*width)+')',rows)
                hits=[a+b for a,b in zip(hits,info['hits'])]
            rt.need(db.execute('SELECT COUNT(*) FROM nodes').fetchone()[0]<=s.MAX_NODES,'Collection node budget exceeded','BUDGET_EXCEEDED')
        s.link(db);db.commit()
        counts={table:db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in ('nodes','edges','issues')}
        issues=dict(db.execute('SELECT code,COUNT(*) FROM issues GROUP BY code'))
    for ref,digest in inputs.items():rt.need(c.hash_file(root,ref)==digest,'Input changed during compile','STALE_INPUT')
    summary={'version':'1.0','counts':counts,'issue_counts':issues,'files':len(files),'parsed_files':parsed,'cached_files':cached,
             'unmatched_profile_rules':[i for i,n in enumerate(hits) if n==0],
             'causality_proven':False,'scalar_values_exported':False,'network_executed':False}
    write(root,args['out']+'/summary.json',summary)
    manifest={'version':'1.0','code':code,'inputs':inputs,'files':files,'profile':spec['profile'],
              'database':args['out']+'/index.sqlite','sha256':c.hash_file(root,args['out']+'/index.sqlite'),
              'summary':args['out']+'/summary.json','summary_sha256':c.hash_file(root,args['out']+'/summary.json')}
    write(root,args['out']+'/manifest.json',manifest)
    return {'result':args['out']+'/summary.json','index':args['out']+'/manifest.json',**counts,'parsed_files':parsed,'cached_files':cached,'network_executed':False}


@contextlib.contextmanager
def index(root,ref,current=True):
    manifest=s.load(root,ref)
    rt.shape(manifest,['version','code','inputs','files','profile','database','sha256','summary','summary_sha256'],label='semantic manifest')
    rt.need(manifest['version']=='1.0' and manifest['code']==c.generator_digest(),'Compiler changed; rebuild index','STALE_INDEX')
    if current:
        for path,digest in manifest['inputs'].items():rt.need(c.hash_file(root,path)==digest,'Source/profile changed; rebuild index','STALE_INDEX')
    rt.need(c.hash_file(root,manifest['database'])==manifest['sha256'],'Index changed','EVIDENCE_CHANGED')
    rt.need(c.hash_file(root,manifest['summary'])==manifest['summary_sha256'],'Summary changed','EVIDENCE_CHANGED')
    with contextlib.closing(s.connect(rt.workspace_path(root,manifest['database'],True))) as db:
        yield manifest,db


def locator(db,value):
    rt.shape(value,['file','pointer'],label='field locator');s.pointer(value['pointer'])
    row=db.execute('SELECT * FROM nodes WHERE file=? AND pointer=?',(value['file'],value['pointer'])).fetchone()
    rt.need(row is not None,'Locator not found','NODE_MISSING')
    rt.need(row['kind']!='redacted','Secret subtree cannot be queried or promoted','REDACTED_NODE')
    return row


def query(root,args):
    spec=s.load(root,args['query'])
    rt.shape(spec,['kind'],['file','pointer','node','direction','depth','offset','limit','max_bytes','code'],label='semantic query')
    mode=spec['kind'];limit=spec.get('limit',12);offset=spec.get('offset',0);budget=spec.get('max_bytes',4096)
    rt.need(type(limit) is int and 1<=limit<=100 and type(offset) is int and 0<=offset<=s.MAX_NODES,'Query page bounds')
    rt.need(type(budget) is int and 512<=budget<=8192,'Query byte budget')
    with index(root,args['index']) as (manifest,db):
        if mode=='summary':return bounded(root,args['out'],s.load(root,manifest['summary']),budget)
        params=[];where=[];truncated=False
        if mode in ('nodes','issues'):
            if 'file' in spec:where.append('n.file=?');params.append(spec['file'])
            if 'pointer' in spec:s.pointer(spec['pointer']);where.append('n.pointer=?');params.append(spec['pointer'])
            sql='SELECT n.id,n.file,n.pointer,n.kind,n.size'+(',i.code,i.severity' if mode=='issues' else '')+' FROM nodes n'
            if mode=='issues':
                sql+=' JOIN issues i ON i.node=n.id'
                if 'code' in spec:where.append('i.code=?');params.append(spec['code'])
            if where:sql+=' WHERE '+' AND '.join(where)
            rows=[dict(x) for x in db.execute(sql+' ORDER BY n.id LIMIT ? OFFSET ?',params+[limit+1,offset])]
        elif mode in ('dependencies','impact'):
            seed=locator(db,spec.get('node',{}))['id'];depth=spec.get('depth',2)
            rt.need(type(depth) is int and 1<=depth<=6,'Slice depth must be 1..6')
            frontier={seed};seen={seed};rows=[]
            for level in range(depth):
                next_ids=set()
                for nid in sorted(frontier):
                    col='src' if mode=='dependencies' else 'dst'
                    found=db.execute('SELECT * FROM edges WHERE '+col+"=? AND kind!='contains' ORDER BY id LIMIT 1001",(nid,)).fetchall()
                    if len(found)>1000:truncated=True
                    for e in found[:1000]:
                        other=e['dst'] if mode=='dependencies' else e['src']
                        n=db.execute('SELECT file,pointer,kind FROM nodes WHERE id=?',(other,)).fetchone()
                        rows.append({**dict(e),'location':dict(n),'depth':level+1})
                        if other not in seen:next_ids.add(other)
                        if len(rows)>=1000:truncated=True;break
                    if truncated:break
                if truncated:break
                seen.update(next_ids);frontier=next_ids
                if not frontier:break
            if frontier and level==depth-1:truncated=True
            rows=rows[offset:offset+limit+1]
        else:raise rt.ToolError('UNKNOWN_QUERY','Use summary, nodes, issues, dependencies or impact')
        selected=[]
        for row in rows[:limit]:
            if len(json.dumps(selected+[row],ensure_ascii=True).encode('ascii'))>budget-400:break
            selected.append(row)
        rt.need(selected or not rows,'One row exceeds budget; use narrower selector','QUERY_TOO_LARGE')
        result={'kind':mode,'rows':selected,'next_offset':offset+len(selected) if len(rows)>len(selected) else None,
                'traversal_truncated':truncated,'causality_proven':False,'index':args['index']}
        return bounded(root,args['out'],result,budget)


def diff(root,args):
    # Old snapshot intentionally permits stale sources, still checks code and sealed DB.
    with index(root,args['before'],False) as (_,a),index(root,args['after']) as (_,b):
        before={x['id']:dict(x) for x in a.execute('SELECT id,file,pointer,kind,value_hash FROM nodes')}
        after={x['id']:dict(x) for x in b.execute('SELECT id,file,pointer,kind,value_hash FROM nodes')}
        counts={'added':0,'removed':0,'changed':0};rows=[]
        for key in sorted(before.keys()|after.keys()):
            status='added' if key not in before else 'removed' if key not in after else 'changed' if before[key]!=after[key] else None
            if status:
                counts[status]+=1;n=after.get(key,before.get(key))
                rows.append({'node':key,'file':n['file'],'pointer':n['pointer'],'change':status})
        # Full delta stays on disk and can itself be indexed as a source.
        write(root,args['out'],{'counts':counts,'changes':rows,'values_exported':False})
        return {'result':args['out'],'counts':counts,'network_executed':False}


PREDICATES=('equal','same_type','depends_on','co_occurs')


def propose(root,args):
    spec=s.load(root,args['spec'])
    rt.shape(spec,[],['hypotheses','seeds'],label='hypotheses')
    rt.need(('hypotheses' in spec)!=('seeds' in spec),'Supply hypotheses or seeds')
    with index(root,args['index']) as (m,db):
        hypotheses=spec.get('hypotheses',[]);skipped=0
        if 'seeds' in spec:
            rt.need(isinstance(spec['seeds'],list) and 1<=len(spec['seeds'])<=16,'Use 1..16 seeds')
            for seed in spec['seeds']:
                a=locator(db,seed)
                if a['kind']!='string' or a['size']<8 or a['value_hash'] is None:skipped+=1;continue
                others=db.execute('SELECT file,pointer FROM nodes WHERE value_hash=? AND id!=? ORDER BY id LIMIT 21',(a['value_hash'],a['id'])).fetchall()
                if len(others)>20:skipped+=1;continue
                for b in others:
                    hypotheses.append({'from':seed,'to':dict(b),'predicate':'equal',
                                       'evidence':sorted({m['files'][a['file']]['path'],m['files'][b['file']]['path']})})
                    rt.need(len(hypotheses)<=100,'Candidate budget; narrow seeds','BUDGET_EXCEEDED')
        rt.need(isinstance(hypotheses,list) and len(hypotheses)<=100,'Hypothesis budget')
        rows=[]
        for h in hypotheses:
            rt.shape(h,['from','to','predicate','evidence'],label='hypothesis')
            rt.need(h['predicate'] in PREDICATES,'Unknown predicate')
            a,b=locator(db,h['from']),locator(db,h['to'])
            rt.need(isinstance(h['evidence'],list) and 1<=len(h['evidence'])<=16,'Evidence references required')
            evidence={r:c.remember(root,r) for r in h['evidence']}
            item={'from':h['from'],'to':h['to'],'predicate':h['predicate'],'evidence':evidence,
                  'status':'candidate','causality_proven':False}
            item['id']=s.fingerprint(item);rows.append(item)
        result={'version':'1.0','index':args['index'],'index_sha256':c.hash_file(root,args['index']),
                'source_hashes':m['inputs'],'profile_hash':m['inputs'][m['profile']],'candidates':rows}
        write(root,args['out'],result)
        return {'result':args['out'],'candidates':len(rows),'skipped_low_selectivity_seeds':skipped,'automatic_activation':False,'network_executed':False}


def promote(root,args):
    proposals=s.load(root,args['proposals']);review=s.load(root,args['review'])
    rt.shape(review,['proposals_sha256','reviewer','decisions'],label='human review')
    rt.need(review['proposals_sha256']==c.hash_file(root,args['proposals']),'Review does not match proposal revision','STALE_REVIEW')
    rt.need(isinstance(review['reviewer'],str) and 1<=len(review['reviewer'])<=120,'Reviewer required')
    rt.need(proposals['index']==args['index'] and proposals['index_sha256']==c.hash_file(root,args['index']),'Proposal index changed','STALE_REVIEW')
    with index(root,args['index']) as (m,db):
        known={x['id']:x for x in proposals['candidates']};accepted=[];seen=set()
        rt.need(isinstance(review['decisions'],list) and len(review['decisions'])<=100,'Decision budget')
        for d in review['decisions']:
            rt.shape(d,['id','decision'],label='decision')
            rt.need(d['id'] in known and d['id'] not in seen and d['decision'] in ('accept','reject'),'Invalid or repeated decision')
            seen.add(d['id']);h=known[d['id']]
            for ref,digest in h['evidence'].items():rt.need(c.hash_file(root,ref)==digest,'Evidence changed','STALE_REVIEW')
            if d['decision']=='accept':accepted.append({k:h[k] for k in ('id','from','to','predicate')})
        rt.need(accepted,'No accepted relations to generate')
        out=rt.workspace_path(root,args['out']);rt.need(not out.exists(),'Output exists','OUTPUT_EXISTS');out.mkdir(parents=True)
        recipe={'version':'1.0','kind':'semantic_assertions','code':c.generator_digest(),'profile_sha256':m['inputs'][m['profile']],
                'file_ids':sorted(m['files']),'review':args['review'],'review_sha256':c.hash_file(root,args['review']),
                'proposals':args['proposals'],'proposals_sha256':c.hash_file(root,args['proposals']),
                'assertions':accepted,'causality_proven':False}
        write(root,args['out']+'/recipe.json',recipe)
        write(root,args['out']+'/check.request.json',{'protocol_version':'1.0','tool':'semantic_check',
              'arguments':{'index':args['index'],'recipe':args['out']+'/recipe.json','out':args['out']+'/first-check.json'}})
        write(root,args['out']+'/batch.json',{'version':'1.0','tasks':[
            {'id':'check-confirmed-relations','request':args['out']+'/check.request.json','depends_on':[]}]})
        # Fixed declarative program, not dynamically imported Python/shell.
        write(root,args['out']+'/recipe.sha256.json',{'sha256':c.hash_file(root,args['out']+'/recipe.json')})
        return {'result':args['out']+'/recipe.json','next_request':args['out']+'/check.request.json','accepted':len(accepted),'network_executed':False}


def check_recipe(root,args):
    recipe=s.load(root,args['recipe'])
    rt.shape(recipe,['version','kind','code','profile_sha256','file_ids','review','review_sha256','proposals','proposals_sha256','assertions','causality_proven'],label='recipe')
    rt.need(recipe['version']=='1.0' and recipe['kind']=='semantic_assertions' and recipe['code']==c.generator_digest(),'Recipe/compiler mismatch','STALE_RECIPE')
    for field in ('review','proposals'):rt.need(c.hash_file(root,recipe[field])==recipe[field+'_sha256'],'Recipe review changed','STALE_RECIPE')
    proposals=s.load(root,recipe['proposals']);review=s.load(root,recipe['review'])
    rt.need(review['proposals_sha256']==recipe['proposals_sha256'],'Review binding mismatch','STALE_RECIPE')
    accepted={x['id'] for x in review['decisions'] if x['decision']=='accept'}
    original={h['id']:{k:h[k] for k in ('id','from','to','predicate')} for h in proposals['candidates']}
    rt.need(recipe['assertions'] and len(recipe['assertions'])<=100,'Assertion budget')
    rt.need({a['id'] for a in recipe['assertions']}==accepted and len(accepted)==len(recipe['assertions'])
            and all(a==original.get(a['id']) for a in recipe['assertions']),'Recipe must preserve exactly the accepted assertions','UNCONFIRMED_RELATION')
    with index(root,args['index']) as (m,db):
        rt.need(m['inputs'][m['profile']]==recipe['profile_sha256'] and sorted(m['files'])==recipe['file_ids'],'Profile/file scope changed; review again','STALE_RECIPE')
        rows=[]
        for a in recipe['assertions']:
            try:
                left,right=locator(db,a['from']),locator(db,a['to']);predicate=a['predicate']
                if predicate=='equal':
                    passed=left['value_hash'] is not None and left['kind']==right['kind'] and left['value_hash']==right['value_hash']
                    status='PASS' if passed else 'UNKNOWN' if left['value_hash'] is None or right['value_hash'] is None else 'FAIL'
                elif predicate=='same_type':status='PASS' if left['kind']==right['kind'] else 'FAIL'
                elif predicate=='depends_on':status='PASS' if db.execute("SELECT 1 FROM edges WHERE src=? AND dst=? AND kind='reads_from'",(left['id'],right['id'])).fetchone() else 'FAIL'
                else:status='PASS'  # Presence only; never claims causal evidence.
            except rt.ToolError as e:
                if e.code not in ('NODE_MISSING','REDACTED_NODE'):raise
                status='UNKNOWN'
            rows.append({'id':a['id'],'predicate':a['predicate'],'status':status})
        result={'status':'FAIL' if any(x['status']=='FAIL' for x in rows) else 'UNKNOWN' if any(x['status']=='UNKNOWN' for x in rows) else 'PASS',
                'checks':rows,'baseline_changed':m['inputs']!=proposals['source_hashes'],
                'causality_proven':False,'business_assertions_replaced':False}
        write(root,args['out'],result)
        return {'result':args['out'],'status':result['status'],'network_executed':False}


def dispatch(root,tool,args):
    with c.capture():
        return {'semantic_compile':compile_index,'semantic_query':query,'semantic_diff':diff,
                'semantic_propose':propose,'semantic_promote':promote,'semantic_check':check_recipe}[tool](root,args)
