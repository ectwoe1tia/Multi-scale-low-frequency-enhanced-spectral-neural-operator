"""One session file and a fixed action; JSON bodies and secrets never enter shell arguments."""
import argparse
import contextlib
import io
import json
import sys
import uuid
from pathlib import Path
import http_runner as rt
import file_workflow as fw
import toolchain as tc
import inspection
import managed_session


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--session','--session-spec',required=True)
    parser.add_argument('--action',type=str.lower,choices=managed_session.ACTIONS,default='status')
    parser.add_argument('--case-id')
    parser.add_argument('--attempt')
    parser.add_argument('--retry-note')
    args=parser.parse_args(argv)
    response_ref=None
    handle=None
    try:
        spec=Path(args.session).resolve()
        root=spec.parent
        rt.need(spec.is_file(),'Session file not found','SESSION_REQUIRED')
        response_ref='.session-replies/'+uuid.uuid4().hex+'.json'
        response_path=rt.workspace_path(root,response_ref)
        response_path.parent.mkdir(parents=True,exist_ok=True)
        handle=response_path.open('x',encoding='utf-8')
        with contextlib.redirect_stdout(io.StringIO()):
            response=managed_session.perform(root,spec.name,args.action,args.case_id,args.attempt,args.retry_note)
    except rt.ToolError as exc:
        response=tc.envelope('session',exc.code,getattr(exc,'details',None),str(exc))
    except (OSError,ValueError,TypeError,KeyError):
        response=tc.envelope('session','INVALID_INPUT',message='Session input or filesystem error; inspect file contracts')
    if handle is not None:
        with handle:
            json.dump(response,handle,ensure_ascii=False,allow_nan=False,indent=2)
            handle.write('\n')
    print(json.dumps(inspection.control_response(response,response_ref),ensure_ascii=False))
    return tc.EXIT_CODES.get(response['code'],2)


if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
