# 公司环境接续路线

## 接手运行，不修改工具

1. 固定本交付版本 runner 2.2.0，先读 SKILL.md；旧版保留可回滚。不要把运行证据一并当作 Skill 安装。
2. 检查 Python 3.9+ / curl，运行注册 doctor。凭据经公司约定注入环境变量，不写进 JSON。此处没有新增 Python 依赖；Word/PDF 等旧能力仍按旧依赖约定。
3. 复用公司已有 suite / adapter / plan；adapter 来源和规约必须有效。用 assets/flow-init.request.json 和 assets/session-spec.example.json 的形状填写路径。
4. flow_init 后项目保存自动生成的请求文件。每次执行使用 `--response-file --brief`。优先从 status 开始，再处理当前 case。
5. 大 body 和复用片段放单独文件，使用 `$file` / pointer。不要将公司完整接口文档/用例/响应粘入聊天；定位失败时只读相关步骤与证据片段。
6. 写入真实经验 note；重试/不确定副作用核对按 file-workflow.md，保留旧证据。项目交接只提供 workspace 路径、Skill 版本、status 请求路径和当前未决问题。

## 额度耗尽时的最小交接模板

```text
workspace = ...
skill version = runner 2.2.0 / file workflow 1.0
resume request = projects/<project>/requests/status.json
last response = replies/...
current case / attempt = ... / ....
unresolved = 具体问题；若没有写 none
next action = 调用 status 后依据 NEXT.json，不重发未知写请求
```

不要求当前会话必须来得及写完总结：每次调用的 request、attempt、intent、结果都落盘。没有完成 checksum 的运行保守阻断。若旧执行者还可能存活，先等其结束或按公司流程确认停止，不能提前 reconcile。

## 接手维护

读 AGENTS.md、collaboration.md、extensions.md，按 snapshot/claim/release 修改；变更单记录真实用户范围。重点入口：file_workflow.py 负责引用和会话；toolchain.py 负责注册/schema/回执；http_runner.py 保持原执行语义；suite.py 生成逐用例项目 Skill。

验证工具和顺序：

```powershell
python -X utf8 -m unittest discover -s tests -v
python -X utf8 scripts/demo_file_workflow.py --out <尚不存在的演示证据目录>
python -X utf8 <skill-creator目录>/scripts/quick_validate.py <skill目录>
```

验证记录保留命令、exit code、日志、metrics.json。单测覆盖引用边界、旧 guard/来源规则、状态恢复、重复发送、失败退出码；30 用例演示覆盖真实回环 HTTP、跨进程恢复和上下文字节体积。验证目录使用新名字，不能覆盖旧运行。独立评审如没有真实开展，保持 pending。

## 后续按需要实施，不在本版虚构完成

| 优先级 | 可追加工作 | 接续验收 |
|---|---|---|
| P1 | 公司真实审批接口适配与脱敏样本回归 | 精确角色/状态断言、来源规约、真实授权测试环境；不能将本地 demo 算作公司验收 |
| P2 | 针对 results 的 JSON Pointer 摘要查询工具 | 有界输出且不泄露凭据；不重解释原始 FAIL；无需模型读整份大响应 |
| P2 | 经验检索索引和人工提升队列 | 仅检索当前 case/operation；严格区分假设与确认，保留依据和适用版本 |
| P3 | 团队并发调度、远端存储或 pgSQL 索引 | 真实分布式互斥/幂等语义，不能以本地文件锁声称已支持分布式事务 |

不包含自动清理历史聊天、真实浏览器操作、公司接口自动发现之外的猜测调用、生产发布以及跨平台完整实机认证。
