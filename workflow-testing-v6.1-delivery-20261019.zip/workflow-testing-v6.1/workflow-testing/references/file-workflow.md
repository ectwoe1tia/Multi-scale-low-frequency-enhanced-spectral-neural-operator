# 文件会话契约 v1 / runner 2.2.0

本契约供执行时按需阅读。设计与分层见 context-design.md，接力开发见 v4-handoff.md。旧工具及所有原有保护仍有效；新增工具没有开放任意 URL、shell 或浏览器执行能力。

请求参数 schema 见 assets/tool-request.schema.json；文件内容的命名模式见 assets/file-workflow.schema.json 的 `$defs`，也由 describe.data.file_workflow_schema 导出。编辑器关联具体 `$defs/SessionSpec`、`Note` 等定义，不将整个 `$defs` 容器当作实例约束。文件存在性、授权来源真实性、运行状态和副作用还需运行时/项目负责人核对。

## 入口和路径

所有调用仍为 `{"protocol_version":"1.0","tool":"工具名","arguments":{...}}`。工具参数都是文件路径或标识字符串。文件内容中的路径一律相对 **workspace 根目录**，不相对当前文件。使用 `/` 最方便；禁止越界路径。输入 JSON 必须无重复键，不允许 NaN。输出文件默认独占创建，不能覆盖历史证据。

```powershell
python -X utf8 .\scripts\toolchain.py --workspace E:\company\workflow --request E:\company\workflow\calls\init.json --response-file replies/init.json --brief

# 同一入口的 PowerShell 包装；不改变机器的执行策略
.\scripts\Invoke-WorkflowTool.ps1 -Workspace E:\company\workflow -Request E:\company\workflow\calls\init.json -ResponseFile replies/init.json -Brief
```

`--response-file` 保存完整工具结果；`--brief` 仅输出工具、结果码和回执路径，必须同时提供 response-file。正常回执不会输出请求/响应正文。回执文件在动作前独占创建，路径冲突不会引起再次发包。要再次查询同一已完成 attempt，使用新回执路径；不要另造 attempt。崩溃可能留下空回执，此时调用 status 查实际证据，不能凭空回执判断写请求未执行。旧版不加这两个参数仍返回完整 JSON。

## 可多级引用的参数

`$file` 是保留对象形式，不能和普通业务字段混用。同一对象允许 `$file`、可选 `pointer`、可选 `format`；没有其他键。`format` 默认 json，也支持 text。引用会递归展开，`${amount}` 等现有运行期变量原样保留，最终仍由执行器根据 capture/vars 解析。

```json
{
  "case_id": "TC-DEMO-1",
  "vars": {"amount": 12000},
  "steps": [
    {"$file": "fragments/create-step.json"},
    {"$file": "fragments/approval-steps.json", "pointer": "/director"}
  ]
}
```

步骤的 `body` 可以继续引用 `{"$file":"payloads/apply.json"}`，里面的字段还可引用 `{"$file":"payloads/description.txt","format":"text"}`。数组中的引用替换一个值，不会隐式摊平数组。这里展示引用方式，不是包含完整业务断言的可执行计划。

`request_compose` 参数为 `spec,out`，将任意包含上述引用的 JSON 组装为独立文件，回传路径/哈希/字节数。不会执行组装结果、合并同名字段、执行代码或读取环境变量。原样业务数据含 `$file` 对象时需调整数据表示，当前没有转义语法。`flow_prepare` 已内置组装，因此日常无需额外 compose 一次。

限制：每个文件及单个展开 JSON 为 16 MiB；引用递归最多 16 层；一次引用读取累计 64 MiB，重复引用计入预算。原有接口响应仍最多 1 MiB；单次运行结果最多 16 MiB；这些限制没有解除。不会把超大文件自动切块发送给业务接口。

## 建立项目，只做一次

先按原有流程得到 suite.json、adapter.json 和 plan.json；运行 doctor。计划可以将大的 body、vars 或单个 step 改为文件引用。初始 plan 的 cases 数组和每项 case_id 保持显式值。

`session-spec.json` 内容：

```json
{"suite":"inputs/suite.json","adapter":"inputs/adapter.json","plan":"inputs/plan.json"}
```

调用：

```json
{"protocol_version":"1.0","tool":"flow_init","arguments":{"spec":"session-spec.json","out":"projects/order"}}
```

init 验证用例基线与 adapter，将选中计划拆成每用例一个 spec，保存 project.json，生成 status / focus / prepare 请求文件。不会联网，**不会宣称每个用例已通过计划校验**；具体用例的所有断言、角色、引用和 guards 在 prepare 中校验。之后项目 cases 文件为当前可编辑计划；原始 plan 是导入来源，修改它不会自动覆盖已拆分的用例。修改 suite/adapter 需按原契约重新验证/生成。

## 当前用例的固定流程

| 工具 | arguments | 输出和效果 |
|---|---|---|
| flow_status | project | 从运行证据重建 outline.json、NEXT.json；短回执含统计和下一用例。是恢复入口，不发网络请求 |
| flow_focus | project, case_id | 生成 FOCUS.json，含当前 attempt、spec 路径和最多三条相关经验 |
| flow_prepare | project, case_id；可选 retry_note | 展开当前 case；执行原有 validate_bundle；保存 plan/preview/meta/execute.request.json，固定 fingerprint 和来源哈希，不联网 |
| flow_execute | project, case_id, attempt | 重新检查来源、生成 adapter 溯源、plan 和 fingerprint，保存独占 intent，再调用原有 HTTP 执行器。已完成 attempt 仅返回证据 |
| flow_note | project, note | 验证并保存经验文件，含证据哈希，不联网 |
| flow_cancel | project, case_id, attempt, reason | 仅取消尚未发送的 PREPARED；与发送竞争同一个独占 intent，保留 CANCELLED 记录 |
| flow_report | project, out | 生成 Markdown 会话报告，逐项保留所有 attempt 历史，输出不能覆盖 |
| flow_reconcile | project, record | 记录对 UNKNOWN/INCOMPLETE 的人工核对，标为 ABANDONED；不把结果改成 PASS，不联网 |

`project` 指 `projects/order/project.json`；attempt 为 `0001` 等四位字符串。工具生成的 execute.request.json 可原样作为 `--request` 调用，不需要模型重抄参数。prepare 校验完整 suite，但只展开当前用例；旧 `plan_preview/run` 不理解 `$file`，不要混用未展开 spec。新链在 prepare/execute 内部执行相同校验，无需重复跑一套旧 run。

执行后使用 status 请求刷新大纲和 NEXT。它们是可重建缓存，不是证据；运行途中或没刷新时可能过期。选择下一用例时默认返回第一个非 PASS；失败不能被无声跳过，也可明确调用其他独立用例的 focus。没有自动执行所有 TODO 的循环。

## 重试和中断

```text
TODO → PREPARED → (先落 intent) → PASS / FAIL / ERROR
                     └ 中断或未完成校验 → UNKNOWN
准备中断、缺 meta → INCOMPLETE
UNKNOWN / INCOMPLETE → 人工核对并确认旧执行者停止 → ABANDONED
PREPARED → flow_cancel（仅未发送）→ CANCELLED
终态 → 明确的 retry_note → 新 attempt；旧记录永久保留
```

有完整 result 和匹配 checksum 即可跨进程恢复完成状态；checksum 缺失即保守处理为 UNKNOWN。checksum 不匹配则 EVIDENCE_CHANGED，不能按完成跳过。完整 ERROR 也可能存在已提交副作用，重试前仍须核对。一次 case 重试从第一步开始，**不是从最后失败步骤自动续跑**，须准备新数据或确认可重复执行条件。

`retry_note` 是 JSON 文件，精确包含：

```json
{"case_id":"TC-DEMO-1","previous_attempt":"0001","reason":"说明失败原因","change":"说明本次实际修正","side_effects":"说明上次提交及清理/新夹具情况","authorization":"已有用户授权的来源","evidence":["checks/retry-review.json"]}
```

前一次必须已为 PASS/FAIL/ERROR/ABANDONED/CANCELLED；PREPARED 不允许重复准备；UNKNOWN/INCOMPLETE 先 reconcile。最多每用例 100 次 attempt。若 prepared 输入变了而尚未发送，使用 flow_cancel 记录原因，再提供 retry_note 准备新 attempt。cancel 和 execute 使用同一个独占 intent 槽位，两者只能一个成功；已经开始发送的请求不能取消，也不能删除 intent/attempt 绕过保护。

`flow_reconcile` 的 record 精确包含 `case_id,attempt,reason,side_effects,authorization,writer_stopped,evidence`；writer_stopped 必须为字符串 `confirmed`。必须先由项目负责人确认旧执行者已停止，再核对业务状态、记录真实证据；不能仅根据超时推断没有提交。程序校验字段/证据存在性和哈希，**不能证明授权文字真实或远程副作用已清除**。不能让仍运行的执行者和重试同时工作。

## 经验和范围

note 文件精确包含 `case_id,kind,summary,next_action,evidence`；case_id 可为 `*` 表示项目共性；kind 为 confirmed 或 hypothesis。所有文本字段 1..1000 字，evidence 为 1..10 个 workspace 内现存文件路径。不要写凭据或复制整个响应。新 note 使用新文件保存；同名输入可修改，但已归档 note 不变。focus 只选该用例及项目级最近三条，每条摘要和下一步最多 240 字；完整依据沿 ref 读取。需要历史检索时按 note 目录索引查阅，不把所有笔记重新加载。

outline 展示每个选中用例的最新 attempt 和 attempt 数；历史失败保留在 attempts/runs，即使最新通过也没有改写旧 FAIL。suite 中未被初始 plan 选中的用例未执行；每次 run 原有 not_selected_cases 仍保留。统计的“全部通过”只针对本会话选中用例，不代表完整业务覆盖或发布许可。

## 常见结果码

STALE_PLAN：先确认哪个文件变化；不会发送请求。ATTEMPT_BLOCKED：未结束或不确定，先读已有证据。RETRY_REQUIRED：新 attempt 缺正式重试记录。EVIDENCE_CHANGED：证据或其校验不一致，停止使用该证据下结论。OUTPUT_EXISTS：回执或输出已存在，先检查该次动作状态。TEST_FAILED 的退出码仍为 10，EXECUTION_ERROR 为 11，其他输入错误通常为 2；简短输出不掩盖失败退出码。
