# 流程测试：固定工具链

本 Skill 适合多个模型交接工作。需求分析由模型完成；结构检查、HTTP 调用、断言、记录和妥协匹配由确定性程序完成。不要自行拼接 curl、执行任意 PowerShell 字符串或改写执行器来使测试通过。

## 选择工作

| 用户提供/要求 | 应做的工作 | 必读 |
|---|---|---|
| 只有初审需求 | 提取规则、问题和分类用例，不要求先填标准模板 | [需求分析](references/requirements.md)、[用例契约](references/contract.md) |
| 接手已有项目，提供 Apifox Markdown | api_discover → 将用户规约写为 policy → adapter_build；不手抄接口清单 | [资料接入与规约](references/intake.md) |
| Word/PDF 测试文档或多份资料 | document_import → cases_build → 综合需求补充覆盖、处理冲突 → suite_validate | [资料接入与规约](references/intake.md)、[需求分析](references/requirements.md) |
| HAR 或 Chrome Recorder JSON | trace_import → trace_match → 按文档预期和新数据写 binding → plan_from_trace | [资料接入与规约](references/intake.md) |
| 测试环境与真实接口 | 将确定用例绑定到 operation，再按固定链执行 | [工具调用](references/toolchain.md)、[HTTP 契约](references/http-contract.md) |
| 到指定节点 | 以正确角色按真实路径执行，最终断言任务、角色和业务状态 | [自动化边界](references/automation.md) |
| 生成项目 Skill | suite_validate → skill_build，保留未决问题 | [工具调用](references/toolchain.md) |
| 多模型交接或修改本 Skill | snapshot → claim → 修改 → 验证 → 交接 → release | [协作规范](references/collaboration.md)、[扩展规定](references/extensions.md) |

## 需求处理规则

1. 接收初审文档，无须业务先整理模板。DOCX/PDF/Markdown/TXT 优先 document_import；保留位置和哈希。扫描件、图片、旧 .doc 或提取缺口明确列出；PDF 有文本不等于表格列序正确。
2. 规则区分 explicit、confirmed、inferred、missing、conflicting。金额、角色、路径、时限等歧义关联问题；会话中的真实确认直接使用。
3. 明确规则生成确定预期；其他规则生成 needs_clarification 用例和候选解释，继续处理不受影响部分。不擅自给“及时”“大额”设数值。
4. 按适用性覆盖正常、边界、校验、权限、状态流转、并行、幂等、并发、恢复、集成、一致性和时效。未要求的能力仅作为待确认建议。
5. 保存 suite.json。业务需求决定预期；代码、BPMN 和页面用于了解实现，不能自动成为验收依据。
6. cases_build 只是从表格/标签提取已写明用例和冲突，coverage_complete 始终为 false。模型须阅读各文档全部相关 blocks，综合补充边界、异常、权限、状态、幂等等适用场景。没有业务依据的候选测试保留问题，不把自动提取误称完整测试设计。
7. 用户自然语言规约由接入者按来源整理为 project-policy.json；工具不执行自然语言。业务已明确的限制直接编码，未明确的环境、角色、账号及允许写操作范围列为接入缺口。拒绝规则优先，重叠允许规则取更窄角色范围，所有数据约束同时生效。

## 固定执行链

先读工具调用文档。动作使用一个 JSON 请求文件，调用 scripts/Invoke-WorkflowTool.ps1；非 Windows 使用 scripts/toolchain.py。不把自然语言、原文或 shell 命令当作工具参数。

```text
doctor → suite_validate → plan_validate → plan_preview → run → report
```

- plan_preview 不联网。run 必须携带预览返回的 fingerprint，且输入没有改变。
- 自动 adapter 绑定原始 Markdown、catalog 和 policy；更改任一来源后重新生成，不能直接编辑生成物以扩大能力。request_guards 在预览和每次实际发送前检查，包括动态获取的流程/任务 ID。
- HAR 的历史响应只说明曾观察到什么；断言依据来自业务资料。不能复制历史 Cookie/token/业务 ID 自动重放。Recorder 记录可绑定现有 HTTP operation，本版执行结果仅代表接口测试，不代表页面、定位器或视觉验证。
- 只有 ready 用例可执行。每个业务断言须绑定一次，每步须检查 HTTP 状态；不得删断言绕过校验。
- 仅支持注册的 HTTP operation。GET/HEAD 可有界轮询，写操作不自动重试。同一 run_id 永不复用。
- TEST_FAILED/EXECUTION_ERROR 后查看真实结果；不能自动改 run_id 重试可能已提交的审批，也不能改变预期或标为跳过。
- status 是原始结果；gate 是选中用例的妥协处置，不是上线批准。已豁免失败仍为 FAIL，未执行后续步骤仍阻断。
- 没有真实接口/角色映射就交付测试设计。界面测试、强制跳转、生产操作尚未由本执行器实现，不伪造可运行适配器。

## 复用和协作

运行 describe 获得真实工具 JSON Schema。工具名、字段和操作符以程序为准，不创造近似名字。错误对应动作见工具调用文档。

用 skill_build 生成包含相同执行器与协作规定的项目 Skill，保留未决问题。生成不等于安装或连接系统。修改共享 Skill 前读协作规范，取得单写者租约，使用 [变更模板](assets/change-request.template.json)；输入错误应修正输入，不能放宽核心检查。

## 交付

给出资产和证据路径、覆盖缺口、问题和接入状态。未执行时明确“尚未执行业务系统测试”。[初审示例](assets/example-requirements.md)、[用例示例](assets/example-suite.json) 及 scripts/demo.py 均为演示，不能算作用户系统验证。实现范围和后续开发见 [实现纲要](references/implementation.md)。
