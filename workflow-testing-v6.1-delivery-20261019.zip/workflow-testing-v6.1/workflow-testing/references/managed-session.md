# v6 文件会话入口、业务请求头与可读报告

发布 `v6 / 20261018`；runner 6.0.0，protocol 仍为 1.0。以代码摘要与包 SHA-256 识别构建。新代码会使旧刷新凭据和生成器产物失效，按流程刷新/重新生成。

## 一个文件入口

将 session-spec.json 放在 workspace 根目录，其他路径都相对这个目录。日常只使用新入口 **Invoke-WorkflowSession.ps1**；不要与旧的 Invoke-WorkflowTool.ps1 参数混用。

```json
{
  "suite": "suite.json",
  "adapter": "adapter.json",
  "plan": "plan.json",
  "project_dir": "project",
  "credentials_file": "private/tokens.json",
  "execution_mode": "file_only"
}
```

```powershell
# 实际调用时，将两个路径替换为本机真实路径；不在命令中填写 JSON、请求正文或 token。
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action init
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action prepare -CaseId TC-001
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action execute -CaseId TC-001
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowSession.ps1' -Session 'E:\company\test workspace\session-spec.json' -Action report
```

不用 PowerShell 时，等效命令为 `python -X utf8 <skill>/scripts/session_cli.py --session <绝对路径>/session-spec.json --action status`。默认 action 为 status；动作枚举只有 init/status/prepare/diagnose/execute/report。prepare/diagnose/execute 要 CaseId；Attempt 只供历史 diagnose 使用；RetryNote 只供 prepare 显式重试使用。PowerShell 的参数校验在无效动作时直接报错，不进入执行器。入口不会更改宿主执行策略；被组织策略阻止时使用已允许的 Python 入口。

| 动作 | 程序执行的固定步骤 | 业务请求 |
|---|---|---|
| init | 初始化或迁移项目，登记严格策略与 session 绑定，status | 无 |
| status | 从证据重建当前状态 | 无 |
| prepare | context_refresh → flow_prepare → flow_diagnose | 无 |
| diagnose | 当前或指定历史 attempt 的诊断 | 无 |
| execute | 已准备状态检查 → flow_diagnose → context_refresh → 读取凭据 → flow_execute | 仅此动作 |
| report | flow_report，生成新的 Markdown 报告文件 | 无 |

程序生成 requests/回执，不需要模型抄 fingerprint 或拼命令参数。每次动作在 `.session-calls/<id>/` 留请求/回执及索引，最外层完整回执在 `.session-replies/<id>.json`，终端固定输出小型控制结果；报告内容留在文件。

执行不会自动 prepare，防止一次误调用隐式扩大动作。已封存 PASS/FAIL/ERROR 再 execute 只返回旧证据，不再读取 tokens、不发 HTTP；UNKNOWN/INCOMPLETE 必须核对，不能凭新 run_id 重发。失败后 prepare 新 attempt 仍要求 RetryNote 文件。

初始化支持将原有同 suite/adapter/plan ID/选中 case 集的文件会话登记为 file_only，原证据保留。迁移前有 PREPARED/UNKNOWN/INCOMPLETE 时阻断：先完成、取消或核对，避免迁移导致旧准备结果失效。迁移显式通过 init 完成，单独复制 Skill 不会改变旧项目模式。

## 由程序强制的步骤

file_only 项目在 project.json 和工作区严格策略中绑定 session-spec 文件。flow_prepare/flow_execute/run 的注册入口及 run_plan 的严格运行检查要求当前会话绑定匹配；仅复制旧 execute.request.json、设置同名环境变量或拿到有效 receipt 仍会返回 SESSION_REQUIRED。所有新鲜度、角色、guards、断言映射、意图记录和不重发保护继续适用。

诊断和刷新由固定动作链自动执行，不能靠模型自行省略。它证明程序执行了校验步骤，不证明模型阅读理解了摘要。合作代码和受支持入口之外的任意 Python、源码修改或删除策略不在此机制保证内；它不是 OS 沙箱。原未迁移项目继续兼容旧入口。

## 凭据文件只由执行进程读取

```json
{
  "version": "1.0",
  "env": {
    "WF_APPLICANT_TOKEN": "在本机填入真实值",
    "WF_CLIENT_ID": "在本机填入真实值"
  }
}
```

真实值应为非空可打印 ASCII。tokens.json 最多 64 KiB，放在项目生成目录外，不交给模型读取，不提交报告或版本库。静态动作不读取 tokens；一次实际 execute 在 Python 进程内读取一次，只注入所选计划实际需要的 bearer/header 环境变量，执行结束（含异常）恢复旧环境。缺少值时拒绝，不回退到外部已有环境变量；不修改用户或系统级环境变量。多余键不注入；保留系统变量名拒绝。嵌入同进程使用时凭据范围串行；推荐每次动作独立 CLI 进程。

curl 的认证和业务请求头经 stdin config 传入，不进入 argv 或请求日志。引用环境变量的值加入运行器脱敏集合，服务端将该值回显在任意响应字段时也会替换。这里只管理所声明的执行凭据，无法识别随意写进业务正文的未知秘密；不要把真实 token 改成 plan.vars/header 字符串来绕过引用。

## 业务请求头

支持五层 headers：adapter 默认 → actor → operation → plan case → plan step，后层覆盖前层，名称不区分大小写。同层重复大小写键拒绝；各层最多 32 个键，合并后最多 64 个。

```json
{
  "headers": {
    "X-Client-Id": {"env": "WF_CLIENT_ID"},
    "X-App-Version": "test-client-v1"
  },
  "actors": {
    "applicant": {"bearer_token_env": "WF_APPLICANT_TOKEN", "headers": {"X-Tenant": "test-tenant"}}
  }
}
```

以上是 adapter 的相关字段片段，不是完整 adapter。完整 schema 在 assets/http.schema.json 的 Adapter/Case/Step/Plan 定义；describe.http_schema 也导出。生成 adapter 时，项目 policy 可配置默认 headers 和 actors.headers，不能绕过 provenance 直接修改生成物。

单个值可为非空可打印 ASCII 字符串（最长 4096 字符）或 `{ "env": "变量名" }`。case 字符串只可引用初始 vars、run_id、case_id；步骤字符串可以使用已有 `${变量}`，捕获值在发送前再次验证，CR/LF/控制字符拒绝。环境变量引用不允许动态变量名。含 token/secret/api-key 等敏感键名必须用 env 引用。

Authorization、Cookie、Host、Content-Length、Content-Type、Accept、Connection/Transfer-Encoding 等传输控制头，以及已配置 idempotency_header，属于运行器保留字段，不能被业务 headers 覆盖。认证仍为 actor 的 bearer_token_env；本修订没有增加任意 Cookie 登录或其他认证协议。

headers 位于 adapter/plan 内，参与 fingerprint 和来源哈希。凭据值不进入 fingerprint，不将 token 哈希写入产物；换 token 后使用下次 execute 的新文件值。已有 request_guards 仍针对 params/query/body，不自动变为业务头的授权策略。

## 报告面向人，诊断面向模型

report 和 flow_report 都生成 Markdown：用例编号、标题、分类、优先级、设计状态、执行状态；PASS/FAIL/ERROR 的原因；失败断言的期望值/实际值；每步方法、路径、角色、HTTP 响应码、检查结果、服务端顶层 msg/message，包含轮询各次观察。中断请求没有响应时写“未知”，不伪造 HTTP 状态。后续未执行步骤明确列出。

新增运行结果保存执行时用例元数据快照。历史运行缺少快照时，flow_report 仅在准备时 suite 哈希仍匹配当前文件时补充并标记来源；漂移后写未知，不用当前标题冒充历史标题。历史 FAIL 与后续 PASS 分开保存，gate 单列；全部选中 case 的当前状态和历史 attempt 均可见。

报告值转义 Markdown/HTML，单值超过 1000 字符显示截短标记，完整值仍在证据 JSON 的对应指针下；报告整体上限 32 MiB。缺失值与 null 保持区别。不会将完整请求正文、凭据或整份响应拼入终端。服务端消息当前读取顶层 msg/message，其他结构需要通过 evidence_query 定位，不自动猜测。

查看报告请打开报告文件；模型排查仍优先 flow_diagnose/evidence_query，避免把人类阅读报告全文塞入对话。本地回环演示仅证明工具行为，不等同于公司业务验收。
