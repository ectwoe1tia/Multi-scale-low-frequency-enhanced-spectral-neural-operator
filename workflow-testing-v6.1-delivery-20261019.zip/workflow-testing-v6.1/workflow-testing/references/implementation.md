# 实现纲要

```text
初审需求/Word/PDF → document_import → cases_build + 模型语义分析 → suite.json
Apifox Markdown → api_discover → catalog + 用户规约 → adapter_build → adapter.json
HAR/Recorder → trace_import → trace_match + 文档预期/新数据 binding → plan_from_trace
JSON 请求 → Invoke-WorkflowTool.ps1 → toolchain.py
  ├─ suite.py：设计校验/导出/生成项目 Skill
  ├─ http_runner.py：计划/指纹/curl/断言/证据/妥协
  ├─ capabilities.py：接口发现、规约编译、来源校验与请求约束
  ├─ intake.py：DOCX/PDF/文本提取、已写用例、冲突/缺口汇总
  ├─ trace_tools.py：HAR/Recorder 导入、HTTP 匹配与显式绑定
  ├─ intake_schema.py：新输入契约的机器 schema
  └─ snapshot/claim/release：协作控制
```

suite.py 兼容第一版命令，供维护和迁移；给其他模型的日常统一入口是 toolchain.py/PowerShell。

## 已实现

- 初审需求的来源、明确/未决规则、分类用例、澄清和覆盖约定。
- Apifox 常见 Markdown 声明发现、稳定 operation ID、按规约生成 adapter、来源变更检测和请求前数据限制。
- DOCX 正文/表格、PDF 文本层、Markdown/TXT 提取，已写用例合并与同名冲突提示。语义分析和扩展分类用例仍由使用 Skill 的模型完成。
- HAR 和 Chrome Recorder JSON 导入，历史响应与业务预期分开；绑定新数据、角色和 capture 后执行 HTTP 测试。
- 跨文件验证，拒绝未知字段/操作/变量、漏掉业务断言、有歧义的自动化用例。
- HTTP operation、真实 curl、角色 bearer 环境变量、参数与 JSON body、JSON Pointer 检查和采集。
- 逐步状态检查、有界只读轮询、无写请求重试、运行去重、预览指纹、发送前日志、脱敏及证据校验和。
- 原始结果和 gate 分开；精确失败签名、版本、环境、批准日期匹配；未执行步骤继续阻断。
- 中文设计报告/CSV、运行报告、项目 Skill 生成、PowerShell 路径兼容。
- 文件哈希、单写者租约、变更与交接约定。
- 本地 HTTP 采购演示，验证财务节点与越权拒绝。它不是 Flowable 或低代码产品。

## 尚未实现

- OCR、旧 .doc 转换、任意排版 PDF 表格恢复、图片/修订意见的完整读取。
- 任意自然语言文档的纯脚本语义理解：cases_build 不代替 LLM 需求分析，不声称完整覆盖。
- 具体低代码产品映射、真实 Flowable JVM/JUnit 桥接、具体自研程序映射。
- 浏览器实际回放、DOM/视觉断言、截图、上传、企业代理、客户端证书、OAuth 刷新。Recorder 支持的是动作到 HTTP 的显式绑定。
- 引擎强制跳转、时钟推进、SQL 夹具、流程迁移、生产运行。
- 实际 MCP server、远程协作平台、测试管理数据库。

缺能力时列明缺口，不通过 shell/eval 临时绕过契约。

## 三类接入

低代码：收集真实测试环境、接口、字段和角色，将创建单据、查待办、办理任务、查询状态映射为 operation。身份分开。仅有页面的系统保留 suite，另按扩展规定实现浏览器适配。

Flowable：先用业务接口验证权限/表单/副作用，再按实际引擎版本补充模型测试。直接 TaskService 完成任务不等于应用授权通过。任务按集合处理，用 task_id/execution_id/scope 区分并行/会签。示例不含真实 Flowable 路径，接入时核对本地代码和官方版本文档。

自研：映射已有 API 与状态转换；不足时由开发补测试数据工厂和状态查询，不直接改业务表制造通过。先验证主路径、权限负例和异常恢复，再扩展。

## 节点交接

最后的只读步骤应断言目标任务、候选人、业务字段、历史顺序及不应残留的任务。交付真实实例/单据 ID、准备模式、保留期限。通用 runner 不自动删除实例；清理需单独注册并限定本轮数据，排除验收实例。本地 demo 退出后内存实例失效，不能交给用户继续验收。

## 后续顺序

1. 选真实流程，从初审文档生成 suite，解决路径/角色歧义。
2. 从 Apifox 导出与用户规约生成 adapter，从文档预期和轨迹绑定 plan，预览请求后执行并检查证据。
3. 根据真实问题增加恢复、通知、会签等，新能力走扩展协议。
4. 按宿主需求决定是否增加 MCP 薄封装，不改变核心判定。

文件锁不是安全沙箱；可写进程仍能改证据。环境标签也不证明真实环境，部署隔离、账号权限和业务批准由项目自身保证。

## v4 已实现扩展（runner 2.2.0）

多级文件引用、逐用例会话、固定请求生成、简短回执、稳定 attempt 与不确定执行阻断、显式重试/核对、未发送取消、分层经验、会话报告及项目 Skill 小索引已实现。接续文档见 [v4-handoff.md](v4-handoff.md)，实际验证报告位于交付根目录 REPORT.md；旧内容中的 v3 状态为历史范围，不表示新增能力缺失。

## v5 当前范围 / runner 3.0.0

已实现刷新 gate、有限 DSL 和规则工具生成、离线 BPMN/Flowable 模型快照图与覆盖、Recorder/HAR 显式/候选对齐、命名查询、版本化经验和跨进程文件接续。未实现通用生成 Python、多步配方、完整并行路径语义、任意 UEL 可满足性、SQLite 或在线定义采集。实际契约见 v5.md，交付报告保留真实验证日志。
