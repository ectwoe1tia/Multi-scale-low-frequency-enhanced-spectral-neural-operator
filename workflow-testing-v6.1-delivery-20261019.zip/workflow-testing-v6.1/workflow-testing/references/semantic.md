# 配置语义索引与组合批处理 · v6.1 / 20261019

本扩展把重复扫描和关系查询放到本地程序。模型只读当前字段的依赖切片、异常码和候选摘要，不读整份 HAR、低代码配置或图。工具只做静态分析；现有受管会话承担实际接口执行。新增模块只依赖 Python 标准库 ast/sqlite3，不要求安装数据库服务。

## 编译模型与实际边界

管线：文件集合 → 严格 JSON 解码 → 结构树与嵌套 JSON → 配置 profile → 受限表达式 AST → 符号解析 → 依赖索引 → 有界查询/差异 → 候选 → 用户确认 → 声明式 recipe。

- 结构节点保存稳定 ID、文件 ID、JSON Pointer、类型、长度、标量摘要；不复制标量原文。嵌套字符串 JSON 使用虚拟段 `/$json`，此段仅适用于语义索引定位，不是原文件可直接使用的 JSON Pointer。
- profile 用显式选择器描述定义、引用、表达式、类型/范围/枚举约束，避免写死某家低代码平台。选择器仅支持 JSON Pointer 的单段 `*`，不接受任意 JSONPath、SQL 或代码。
- `python_subset` 使用 `ast.parse`，保留结构化 AST/IR，提取成员访问；支持算术、比较、布尔与条件表达式。拒绝函数调用、赋值、导入、动态下标；不调用 eval/exec，不执行表达式。字面量和符号只保存类型/摘要。
- 这是表达式的保守读取依赖：条件分支两侧都可能被提取，不能证明某次执行走了该分支。没有完整控制流图、SSA、别名分析或跨语言程序分析。
- 通用 `${name.path}` 模板可以提取引用，需要 namespace=`template` 的 define 规则解析。JavaScript/UEL/脚本不能伪装为 Python 子集；不支持语法标记 OPAQUE，不猜成已解析。支持 JSON 配置结构；不直接解析整个前后端源码仓库。
- profile 可把请求 ID、事件 ID、parent ID 等字段配置为 define/reference，以建立显式关联。相同值或相邻请求只提供候选证据，不证明因果、角色权限或业务 expected；原有 trace_align 继续负责 Recorder/HAR 事件对齐。

这些设计借鉴了 [Python AST](https://docs.python.org/3/library/ast.html) 的结构化语法表示、[Clang AST](https://clang.llvm.org/docs/IntroductionToTheClangAST.html) 的节点遍历思想，并用 SQLite 固定查询保存图。没有嵌入 Clang，也没有实现通用编译器。图遍历采用程序控制的有界 BFS；SQLite 的[递归查询文档](https://sqlite.org/lang_with.html)是扩展参考，不接受模型输入 SQL。

## 文件集合与编译

所有路径均相对 workspace。创建 file-set.json，参考 assets/file-set.example.json；通过 includes 引用子集合。显式文件清单，拒绝重复 ID/路径、循环和越界路径，不自动递归扫描项目与凭据目录。

profile.json 参考 assets/semantic-profile.example.json。字段必须按实际平台资料配置；不能把示例的金额范围当成业务要求。未匹配规则在 summary.unmatched_profile_rules 中列出，不能认为已完成校验。

compile.json：

```json
{"file_set":"file-set.json","profile":"profile.json","cache":".semantic-cache"}
```

requests/compile.json：

```json
{"protocol_version":"1.0","tool":"semantic_compile","arguments":{"spec":"compile.json","out":"analysis/revision-001"}}
```

使用已有 toolchain.py 的 `--request ... --response-file ... --control` 文件入口。输出 index.sqlite、manifest.json、summary.json；完整图留磁盘，不输出大型 JSON 图。

缓存按源文件哈希、文件 ID、profile、实现摘要分片。相同内容复用分片，变更后只重新解析受影响文件，再做全局符号解析。profile/代码变化使缓存失效。每次查询仍校验输入哈希，所以节省的是解析和模型上下文，不是完全免除磁盘读取。

限制：单文件 32 MiB、集合 256 MiB、最多 256 文件/200,000 节点、深度 80、profile 最多 128 规则、表达式 4096 字符/256 AST 节点。超限明确失败，不静默截断后宣称完整。原始 JSON 按文件加载内存，不是超大 HAR 流式解析器；更大输入应由项目导出器按请求/配置实体分文件。

## 只查询局部

semantic_query 参数为 index/query/out，均为文件引用。query 内容示例：

```json
{"kind":"dependencies","node":{"file":"config","pointer":"/conditions/0/expression"},"depth":2,"limit":8,"max_bytes":4096}
```

具名查询：summary、nodes、issues、dependencies、impact。nodes/issues 可以按 file、精确 pointer 过滤，issues 可按 code；limit/offset 分页。默认 4096 字节，最大 8192；切片深度最多 6、访问边最多 1000，截断和 next_offset 明示。依赖边由读取者指向定义，impact 沿反向查使用者。结果不包含原始标量或表达式正文；需要原文时才在已授权范围查询来源的指定位置。

semantic_diff 接收 before/after 两个 manifest 和 out。旧快照允许来源过期，但数据库/实现摘要仍校验；新快照必须新鲜。完整字段变化清单写文件，回执只有计数和路径。用于确定本轮应重新排查哪些字段，不能证明业务影响范围完整。

## 异常与乱码

确定问题：非法 UTF-8/重复 JSON 键导致输入拒绝；替换字符 U+FFFD、未配对 surrogate、非预期控制字符、嵌套 JSON 解析失败、声明类型/范围/枚举不符进入问题索引。可疑项：部分常见乱码组合、键中的双向控制符；只给 warning，不自动改编码。重复/缺失/含糊符号、未支持表达式、base64 HAR 内容分别标记。语法有效的异常业务值只有存在明确 profile 约束才可判断。

凭据文件名 tokens/credentials 拒绝作为来源；敏感键子树及 HAR 敏感 name/value 条目不展开。不保证识别放在任意普通字段里的秘密，源文件仍需按公司要求脱敏。本地索引中的摘要是关联用途，不是密码保护或匿名化证明。

## 候选、确认与可执行经验

semantic_propose 接收 index/spec/out，支持两种 spec：

```json
{"seeds":[{"file":"config","pointer":"/payload/$json/flowId"}]}
```

自动候选仅针对至少 8 字符的字符串摘要相等，匹配多于 20 项视为低区分度跳过；不基于 ID 大小、相邻顺序推断因果。最多 16 个种子/100 个候选。或者显式提交 hypotheses：

```json
{"hypotheses":[{"from":{"file":"config","pointer":"/condition"},"to":{"file":"config","pointer":"/fields/amount/name"},"predicate":"depends_on","evidence":["inputs/config.json"]}]}
```

候选文件绑定来源和证据哈希，状态始终 candidate。**未得到用户确认，不得由模型自行写 accept 或冒充 reviewer。** 用户可确认部分候选、拒绝部分，剩余保持待定。确认文件格式：

```json
{"proposals_sha256":"候选文件的实际SHA256","reviewer":"确认人标识","decisions":[{"id":"实际候选ID","decision":"accept"}]}
```

用 semantic_promote(index,proposals,review,out) 生成 recipe.json、check.request.json 和可组合 batch.json。没有自动执行或自动生效；批处理入口不允许调用 promote。确认文件与哈希记录同意范围，但本地文件机制无法认证填写者是否真是人，需公司权限或评审系统保证。

recipe 是由固定 semantic_check 解释的声明式小程序，不生成/导入任意 Python。支持 equal（同类型标量摘要）、same_type、depends_on（直接语法依赖）、co_occurs（两处存在）；不把它们声称为因果证明。容器相等未实现，返回 UNKNOWN；字段缺失也为 UNKNOWN。

recipe 可检查新数据版本，要求相同 profile 和文件 ID 范围；记录 baseline_changed。新的 profile/代码/范围须重新确认。不能修改 recipe 添加未确认断言；保存旧候选、review 和 recipe，不覆盖历史文件。例外、适用范围和反例可以继续用 knowledge_record 留证。

累积方式：每次只查询一个疑点 → 保存候选 → 请求用户确认 → 生成 recipe → 后续批次自动检查 → 把失败反例与版本留在项目 knowledge 目录。当前候选搜索是确定性的相等关联，不是自动学习任意业务规则。

## 组合批处理与额度接续

batch.json 引用多个请求文件，并支持 includes 子批次与 depends_on。参考 assets/batch.example.json。固定入口：

```powershell
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowBatch.ps1' -Batch 'E:\company\workspace\batch.json' -State 'batch-state/run-001'
```

Batch 顶层文件必须位于 workspace 根目录；State 相对该根目录。同一命令可在预算暂停后继续，只执行 TODO。改预算或任务文件会改变批次签名，不能悄悄改原批次；新批次需保留旧记录并重新安排范围。内含子 batch 只能通过根集合引用，不能把它当新 workspace 直接调用。

- max_tasks 默认 10、最多 100；max_seconds 默认 30、最多 300，是任务之间的检查点，不会强行杀死正在执行的 HTTP。建议短批次保障交互。
- parallel_queries 默认 1、最多 4，只并行独立 semantic_query/tool_help；编译和业务请求串行。
- 静态白名单允许本扩展编译/查询/差异/提案/检查及原 flow_analysis、trace_align、rules_codegen、artifact_query、tool_help。其余操作显式拒绝，尤其是原始 run、shell 和 promote。
- 业务任务引用 session 文件和固定 action，顶层必须显式 allow_execute=true 才能包含 execute。仍经过 v6 file_only 入口，不复制 token。该开关不替代用户对测试范围的授权。
- 将 semantic_check 作为 prepare 的依赖，再将 prepare 作为 execute 的依赖，可使已确认关系成为该批次的前置检查。它不会自动改造所有旧 session 的执行入口；直接单独执行 session 时不包含这个可选前置检查。
- 记录状态与独立回执后推进。FAILED 停止；中断 RUNNING 视为 UNKNOWN，不重发。人工先按原会话核对副作用，再创建明确范围的新批次。不要删除 state/lock、换 run_id 来跳过不确定性。
- 拒绝任务环、重复输出、覆盖输入。状态文件、回执哈希与输入签名用于合作代码一致性，不是对抗任意本地写者的安全沙箱。

## 接力最小上下文

常驻：SKILL 路由、当前 collection/profile/index/recipe 引用、当前批次状态与一个疑点。按需：短切片/问题页/候选。磁盘：源配置、HAR、AST 索引、缓存、完整变化清单、所有回执与确认历史。交接记录版本、workspace、根 batch 路径、State 路径、待确认候选路径即可；不把 SQLite 导出或大配置重新贴入对话。
