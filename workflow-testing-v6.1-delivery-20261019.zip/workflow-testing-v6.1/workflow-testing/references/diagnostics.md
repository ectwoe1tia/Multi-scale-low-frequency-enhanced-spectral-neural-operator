# v5：小上下文排查与确定性边界

适用于 v5 修订标记 `20261014-control`，runner 仍为 3.0.0，请求协议仍为 1.0。这是用户要求保留版本号的维护修订；以包 SHA-256 / generator_digest 区分构建。旧项目升级后原刷新凭据和生成物可能因代码摘要变化失效，按已有流程刷新/重新生成，不删除严格策略。

## 入口：文件请求、控制输出

```powershell
python -X utf8 <skill>/scripts/toolchain.py --workspace <workspace> --request <workspace>/calls/current.json --response-file replies/unique.json --control
# PowerShell 包装等价参数：-ResponseFile replies/unique.json -Control
```

`--control` 和 `--brief` 互斥，均要求 response-file。完整回执在 dispatch 前独占预留；冲突不会再次发送 HTTP。control 的 JSON 输出最多 4096 UTF-8 字节（不计终端换行），只有工具名、code、action、automatic_retry=false、回执及至多几个引用，不复制任意 message、业务值或大列表。只在需要时读引用文件；诊断与查询输出自身也受字节预算约束。原始 CLI 模式保持兼容，不具有小输出保证。

| 场景 | 首选动作 | 保留在上下文 |
|---|---|---|
| 忘记接口参数 | tool_help，传 name | 单个工具的必填/可选参数及副作用 |
| 接续 | status → refresh | 当前 case、状态和下一请求引用 |
| 检查准备结果 | flow_diagnose | 步骤/断言数量、前 5 个操作/角色标识 |
| FAIL/ERROR | flow_diagnose | 断言 ID、错误码、证据 JSON Pointer |
| 看某个字段 | evidence_query | 默认类型/大小；必要时显式读取短标量 |
| UNKNOWN/INCOMPLETE | 核对真实副作用与旧写者状态 | 待核对项和证据引用；不自动重试 |
| 总结经验 | knowledge_record | 简短结论、适用版本、证据引用 |

## 工具契约

工具 envelope 都是 `protocol_version, tool, arguments`；所有路径相对 workspace。

**tool_help**：必填 `name`。从运行时 TOOLS 直接投影 required/optional，结合闭合副作用表返回 category、business_network、local_writes、automatic_write_retry。未知工具拒绝。模板中的占位符需替换为契约规定类型；snapshot.files 是数组，claim.base_hashes 是对象。完整 schema 在 assets/tool-request.schema.json；单工具查询不加载全部工具。

**flow_diagnose**：必填 `project, case_id, out`，可选 `attempt`（四位编号，默认最新）。只读准备/运行证据并在项目内新写诊断文件，不变更 attempt/NEXT/运行结果，不创建 execute 请求。输出最多 8192 字节，返回结果引用和字节数。

- TODO：refresh_prepare；PREPARED：review_then_refresh_execute。
- PREPARED 来源漂移：cancel_stale_preparation_then_review_retry；不能直接重新 prepare 覆盖。
- FAIL：inspect_failed_checks；ERROR：inspect_execution_error。两者保持原始状态和 gate，最多列 5 个失败断言，不复制 actual/expected/error.message/context。
- UNKNOWN/INCOMPLETE：reconcile_side_effects。不加载未封存结果里的业务值。
- PASS：continue_status；CANCELLED/ABANDONED：review_explicit_retry。
- 元数据、plan 哈希或封存结果校验不一致则拒绝，不编造诊断结论。

`artifacts.plan/results` 给出引用和 SHA-256。来源漂移只列数量和至多 5 个路径。以上是确定的排查路由，不能推断根因，更不代表已经授权再次执行。

**evidence_query**：必填 `project, case_id, query, out`，可选 `attempt`。query 内容：

```json
{
  "artifact": "results",
  "sha256": {"$file": "project/inspect/diagnosis.json", "pointer": "/artifacts/results/sha256"},
  "pointers": ["/cases/0/failures/0/actual", "/cases/0/failures/0/expected"],
  "mode": "structure",
  "max_bytes": 2048
}
```

sha256 可以是 64 位哈希或上述文件指针；程序取值，模型不手抄哈希。不支持任意表达式或脚本。查询只允许指定 attempt 的 `plan/preview/results`，不接受任意源文件路径。results 必须完整封存并通过校验。preview 是派生视图，查询者必须另行取得其哈希，完整性权威为已绑定的 plan/运行证据，不能凭 preview 取得执行权限。

1..8 个无重复 JSON Pointer，单指针最多 240 字符。structure 只返回类型、序列化字节数、容器/字符串长度；missing 与 null 分开。value 仅返回标量，容器和超大标量拒绝，禁止以超长列表绕过。max_bytes 默认 2048，可设 512..8192，约束最终落盘的 UTF-8 JSON；超限返回 QUERY_TOO_LARGE，无自动截断实际值。敏感键路径显示 REDACTED；这不是未知秘密的通用检测器，凭据仍由原执行环境管理。输出路径限当前项目且不得覆盖。

## 模块边界与扩展位置

```mermaid
flowchart LR
  M[模型：意图与证据判断] --> Q[JSON 请求文件]
  Q --> D[toolchain：参数与副作用契约]
  D --> S[静态编译/诊断/查询]
  D --> E[run / flow_execute]
  S --> F[文件证据及短结果]
  E --> G[新鲜度/权限/断言/意图记录]
  G --> H[HTTP transport]
  H --> F
  F --> M
```

| 变更 | 位置 | 验证边界 |
|---|---|---|
| 接口地址、角色、参数 | adapter/policy/文件夹具 | 已注册操作和 guards，不生成任意 URL 调用 |
| 业务条件、覆盖义务 | DSL、suite、来源文件 | 固定操作符及来源；录制事实不决定 expected |
| 通用编译/分析 | rules_codegen/flow_analysis/trace_align | 不进入执行器，不动态导入业务脚本 |
| 排查投影 | inspection | 状态/指针与值分开，大小/完整性测试 |
| 新工具 | TOOLS + tool_contracts + 导出 schema | 必须显式声明副作用，无默认授权 |
| 网络/运行语义 | http_runner | 回环 HTTP 正反例，不重发、不削弱断言 |

toolchain.dispatch 为每个注册工具设置 ContextVar 能力；只有 run、flow_execute 标记业务网络。静态父调用的能力不能被嵌套 run 提升。advanced_tools 的直接 dispatch 同样强制静态能力；run_plan 入口及 curl_request 端口均检查 EFFECT_DENIED，阻断发生在运行目录创建或 transport 之前。

这是协作代码的边界，不是 OS 沙箱。原有直接 Python 调用 http_runner 的集成保留兼容；绕开受支持入口、恶意修改源码、新线程丢失上下文或自行发 socket，不在此边界的防护承诺中。静态模块本次没有新增线程。不得把此机制称为任意不可信插件隔离。

CI 执行 `python -X utf8 scripts/check_boundaries.py`：检查 5 个维护中的静态模块不得导入网络/进程执行设施，不调用执行/动态代码入口；检查全部注册工具与副作用表一致。该 AST 检查是架构回归检查，不是完备数据流分析。新增静态模块时加入 STATIC_MODULES；新增合法能力走显式审查和行为测试。

## 测试架构借鉴与实际落地

- [Playwright fixtures](https://playwright.dev/docs/test-fixtures)：按用例准备所需资源并隔离状态。这里沿用 case/attempt 文件夹、独立夹具与显式重试，不引入浏览器 fixture 引擎。
- [Playwright Trace Viewer](https://playwright.dev/docs/trace-viewer)：先定位步骤再查证据。这里以 failed_checks 的指针做延迟读取，不要求模型吞下整段 trace。
- [pytest fixtures](https://docs.pytest.org/en/stable/how-to/fixtures.html)：显式依赖与受控生命周期。本包继续使用 unittest + TemporaryDirectory；通用输入用文件引用，不添加全局可变业务缓存。
- [Pact 契约验证](https://docs.pact.io/getting_started/how_pact_works)：契约生成与实际验证结果分开。这里区分 schema、规则校验、静态覆盖与真实 HTTP 结果；未实现 Pact 协议适配。
- [ArchUnit 架构检查](https://www.archunit.org/userguide/html/000_Index.html)：把依赖边界纳入测试。这里用标准库 AST + 运行时能力检查，无需 Java/额外依赖；不宣称与 ArchUnit 功能等价。

## 验证与接续

运行 `python -X utf8 -m unittest discover -s tests -v` 和架构检查。新能力需正例、超限/错误字段反例、来源漂移、静态嵌套执行阻断、真实 CLI/PowerShell 测试。原 HTTP 回环测试继续证明合法执行正常、保护未被削弱。

常驻只留 SKILL 核心、当前控制回执/诊断摘要；流程专项契约按需加载；大来源/夹具/响应/trace 放文件；经验证经验放项目 knowledge 并绑定适用版本；更改通用能力才进入维护区与行为测试。交接引用 status、当前 diagnosis/query 和未决项，不把单次业务数据升级为全局规则。
