import contextlib
import copy
import io
import json
import shutil
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import test_v5
import toolchain as tc
import http_runner as rt
import file_workflow as fw
import inspection
import advanced_tools
import execution_boundary as boundary
import check_boundaries
import tool_contracts
import v5_schema


class InspectionTests(unittest.TestCase):
    def setUp(self):
        self.h = test_v5.V5Tests()
        self.h.setUp()
        self.root = self.h.root
        self.cid = 'TC-DEMO-1'

    def tearDown(self):
        self.h.tearDown()

    def args(self, out='project/inspect/result.json'):
        return dict(project='project/project.json', case_id=self.cid, out=out)

    def prepare(self):
        self.h.call('flow_prepare', project='project/project.json', case_id=self.cid)
        return self.h.get('project/attempts/' + self.cid + '/0001/meta.json')

    def sealed(self, status='FAIL', big=False):
        meta = self.prepare()
        large = 'BUSINESS-CANARY-' + ('敏感明细' * 80000 if big else 'VALUE')
        failure = {'step_id':'S1', 'check_id':'C1', 'assertion_id':'A1',
                   'pointer':'/json/customer', 'actual':large, 'expected':large, 'status':'FAIL'}
        case = {'case_id':self.cid,'execution_status':status,'gate':'BLOCKED',
                'failures':[failure] if status == 'FAIL' else [],'steps':[],
                'unexecuted_steps':['S2'],'context':{'account':large},
                'error':{'code':'CAPTURE_ERROR','message':large}}
        value = {'run_id':meta['run_id'],'fingerprint':meta['fingerprint'],
                 'finished_at':'2026-10-14T00:00:00Z','status':status,'gate':'BLOCKED','cases':[case]}
        ref = 'runs/' + meta['run_id'] + '/results.json'
        self.h.put(ref,value)
        (self.root / ref).with_suffix('.sha256').write_text(fw.sha(self.root / ref),encoding='ascii')
        return ref

    def diagnosis(self, name='one'):
        result = self.h.call('flow_diagnose', **self.args('project/inspect/' + name + '.json'))
        return self.h.get(result['result'])

    def query(self, artifact, pointers, mode='structure', budget=2048, name='query', digest=None):
        diag = self.diagnosis(name + '-diag')
        self.h.put(name + '.json', {'artifact':artifact,'sha256':digest or diag['artifacts'][artifact]['sha256'],
                                  'pointers':pointers,'mode':mode,'max_bytes':budget})
        result = self.h.call('evidence_query', query=name + '.json', **self.args('project/inspect/' + name + '.json'))
        return self.h.get(result['result'])

    def test_todo_diagnosis_needs_no_business_input_or_network(self):
        with patch.object(rt, 'curl_request', side_effect=AssertionError('network')):
            d = self.diagnosis()
        self.assertEqual(d['action'],'refresh_prepare')
        self.assertFalse(d['automatic_retry'])
        self.assertEqual(d['artifacts'],{})

    def test_prepared_counts_and_drift_do_not_change_attempt(self):
        self.prepare()
        before = fw.sha(self.root/'project/attempts/TC-DEMO-1/0001/meta.json')
        d = self.diagnosis()
        self.assertGreater(d['prepared']['checks'],0)
        self.h.put('suite.json', {**self.h.suite,'project':'changed'})
        d = self.diagnosis('drift')
        self.assertEqual(d['action'],'cancel_stale_preparation_then_review_retry')
        self.assertEqual(fw.sha(self.root/'project/attempts/TC-DEMO-1/0001/meta.json'),before)

    def test_large_failure_diagnosis_never_copies_values_or_exception_messages(self):
        ref = self.sealed(big=True)
        self.assertGreater((self.root/ref).stat().st_size,1000000)
        d = self.diagnosis()
        self.assertEqual(d['execution']['failure_count'],1)
        self.assertIn('evidence_pointer',d['failed_checks'][0])
        self.assertNotIn('BUSINESS-CANARY',json.dumps(d))
        self.assertLess((self.root/'project/inspect/one.json').stat().st_size,8192)

    def test_fail_and_error_have_distinct_actions(self):
        self.sealed('ERROR')
        d = self.diagnosis()
        self.assertEqual(d['action'],'inspect_execution_error')
        self.assertEqual(d['execution']['error_code'],'CAPTURE_ERROR')
        self.assertNotIn('message',json.dumps(d))

    def test_unknown_does_not_read_unsealed_response_or_retry(self):
        meta = self.prepare()
        self.h.put('project/attempts/TC-DEMO-1/0001/intent.json',{'kind':'execute'})
        self.h.put('runs/'+meta['run_id']+'/results.json',{'bad':'BUSINESS-CANARY'})
        d = self.diagnosis()
        self.assertEqual(d['action'],'reconcile_side_effects')
        self.assertNotIn('results',d['artifacts'])
        self.h.put('q.json',{'artifact':'results','sha256':'0'*64,'pointers':['']})
        self.h.error('EVIDENCE_UNAVAILABLE','evidence_query',query='q.json',**self.args())

    def test_tampered_plan_and_sealed_run_are_rejected(self):
        ref = self.sealed()
        self.h.put(ref,{'tampered':True})
        self.h.error('EVIDENCE_CHANGED','flow_diagnose',**self.args())

    def test_tampered_plan_hash_rejected(self):
        self.prepare()
        self.h.put('project/attempts/TC-DEMO-1/0001/plan.json',{})
        self.h.error('EVIDENCE_CHANGED','flow_diagnose',**self.args())

    def test_shape_distinguishes_missing_null_array_and_large_string(self):
        self.sealed(big=True)
        d = self.query('results',['/cases/0/failures/0/actual','/cases/0/failures','/absent'])
        self.assertEqual([r['type'] for r in d['rows']],['string','array','missing'])
        self.assertNotIn('value',d['rows'][0])
        self.assertNotIn('BUSINESS-CANARY',json.dumps(d))
        self.assertEqual(inspection._kind(None),'null')

    def test_scalar_projection_is_explicit_and_bounded(self):
        self.sealed()
        d = self.query('results',['/cases/0/failures/0/actual'],mode='value')
        self.assertEqual(d['rows'][0]['value'],'BUSINESS-CANARY-VALUE')

    def test_container_projection_and_large_scalar_refused(self):
        self.sealed(big=True)
        for name,pointer in [('container','/cases'),('scalar','/cases/0/failures/0/actual')]:
            with self.assertRaises(rt.ToolError) as e:
                self.query('results',[pointer],mode='value',name=name)
            self.assertEqual(e.exception.code,'QUERY_TOO_LARGE')
            self.assertFalse((self.root/('project/inspect/'+name+'.json')).exists())

    def test_query_hash_required_and_revision_checked(self):
        self.sealed()
        with self.assertRaises(rt.ToolError) as e:
            self.query('results',['/status'],digest='0'*64)
        self.assertEqual(e.exception.code,'EVIDENCE_CHANGED')

    def test_secret_pointer_values_redacted(self):
        meta = self.prepare()
        path = 'project/attempts/TC-DEMO-1/0001/plan.json'
        plan = self.h.get(path)
        plan['cases'][0]['vars']['token'] = 'NEVER-PRINT'
        self.h.put(path,plan)
        meta['plan_hash'] = fw.sha(self.root/path)
        self.h.put('project/attempts/TC-DEMO-1/0001/meta.json',meta)
        d = self.query('plan',['/cases/0/vars/token'],mode='value')
        self.assertEqual(d['rows'][0]['value'],'[REDACTED]')

    def test_digest_file_reference_avoids_copying_hashes_into_context(self):
        self.sealed()
        self.diagnosis()
        self.h.put('q.json',{'artifact':'results',
                            'sha256':{'$file':'project/inspect/one.json','pointer':'/artifacts/results/sha256'},
                            'pointers':['/status'],'mode':'value'})
        d = self.h.call('evidence_query',query='q.json',**self.args())
        self.assertEqual(self.h.get(d['result'])['rows'][0]['value'],'FAIL')

    def test_outside_project_and_overwrite_rejected(self):
        self.h.error('INVALID_INPUT','flow_diagnose',**self.args('elsewhere.json'))
        self.diagnosis()
        with self.assertRaises(FileExistsError):
            self.diagnosis()

    def test_query_strict_schema_budget_and_pointer_limits(self):
        self.prepare()
        digest = self.diagnosis()['artifacts']['plan']['sha256']
        base = {'artifact':'plan','sha256':digest,'pointers':['/cases']}
        for i,mod in enumerate([{'sql':'select 1'},{'artifact':'../../secret'},
                                {'pointers':['/bad~2']},{'pointers':['/a']*9},
                                {'max_bytes':True},{'mode':'eval'}]):
            self.h.put('q.json',{**base,**mod})
            self.h.error('INVALID_INPUT','evidence_query',query='q.json',**self.args('project/q%d.json'%i))

    def test_all_tools_have_effects_and_help_matches_runtime_registry(self):
        self.assertEqual(set(tc.TOOLS),set(tool_contracts.EFFECTS))
        for name in tc.TOOLS:
            d = self.h.call('tool_help',name=name)
            self.assertEqual(d['arguments']['required'],tc.TOOLS[name][0])
            self.assertEqual(d['argument_schema']['required'],tc.TOOLS[name][0])
            self.assertEqual(d['effects']['business_network'],name in ('run','flow_execute'))
        self.h.error('INVALID_INPUT','tool_help',name='run_shell')

    def test_static_tool_cannot_enter_transport_or_execution_even_nested(self):
        for entry in (lambda: rt.curl_request(None,None,None,None,None,None,None,None,None),
                      lambda: rt.run_plan(None,None,None,None,None,None),
                      lambda: self.h.call('run',suite='suite.json',adapter='adapter.json',plan='plan.json',
                                          expected_fingerprint=rt.validate_bundle(self.h.suite,self.h.adapter,self.h.plan)['fingerprint'],run_id='NESTED')):
            with patch.object(advanced_tools.flow_analysis,'analyze',side_effect=lambda *a: entry()):
                self.h.error('EFFECT_DENIED','flow_analysis',project='project/project.json',spec='unused.json',out='project/unused')
        self.assertFalse((self.root/'runs').exists())

    def test_boundary_context_resets_on_exception(self):
        with self.assertRaises(RuntimeError):
            with boundary.scope(False):
                raise RuntimeError()
        # Legacy direct Python integrations remain compatible after a static error.
        boundary.check_transport()
        with boundary.scope(True):
            boundary.check_transport()
            with boundary.scope(False):
                with self.assertRaises(rt.ToolError):
                    with boundary.scope(True):
                        boundary.check_transport()

    def test_architecture_check_detects_offline_network_and_eval(self):
        self.assertTrue(check_boundaries.check()['ok'])
        issues = check_boundaries.check_source('import subprocess\nrt.run_plan()\neval("1")\n','bad.py')
        self.assertEqual(len(issues),3)

    def test_control_view_drops_messages_values_and_large_lists(self):
        full = tc.envelope('flow_execute','TEST_FAILED',
                           {'results':'runs/r/results.json','actual':'BUSINESS-CANARY'*100000,
                            'not_selected_cases':['SECRET']*10000},message='SECRET-ERROR')
        d = inspection.control_response(full,'replies/one.json')
        self.assertEqual(d['action'],'diagnose_case')
        self.assertFalse(d['automatic_retry'])
        self.assertNotIn('SECRET',json.dumps(d))
        self.assertNotIn('BUSINESS-CANARY',json.dumps(d))
        self.assertLess(len(json.dumps(d)),4096)

    def test_control_cli_writes_full_receipt_and_only_emits_small_refs(self):
        self.h.put('req.json',fw.request('flow_diagnose',**self.args()))
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            code = tc.main(['--workspace',str(self.root),'--request',str(self.root/'req.json'),
                            '--response-file','reply.json','--control'])
        self.assertEqual(code,0)
        d = json.loads(stdout.getvalue())
        self.assertEqual(d['refs']['result'],'project/inspect/result.json')
        self.assertLess(len(stdout.getvalue().encode('utf-8')),4096)
        self.assertIn('bytes',self.h.get('reply.json')['data'])

    def test_control_powershell_entrypoint(self):
        powershell = shutil.which('powershell') or shutil.which('pwsh')
        if not powershell:
            self.skipTest('PowerShell unavailable')
        self.h.put('req.json',fw.request('flow_diagnose',**self.args()))
        script = Path(tc.__file__).with_name('Invoke-WorkflowTool.ps1')
        p = subprocess.run([powershell,'-NoProfile','-File',str(script),
                            '-Workspace',str(self.root),'-Request',str(self.root/'req.json'),
                            '-ResponseFile','powershell-reply.json','-Control'],
                           capture_output=True,encoding='utf-8',timeout=30)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(json.loads(p.stdout)['refs']['result'],'project/inspect/result.json')

    def test_diagnosing_does_not_invalidate_execution_receipt(self):
        self.h.strict()
        self.h.prepare()
        execute = self.h.get('project/attempts/TC-DEMO-1/0001/execute.request.json')
        self.diagnosis()
        import freshness
        freshness.guard(self.root,'flow_execute',execute['arguments'])

    def test_control_budget_counts_actual_unicode_serialization(self):
        response = tc.envelope('flow_diagnose',data={'result':'文'*170,'focus':'件'*170})
        d = inspection.control_response(response,'文'*1400)
        self.assertLessEqual(len(json.dumps(d,ensure_ascii=False).encode('utf-8')),4096)

    def test_response_collision_does_not_dispatch(self):
        self.h.put('req.json',fw.request('flow_diagnose',**self.args()))
        self.h.put('reply.json',{'old':True})
        with patch.object(tc,'dispatch') as dispatch, contextlib.redirect_stdout(io.StringIO()):
            code = tc.main(['--workspace',str(self.root),'--request',str(self.root/'req.json'),
                            '--response-file','reply.json','--control'])
        dispatch.assert_not_called()
        self.assertNotEqual(code,0)

    def test_exported_schemas_equal_runtime(self):
        skill = Path(__file__).resolve().parents[1]
        self.assertEqual(rt.read_json(skill/'assets/v5.schema.json'),v5_schema.schema())
        self.assertEqual(rt.read_json(skill/'assets/tool-request.schema.json'),tc.protocol_schema())


