import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import toolchain as tc
import file_workflow as fw
import http_runner as rt
import freshness
import v5_common as common
import rules_codegen as rules
import flow_model
from demo_support import DemoServer,make_assets

AUTH={'WF_DEMO_APPLICANT':'demo-applicant','WF_DEMO_MANAGER':'demo-manager','WF_DEMO_DIRECTOR':'demo-director'}
XML='''<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL"><process id="expense">
<startEvent id="start"/><userTask id="manager"/><exclusiveGateway id="decision" default="F-no"/>
<userTask id="director"/><endEvent id="end"/>
<sequenceFlow id="F-start" sourceRef="start" targetRef="manager"/>
<sequenceFlow id="F-decision" sourceRef="manager" targetRef="decision"/>
<sequenceFlow id="F-yes" sourceRef="decision" targetRef="director"><conditionExpression>${amount &gt; 10000}</conditionExpression></sequenceFlow>
<sequenceFlow id="F-no" sourceRef="decision" targetRef="end"/>
<sequenceFlow id="F-end" sourceRef="director" targetRef="end"/>
</process></definitions>'''

class V5Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='v5-')
        self.root=Path(self.tmp.name)
        self.suite,self.adapter,self.plan=make_assets(19001)
        self.init_project()
    def tearDown(self):self.tmp.cleanup()
    def put(self,ref,value):
        path=self.root/ref;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8');return ref
    def get(self,ref):return json.loads((self.root/ref).read_text(encoding='utf-8'))
    def call(self,tool,**args):return tc.dispatch(self.root,fw.request(tool,**args))['data']
    def error(self,code,tool,**args):
        with self.assertRaises(rt.ToolError) as e:self.call(tool,**args)
        self.assertEqual(e.exception.code,code,str(e.exception))
    def init_project(self):
        for ref,obj in [('suite.json',self.suite),('adapter.json',self.adapter),('plan.json',self.plan)]:self.put(ref,obj)
        self.put('session.json',{'suite':'suite.json','adapter':'adapter.json','plan':'plan.json'})
        self.call('flow_init',spec='session.json',out='project')
    def strict(self):return self.call('runtime_init',project='project/project.json',out='project/runtime/environment')
    def refresh(self,label='one',phase='prepare',cid='TC-DEMO-1',**args):
        return self.call('context_refresh',project='project/project.json',case_id=cid,phase=phase,out='project/context/'+label,**args)
    def prepare(self,label='one'):
        r=self.refresh(label)
        return self.call('flow_prepare',**self.get(r['next_request'])['arguments'])
    def rule(self,kind='constraint',require=None,status='confirmed'):
        self.put('source.json',{'requirement':'金额不得超过13000；金额大于10000经过总监'})
        return {'dsl_version':'1.0','id':'R-AMOUNT','kind':kind,'scope':{'operations':['create']},
                'when':{'literal':True},'require':require or {'op':'le','left':{'case_var':'amount'},'right':{'literal':13000}},
                'status':status,'source_refs':['source.json']}
    def compile(self,r=None,out='project/generated/rules',activate=True):
        self.put('rule.json',r or self.rule())
        self.put('rules-spec.json',{'rules':['rule.json'],'activate':activate})
        return self.call('rules_codegen',project='project/project.json',spec='rules-spec.json',out=out)
    def graph_fixture(self,xml=XML):
        (self.root/'expense.bpmn').write_text(xml,encoding='utf-8')
        self.put('definition.json',{'format':'bpmn_xml','file':'expense.bpmn','process_id':'expense',
                 'definition':{'id':'expense:1:xyz','key':'expense','version':1}})
        self.put('binding.json',{'definition_id':'expense:1:xyz','cases':[
            {'case_id':'TC-DEMO-1','activities':['start','manager','decision','director','end'],
             'edges':['F-start','F-decision','F-yes','F-end']}]})
        self.put('obligations.json',{'definition_id':'expense:1:xyz','obligations':[
            {'id':'O-DIRECTOR','activities_in_order':['manager','director'],'source_refs':['suite.json']},
            {'id':'O-DIRECT','activities_in_order':['decision','end'],'edges_in_order':['F-no'],'source_refs':['suite.json']}]})
        self.put('analysis.json',{'definition_ref':'definition.json','case_binding_ref':'binding.json','obligations_ref':'obligations.json'})
    def analyze(self,out='project/analysis/one'):
        return self.call('flow_analysis',project='project/project.json',spec='analysis.json',out=out)
    def traces(self):
        self.put('recorder.json',{'title':'demo','steps':[{'type':'navigate','url':self.adapter['base_url']+'/form'},
            {'type':'change','value':'password-secret','selectors':[['#password']]},{'type':'click','selectors':[['#submit']]}]})
        self.put('har.json',{'log':{'entries':[
            {'startedDateTime':'2026-10-13T00:00:00Z','time':10,'request':{'method':'POST','url':self.adapter['base_url']+'/instances',
             'headers':[{'name':'Authorization','value':'Bearer secret-canary'}],'postData':{'mimeType':'application/json','text':'{"amount":12000}'}},'response':{'status':201}},
            {'startedDateTime':'2026-10-13T00:00:01Z','time':10,'request':{'method':'GET','url':self.adapter['base_url']+'/instances/i-1'},'response':{'status':200}}]}})
        self.put('align-spec.json',{'session_id':'S-DEMO','environment':'local','recorder':'recorder.json','har':'har.json',
                                  'case_id':'TC-DEMO-1','attempt':'0001'})

    def test_runtime_init_is_static_and_does_not_require_curl(self):
        with patch('shutil.which',return_value=None),patch('socket.create_connection',side_effect=AssertionError('network prohibited')):
            info=self.strict()
        self.assertTrue(info['static_ready']);self.assertFalse(self.get(info['environment'])['execution_ready'])
    def test_missing_context_and_legacy_run_are_blocked(self):
        self.strict()
        self.error('CONTEXT_REQUIRED','flow_prepare',project='project/project.json',case_id='TC-DEMO-1')
        self.error('CONTEXT_REQUIRED','run',suite='suite.json',adapter='adapter.json',plan='plan.json',expected_fingerprint='x',run_id='Legacy')
        preview=rt.validate_bundle(self.suite,self.adapter,self.plan)
        with self.assertRaises(rt.ToolError) as e:rt.run_plan(self.root,self.suite,self.adapter,self.plan,preview,'Direct')
        self.assertEqual(e.exception.code,'CONTEXT_REQUIRED')
        self.assertFalse((self.root/'runs').exists())
    def test_state_rule_contract_and_expiry_refresh(self):
        self.strict();r=self.refresh()
        self.put('project/contracts/new.json',{'constraint':'new'})
        self.error('CONTEXT_STALE','flow_prepare',project='project/project.json',case_id='TC-DEMO-1',context_receipt=r['receipt'])
        r=self.refresh('new')
        with patch('freshness.time.time',return_value=self.get(r['receipt'])['issued_at']+601):
            self.error('CONTEXT_STALE','flow_prepare',project='project/project.json',case_id='TC-DEMO-1',context_receipt=r['receipt'])
        self.call('flow_prepare',project='project/project.json',case_id='TC-DEMO-1',context_receipt=r['receipt'])
        self.error('CONTEXT_STALE','flow_prepare',project='project/project.json',case_id='TC-DEMO-1',context_receipt=r['receipt'])
    def test_rule_change_invalidates_fresh_context(self):
        self.strict();self.compile();r=self.refresh()
        changed=self.get('rule.json');changed['require']['right']['literal']=15000;self.put('rule.json',changed)
        self.error('CONTEXT_STALE','flow_prepare',project='project/project.json',case_id='TC-DEMO-1',context_receipt=r['receipt'])
    def test_receipt_tamper_scope_and_explicit_refresh(self):
        self.strict();r=self.refresh()
        self.error('CONTEXT_STALE','flow_prepare',project='project/project.json',case_id='TC-DEMO-2',context_receipt=r['receipt'])
        receipt=self.get(r['receipt']);receipt['ttl_seconds']=999999;self.put(r['receipt'],receipt)
        self.error('EVIDENCE_CHANGED','flow_prepare',project='project/project.json',case_id='TC-DEMO-1',context_receipt=r['receipt'])
    def test_real_strict_http_and_repeat_do_not_resend(self):
        with DemoServer() as server,patch.dict(os.environ,AUTH):
            self.adapter['base_url']=f'http://127.0.0.1:{server.server_port}';self.put('adapter.json',self.adapter)
            self.strict();self.compile();prepared=self.prepare()
            req=self.get(prepared['execute_request'])
            outcome=self.call('flow_execute',**req['arguments'])
            self.assertEqual(outcome['status'],'PASS');self.assertEqual(len(server.calls),4)
            self.put('project/contracts/changed.json',{'new':'rule'})
            duplicate=self.call('flow_execute',project='project/project.json',case_id='TC-DEMO-1',attempt='0001')
            self.assertTrue(duplicate['reused_evidence']);self.assertEqual(len(server.calls),4)
    def test_execute_changed_case_blocks_without_sending(self):
        self.strict();prepared=self.prepare();req=self.get(prepared['execute_request'])
        case=self.get('project/cases/TC-DEMO-1.json');case['vars']['amount']=50000;self.put('project/cases/TC-DEMO-1.json',case)
        self.error('CONTEXT_STALE','flow_execute',**req['arguments'])
        self.assertFalse((self.root/'project/attempts/TC-DEMO-1/0001/intent.json').exists())
    def test_rule_rejects_before_attempt_creation(self):
        self.strict();self.compile(self.rule(require={'literal':False}));r=self.refresh()
        self.error('RULE_VIOLATION','flow_prepare',**self.get(r['next_request'])['arguments'])
        self.assertFalse((self.root/'project/attempts').exists())
    def test_dsl_unknown_boolean_and_injection_are_not_permissive(self):
        self.assertIs(rules.evaluate({'op':'gt','left':{'case_var':'missing'},'right':{'literal':1}},{}),rules.UNKNOWN)
        with self.assertRaises(rt.ToolError):rules.evaluate({'op':'eq','left':{'literal':True},'right':{'literal':1}},{})
        self.assertFalse(rules.evaluate({'op':'eq','left':{'literal':[True]},'right':{'literal':[1]}},{}))
        r=self.rule();r['when']={'op':'exec','code':'import os'}
        self.put('rule.json',r);self.put('rules-spec.json',{'rules':['rule.json']})
        self.error('INVALID_DSL','rules_codegen',project='project/project.json',spec='rules-spec.json',out='bad')
    def test_candidate_activation_and_conflicting_rules_rejected(self):
        r=self.rule(status='candidate');self.put('rule.json',r);self.put('rules-spec.json',{'rules':['rule.json'],'activate':True})
        self.error('UNCONFIRMED_RULE','rules_codegen',project='project/project.json',spec='rules-spec.json',out='bad')
        self.put('r1.json',self.rule(require={'literal':True}))
        r=self.rule(require={'literal':False});r['id']='R-CONFLICT';self.put('r2.json',r)
        self.put('rules-spec.json',{'rules':['r1.json','r2.json'],'activate':True})
        self.error('RULE_CONFLICT','rules_codegen',project='project/project.json',spec='rules-spec.json',out='bad')
    def test_generated_tool_and_query_hash_checks(self):
        self.compile();self.put('input.json',{'vars':{'amount':12000}})
        self.call('project_tool_invoke',project='project/project.json',tool_ref='project/generated/rules/tool-R-AMOUNT.json',input_ref='input.json',out='eval.json')
        self.assertTrue(self.get('eval.json')['requirement'])
        self.put('query.json',{'kind':'tools','limit':1})
        self.assertEqual(self.call('artifact_query',project='project/project.json',query='query.json',out='query-result.json')['returned'],1)
        self.put('source.json',{'changed':True})
        self.error('STALE_ARTIFACT','artifact_query',project='project/project.json',query='query.json',out='stale.json')
    def test_static_gold_coverage_does_not_fabricate_observed(self):
        self.graph_fixture()
        with patch('socket.create_connection',side_effect=AssertionError('network prohibited')),patch('subprocess.run',side_effect=AssertionError('no subprocess')):
            self.analyze()
        cov=self.get('project/analysis/one/coverage.json')
        self.assertEqual(cov['metrics']['planned']['nodes']['ratio'],1)
        self.assertEqual(cov['metrics']['planned']['edges']['ratio'],4/5)
        self.assertEqual(cov['metrics']['planned']['path_obligations']['ratio'],0.5)
        self.assertIsNone(cov['metrics']['observed']['nodes']['ratio'])
        self.assertEqual(cov['path_enumeration']['planned_path_ratio'],0.5)
    def test_observed_and_derived_edges_are_separate(self):
        self.graph_fixture()
        self.put('engine.json',{'instance':'i-1','activities':['start','manager','decision','director','end']})
        self.put('trace.json',{'case_id':'TC-DEMO-1','attempt':'0001','definition_id':'expense:1:xyz','instance_id':'i-1',
                              'activities':['start','manager','decision','director','end'],'edges':['F-start'],'evidence_refs':['engine.json']})
        self.put('trace-index.json',{'traces':['trace.json']})
        spec=self.get('analysis.json');spec['trace_index_ref']='trace-index.json';self.put('analysis.json',spec)
        self.analyze();cov=self.get('project/analysis/one/coverage.json')['metrics']
        self.assertEqual(cov['observed']['edges']['covered'],1)
        self.assertEqual(cov['derived']['edges']['covered'],3)
    def test_definition_and_evidence_mismatch_are_rejected(self):
        self.graph_fixture();binding=self.get('binding.json');binding['definition_id']='expense:2:xyz';self.put('binding.json',binding)
        self.error('DEFINITION_MISMATCH','flow_analysis',project='project/project.json',spec='analysis.json',out='bad')
    def test_rest_model_and_xml_have_equivalent_topology(self):
        self.graph_fixture();xml,_=flow_model.load(self.root,'definition.json')
        elements=[{'id':n['id'],'name':n['name'],'type':n['type'],'defaultFlow':n['default']} for n in xml['nodes']]
        elements += [{'id':e['id'],'sourceRef':e['source'],'targetRef':e['target'],'conditionExpression':e['condition']} for e in xml['edges']]
        self.put('model.json',{'processes':[{'id':'expense','flowElements':elements}]})
        bundle=self.get('definition.json');bundle.update(format='flowable_model',file='model.json');self.put('model-bundle.json',bundle)
        model,_=flow_model.load(self.root,'model-bundle.json')
        self.assertEqual([(n['id'],n['type'],n['default']) for n in model['nodes']],[(n['id'],n['type'],n['default']) for n in xml['nodes']])
        self.assertEqual(model['edges'],xml['edges'])
    def test_xml_external_entities_and_dangling_ids_rejected(self):
        self.graph_fixture('<!DOCTYPE x [<!ENTITY file SYSTEM "file:///secret">]>'+XML)
        with self.assertRaises(rt.ToolError):flow_model.load(self.root,'definition.json')
        self.graph_fixture(XML.replace('targetRef="director"','targetRef="missing"'))
        with self.assertRaises(rt.ToolError):flow_model.load(self.root,'definition.json')
    def test_loop_truncation_and_parallel_not_counted_as_xor_path(self):
        self.graph_fixture(XML.replace('<endEvent id="end"/>','<endEvent id="end"/><sequenceFlow id="F-loop" sourceRef="decision" targetRef="manager"/>'))
        graph,_=flow_model.load(self.root,'definition.json');paths=flow_model.paths(graph,{'max_paths':1})
        self.assertFalse(paths['complete']);self.assertIn('max_paths',paths['reason'])
        self.graph_fixture(XML.replace('exclusiveGateway','parallelGateway'))
        graph,_=flow_model.load(self.root,'definition.json');paths=flow_model.paths(graph,{})
        self.assertFalse(paths['complete']);self.assertEqual(paths['reason'],'opaque_or_concurrent_structure')
    def test_denominator_stable_and_query_rejects_stale(self):
        self.graph_fixture();self.analyze();self.put('query.json',{'kind':'uncovered_edges','limit':1})
        first=self.call('artifact_query',project='project/project.json',query='query.json',out='query.json.out')
        self.assertEqual(first['returned'],1)
        self.graph_fixture(XML.replace('name="none"','name="unused"')+' ')
        self.error('STALE_ARTIFACT','artifact_query',project='project/project.json',query='query.json',out='stale.json')
    def test_recorder_har_explicit_one_to_many_and_secrets_omitted(self):
        self.traces();self.put('alignment.json',{'session_id':'S-DEMO','environment':'local','links':[
            {'ui':'U00003','http':['H00001','H00002'],'reason':'manual inspection'}]})
        spec=self.get('align-spec.json');spec['alignment']='alignment.json';self.put('align-spec.json',spec)
        with patch('socket.create_connection',side_effect=AssertionError('network prohibited')):
            self.call('trace_align',project='project/project.json',spec='align-spec.json',out='project/traces/one')
        links=self.get('project/traces/one/alignment.json')
        self.assertEqual(links[0]['status'],'confirmed');self.assertEqual(len(links[0]['http']),2)
        text=''.join(p.read_text(encoding='utf-8') for p in (self.root/'project/traces/one').glob('*'))
        self.assertNotIn('secret-canary',text);self.assertNotIn('password-secret',text)
        self.assertEqual(len((self.root/'project/traces/one/test-trace.jsonl').read_text(encoding='utf-8').splitlines()),5)
    def test_trace_wrong_session_overlap_and_unassigned(self):
        self.traces();self.put('alignment.json',{'session_id':'other','environment':'local','links':[]})
        spec=self.get('align-spec.json');spec['alignment']='alignment.json';self.put('align-spec.json',spec)
        self.error('TRACE_SESSION_MISMATCH','trace_align',project='project/project.json',spec='align-spec.json',out='bad')
        spec.pop('alignment');spec.pop('case_id');spec.pop('attempt');self.put('align-spec.json',spec)
        self.call('trace_align',project='project/project.json',spec='align-spec.json',out='project/traces/two')
        self.assertTrue(self.get('project/traces/two/trace.meta.json')['unassigned_to_case'])
    def test_single_input_modes_and_no_fake_click_alignment(self):
        self.traces();spec=self.get('align-spec.json');spec.pop('har');self.put('rec-only.json',spec)
        self.call('trace_align',project='project/project.json',spec='rec-only.json',out='project/traces/ui')
        self.assertTrue(all(x['status']=='unmatched' for x in self.get('project/traces/ui/alignment.json')))
        spec=self.get('align-spec.json');spec.pop('recorder');self.put('har-only.json',spec)
        self.call('trace_align',project='project/project.json',spec='har-only.json',out='project/traces/http')
        self.assertEqual(self.get('project/traces/http/trace.meta.json')['http_count'],2)
    def test_operation_anchors_integrate_only_as_derived_flow_coverage(self):
        self.graph_fixture();self.traces()
        self.put('activity-map.json',{'definition_id':'expense:1:xyz','operations':{'create':'manager'}})
        spec=self.get('align-spec.json');spec.update(adapter='adapter.json',operation_map={'U00003':['create']},activity_map='activity-map.json');self.put('align-spec.json',spec)
        self.call('trace_align',project='project/project.json',spec='align-spec.json',out='project/traces/one')
        spec=self.get('analysis.json');spec['aligned_trace_ref']='project/traces/one/manifest.json';self.put('analysis.json',spec)
        self.analyze();cov=self.get('project/analysis/one/coverage.json')['metrics']
        self.assertEqual(cov['derived']['nodes']['covered'],1);self.assertIsNone(cov['observed']['nodes']['ratio'])
    def test_knowledge_version_scope_and_query_are_bounded(self):
        self.put('note.json',{'case_id':'TC-DEMO-1','kind':'confirmed','summary':'角色映射经验','next_action':'核对任务办理人',
                              'evidence_refs':['suite.json'],'applies_to':['adapter.json']})
        self.call('knowledge_record',project='project/project.json',spec='note.json',out='project/knowledge/K-001.json')
        self.put('query.json',{'kind':'lessons','case_id':'TC-DEMO-1','limit':1})
        self.call('artifact_query',project='project/project.json',query='query.json',out='q1.json')
        self.assertEqual(self.get('q1.json')['rows'][0]['status'],'confirmed')
        adapter=self.get('adapter.json');adapter['timeout_seconds']=4;self.put('adapter.json',adapter)
        self.call('artifact_query',project='project/project.json',query='query.json',out='q2.json')
        self.assertEqual(self.get('q2.json')['rows'][0]['status'],'superseded')
        self.put('query.json',{'kind':'sql','statement':'select *'})
        with self.assertRaises(rt.ToolError):self.call('artifact_query',project='project/project.json',query='query.json',out='q3.json')

    def test_strict_legacy_run_can_use_valid_scoped_receipt(self):
        with DemoServer() as server,patch.dict(os.environ,AUTH):
            self.adapter['base_url']=f'http://127.0.0.1:{server.server_port}';self.put('adapter.json',self.adapter)
            self.strict();r=self.refresh('legacy',phase='run',cid='*',plan='plan.json')
            preview=self.call('plan_preview',suite='suite.json',adapter='adapter.json',plan='plan.json')
            self.call('run',suite='suite.json',adapter='adapter.json',plan='plan.json',expected_fingerprint=preview['fingerprint'],run_id='LegacyFresh',
                      project='project/project.json',context_receipt=r['receipt'])
            self.assertEqual(len(server.calls),7)

    def test_rule_with_captured_task_id_blocks_second_side_effect(self):
        with DemoServer() as server,patch.dict(os.environ,AUTH):
            self.adapter['base_url']=f'http://127.0.0.1:{server.server_port}';self.put('adapter.json',self.adapter)
            r=self.rule(require={'op':'eq','left':{'step_pointer':'/params/task_id'},'right':{'literal':'not-permitted'}})
            r['scope']={'operations':['complete']}
            self.strict();self.compile(r);prepared=self.prepare()
            response=tc.dispatch(self.root,self.get(prepared['execute_request']))
            self.assertEqual(response['code'],'EXECUTION_ERROR')
            self.assertEqual(len(server.calls),1)
            self.assertEqual(server.calls[0],('POST','/instances'))

    def test_rule_type_and_compatible_constraints_accumulate(self):
        self.assertFalse(rules.evaluate({'op':'type_is','arg':{'literal':True},'type':'number'},{}))
        r1=self.rule();r2=self.rule(require={'op':'ge','left':{'case_var':'amount'},'right':{'literal':1}});r2['id']='R-MIN'
        self.put('r1.json',r1);self.put('r2.json',r2);self.put('rules-spec.json',{'rules':['r1.json','r2.json'],'activate':True})
        generated=self.call('rules_codegen',project='project/project.json',spec='rules-spec.json',out='project/generated/bounds')
        self.assertEqual(generated['rule_count'],2)

    def test_generation_input_race_is_not_published_as_fresh(self):
        self.graph_fixture();original=flow_model.load
        def mutate_after_parse(root,ref):
            graph,inputs=original(root,ref)
            (self.root/'expense.bpmn').write_text(XML+' ',encoding='utf-8')
            return graph,inputs
        with patch('flow_model.load',side_effect=mutate_after_parse):
            self.error('STALE_INPUT','flow_analysis',project='project/project.json',spec='analysis.json',out='project/analysis/raced')
        self.assertFalse((self.root/'project/analysis/raced/manifest.json').exists())

    def test_artifact_tamper_and_overlap_are_rejected(self):
        self.graph_fixture();self.analyze();self.put('project/analysis/one/coverage.json',{})
        self.put('query.json',{'kind':'coverage'})
        self.error('EVIDENCE_CHANGED','artifact_query',project='project/project.json',query='query.json',out='q.json')
        self.traces();self.put('alignment.json',{'session_id':'S-DEMO','environment':'local','links':[
            {'ui':'U00001','http':['H00001'],'reason':'a'},{'ui':'U00003','http':['H00001'],'reason':'b'}]})
        spec=self.get('align-spec.json');spec['alignment']='alignment.json';self.put('align-spec.json',spec)
        with self.assertRaises(rt.ToolError):self.call('trace_align',project='project/project.json',spec='align-spec.json',out='project/traces/bad')

    def test_large_payload_stays_out_of_fresh_context_and_queries(self):
        case=self.get('project/cases/TC-DEMO-1.json');case['steps'][0]['body']['padding']='BIG-CANARY'*250000
        self.put('project/cases/TC-DEMO-1.json',case);self.strict();r=self.refresh()
        focus=(self.root/r['focus']).read_text(encoding='utf-8')
        self.assertLess(len(focus.encode('utf-8')),4096);self.assertNotIn('BIG-CANARY',focus)

    def test_active_coverage_dsl_generates_case_scoped_obligation(self):
        self.graph_fixture();r=self.rule(kind='coverage_obligation',require={'activities_in_order':['manager','director']})
        r['scope']={'process_key':'expense'};r['when']={'op':'gt','left':{'case_var':'amount'},'right':{'literal':10000}}
        self.compile(r);self.analyze();cov=self.get('project/analysis/one/coverage.json')['metrics']
        self.assertEqual(cov['planned']['path_obligations']['total'],3)
        self.assertEqual(cov['planned']['path_obligations']['covered'],2)

    def test_exported_v5_schema_and_all_examples_match(self):
        described=self.call('describe')
        schema_path=Path(tc.__file__).parents[1]/'assets/v5.schema.json'
        self.assertEqual(rt.read_json(schema_path),described['v5_schema'])
        assets=Path(tc.__file__).parents[1]/'assets'
        for path in assets.glob('*.request.json'):tc.validate_request(rt.read_json(path))

    def test_knowledge_is_in_fresh_focus_and_invalid_evidence_is_excluded(self):
        self.put('note.json',{'case_id':'TC-DEMO-1','kind':'confirmed','summary':'可复用经验','next_action':'验证角色',
                              'evidence_refs':['suite.json'],'applies_to':['adapter.json']})
        self.call('knowledge_record',project='project/project.json',spec='note.json',out='project/knowledge/K-001.json')
        self.strict();r=self.refresh()
        self.assertEqual(self.get(r['focus'])['knowledge'][0]['kind'],'confirmed')
        self.put('suite.json',{**self.suite,'project':'new scope'})
        r=self.refresh('new-evidence');self.assertEqual(self.get(r['focus'])['knowledge'],[])

    def test_implicit_concurrency_and_non_bpmn_xml_cannot_claim_complete_paths(self):
        self.graph_fixture(XML.replace('exclusiveGateway','task'))
        graph,_=flow_model.load(self.root,'definition.json')
        self.assertFalse(flow_model.paths(graph,{})['complete'])
        self.graph_fixture(XML.replace('http://www.omg.org/spec/BPMN/20100524/MODEL','urn:other'))
        with self.assertRaises(rt.ToolError) as error:flow_model.load(self.root,'definition.json')
        self.assertEqual(error.exception.code,'INVALID_BPMN')

    def test_rule_scope_rejects_typos_and_does_not_mix_definition_versions(self):
        r=self.rule();r['scope']={'operations':['typo-operation']}
        self.put('rule.json',r);self.put('rules-spec.json',{'rules':['rule.json']})
        self.error('CAPABILITY_MISMATCH','rules_codegen',project='project/project.json',spec='rules-spec.json',out='project/generated/bad')
        self.graph_fixture()
        adapter=self.get('adapter.json');adapter['operations']['audit']={'method':'GET','path':'/audit','actors':['applicant']};self.put('adapter.json',adapter)
        r=self.rule(kind='coverage_obligation',require={'activities_in_order':['manager','director']});r['scope']={'operations':['audit']}
        self.compile(r);self.analyze()
        self.assertEqual(self.get('project/analysis/one/coverage.json')['metrics']['planned']['path_obligations']['total'],2)
        bundle=self.get('definition.json');bundle['definition']={'id':'expense:2:abc','key':'expense','version':2};self.put('definition-v2.json',bundle)
        r['scope']={'definition_ref':'definition-v2.json'};self.compile(r,out='project/generated/v2')
        self.error('DEFINITION_MISMATCH','flow_analysis',project='project/project.json',spec='analysis.json',out='project/analysis/mixed')

    def test_no_end_exponential_graph_stops_at_work_budget(self):
        nodes=[{'id':'start','type':'startEvent','scope':'p','opaque':False},{'id':'dead','type':'task','scope':'p','opaque':False}]
        edges=[{'id':'initial','source':'start','target':'D0'}]
        for i in range(30):
            nodes += [{'id':f'D{i}','type':'exclusiveGateway','scope':'p','opaque':False},
                      {'id':f'L{i}','type':'task','scope':'p','opaque':False},{'id':f'R{i}','type':'task','scope':'p','opaque':False}]
            for side in ('L','R'):
                edges += [{'id':f'{side}-in-{i}','source':f'D{i}','target':f'{side}{i}'},
                          {'id':f'{side}-out-{i}','source':f'{side}{i}','target':f'D{i+1}' if i<29 else 'dead'}]
        result=flow_model.paths({'process_id':'p','nodes':nodes,'edges':edges,'opaque_nodes':[]},{})
        self.assertFalse(result['complete']);self.assertIn('state_budget',result['reason']);self.assertLessEqual(result['visited_states'],50000)

if __name__=='__main__':unittest.main()
