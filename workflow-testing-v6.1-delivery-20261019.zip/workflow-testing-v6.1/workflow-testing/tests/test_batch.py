import copy
import json
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import batch_session as batch
import http_runner as rt
import toolchain as tc
import managed_session as ms
from test_session_reporting import assets,HeaderHandler


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='batch 中文 ');self.root=Path(self.temp.name)
        self.put('config.json',{'ref':'FLOW-12345678'})
        self.put('set.json',{'version':'1.0','files':[{'id':'config','path':'config.json','kind':'json'}]})
        self.put('profile.json',{'version':'1.0','rules':[]})
        self.put('compile.json',{'file_set':'set.json','profile':'profile.json'})
        self.request('compile','semantic_compile',spec='compile.json',out='idx')
        tasks=[{'id':'compile','request':'compile.request.json','depends_on':[]}]
        for i in range(5):
            self.put('query'+str(i)+'.json',{'kind':'summary'})
            self.request('query'+str(i),'semantic_query',index='idx/manifest.json',query='query'+str(i)+'.json',out='results/'+str(i)+'.json')
            tasks.append({'id':'query'+str(i),'request':'query'+str(i)+'.request.json','depends_on':['compile']})
        self.spec={'version':'1.0','tasks':tasks,'max_tasks':2,'parallel_queries':2}
        self.put('batch.json',self.spec)
    def tearDown(self):self.temp.cleanup()
    def put(self,ref,value):
        p=self.root/ref;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value),encoding='utf-8')
    def read(self,ref):return json.loads((self.root/ref).read_text(encoding='utf-8'))
    def request(self,name,tool,**args):self.put(name+'.request.json',{'protocol_version':'1.0','tool':tool,'arguments':args})
    def run_batch(self):return batch.run(self.root,'batch.json','state')

    def test_composition_budget_resume_and_complete_reuse(self):
        self.put('part.json',{'version':'1.0','tasks':self.spec['tasks'][1:]})
        self.spec['tasks']=self.spec['tasks'][:1];self.spec['includes']=['part.json'];self.put('batch.json',self.spec)
        for _ in range(3):result=self.run_batch()
        self.assertEqual(result['status'],'COMPLETE');self.assertEqual(result['counts']['DONE'],6)
        with patch.object(tc,'dispatch',side_effect=AssertionError('must not repeat')):
            result=self.run_batch();self.assertEqual(result['executed_now'],0)

    def test_parallel_queries_use_workers_and_preserve_receipts(self):
        self.spec['max_tasks']=6;self.put('batch.json',self.spec)
        names=set();original=tc.dispatch
        def observed(root,request):
            if request['tool']=='semantic_query':names.add(threading.current_thread().name)
            return original(root,request)
        with patch.object(tc,'dispatch',side_effect=observed):result=self.run_batch()
        self.assertEqual(result['status'],'COMPLETE')
        self.assertTrue(any('ThreadPoolExecutor' in x for x in names))
        for entry in self.read('state/state.json')['tasks'].values():self.assertIn('receipt_sha256',entry)

    def test_unknown_interruption_blocks_all_resend(self):
        with patch.object(tc,'dispatch',side_effect=RuntimeError('simulated interruption')):result=self.run_batch()
        self.assertEqual(result['status'],'BLOCKED')
        with patch.object(tc,'dispatch',side_effect=AssertionError('no resend')):
            self.assertEqual(self.run_batch()['status'],'BLOCKED_UNKNOWN')

    def test_source_revision_change_blocks_same_batch(self):
        self.run_batch();self.put('config.json',{'ref':'CHANGED-12345678'})
        with self.assertRaises(rt.ToolError) as e:self.run_batch()
        self.assertEqual(e.exception.code,'STALE_BATCH')

    def test_changed_batch_or_receipt_blocks_resume(self):
        self.run_batch();state=self.read('state/state.json')
        receipt=state['tasks']['compile']['receipt'];self.put(receipt,{'ok':True})
        with self.assertRaises(rt.ToolError) as e:self.run_batch()
        self.assertEqual(e.exception.code,'EVIDENCE_CHANGED')
        self.spec['max_tasks']=3;self.put('batch.json',self.spec)
        with self.assertRaises(rt.ToolError) as e:self.run_batch()
        self.assertEqual(e.exception.code,'STALE_BATCH')

    def test_duplicate_outputs_cycle_and_unregistered_side_effects_rejected(self):
        self.request('query1','semantic_query',index='idx/manifest.json',query='query1.json',out='results/0.json')
        with self.assertRaises(rt.ToolError):self.run_batch()
        self.spec['tasks'][0]['depends_on']=['query0'];self.spec['tasks']=self.spec['tasks'][:2];self.put('batch.json',self.spec)
        with self.assertRaises(rt.ToolError):self.run_batch()
        self.request('compile','run',suite='suite.json',adapter='a.json',plan='p.json',expected_fingerprint='x',run_id='X')
        self.spec['tasks']=self.spec['tasks'][:1];self.spec['tasks'][0]['depends_on']=[];self.put('batch.json',self.spec)
        with self.assertRaises(rt.ToolError) as e:self.run_batch()
        self.assertEqual(e.exception.code,'EFFECT_DENIED')

    def test_failed_precondition_blocks_dependent_tasks_and_no_auto_retry(self):
        self.put('profile.json',{'version':'1.0','rules':[],'invalid':1})
        result=self.run_batch();self.assertEqual(result['counts']['FAILED'],1)
        self.assertFalse((self.root/'results').exists())
        with patch.object(tc,'dispatch',side_effect=AssertionError('no retry')):
            self.assertEqual(self.run_batch()['status'],'BLOCKED_FAILED')

    def test_real_powershell_entry_continues_from_files(self):
        shell=shutil.which('powershell') or shutil.which('pwsh')
        if not shell:self.skipTest('PowerShell unavailable')
        script=Path(batch.__file__).with_name('Invoke-WorkflowBatch.ps1')
        for _ in range(3):
            result=subprocess.run([shell,'-NoProfile','-File',str(script),'-Batch',str(self.root/'batch.json'),'-State','state'],capture_output=True,encoding='utf-8',timeout=30)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertLess(len(result.stdout.encode('utf-8')),1024)
        self.assertEqual(json.loads(result.stdout)['status'],'COMPLETE')

    def test_managed_session_real_http_serial_and_no_resend(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),HeaderHandler);server.seen=[];server.fail=False
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            suite,adapter,plan=assets(server.server_port)
            for ref,data in [('suite.json',suite),('adapter.json',adapter),('plan.json',plan)]:self.put(ref,data)
            self.put('session-spec.json',{'suite':'suite.json','adapter':'adapter.json','plan':'plan.json','project_dir':'project','credentials_file':'private/tokens.json','execution_mode':'file_only'})
            self.put('private/tokens.json',{'version':'1.0','env':{'WF_DEMO_APPLICANT':'SYNTHETIC-TOKEN','WF_CLIENT_ID':'SYNTHETIC-CLIENT'}})
            ms.perform(self.root,'session-spec.json','init')
            tasks=[{'id':'prepare','session':'session-spec.json','action':'prepare','case_id':'TC-DEMO-1','depends_on':[]},
                   {'id':'execute','session':'session-spec.json','action':'execute','case_id':'TC-DEMO-1','depends_on':['prepare']}]
            self.put('batch.json',{'version':'1.0','tasks':tasks,'allow_execute':False})
            with self.assertRaises(rt.ToolError):self.run_batch()
            self.assertEqual(server.seen,[])
            self.put('batch.json',{'version':'1.0','tasks':tasks,'allow_execute':True})
            self.assertEqual(self.run_batch()['status'],'COMPLETE');self.assertEqual(len(server.seen),2)
            self.assertEqual(self.run_batch()['executed_now'],0);self.assertEqual(len(server.seen),2)
        finally:server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main()
