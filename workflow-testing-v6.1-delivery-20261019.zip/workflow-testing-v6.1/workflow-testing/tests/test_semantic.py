import contextlib
import copy
import hashlib
import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import http_runner as rt
import toolchain as tc
import semantic_core as core
import semantic_schema
import semantic_tools as st


class SemanticTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='semantic 中文 ');self.root=Path(self.tmp.name)
        self.config={'fields':{'amount':{'name':'amount','value':400}},'condition':'form.amount > 100 and form.amount < 900',
                     'malformed':'bad\ufffd','payload':json.dumps({'flowId':'FLOW-12345678'}),'privateToken':'PRIVATE-NEVER-PERSIST'}
        self.har={'log':{'entries':[{'request':{'headers':[{'name':'Authorization','value':'PRIVATE-HEADER'}],
                   'postData':{'text':json.dumps({'flowId':'FLOW-12345678'})}}}]}}
        self.put('config.json',self.config);self.put('record.har',self.har)
        self.put('set.json',{'version':'1.0','files':[{'id':'config','path':'config.json','kind':'json'},
                                                     {'id':'network','path':'record.har','kind':'har'}]})
        self.profile={'version':'1.0','embedded_json':True,'templates':False,'rules':[
            {'file':'config','select':'/fields/*/name','kind':'define','namespace':'form','prefix':'form.'},
            {'file':'config','select':'/condition','kind':'expression','namespace':'form','dialect':'python_subset'},
            {'file':'config','select':'/fields/*/value','kind':'expect','type':'number','min':0,'max':1000}]}
        self.put('profile.json',self.profile);self.put('compile.json',{'file_set':'set.json','profile':'profile.json'})
    def tearDown(self):self.tmp.cleanup()
    def put(self,ref,value):
        p=self.root/ref;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=True),encoding='utf-8')
    def read(self,ref):return json.loads((self.root/ref).read_text(encoding='utf-8'))
    def call(self,tool,**args):return tc.dispatch(self.root,{'protocol_version':'1.0','tool':tool,'arguments':args})
    def build(self,out='idx'):return self.call('semantic_compile',spec='compile.json',out=out)
    def query(self,value,out='q.json',index='idx/manifest.json'):
        self.put('query.json',value);self.call('semantic_query',index=index,query='query.json',out=out);return self.read(out)

    def test_ast_cross_field_dependencies_and_impact_without_values(self):
        self.build()
        q=self.query({'kind':'dependencies','node':{'file':'config','pointer':'/condition'}})
        self.assertEqual(q['rows'][0]['location']['pointer'],'/fields/amount/name')
        self.assertFalse(q['causality_proven'])
        impact=self.query({'kind':'impact','node':{'file':'config','pointer':'/fields/amount/name'}},'impact.json')
        self.assertEqual(impact['rows'][0]['location']['pointer'],'/condition')
        raw=(self.root/'idx/index.sqlite').read_bytes()
        for secret in (b'PRIVATE-NEVER-PERSIST',b'PRIVATE-HEADER',b'FLOW-12345678'):
            self.assertNotIn(secret,raw)

    def test_embedded_json_query_and_replacement_character(self):
        self.build()
        q=self.query({'kind':'nodes','file':'network','pointer':'/log/entries/0/request/postData/text/$json/flowId'})
        self.assertEqual(q['rows'][0]['kind'],'string')
        self.assertNotIn('value',q['rows'][0])
        q=self.query({'kind':'issues','code':'REPLACEMENT_CHARACTER'},'issues.json')
        self.assertEqual(q['rows'][0]['pointer'],'/malformed')

    def test_incremental_cache_reuses_unchanged_source(self):
        self.build()
        with patch.object(core,'extract',wraps=core.extract) as parse:
            second=self.build('idx2')['data'];self.assertEqual(parse.call_count,0)
        self.assertEqual(second['cached_files'],2)
        self.config['fields']['amount']['value']=1234;self.put('config.json',self.config)
        third=self.build('idx3')['data'];self.assertEqual((third['cached_files'],third['parsed_files']),(1,1))
        q=self.query({'kind':'issues','code':'OUT_OF_RANGE'},index='idx3/manifest.json')
        self.assertEqual(len(q['rows']),1)
        self.call('semantic_diff',before='idx/manifest.json',after='idx3/manifest.json',out='delta.json')
        self.assertEqual(self.read('delta.json')['counts']['changed'],1)

    def test_stale_index_and_tampered_cache_rejected(self):
        self.build();self.config['malformed']='fixed';self.put('config.json',self.config)
        with self.assertRaises(rt.ToolError) as e:self.query({'kind':'summary'})
        self.assertEqual(e.exception.code,'STALE_INDEX')
        # Restore this source so every original shard is a live cache candidate.
        self.config['malformed']='bad\ufffd';self.put('config.json',self.config)
        cache=next((self.root/'.semantic-cache').glob('*.sqlite'));cache.write_bytes(b'broken')
        with self.assertRaises(rt.ToolError):self.build('new')

    def test_call_ast_is_opaque_and_never_executed(self):
        self.config['condition']='__import__("os").system("danger")';self.put('config.json',self.config)
        self.build();q=self.query({'kind':'issues','code':'OPAQUE_EXPRESSION'})
        self.assertEqual(len(q['rows']),1)
        with self.assertRaises(rt.ToolError):core.expression('form[dynamic]')

    def test_composed_sets_and_cycle_unknown_fields(self):
        self.put('top.json',{'version':'1.0','files':[],'includes':['set.json']})
        self.put('compile.json',{'file_set':'top.json','profile':'profile.json'});self.build()
        self.put('top.json',{'version':'1.0','files':[],'includes':['top.json']})
        with self.assertRaises(rt.ToolError):self.build('cycle')
        self.put('profile.json',{**self.profile,'eval':True})
        with self.assertRaises(rt.ToolError):core.profile(self.read('profile.json'))

    def test_duplicate_keys_and_invalid_utf8_are_generic(self):
        for raw in (b'{"PRIVATE-KEY":1,"PRIVATE-KEY":2}',b'{"x":"\xff"}'):
            (self.root/'config.json').write_bytes(raw)
            with self.assertRaises(rt.ToolError) as e:self.build('bad'+str(len(raw)))
            self.assertNotIn('PRIVATE-KEY',str(e.exception))

    def test_unknown_reference_and_ambiguous_definitions(self):
        self.config['fields']['duplicate']={'name':'amount','value':1}
        self.config['condition']='form.amount + form.missing';self.put('config.json',self.config)
        self.build();q=self.query({'kind':'summary'})
        self.assertIn('AMBIGUOUS_SYMBOL',q['issue_counts']);self.assertIn('UNRESOLVED_SYMBOL',q['issue_counts'])
        self.assertIn('DUPLICATE_DEFINITION',q['issue_counts'])

    def proposals(self):
        self.build()
        self.put('seeds.json',{'seeds':[{'file':'config','pointer':'/payload/$json/flowId'}]})
        self.call('semantic_propose',index='idx/manifest.json',spec='seeds.json',out='knowledge/proposals.json')
        return self.read('knowledge/proposals.json')
    def approve(self):
        p=self.proposals()
        self.put('human-review.json',{'proposals_sha256':hashlib.sha256((self.root/'knowledge/proposals.json').read_bytes()).hexdigest(),
            'reviewer':'synthetic-fixture-reviewer','decisions':[{'id':p['candidates'][0]['id'],'decision':'accept'}]})
        self.call('semantic_promote',index='idx/manifest.json',proposals='knowledge/proposals.json',review='human-review.json',out='knowledge/recipe')

    def test_candidates_never_auto_activate_and_review_generates_recipe(self):
        self.approve()
        p=self.read('knowledge/proposals.json');self.assertEqual(len(p['candidates']),1)
        self.assertEqual(p['candidates'][0]['status'],'candidate')
        result=self.call('semantic_check',index='idx/manifest.json',recipe='knowledge/recipe/recipe.json',out='check.json')
        self.assertEqual(result['data']['status'],'PASS')
        self.assertFalse(self.read('check.json')['business_assertions_replaced'])
        self.har['log']['entries'][0]['request']['postData']['text']=json.dumps({'flowId':'DIFFERENT-1234'});self.put('record.har',self.har)
        self.build('next')
        result=self.call('semantic_check',index='next/manifest.json',recipe='knowledge/recipe/recipe.json',out='check-next.json')
        self.assertEqual(result['code'],'TEST_FAILED');self.assertTrue(self.read('check-next.json')['baseline_changed'])

    def test_missing_or_stale_review_cannot_promote(self):
        self.proposals()
        self.put('review.json',{'proposals_sha256':'0'*64,'reviewer':'user','decisions':[]})
        with self.assertRaises(rt.ToolError) as e:
            self.call('semantic_promote',index='idx/manifest.json',proposals='knowledge/proposals.json',review='review.json',out='recipe')
        self.assertEqual(e.exception.code,'STALE_REVIEW')
        self.assertFalse((self.root/'recipe').exists())

    def test_tampered_recipe_and_profile_scope_rejected(self):
        self.approve();recipe=self.read('knowledge/recipe/recipe.json')
        recipe['assertions'][0]['predicate']='co_occurs';self.put('forged.json',recipe)
        with self.assertRaises(rt.ToolError) as e:self.call('semantic_check',index='idx/manifest.json',recipe='forged.json',out='bad.json')
        self.assertEqual(e.exception.code,'UNCONFIRMED_RELATION')
        self.profile['templates']=True;self.put('profile.json',self.profile);self.build('next')
        with self.assertRaises(rt.ToolError) as e:self.call('semantic_check',index='next/manifest.json',recipe='knowledge/recipe/recipe.json',out='bad2.json')
        self.assertEqual(e.exception.code,'STALE_RECIPE')

    def test_cannot_drop_one_of_multiple_confirmed_assertions(self):
        self.build()
        self.put('hypotheses.json',{'hypotheses':[
            {'from':{'file':'config','pointer':'/payload/$json/flowId'},'to':{'file':'network','pointer':'/log/entries/0/request/postData/text/$json/flowId'},'predicate':predicate,'evidence':['config.json']}
            for predicate in ('equal','same_type')]})
        self.call('semantic_propose',index='idx/manifest.json',spec='hypotheses.json',out='props.json')
        proposals=self.read('props.json')
        self.put('review.json',{'proposals_sha256':hashlib.sha256((self.root/'props.json').read_bytes()).hexdigest(),
          'reviewer':'fixture','decisions':[{'id':h['id'],'decision':'accept'} for h in proposals['candidates']]})
        self.call('semantic_promote',index='idx/manifest.json',proposals='props.json',review='review.json',out='recipe')
        recipe=self.read('recipe/recipe.json');recipe['assertions']=recipe['assertions'][:1];self.put('weakened.json',recipe)
        with self.assertRaises(rt.ToolError) as e:self.call('semantic_check',index='idx/manifest.json',recipe='weakened.json',out='bad.json')
        self.assertEqual(e.exception.code,'UNCONFIRMED_RELATION')

    def test_query_budget_pagination_and_no_unknown_sql(self):
        self.build()
        first=self.query({'kind':'nodes','limit':1});self.assertEqual(len(first['rows']),1);self.assertEqual(first['next_offset'],1)
        with self.assertRaises(rt.ToolError):self.query({'kind':'sql','sql':'DROP TABLE nodes'},'bad.json')
        self.config['nested']={'x'*1000:1};self.put('config.json',self.config);self.build('next')
        with self.assertRaises(rt.ToolError) as e:self.query({'kind':'nodes','file':'config','pointer':'/nested/'+'x'*1000,'max_bytes':512},'too-big.json','next/manifest.json')
        self.assertEqual(e.exception.code,'QUERY_TOO_LARGE')

    def test_query_budget_counts_written_format_and_newline(self):
        value={'rows':[1]*150}
        self.assertLess(len(json.dumps(value).encode('utf-8')),512)
        with self.assertRaises(rt.ToolError) as e:st.bounded(self.root,'oversize.json',value,512)
        self.assertEqual(e.exception.code,'QUERY_TOO_LARGE');self.assertFalse((self.root/'oversize.json').exists())

    def test_depth_and_private_file_budgets(self):
        nested={};current=nested
        for _ in range(82):current['child']={};current=current['child']
        self.put('config.json',nested)
        with self.assertRaises(rt.ToolError) as e:self.build()
        self.assertEqual(e.exception.code,'BUDGET_EXCEEDED')
        self.put('tokens.json',{'secret':'x'})
        self.put('set.json',{'version':'1.0','files':[{'id':'private','path':'tokens.json','kind':'json'}]})
        with self.assertRaises(rt.ToolError):self.build('private')

    def test_schema_and_export_registry_are_synchronized(self):
        folder=Path(tc.__file__).parents[1]
        self.assertEqual(rt.read_json(folder/'assets/semantic.schema.json'),semantic_schema.schema())
        self.assertEqual(rt.read_json(folder/'assets/tool-request.schema.json'),tc.protocol_schema())
        import check_boundaries
        self.assertTrue(check_boundaries.check()['ok'])

    def test_static_dispatch_cannot_enter_transport(self):
        def illegal(*_):rt.curl_request(None,None,None,None,None,None,None,None,None)
        with patch.object(st,'compile_index',illegal),self.assertRaises(rt.ToolError) as e:self.build()
        self.assertEqual(e.exception.code,'EFFECT_DENIED')

if __name__=='__main__':unittest.main()
