import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import toolchain as tc
import file_workflow as fw
import http_runner as rt
from demo_support import DemoServer, make_assets

AUTH = {'WF_DEMO_APPLICANT': 'demo-applicant', 'WF_DEMO_MANAGER': 'demo-manager', 'WF_DEMO_DIRECTOR': 'demo-director'}


class FileWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='workflow-v4-')
        self.root = Path(self.tmp.name)
        self.suite, self.adapter, self.plan = make_assets(19999)

    def tearDown(self):
        self.tmp.cleanup()

    def put(self, ref, value):
        p = self.root / ref
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        return p

    def call(self, tool, **args):
        return tc.dispatch(self.root, fw.request(tool, **args))

    def init(self):
        self.put('suite.json', self.suite)
        self.put('adapter.json', self.adapter)
        self.put('plan.json', self.plan)
        self.put('session.json', {'suite': 'suite.json', 'adapter': 'adapter.json', 'plan': 'plan.json'})
        return self.call('flow_init', spec='session.json', out='project')

    def prepare(self, cid='TC-DEMO-1', **args):
        return self.call('flow_prepare', project='project/project.json', case_id=cid, **args)['data']

    def execute(self, cid='TC-DEMO-1', attempt='0001'):
        return self.call('flow_execute', project='project/project.json', case_id=cid, attempt=attempt)

    def cli(self, request, response='reply.json', brief=True):
        self.put('request.json', request)
        cmd = [sys.executable, '-X', 'utf8', str(Path(tc.__file__)), '--workspace', str(self.root), '--request', str(self.root / 'request.json')]
        if response:
            cmd += ['--response-file', response]
        if brief:
            cmd += ['--brief']
        return subprocess.run(cmd, capture_output=True, encoding='utf-8', timeout=30)

    def test_nested_json_text_pointer_and_literal_runtime_variable(self):
        (self.root / 'text.txt').write_text('中文\nvalue', encoding='utf-8')
        self.put('part.json', {'picked': {'$file': 'text.txt', 'format': 'text'}})
        self.put('spec.json', {'data': {'$file': 'part.json', 'pointer': '/picked'}, 'var': '${run_id}'})
        result = self.call('request_compose', spec='spec.json', out='out.json')['data']
        self.assertEqual(json.loads((self.root / 'out.json').read_text(encoding='utf-8')), {'data': '中文\nvalue', 'var': '${run_id}'})
        self.assertEqual(result['source_count'], 3)
        self.assertNotIn('中文', json.dumps(result))

    def test_cycle_traversal_missing_pointer_and_unknown_reference_fields(self):
        self.put('part.json', {'a': 1})
        for value in ({'$file': 'spec.json'}, {'$file': '../outside.json'}, {'$file': 'part.json', 'pointer': '/missing'}, {'$file': 'part.json', 'command': 'echo'}):
            self.put('spec.json', value)
            with self.assertRaises(rt.ToolError):
                self.call('request_compose', spec='spec.json', out='out.json')
        self.assertFalse((self.root / 'out.json').exists())

    def test_size_limit_and_duplicate_keys(self):
        (self.root / 'spec.json').write_text('{"x":1,"x":2}', encoding='utf-8')
        with self.assertRaises(rt.ToolError):
            self.call('request_compose', spec='spec.json', out='out.json')
        self.put('spec.json', {'large': 'x' * 200})
        with patch.object(fw, 'LIMIT', 100), self.assertRaises(rt.ToolError):
            self.call('request_compose', spec='spec.json', out='out.json')

    def test_split_and_focus_do_not_print_bulk_payload(self):
        self.plan['cases'][0]['steps'][0]['body']['padding'] = 'CANARY' * 50000
        self.init()
        result = self.call('flow_focus', project='project/project.json', case_id='TC-DEMO-1')
        self.assertLess(len(json.dumps(result)), 600)
        self.assertNotIn('CANARY', (self.root / 'project/FOCUS.json').read_text(encoding='utf-8'))
        self.assertEqual(len(list((self.root / 'project/cases').glob('*.json'))), 2)

    def test_changed_source_or_prepared_plan_blocks_before_network(self):
        self.init()
        self.prepare()
        self.suite['project'] = 'changed'
        self.put('suite.json', self.suite)
        with self.assertRaises(rt.ToolError) as error:
            self.execute()
        self.assertEqual(error.exception.code, 'STALE_PLAN')
        self.assertFalse((self.root / 'runs').exists())

    def test_references_are_validated_before_transport(self):
        self.plan['cases'][0]['steps'][0]['body'] = {'$file': 'body.json'}
        self.put('body.json', {'amount': '${amount}'})
        self.init()
        self.prepare()
        self.put('body.json', {'amount': 90000})
        with self.assertRaises(rt.ToolError) as error:
            self.execute()
        self.assertEqual(error.exception.code, 'STALE_PLAN')

    def test_missing_business_assertion_cannot_be_hidden_in_reference(self):
        self.plan['cases'][0]['steps'] = self.plan['cases'][0]['steps'][:1]
        self.init()
        with self.assertRaises(rt.ToolError):
            self.prepare()
        self.assertFalse((self.root / 'runs').exists())

    def test_real_http_duplicate_and_fresh_process_resume(self):
        with DemoServer() as server, patch.dict(os.environ, AUTH):
            self.suite, self.adapter, self.plan = make_assets(server.server_port)
            self.init()
            self.prepare()
            first = self.execute()
            calls = len(server.calls)
            second = self.execute()
            self.assertEqual(first['data']['status'], 'PASS')
            self.assertTrue(second['data']['reused_evidence'])
            self.assertEqual(calls, len(server.calls))
            status = self.cli(fw.request('flow_status', project='project/project.json'))
            self.assertEqual(status.returncode, 0, status.stderr)
            self.assertLess(len(status.stdout.encode('utf-8')), 2048)
            saved = json.loads((self.root / 'reply.json').read_text(encoding='utf-8'))
            self.assertEqual(saved['data']['counts'], {'PASS': 1, 'TODO': 1})
            evidence = self.root / first['data']['results']
            self.assertNotIn('response-secret-canary', evidence.read_text(encoding='utf-8'))
            evidence.write_text('{}', encoding='utf-8')
            with self.assertRaises(rt.ToolError) as error:
                self.execute()
            self.assertEqual(error.exception.code, 'EVIDENCE_CHANGED')

    def test_interruption_intent_never_resends_and_requires_reconciliation(self):
        self.init()
        self.prepare()
        with patch.object(rt, 'run_plan', side_effect=KeyboardInterrupt), self.assertRaises(KeyboardInterrupt):
            self.execute()
        with patch.object(rt, 'run_plan') as run, self.assertRaises(rt.ToolError) as error:
            self.execute()
        self.assertEqual(error.exception.code, 'ATTEMPT_BLOCKED')
        run.assert_not_called()
        with self.assertRaises(rt.ToolError):
            self.prepare()
        self.put('reconcile.json', {'case_id': 'TC-DEMO-1', 'attempt': '0001', 'reason': 'simulated stop', 'side_effects': 'mock transport never called', 'authorization': 'local unit test fixture', 'writer_stopped': 'confirmed', 'evidence': ['suite.json']})
        self.call('flow_reconcile', project='project/project.json', record='reconcile.json')
        self.put('retry.json', {'case_id': 'TC-DEMO-1', 'previous_attempt': '0001', 'reason': 'mock interrupted', 'change': 'new fixture', 'side_effects': 'none', 'authorization': 'local unit test', 'evidence': ['reconcile.json']})
        self.assertEqual(self.prepare(retry_note='retry.json')['attempt'], '0002')
        self.assertTrue((self.root / 'project/attempts/TC-DEMO-1/0001/intent.json').exists())

    def test_prepared_attempt_cannot_be_replaced_or_resend_via_output_collision(self):
        self.init()
        self.prepare()
        with self.assertRaises(rt.ToolError):
            self.prepare()
        self.put('reply.json', {'keep': True})
        with DemoServer() as server:
            result = self.cli(fw.request('flow_execute', project='project/project.json', case_id='TC-DEMO-1', attempt='0001'))
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(server.calls, [])
            self.assertFalse((self.root / 'project/attempts/TC-DEMO-1/0001/intent.json').exists())

    def test_raw_failure_exit_and_explicit_retry_history(self):
        with DemoServer() as server, patch.dict(os.environ, AUTH):
            self.suite, self.adapter, self.plan = make_assets(server.server_port)
            self.plan['cases'][0]['steps'][-1]['checks'][1]['expected'] = 'impossible'
            self.init()
            self.prepare()
            result = self.cli(fw.request('flow_execute', project='project/project.json', case_id='TC-DEMO-1', attempt='0001'))
            self.assertEqual(result.returncode, 10, result.stdout + result.stderr)
            self.assertEqual(json.loads(result.stdout)['code'], 'TEST_FAILED')
            with self.assertRaises(rt.ToolError) as error:
                self.prepare()
            self.assertEqual(error.exception.code, 'RETRY_REQUIRED')
            before = len(server.calls)
            self.assertEqual(self.execute()['code'], 'TEST_FAILED')
            self.assertEqual(before, len(server.calls))

    def test_lesson_scope_bounded_focus_and_no_fabricated_global_pass(self):
        self.init()
        for i in range(5):
            self.put('note.json', {'case_id': 'TC-DEMO-1', 'kind': 'hypothesis', 'summary': 'Observed issue ' + str(i), 'next_action': 'check roles', 'evidence': ['suite.json']})
            self.call('flow_note', project='project/project.json', note='note.json')
        self.call('flow_focus', project='project/project.json', case_id='TC-DEMO-1')
        focus = json.loads((self.root / 'project/FOCUS.json').read_text(encoding='utf-8'))
        self.assertEqual(len(focus['lessons']), 3)
        self.call('flow_focus', project='project/project.json', case_id='TC-DEMO-2')
        self.assertEqual(json.loads((self.root / 'project/FOCUS.json').read_text(encoding='utf-8'))['lessons'], [])
        self.assertEqual(self.call('flow_status', project='project/project.json')['data']['counts'], {'TODO': 2})

    def test_brief_describe_saves_schema_instead_of_context(self):
        result = self.cli(fw.request('describe'))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertLess(len(result.stdout.encode('utf-8')), 2048)
        self.assertNotIn('request_schema', result.stdout)
        saved = json.loads((self.root / 'reply.json').read_text(encoding='utf-8'))
        self.assertIn('request_schema', saved['data'])
        exported = rt.read_json(Path(tc.__file__).parents[1] / 'assets/file-workflow.schema.json')
        self.assertEqual(exported, saved['data']['file_workflow_schema'])
        result = self.cli(fw.request('doctor'), response=None)
        self.assertNotEqual(result.returncode, 0)

    def test_generated_skill_contains_file_tools_and_small_baseline_index(self):
        self.put('suite.json', self.suite)
        self.call('skill_build', suite='suite.json', out='generated', name='sample-project')
        base = self.root / 'generated/sample-project'
        self.assertTrue((base / 'scripts/file_workflow.py').is_file())
        self.assertTrue((base / 'tests/test_file_workflow.py').is_file())
        self.assertLess((base / 'references/project-index.json').stat().st_size, 1000)
        self.assertTrue((base / 'references/project-cases/TC-DEMO-1.json').is_file())
        self.assertNotIn('先读取 [项目需求与用例基线]', (base / 'SKILL.md').read_text(encoding='utf-8'))

    def test_cancel_only_unsent_attempt_and_preserve_report_history(self):
        self.init()
        self.prepare()
        cancelled = self.call('flow_cancel', project='project/project.json', case_id='TC-DEMO-1', attempt='0001', reason='input correction')
        self.assertEqual(cancelled['data']['status'], 'CANCELLED')
        with patch.object(rt, 'run_plan') as run, self.assertRaises(rt.ToolError):
            self.execute()
        run.assert_not_called()
        self.put('retry.json', {'case_id': 'TC-DEMO-1', 'previous_attempt': '0001', 'reason': 'cancelled before sending', 'change': 'correct input', 'side_effects': 'not sent', 'authorization': 'local fixture', 'evidence': ['project/attempts/TC-DEMO-1/0001/intent.json']})
        self.prepare(retry_note='retry.json')
        with patch.object(rt, 'run_plan', side_effect=KeyboardInterrupt), self.assertRaises(KeyboardInterrupt):
            self.execute(attempt='0002')
        with self.assertRaises(rt.ToolError):
            self.call('flow_cancel', project='project/project.json', case_id='TC-DEMO-1', attempt='0002', reason='cannot cancel unknown')
        self.call('flow_report', project='project/project.json', out='report.md')
        report = (self.root / 'report.md').read_text(encoding='utf-8')
        self.assertIn('CANCELLED', report)
        self.assertIn('UNKNOWN', report)
        self.assertIn('TODO', report)

    def test_cancel_execute_race_has_only_one_winner(self):
        with DemoServer() as server, patch.dict(os.environ, AUTH):
            self.suite, self.adapter, self.plan = make_assets(server.server_port)
            self.init()
            self.prepare()
            barrier = threading.Barrier(2)
            original_write = fw.write
            def racing_write(path, data):
                if path.name == 'intent.json':
                    barrier.wait(timeout=10)
                return original_write(path, data)
            def cancel():
                return self.call('flow_cancel', project='project/project.json', case_id='TC-DEMO-1', attempt='0001', reason='race fixture')
            with patch.object(fw, 'write', side_effect=racing_write), ThreadPoolExecutor(max_workers=2) as pool:
                futures = [pool.submit(self.execute), pool.submit(cancel)]
                outcomes = []
                for f in futures:
                    try:
                        outcomes.append(f.result(timeout=20))
                    except FileExistsError:
                        outcomes.append('exclusive-slot-lost')
            self.assertEqual(outcomes.count('exclusive-slot-lost'), 1)
            self.assertIn(len(server.calls), (0, 4))
            state = self.call('flow_status', project='project/project.json')['data']['counts']
            self.assertTrue('PASS' in state or 'CANCELLED' in state)

    def test_powershell_brief_entrypoint(self):
        import shutil
        shell = shutil.which('powershell.exe')
        if not shell:
            self.skipTest('Windows PowerShell unavailable')
        req = self.put('调用.json', fw.request('describe'))
        cmd = [shell, '-NoProfile', '-File', str(Path(tc.__file__).with_name('Invoke-WorkflowTool.ps1')),
               '-Workspace', str(self.root), '-Request', str(req), '-Python', sys.executable,
               '-ResponseFile', '回执.json', '-Brief']
        result = subprocess.run(cmd, capture_output=True, encoding='utf-8-sig', timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertLess(len(result.stdout.encode('utf-8')), 2048)
        self.assertTrue((self.root / '回执.json').is_file())


if __name__ == '__main__':
    unittest.main()
