import copy
import io
import contextlib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import http_runner as rt
import managed_session as ms
import toolchain as tc
import file_workflow as fw
import business_headers as bh
import session_cli
import http_schema
import reporting
from demo_support import make_assets


class HeaderHandler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def respond(self,write):
        self.rfile.read(int(self.headers.get('Content-Length','0')))
        self.server.seen.append({'method':self.command,'path':self.path,'headers':dict(self.headers)})
        value={'msg':'文档编号不能为空' if write and self.server.fail else '成功',
               'accepted':not (write and self.server.fail),'echo':self.headers.get('X-Client-Id')}
        raw=json.dumps(value,ensure_ascii=False).encode('utf-8')
        self.send_response(400 if write and self.server.fail else 201 if write else 200)
        self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def do_GET(self):self.respond(False)
    def do_POST(self):self.respond(True)


def assets(port):
    suite,adapter,plan=make_assets(port)
    suite['cases']=suite['cases'][:1]
    suite['cases'][0]['title']='文件编制—必填编号校验（本地演示）'
    adapter['headers']={'X-Client-Id':{'env':'WF_CLIENT_ID'},'X-Level':'adapter'}
    adapter['actors']['applicant']['headers']={'x-level':'actor'}
    adapter['operations']={
        'ready':{'method':'GET','path':'/ready','actors':['applicant'],'headers':{'X-Level':'operation'}},
        'save':{'method':'POST','path':'/documents','actors':['applicant']}}
    plan['cases']=[{'case_id':'TC-DEMO-1','vars':{'level':'step'},'steps':[
        {'id':'ready','operation':'ready','actor':'applicant','params':{},'query':{},'body':None,'capture':{},
         'headers':{'X-LEVEL':'${level}'},'checks':[{'id':'ready-http','pointer':'/status_code','op':'eq','expected':200}]},
        {'id':'save','operation':'save','actor':'applicant','params':{},'query':{},'body':{'documentNumber':''},'capture':{},
         'checks':[{'id':'save-http','pointer':'/status_code','op':'eq','expected':201},
                   {'id':'saved','assertion_id':'A-RESULT','pointer':'/body/accepted','op':'eq','expected':True}]}]}]
    return suite,adapter,plan


class SessionReportTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='workflow session 中文 ')
        self.root=Path(self.temp.name)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),HeaderHandler)
        self.server.seen=[];self.server.fail=True
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.suite,self.adapter,self.plan=assets(self.server.server_port)
        for ref,value in [('suite.json',self.suite),('adapter.json',self.adapter),('plan.json',self.plan)]:self.put(ref,value)
        self.spec={'suite':'suite.json','adapter':'adapter.json','plan':'plan.json','project_dir':'project',
                   'credentials_file':'private/tokens.json','execution_mode':'file_only'}
        self.put('session-spec.json',self.spec)
        self.values={'WF_DEMO_APPLICANT':'PRIVATE-TOKEN-CANARY','WF_CLIENT_ID':'PRIVATE-CLIENT-CANARY'}
        self.put('private/tokens.json',{'version':'1.0','env':self.values})

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join();self.temp.cleanup()
    def put(self,ref,value):
        p=self.root/ref;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
    def get(self,ref):return rt.read_json(self.root/ref,max_bytes=16*rt.MAX_BYTES)
    def call(self,action,**kw):return ms.perform(self.root,'session-spec.json',action,**kw)
    def ready(self):
        self.call('init');return self.call('prepare',case_id='TC-DEMO-1')
    def execute(self):return self.call('execute',case_id='TC-DEMO-1')

    def test_real_headers_report_and_credential_restoration(self):
        with patch.dict(os.environ,{'WF_DEMO_APPLICANT':'PREVIOUS-TOKEN'}):
            self.ready()
            result=self.execute()
            self.assertEqual(os.environ['WF_DEMO_APPLICANT'],'PREVIOUS-TOKEN')
        self.assertNotIn('WF_CLIENT_ID',os.environ)
        self.assertEqual(result['code'],'TEST_FAILED')
        self.assertEqual(len(self.server.seen),2)
        sent=[{k.lower():v for k,v in r['headers'].items()} for r in self.server.seen]
        self.assertEqual(sent[0]['x-level'],'step');self.assertEqual(sent[1]['x-level'],'actor')
        self.assertEqual(sent[0]['x-client-id'],self.values['WF_CLIENT_ID'])
        self.assertEqual(sent[0]['authorization'],'Bearer '+self.values['WF_DEMO_APPLICANT'])
        self.assertNotIn('idempotency-key',sent[0]);self.assertIn('idempotency-key',sent[1])
        report=self.call('report')['data']['report']
        text=(self.root/report).read_text(encoding='utf-8')
        for part in ('文件编制','happy_path','P0','FAIL','期望值','实际值','文档编号不能为空','/documents','400','201','save-http','ready-http','POST','GET'):
            self.assertIn(part,text)
        for base in ('runs','project','.session-calls','.session-replies'):
            for p in (self.root/base).rglob('*'):
                if p.is_file():
                    content=p.read_text(encoding='utf-8')
                    for secret in self.values.values():self.assertNotIn(secret,content,str(p))

    def test_credentials_read_once_per_execution_not_static_or_completed_reuse(self):
        original=rt.read_json
        reads=[]
        def read(path,*a,**kw):
            if Path(path).name=='tokens.json':reads.append(path)
            return original(path,*a,**kw)
        with patch.object(rt,'read_json',side_effect=read):
            self.ready();self.assertEqual(reads,[])
            self.execute();self.assertEqual(len(reads),1)
            (self.root/'private/tokens.json').unlink()
            again=self.execute();self.assertTrue(again['data']['reused_evidence'])
            self.assertEqual(len(reads),1)
        self.assertEqual(len(self.server.seen),2)

    def test_missing_tokens_block_before_intent_and_no_parent_env_fallback(self):
        self.ready();self.put('private/tokens.json',{'version':'1.0','env':{}})
        with patch.dict(os.environ,self.values), self.assertRaises(rt.ToolError) as error:self.execute()
        self.assertEqual(error.exception.code,'CREDENTIALS_INVALID')
        self.assertEqual(self.server.seen,[])
        self.assertFalse((self.root/'project/attempts/TC-DEMO-1/0001/intent.json').exists())

    def test_direct_and_direct_runtime_execution_rejected_even_with_fresh_receipt(self):
        self.ready()
        execute=self.get('project/attempts/TC-DEMO-1/0001/execute.request.json')
        with self.assertRaises(rt.ToolError) as error:tc.dispatch(self.root,execute)
        self.assertEqual(error.exception.code,'SESSION_REQUIRED')
        plan=self.get('project/attempts/TC-DEMO-1/0001/plan.json')
        with self.assertRaises(rt.ToolError) as error:
            rt.run_plan(self.root,self.suite,self.adapter,plan,rt.validate_bundle(self.suite,self.adapter,plan),'RAW',
                        execution_context={'project':'project/project.json','receipt':execute['arguments']['context_receipt'],'phase':'execute'})
        self.assertEqual(error.exception.code,'SESSION_REQUIRED')
        self.assertEqual(self.server.seen,[])

    def test_execute_cannot_skip_prepare_or_reconcile(self):
        self.call('init')
        with self.assertRaises(rt.ToolError):self.execute()
        self.call('prepare',case_id='TC-DEMO-1')
        self.put('project/attempts/TC-DEMO-1/0001/intent.json',{'kind':'execute'})
        with self.assertRaises(rt.ToolError) as error:self.execute()
        self.assertEqual(error.exception.code,'ATTEMPT_BLOCKED');self.assertEqual(self.server.seen,[])

    def test_prepare_retries_still_require_explicit_note(self):
        self.ready();self.execute()
        with self.assertRaises(rt.ToolError) as error:self.call('prepare',case_id='TC-DEMO-1')
        self.assertEqual(error.exception.code,'RETRY_REQUIRED')
        self.assertEqual(len(self.server.seen),2)

    def test_session_runs_required_refresh_and_diagnosis(self):
        prepared=self.ready()
        trace=self.get(prepared['data']['session_log'])
        self.assertEqual([x['tool'] for x in trace['calls']],['context_refresh','flow_prepare','flow_diagnose'])
        result=self.execute();trace=self.get(result['data']['session_log'])
        self.assertEqual([x['tool'] for x in trace['calls']],['flow_diagnose','context_refresh','flow_execute'])

    def test_pass_reason_and_execution_metadata_remain_historical(self):
        self.server.fail=False
        self.ready();self.assertEqual(self.execute()['code'],'OK')
        self.suite['cases'][0]['title']='变更后的业务标题'
        self.put('suite.json',self.suite)
        report=self.call('report')['data']['report'];text=(self.root/report).read_text(encoding='utf-8')
        self.assertIn('全部步骤完成',text)
        self.assertIn('### TC-DEMO-1 — 文件编制',text)
        self.assertIn('变更后的业务标题',text)

    def test_report_tool_includes_same_detailed_evidence(self):
        self.ready();result=self.execute()
        reply=tc.dispatch(self.root,fw.request('report',run_id=result['data']['run_id'],out='run-report.md'))
        text=(self.root/reply['data']['report']).read_text(encoding='utf-8')
        self.assertIn('文档编号不能为空',text);self.assertIn('save-http',text)

    def test_headers_reserved_duplicates_injection_and_unknown_variables_rejected(self):
        for headers in [{'Authorization':'Bearer literal'}, {'X-a':'ok','x-A':'bad'}, {'X-a':'a\r\nHost:evil'},
                        {'Host':'evil'}, {'X-api-key':'literal'}, {'X-a':{'env':'PATH\n'}}, {'Idempotency-Key':'override'}]:
            adapter=copy.deepcopy(self.adapter);adapter['headers']=headers
            with self.assertRaises(rt.ToolError):rt.validate_adapter(adapter)
        plan=copy.deepcopy(self.plan);plan['cases'][0]['steps'][0]['headers']={'X-Client':'${unknown}'}
        with self.assertRaises(rt.ToolError):rt.validate_bundle(self.suite,self.adapter,plan)

    def test_header_precedence_and_fingerprint(self):
        op=self.adapter['operations']['ready']
        self.assertEqual(bh.merged(self.adapter,op,'applicant')['x-level'],'operation')
        before=rt.validate_bundle(self.suite,self.adapter,self.plan)['fingerprint']
        self.adapter['headers']['X-New']='static'
        self.assertNotEqual(before,rt.validate_bundle(self.suite,self.adapter,self.plan)['fingerprint'])

    def test_reserved_process_env_in_credentials_refused(self):
        self.adapter['actors']['applicant']['bearer_token_env']='PATH'
        self.put('private/tokens.json',{'version':'1.0','env':{**self.values,'PATH':'do-not-install'}})
        with self.assertRaises(rt.ToolError) as error:
            with ms.credentials(self.root,'private/tokens.json',self.adapter,self.plan):pass
        self.assertEqual(error.exception.code,'CREDENTIALS_INVALID')

    def test_malformed_credential_error_never_echoes_values(self):
        self.ready()
        self.put('private/tokens.json',{'PRIVATE-TOKEN-CANARY':'wrong-format'})
        with self.assertRaises(rt.ToolError) as error:self.execute()
        self.assertNotIn('PRIVATE-TOKEN-CANARY',str(error.exception))

    def test_init_migrates_existing_completed_project_without_deleting_evidence(self):
        self.put('legacy.json',{k:self.spec[k] for k in ('suite','adapter','plan')})
        tc.dispatch(self.root,fw.request('flow_init',spec='legacy.json',out='project'))
        tc.dispatch(self.root,fw.request('runtime_init',project='project/project.json',out='project/runtime/legacy'))
        self.call('init')
        self.assertEqual(self.get('project/project.json')['session_spec'],'session-spec.json')
        self.assertEqual(self.get('.workflow-runtime.json')['sessions']['project/project.json'],'session-spec.json')
        self.call('prepare',case_id='TC-DEMO-1')

    def test_no_mutable_credential_values_are_written_to_argv(self):
        self.ready();original=subprocess.Popen;args_seen=[]
        def capture(*args,**kw):args_seen.append(args[0]);return original(*args,**kw)
        with patch.object(subprocess,'Popen',side_effect=capture):self.execute()
        self.assertTrue(args_seen)
        for args in args_seen:
            for secret in self.values.values():self.assertNotIn(secret,' '.join(args))

    def test_new_schema_exports_and_policy_headers(self):
        root=Path(tc.__file__).resolve().parents[1]
        self.assertEqual(rt.read_json(root/'assets/http.schema.json'),http_schema.schema())
        self.assertIn('headers',http_schema.schema()['$defs']['Adapter']['properties'])
        self.assertIn('headers',http_schema.schema()['$defs']['Step']['properties'])

    def test_report_cell_escapes_markup_and_marks_large_values(self):
        self.assertNotIn('<script>',reporting.cell('<script>bad</script>'))
        self.assertIn('已截短',reporting.cell('x'*1001))
        self.assertEqual(reporting.cell(None),'null')

    def test_cli_control_uses_session_file_and_preserves_failure_exit(self):
        for action,expected in [('init',0),('prepare',0),('execute',10),('report',0)]:
            args=['--session',str(self.root/'session-spec.json'),'--action',action]
            if action in ('prepare','execute'):args+=['--case-id','TC-DEMO-1']
            output=io.StringIO()
            with contextlib.redirect_stdout(output):code=session_cli.main(args)
            self.assertEqual(code,expected,output.getvalue())
            self.assertLess(len(output.getvalue().encode('utf-8')),4096)
            self.assertNotIn('PRIVATE-',output.getvalue())

    def test_powershell_session_path_with_spaces_and_cjk(self):
        shell=shutil.which('powershell') or shutil.which('pwsh')
        if not shell:self.skipTest('PowerShell unavailable')
        script=Path(tc.__file__).with_name('Invoke-WorkflowSession.ps1')
        for action,expected in [('init',0),('prepare',0),('execute',10),('report',0)]:
            args=[shell,'-NoProfile','-File',str(script),'-Session',str(self.root/'session-spec.json'),'-Action',action.upper()]
            if action in ('prepare','execute'):args+=['-CaseId','TC-DEMO-1']
            result=subprocess.run(args,capture_output=True,encoding='utf-8',timeout=30)
            self.assertEqual(result.returncode,expected,result.stdout+result.stderr)
            self.assertNotIn('PRIVATE-',result.stdout)
            self.assertIn('response_file',json.loads(result.stdout))

    def test_powershell_missing_session_fails_without_interactive_prompt(self):
        shell=shutil.which('powershell') or shutil.which('pwsh')
        if not shell:self.skipTest('PowerShell unavailable')
        result=subprocess.run([shell,'-NoProfile','-NonInteractive','-File',str(Path(tc.__file__).with_name('Invoke-WorkflowSession.ps1'))],
                              capture_output=True,encoding='utf-8',timeout=10)
        self.assertEqual(result.returncode,2,result.stderr)
        self.assertEqual(json.loads(result.stdout)['code'],'SESSION_REQUIRED')

    def test_legacy_metadata_only_filled_from_unchanged_preparation_source(self):
        self.ready();result=self.execute()
        source=self.root/result['data']['results'];raw=self.get(result['data']['results'])
        raw['cases'][0].pop('metadata');self.put(result['data']['results'],raw)
        source.with_suffix('.sha256').write_text(hashlib.sha256(source.read_bytes()).hexdigest(),encoding='ascii')
        first=self.call('report')['data']['report']
        self.assertIn('经哈希验证的准备来源',(self.root/first).read_text(encoding='utf-8'))
        self.suite['cases'][0]['title']='不同的新版标题';self.put('suite.json',self.suite)
        second=self.call('report')['data']['report'];text=(self.root/second).read_text(encoding='utf-8')
        self.assertIn('### TC-DEMO-1 — 历史证据未保存标题',text)

    def test_migration_does_not_invalidate_pending_legacy_attempt(self):
        self.put('legacy.json',{k:self.spec[k] for k in ('suite','adapter','plan')})
        tc.dispatch(self.root,fw.request('flow_init',spec='legacy.json',out='project'))
        tc.dispatch(self.root,fw.request('flow_prepare',project='project/project.json',case_id='TC-DEMO-1'))
        with self.assertRaises(rt.ToolError) as error:self.call('init')
        self.assertEqual(error.exception.code,'ATTEMPT_BLOCKED')
        self.assertNotIn('session_spec',self.get('project/project.json'))

    def test_execution_exception_restores_environment(self):
        with patch.dict(os.environ,{'WF_CLIENT_ID':'previous'}):
            with self.assertRaises(RuntimeError):
                with ms.credentials(self.root,'private/tokens.json',self.adapter,self.plan):
                    self.assertEqual(os.environ['WF_CLIENT_ID'],self.values['WF_CLIENT_ID'])
                    raise RuntimeError('test interruption')
            self.assertEqual(os.environ['WF_CLIENT_ID'],'previous')

    def test_dynamic_header_injection_is_rejected_before_http(self):
        self.plan['cases'][0]['vars']['level']='bad\r\nHost:evil'
        self.put('plan.json',self.plan)
        self.ready();result=self.execute()
        self.assertEqual(result['code'],'EXECUTION_ERROR')
        self.assertEqual(self.server.seen,[])

    def test_case_headers_and_step_precedence_over_real_http(self):
        self.plan['cases'][0]['headers']={'X-Level':'case','X-Case':'${case_id}',
                                         'X-Case-Client':{'env':'WF_CASE_CLIENT'}}
        self.values['WF_CASE_CLIENT']='PRIVATE-CASE-CLIENT'
        self.put('private/tokens.json',{'version':'1.0','env':self.values})
        self.put('plan.json',self.plan)
        self.ready();result=self.execute()
        first,second=[{k.lower():v for k,v in x['headers'].items()} for x in self.server.seen]
        self.assertEqual(first['x-level'],'step')
        self.assertEqual(second['x-level'],'case')
        self.assertEqual(second['x-case'],'TC-DEMO-1')
        self.assertEqual(second['x-case-client'],'PRIVATE-CASE-CLIENT')
        self.assertNotIn('PRIVATE-CASE-CLIENT',(self.root/result['data']['results']).read_text(encoding='utf-8'))

    def test_case_headers_reject_unknown_variable_and_reserved_header(self):
        for headers in ({'X-Case':'${captured_later}'},{'Authorization':'forbidden'},
                        {'X-Case':'a','x-case':'b'}):
            with self.subTest(headers=headers):
                self.plan['cases'][0]['headers']=headers
                with self.assertRaises(rt.ToolError):rt.validate_bundle(self.suite,self.adapter,self.plan)
        self.assertEqual(self.server.seen,[])

    def test_generated_policy_keeps_business_headers(self):
        import capabilities
        path=self.root/'api.md';path.write_text('# Readiness\nGET /ready\n',encoding='utf-8')
        policy={k:v for k,v in self.adapter.items() if k not in ('operations','schema_version')}
        policy.update(policy_version='1.0',allow=[{'methods':['GET'],'path_prefix':'/ready',
                                                 'actors':['applicant'],'request_guards':[]}],deny=[])
        catalog=capabilities.discover(path,'api.md')
        compiled,_=capabilities.compile_adapter(catalog,policy)
        self.assertEqual(compiled['headers'],self.adapter['headers'])
        self.assertEqual(compiled['actors']['applicant']['headers'],{'x-level':'actor'})


if __name__=='__main__':unittest.main()
