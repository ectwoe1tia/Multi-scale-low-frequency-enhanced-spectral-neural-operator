"""Behavioral tests for discovery, document evidence, enforced policy and trace execution."""
import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import capabilities as cap
import http_runner as rt
import intake
import intake_demo
import toolchain
import trace_tools
import suite as suite_tools
import intake_schema
from demo_support import DemoServer, make_assets


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='workflow-intake-')
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def call(self, tool, **arguments):
        return toolchain.dispatch(self.root, {'protocol_version': '1.0', 'tool': tool, 'arguments': arguments})['data']

    def fixture(self, port=8765):
        intake_demo.fixture_inputs(self.root / 'inputs', port)
        self.call('api_discover', source='inputs/apifox.md', out='catalog.json')
        self.call('adapter_build', catalog='catalog.json', policy='inputs/policy.json', out='compiled')
        return cap.load_adapter(self.root, self.root / 'compiled/adapter.json')

    def dump(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    def imported_suite(self):
        self.call('document_import', source='inputs/cases.docx', out='document.json')
        self.dump('manifest.json', {'project': '测试', 'platform': 'custom', 'documents': [{'document': 'document.json', 'role': 'test_cases'}]})
        self.call('cases_build', manifest='manifest.json', out='cases')
        return rt.read_json(self.root / 'cases/suite.json')


class CapabilityTests(WorkspaceTests):
    def test_apifox_common_declarations_and_code_examples(self):
        source = self.root / 'export.md'
        source.write_text('# GET 查询\nGET /api/items/{id}\n\n## 删除\n**请求方式**：DELETE\n**请求地址**：https://uat.example.invalid/api/items/{id}\n\n```curl\nPOST /not-a-declaration\n```\n', encoding='utf-8')
        catalog = cap.discover(source, 'export.md')
        self.assertEqual({(op['method'], op['path']) for op in catalog['operations']}, {('GET', '/api/items/{id}'), ('DELETE', '/api/items/{id}')})
        self.assertTrue(all(op['evidence'][0]['line'] > 0 for op in catalog['operations']))

    def test_duplicate_endpoints_have_stable_ids_and_merged_evidence(self):
        path = self.root / 'api.md'
        path.write_text('# 查询\nGET /items/{id}\nGET /items/{id}\n', encoding='utf-8')
        first = cap.discover(path, 'api.md')['operations']
        self.assertEqual(len(first), 1)
        self.assertEqual(len(first[0]['evidence']), 2)
        path.write_text('# 换了名称\nGET /items/{id}\n', encoding='utf-8')
        self.assertEqual(first[0]['id'], cap.discover(path, 'api.md')['operations'][0]['id'])

    def test_apifox_parameter_sections_remain_bound_to_endpoint(self):
        source = self.root / 'api.md'
        source.write_text('# GET 获取单据\nGET /items/{id}\n\n## 请求参数\n|名称|位置|类型|必填|\n|---|---|---|---|\n|id|path|string|是|\n\n## 返回结果\n|状态码|含义|\n|200|成功|\nHTTP 状态码: 200\n', encoding='utf-8')
        operation = cap.discover(source, 'api.md')['operations'][0]
        self.assertEqual(operation['parameters'][0]['name'], 'id')
        self.assertEqual(operation['response_statuses'], [200])

    def test_invalid_route_is_reported_and_no_silent_permission(self):
        path = self.root / 'api.md'
        path.write_text('GET /ok\nDELETE //evil.invalid/path\nPOST /a/../b\n', encoding='utf-8')
        catalog = cap.discover(path, 'api.md')
        self.assertEqual(len(catalog['operations']), 1)
        self.assertEqual(len(catalog['issues']), 2)

    def test_policy_deny_and_readonly_actually_remove_operations(self):
        adapter = self.fixture()
        self.assertEqual(len(adapter['operations']), 3)
        policy = rt.read_json(self.root / 'inputs/policy.json')
        policy['allow'] = [{'methods': ['GET', 'POST', 'DELETE'], 'path_prefix': '/', 'actors': ['applicant'], 'request_guards': []}]
        policy['allow_mutations'] = False
        catalog = rt.read_json(self.root / 'catalog.json')
        compiled, decisions = cap.compile_adapter(catalog, policy)
        self.assertEqual({op['method'] for op in compiled['operations'].values()}, {'GET'})
        self.assertIn('denied_by_policy', {d['decision'] for d in decisions})

    def test_prefix_respects_segments_and_overlap_narrows_roles(self):
        self.fixture()
        policy = rt.read_json(self.root / 'inputs/policy.json')
        rule = {'methods': ['POST'], 'path_prefix': '/', 'actors': ['manager'], 'request_guards': []}
        policy['allow'].append(rule)
        adapter, decisions = cap.compile_adapter(rt.read_json(self.root / 'catalog.json'), policy)
        self.assertNotIn(cap.operation_id('POST', '/instances'), adapter['operations'])
        self.assertEqual(adapter['operations'][cap.operation_id('POST', '/tasks/{task_id}/complete')]['actors'], ['manager'])
        self.assertFalse(cap.matches({'methods': ['GET'], 'path_prefix': '/instances'}, {'method': 'GET', 'path': '/instances-admin'}))

    def test_policy_changed_invalidates_generated_adapter(self):
        self.fixture()
        policy = rt.read_json(self.root / 'inputs/policy.json')
        policy['allow_mutations'] = False
        self.dump('inputs/policy.json', policy)
        with self.assertRaises(rt.ToolError) as raised:
            cap.load_adapter(self.root, self.root / 'compiled/adapter.json')
        self.assertEqual(raised.exception.code, 'STALE_SOURCE')

    def test_api_source_changed_requires_rediscovery(self):
        self.fixture()
        with (self.root / 'inputs/apifox.md').open('a', encoding='utf-8') as handle:
            handle.write('\nGET /new\n')
        with self.assertRaises(rt.ToolError) as raised:
            cap.load_adapter(self.root, self.root / 'compiled/adapter.json')
        self.assertEqual(raised.exception.code, 'STALE_SOURCE')

    def test_editing_generated_capabilities_is_rejected(self):
        adapter = self.fixture()
        adapter['operations'][cap.operation_id('POST', '/instances')]['request_guards'] = []
        self.dump('compiled/adapter.json', adapter)
        with self.assertRaises(rt.ToolError) as raised:
            cap.load_adapter(self.root, self.root / 'compiled/adapter.json')
        self.assertEqual(raised.exception.code, 'POLICY_DENIED')

    def test_guards_do_not_treat_missing_as_null_or_bool_as_number(self):
        op = {'request_guards': [{'target': 'body', 'pointer': '/tenant', 'op': 'eq', 'expected': None}]}
        with self.assertRaises(rt.ToolError):
            cap.enforce_guards(op, {'body': {}})
        cap.enforce_guards(op, {'body': {'tenant': None}})
        op['request_guards'][0].update(op='in', expected=[1])
        with self.assertRaises(rt.ToolError):
            cap.enforce_guards(op, {'body': {'tenant': True}})

    def test_unknown_policy_fields_and_dynamic_constraints_are_rejected(self):
        self.fixture()
        policy = rt.read_json(self.root / 'inputs/policy.json')
        policy['allow'][0]['script'] = 'anything'
        with self.assertRaises(rt.ToolError):
            cap.validate_policy(policy)
        with self.assertRaises(rt.ToolError):
            cap.validate_guards([{'target': 'body', 'pointer': '/tenant', 'op': 'eq', 'expected': '${tenant}'}])

    def test_workspace_traversal_and_overwriting_imports_are_rejected(self):
        self.fixture()
        with self.assertRaises(rt.ToolError):
            self.call('api_discover', source='inputs/apifox.md', out='../outside.json')
        with self.assertRaises(FileExistsError):
            self.call('api_discover', source='inputs/apifox.md', out='catalog.json')


class DocumentTests(WorkspaceTests):
    def test_chinese_word_table_import_preserves_evidence_and_cases(self):
        self.fixture()
        suite = self.imported_suite()
        self.assertEqual(len(suite['cases']), 2)
        self.assertEqual(suite['cases'][0]['title'], '推进到财务待办')
        self.assertTrue(all(case['status'] == 'ready' for case in suite['cases']))
        self.assertTrue(all(case['automation']['status'] == 'unbound' for case in suite['cases']))
        self.assertIn('table:1/row:2', suite['sources'][0]['location'])
        self.assertEqual(suite_tools.validate(suite)[0], [])

    @unittest.skipUnless(intake.pdf_backend(), 'PDF backend not installed')
    def test_real_pdf_text_and_page_location(self):
        intake_demo.pdf_file(self.root / 'case.pdf', ['Title: Approve purchase', 'Preconditions: Test server running',
                                                   'Actors: applicant', 'Steps: Submit purchase', 'Expected: manager'])
        result = self.call('document_import', source='case.pdf', out='pdf.json')
        self.assertEqual(result['blocks'], 1)
        doc = rt.read_json(self.root / 'pdf.json')
        self.assertEqual(doc['blocks'][0]['location'], 'page:1')
        self.assertEqual(intake.candidates(doc)[0]['fields']['expected'], 'manager')

    @unittest.skipUnless(intake.pdf_backend(), 'PDF backend not installed')
    def test_blank_pdf_is_not_silently_read(self):
        intake_demo.pdf_file(self.root / 'blank.pdf', [])
        result = self.call('document_import', source='blank.pdf', out='pdf.json')
        self.assertIn('OCR_REQUIRED', {w['code'] for w in result['warnings']})

    def test_missing_pdf_dependency_is_structured_error(self):
        intake_demo.pdf_file(self.root / 'case.pdf', ['Hello'])
        with patch.object(intake, 'pdf_backend', return_value=None):
            with self.assertRaises(rt.ToolError) as raised:
                self.call('document_import', source='case.pdf', out='pdf.json')
        self.assertEqual(raised.exception.code, 'DEPENDENCY_MISSING')
        self.assertFalse((self.root / 'pdf.json').exists())

    def test_changed_source_and_forged_evidence_are_rejected(self):
        (self.root / 'case.md').write_text('Title: Test\nExpected: OK', encoding='utf-8')
        self.call('document_import', source='case.md', out='doc.json')
        doc = rt.read_json(self.root / 'doc.json')
        forged = copy.deepcopy(doc)
        forged['blocks'][0]['text'] = 'Title: changed by model'
        with self.assertRaises(rt.ToolError) as raised:
            intake.verify_document(self.root, forged)
        self.assertEqual(raised.exception.code, 'EVIDENCE_CHANGED')
        (self.root / 'case.md').write_text('Title: New', encoding='utf-8')
        with self.assertRaises(rt.ToolError) as raised:
            intake.verify_document(self.root, doc)
        self.assertEqual(raised.exception.code, 'STALE_SOURCE')

    def test_freeform_and_missing_expectation_remain_unresolved(self):
        (self.root / 'rough.md').write_text('金额较大时应增加审批。审批需要及时处理。', encoding='utf-8')
        self.call('document_import', source='rough.md', out='doc.json')
        suite, report = intake.build_cases(self.root, {'project': '粗略需求', 'platform': 'unknown', 'documents': [{'document': 'doc.json', 'role': 'requirements'}]})
        self.assertEqual(suite['cases'][0]['status'], 'needs_clarification')
        self.assertFalse(report['coverage_complete'])
        self.assertEqual(suite_tools.validate(suite)[0], [])

    def test_conflicting_documents_do_not_auto_confirm(self):
        for i, expected in enumerate(['manager', 'finance']):
            (self.root / ('case%d.md' % i)).write_text('Title: Approval\nPreconditions: seeded\nActors: applicant\nSteps: submit\nExpected: ' + expected, encoding='utf-8')
            self.call('document_import', source='case%d.md' % i, out='doc%d.json' % i)
        suite, report = intake.build_cases(self.root, {'project': '冲突', 'platform': 'custom', 'documents': [{'document': 'doc%d.json' % i, 'role': 'test_cases'} for i in range(2)]})
        self.assertTrue(all(case['status'] == 'needs_clarification' for case in suite['cases']))
        self.assertTrue(all(rule['status'] == 'conflicting' for rule in suite['requirements']))
        self.assertEqual(suite_tools.validate(suite)[0], [])

    def test_word_external_entities_and_legacy_doc_are_rejected(self):
        with zipfile.ZipFile(self.root / 'bad.docx', 'w') as archive:
            archive.writestr('word/document.xml', '<!DOCTYPE x [<!ENTITY e SYSTEM "file:///secret">]><x/>')
        with self.assertRaises(rt.ToolError):
            self.call('document_import', source='bad.docx', out='out.json')
        (self.root / 'old.doc').write_bytes(b'old-format')
        with self.assertRaises(rt.ToolError) as raised:
            self.call('document_import', source='old.doc', out='out.json')
        self.assertEqual(raised.exception.code, 'UNSUPPORTED_FORMAT')

    def test_corrupt_docx_and_xml_produce_document_errors(self):
        (self.root / 'corrupt.docx').write_bytes(b'not-a-zip')
        with self.assertRaises(rt.ToolError) as raised:
            self.call('document_import', source='corrupt.docx', out='out.json')
        self.assertEqual(raised.exception.code, 'DOCUMENT_READ_ERROR')
        with zipfile.ZipFile(self.root / 'malformed.docx', 'w') as archive:
            archive.writestr('word/document.xml', '<unclosed>')
        with self.assertRaises(rt.ToolError) as raised:
            self.call('document_import', source='malformed.docx', out='out.json')
        self.assertEqual(raised.exception.code, 'DOCUMENT_READ_ERROR')

    def test_multiline_steps_and_empty_cells_keep_valid_case_assets(self):
        (self.root / 'case.md').write_text('Title: Test\nPreconditions: Seeded\nActors: applicant\nSteps:\n1. Submit\n2. Approve\nExpected: manager', encoding='utf-8')
        doc = intake.extract(self.root / 'case.md', 'case.md')
        self.assertIn('2. Approve', intake.candidates(doc)[0]['fields']['steps'])
        intake_demo.word_file(self.root / 'blank.docx', [['用例名称', '步骤', '预期结果', '角色', '前置条件'], ['待补用例', '', '成功', '', '']])
        self.call('document_import', source='blank.docx', out='blank.json')
        suite, _ = intake.build_cases(self.root, {'project': '空白', 'platform': 'unknown', 'documents': [{'document': 'blank.json', 'role': 'test_cases'}]})
        self.assertEqual(suite['cases'][0]['status'], 'needs_clarification')
        self.assertEqual(suite_tools.validate(suite)[0], [])


class TraceTests(WorkspaceTests):
    def test_har_auth_is_dropped_and_observations_are_not_assertions(self):
        self.fixture()
        self.call('trace_import', source='inputs/session.har', out='trace.json')
        text = (self.root / 'trace.json').read_text(encoding='utf-8')
        self.assertNotIn('historical-token-do-not-copy', text)
        self.assertNotIn('historical-body-token', text)
        self.assertNotIn('old-observed-output', text)
        trace = rt.read_json(self.root / 'trace.json')
        self.assertTrue(trace['observations_only'])
        self.assertEqual(len(trace['entries']), 7)

    def test_matching_requires_correct_host_and_method(self):
        adapter = self.fixture()
        trace = trace_tools.import_trace(self.root / 'inputs/session.har', 'inputs/session.har')
        entry = trace['entries'][0]
        self.assertEqual(len(trace_tools.matches(entry, adapter)), 1)
        entry['origin'] = 'https://other.invalid'
        self.assertEqual(trace_tools.matches(entry, adapter), [])

    def test_known_credentials_are_redacted_even_under_other_keys(self):
        self.dump('secret.har', {'log': {'entries': [{'request': {'method': 'POST', 'url': 'https://uat.invalid/api?token=query-canary',
            'headers': [{'name': 'Authorization', 'value': 'Bearer auth-canary'}],
            'postData': {'mimeType': 'application/json', 'text': json.dumps({'token': 'body-canary', 'note': 'auth-canary body-canary query-canary'})}},
            'response': {'status': 200}}]}})
        serialized = rt.canonical(trace_tools.import_trace(self.root / 'secret.har', 'secret.har'))
        for canary in ('auth-canary', 'body-canary', 'query-canary'):
            self.assertNotIn(canary, serialized)

    def test_recorded_inputs_not_used_without_explicit_binding(self):
        adapter = self.fixture()
        suite = self.imported_suite()
        trace = trace_tools.import_trace(self.root / 'inputs/session.har', 'inputs/session.har')
        binding = rt.read_json(self.root / 'inputs/binding.json')
        plan, report = trace_tools.build_plan(self.root, suite, adapter, trace, binding)
        self.assertEqual(plan['cases'][0]['steps'][0]['body'], {'amount': '${amount}', 'tenant': 'qa'})
        self.assertEqual(plan['cases'][0]['steps'][0]['checks'][0]['expected'], 201)
        self.assertEqual(trace['entries'][0]['observed_status'], 200)
        del binding['cases'][0]['steps'][0]['body']
        with self.assertRaises(rt.ToolError):
            trace_tools.build_plan(self.root, suite, adapter, trace, binding)

    def test_har_form_body_and_duplicate_query_are_not_replayed(self):
        adapter = self.fixture()
        self.dump('bad.har', {'log': {'entries': [{'request': {'method': 'POST', 'url': adapter['base_url'] + '/instances?a=1&a=2',
                  'postData': {'mimeType': 'application/x-www-form-urlencoded', 'text': 'password=canary'}}, 'response': {'status': 200}}]}})
        trace = trace_tools.import_trace(self.root / 'bad.har', 'bad.har')
        self.assertIn('UNSUPPORTED_REQUEST_BODY', trace['entries'][0]['issues'])
        self.assertIn('DUPLICATE_QUERY_KEYS', trace['entries'][0]['issues'])
        self.assertEqual(trace_tools.matches(trace['entries'][0], adapter), [])
        self.assertNotIn('canary', rt.canonical(trace))

    def test_recorder_discards_values_and_does_not_execute_expressions(self):
        self.dump('recording.json', {'steps': [{'type': 'change', 'selectors': [['input[value=secret-value]']], 'value': 'secret-value'},
                                              {'type': 'waitForExpression', 'expression': 'malicious-code()'}]})
        trace = trace_tools.import_trace(self.root / 'recording.json', 'recording.json')
        self.assertNotIn('secret-value', rt.canonical(trace))
        self.assertNotIn('malicious-code', rt.canonical(trace))
        self.assertEqual(trace['entries'][1]['issues'], ['EXPRESSION_NOT_EXECUTED'])

    def test_recorder_can_bind_registered_http_action(self):
        adapter = self.fixture()
        suite = self.imported_suite()
        self.dump('recorder.json', {'steps': [{'type': 'click'}, {'type': 'click'}, {'type': 'click'}, {'type': 'navigate'}]})
        trace = trace_tools.import_trace(self.root / 'recorder.json', 'recorder.json')
        binding = rt.read_json(self.root / 'inputs/binding.json')
        binding['cases'] = binding['cases'][:1]
        ops = [('POST', '/instances'), ('POST', '/tasks/{task_id}/complete'), ('POST', '/tasks/{task_id}/complete'), ('GET', '/instances/{instance_id}')]
        for number, (step, op) in enumerate(zip(binding['cases'][0]['steps'], ops), 1):
            step['entry_id'] = 'E%05d' % number
            step['operation'] = cap.operation_id(*op)
        plan, report = trace_tools.build_plan(self.root, suite, adapter, trace, binding)
        self.assertEqual(len(plan['cases'][0]['steps']), 4)
        self.assertFalse(report['browser_executed'])
        del binding['cases'][0]['steps'][0]['operation']
        with self.assertRaises(rt.ToolError):
            trace_tools.build_plan(self.root, suite, adapter, trace, binding)

    def test_all_document_assertions_are_still_required(self):
        adapter = self.fixture()
        suite = self.imported_suite()
        trace = trace_tools.import_trace(self.root / 'inputs/session.har', 'inputs/session.har')
        binding = rt.read_json(self.root / 'inputs/binding.json')
        del binding['cases'][0]['steps'][-1]['checks'][1]['assertion_id']
        with self.assertRaises(rt.ToolError):
            trace_tools.build_plan(self.root, suite, adapter, trace, binding)


class IntakeExecutionTests(WorkspaceTests):
    def test_exported_schemas_and_request_examples_are_current(self):
        self.assertEqual(rt.read_json(ROOT / 'assets/tool-request.schema.json'), toolchain.protocol_schema())
        self.assertEqual(rt.read_json(ROOT / 'assets/intake.schema.json'), intake_schema.schema())
        for source in (ROOT / 'assets').glob('*.request.json'):
            toolchain.validate_request(rt.read_json(source))
        cap.validate_policy(rt.read_json(ROOT / 'assets/project-policy.example.json'))

    @unittest.skipUnless(intake.pdf_backend(), 'PDF backend not installed')
    def test_real_full_chain_with_word_pdf_and_har(self):
        result = intake_demo.run_demo(self.root / 'demo', 'DEMO-TEST')
        self.assertEqual(result['summary'], {'PASS': 2, 'FAIL': 0, 'ERROR': 0})
        self.assertEqual(result['http_calls'], 7)
        self.assertEqual(result['not_selected_cases'], ['TC-IMP-003'])

    def test_dynamic_project_guard_stops_request_before_transport(self):
        with DemoServer() as server:
            suite, adapter, plan = make_assets(server.server_address[1])
            plan['cases'] = plan['cases'][:1]
            adapter['operations']['create']['request_guards'] = [{'target': 'body', 'pointer': '/tenant', 'op': 'eq', 'expected': 'qa'}]
            case = plan['cases'][0]
            case['vars']['tenant'] = 'production-tenant'
            case['steps'][0]['body']['tenant'] = '${tenant}'
            preview = rt.validate_bundle(suite, adapter, plan)
            with patch.dict(os.environ, intake_demo.AUTH):
                result = rt.run_plan(self.root, suite, adapter, plan, preview, 'DENIED-RUN')
            self.assertEqual(result['status'], 'ERROR')
            self.assertEqual(result['cases'][0]['error']['code'], 'POLICY_DENIED')
            self.assertEqual(server.calls, [])

    def test_captured_id_is_guarded_before_second_side_effect(self):
        with DemoServer() as server:
            suite, adapter, plan = make_assets(server.server_address[1])
            plan['cases'] = plan['cases'][:1]
            adapter['operations']['complete']['request_guards'] = [{'target': 'params', 'pointer': '/task_id', 'op': 'eq', 'expected': 'permitted-task'}]
            preview = rt.validate_bundle(suite, adapter, plan)
            with patch.dict(os.environ, intake_demo.AUTH):
                result = rt.run_plan(self.root, suite, adapter, plan, preview, 'CAPTURE-GUARD')
            self.assertEqual(result['status'], 'ERROR')
            self.assertEqual(len(server.calls), 1)
            self.assertEqual(server.calls[0][1], '/instances')

    def test_new_tools_work_through_powershell_json_protocol(self):
        self.fixture()
        request = {'protocol_version': '1.0', 'tool': 'document_import', 'arguments': {'source': 'inputs/cases.docx', 'out': '中文 evidence.json'}}
        self.dump('request.json', request)
        if os.name == 'nt':
            command = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'RemoteSigned', '-File', str(ROOT / 'scripts/Invoke-WorkflowTool.ps1'), '-Workspace', str(self.root), '-Request', str(self.root / 'request.json'), '-Python', sys.executable]
        else:
            command = [sys.executable, str(ROOT / 'scripts/toolchain.py'), '--workspace', str(self.root), '--request', str(self.root / 'request.json')]
        result = subprocess.run(command, capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['code'], 'OK')
        self.assertTrue((self.root / '中文 evidence.json').is_file())


if __name__ == '__main__':
    unittest.main()
