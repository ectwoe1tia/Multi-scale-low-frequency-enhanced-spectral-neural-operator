# Workflow Testing v6.1 · 20261019

本包在 v6-1018 基础上兼容扩展，runner 为 6.1.0。旧包保留，没有自动安装或连接公司业务系统。先读 [设计](DESIGN.md) 和 [验证报告](REPORT.md)，执行时按需读 [语义工具契约](workflow-testing/references/semantic.md)。

1. 在公司 workspace 建立 `file-set.json`，用 includes 组合配置、HAR、Recorder；源文件按实体分片，避免一次超大 HAR。
2. 按实际平台配置 `profile.json`：哪些字段定义变量、哪些字段引用变量、哪些表达式属于受支持语法、哪些约束有业务依据。assets 中均为示例，不直接当公司业务规则。
3. 用 `semantic_compile` 生成索引，再用 `semantic_query` 查询当前字段或异常。完整数据与 SQLite 不读入聊天。
4. 将多个工具请求列入 `batch.json`，配置依赖和预算，通过下面的固定入口执行；额度或上下文不足时，保存原命令和状态路径即可接续。
5. 用 `semantic_propose` 留候选，你确认后才生成 review，再 `semantic_promote` 为 recipe。让 `semantic_check` 成为后续批次的前置条件。

```powershell
& 'E:\tools\workflow-testing\scripts\Invoke-WorkflowBatch.ps1' -Batch 'E:\company\workspace\batch.json' -State 'batch-state/run-001'
```

替换为本机实际路径。批次根文件位于 workspace 根目录；其他引用相对该根。默认不允许 execute；实际业务执行须在授权范围内使用 file_only session，并显式配置 allow_execute。批次内实际请求仍经过 v6 会话入口。

文件 schema 位于 `workflow-testing/assets/semantic.schema.json`；字段入口通过 `tool_help` 按工具查询，完整 describe 保存文件。旧功能和会话调用方法仍见 [managed-session.md](workflow-testing/references/managed-session.md)。

本包带有可复验的合成演示，见 REPORT.md 的证据链接。演示 review 明确是测试 fixture，不代表你已确认任何公司的真实关系。

本地复验：在 workflow-testing 目录运行 `python -X utf8 -m unittest discover -s tests -v` 和 `python -X utf8 scripts/check_boundaries.py`。完整演示从交付根目录运行 `python -X utf8 verification/verify.py <未存在的输出目录名>`。

接力只交接 workspace、v6.1/6.1.0、根 batch 路径、State 路径、当前候选与诊断引用。FAILED/UNKNOWN 不能删状态或换 run_id 绕过；先核对原证据。公司平台语法适配、独立评审与真实业务验收仍需后续完成。
