"""Verify declared scope, retain v6, release own claim and package v6.1."""
import hashlib,json,re,sys,zipfile
from pathlib import Path
here=Path(__file__).resolve().parent;delivery=here.parent;skill=delivery/'workflow-testing';final=here/'published'
sys.path.insert(0,str(skill/'scripts'))
import toolchain as tc
import http_runner as rt
import v5_common
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
validation=read(final/'validation.json');m=validation['metrics']
assert all(x['exit_code']==0 for x in validation['checks'])
log=(final/'regression.stderr.log').read_text(encoding='utf-8')
assert re.search(r'Ran 208 tests',log) and log.strip().endswith('OK')
assert rt.VERSION=='6.1.0'
source=read(here/'source-manifest.json');before=source['files']
assert all(sha(Path(source['source'])/ref)==value for ref,value in before.items()),'v6 source changed'
change=read(here/'change-request.json');changed=[];added=[]
for p in skill.rglob('*'):
 if not p.is_file() or '__pycache__' in p.parts or '.coordination' in p.parts:continue
 ref=p.relative_to(skill).as_posix()
 if ref not in before:added.append(ref)
 elif sha(p)!=before[ref]:changed.append(ref)
assert set(changed)<=set(change['changed_files']),set(changed)-set(change['changed_files'])
assert set(added)==set(change['new_files']),(added,change['new_files'])
assert all((skill/ref).exists() for ref in before),'Unexpected deletion'
report=f'''# v6.1 实现与验证报告 · 20261019

在 v6-1018 上兼容扩展为 **v6.1 / runner 6.1.0**。旧 v6 源文件逐一核对哈希未变，协议仍为 1.0。设计与边界见 [DESIGN.md](DESIGN.md)，实操见 [语义契约](workflow-testing/references/semantic.md)。

## 已实现

| 需求 | 交付 |
|---|---|
| 大配置预提取 | 文件集合 includes、严格 JSON/嵌套 JSON、受限表达式 AST、显式 profile、符号表与依赖图 |
| 减少重复解析 | 内容/profile/实现摘要绑定的分片缓存；源码变化后拒绝旧索引，重建时复用未变文件 |
| 只分析当前关系 | SQLite 固定查询，依赖/反向影响切片，分页、字节/深度/边预算；默认不导出标量 |
| 异常与乱码 | 类型/范围/枚举、非法字符、可疑编码、重复/未解析符号、嵌套 JSON 错误和不支持语法标记 |
| 逐步猜测与确认 | 相等字符串候选或显式假设，绑定来源/证据，用户确认后生成声明式 recipe；不自动采纳 |
| 可复用约束 | equal/same_type/depends_on/co_occurs 固定解释器；拒绝添加或删除已确认断言，新 profile/代码/范围须重新确认 |
| 大量调用与接力 | 组合批次 DAG、任务预算、持久状态、回执哈希；独立静态查询并行，写请求串行；失败/不确定阻断 |

新增 6 个注册静态工具：semantic_compile/query/diff/propose/promote/check；总计 46 个工具。批次 CLI 编排这些注册工具与 v6 受管会话，不提供万能 shell 或任意 SQL 入口。新模块使用标准库 ast/sqlite3，没有新增 pip 依赖。

## 实际验证

**208 项回归全部通过**，包括原有 182 项和新增 26 项。静态边界检查覆盖 11 个模块并通过，Skill 格式校验通过。新测试包括真正的 PowerShell 调用和本地回环 HTTP，验证了凭据/执行保护沿用、重复批次不重发、失败前置条件不推进、缓存损坏/来源漂移/未确认规则拒绝、输出实际字节预算。

较大配置演示全部通过文件与独立进程调用：

| 项目 | 实测 |
|---|---:|
| 配置 + HAR + Recorder 输入 | {m['input_bytes']:,} 字节 |
| 索引节点 / 边 | {m['index_counts']['nodes']} / {m['index_counts']['edges']} |
| 静态任务 | {m['tasks']} |
| 分批调用次数 | {m['batch_invocations']} |
| 4 次终端输出合计 | {m['batch_stdout_total_bytes']} 字节 |
| 单次终端最大输出 | {m['batch_stdout_max_bytes']} 字节 |
| 当前依赖查询文件最大值 | {m['query_bytes_max']} 字节 |
| 相同输入再次构建 | 缓存命中 {m['cached_files']} 文件，重新解析 {m['reparse_files_on_identical_build']} 文件 |
| 本地批次演示耗时 | {m['elapsed_batch_seconds']} 秒 |
| 业务网络请求 | 0 |

演示保留 2 个一对多候选，不自动选一个因果关系。为了验证生成和检查链路，演示使用明确标记的 **synthetic fixture review**；不是你对公司真实关系的确认。乱码检测数量为按来源位置计数，不代表独立业务问题数量。

这是输出字节、缓存和本机耗时测量，不是模型 token 计费、准确率或真实公司流程覆盖的测量。每次查询仍有来源哈希校验成本。

## 验证证据与接续

- [命令、退出码与指标](verification/published/validation.json)
- [最终回归日志](verification/published/regression.stderr.log)
- [合成批次根文件](verification/published/demo/batch.json)
- [38 项任务最终状态](verification/published/demo/batch-state/demo/state.json)
- [字段依赖样例](verification/published/demo/answers/q0.json)
- [乱码问题定位样例](verification/published/demo/answers/issues.json)
- [候选文件](verification/published/demo/knowledge/candidates.json)
- [确认后生成的声明式 recipe](verification/published/demo/knowledge/recipe-v1/recipe.json)
- [recipe 检查结果](verification/published/demo/checks/first.json)

早期演示的预期把一对多匹配错误写成单匹配，已调整 fixture 保留两个候选；缓存损坏测试原先可能破坏已失效的旧分片，现已确保验证正在使用的分片。最终发布证据以 published 目录为准，没有为通过而把业务失败改写成通过。

## 尚未实现或验证

没有任意 JavaScript/UEL/Java 源码编译器、完整控制流/SSA/别名求解、自动业务因果发现、运行时埋点或自动浏览器执行。表达式提取的是保守读取依赖；未知内容保持 OPAQUE/UNKNOWN。业务异常需要明确 profile，疑似乱码不自动修复。

单文件 32 MiB、集合 256 MiB、节点 200,000，按文件加载内存；更大的输入需要项目导出器分片，本版不是流式超大 HAR 引擎。确定性代码不能凭配置证明所有运行行为。

用户确认由本地 review 文件记录，程序无法认证填写者确为人；生产使用需接公司评审/权限流程。批次前置 recipe 检查仅约束采用该批次的调用；旧的独立 session 不会自动新增这个前置条件。

**独立评审 pending；公司业务验收 not_executed。** 没有读取公司凭据、调用公司接口、改宿主策略或自动安装 Skill。
'''
(delivery/'REPORT.md').write_text(report,encoding='utf-8')
change.update(status='implemented_and_locally_verified',version='v6.1',runner_version=rt.VERSION,date='20261019',
 validation={'status':'passed','tests':208,'evidence':'verification/published/validation.json'},
 review={'status':'pending','reviewer':''},next_action='接入公司脱敏配置和实际平台 profile；按疑点查询，待用户确认候选，再生成 recipe 并接入批次前置条件。')
save(here/'change-request.json',change);save(skill/'change-request.json',change)
token=read(here/'lease.json')['data']['lease_token']
release=tc.dispatch(skill,{'protocol_version':'1.0','tool':'release','arguments':{'lease_token':token}})
assert release['ok'];save(here/'release.json',release)
save(delivery/'handoff.json',{'version':'v6.1','runner_version':rt.VERSION,'date':'20261019','protocol':'1.0',
 'status':'implemented_and_locally_verified','tests':{'passed':208,'failed':0},'registered_tools':46,
 'source_v6_unchanged':True,'maintenance_lease_released':True,'generator_digest':v5_common.generator_digest(),
 'entry':'START_HERE.md','design':'DESIGN.md','report':'REPORT.md','validation':'verification/published/validation.json',
 'metrics':m,'independent_review':'pending','company_acceptance':'not_executed',
 'resume':'Keep workspace, version, root batch path, state path, current query and pending candidate refs. Never expand whole graph/config into chat.',
 'next':'Provide platform-specific sanitized fixtures and profile; review hypotheses before generating reusable recipes.'})
def included(p):
 if not p.is_file() or '__pycache__' in p.parts or '.coordination' in p.parts or p.name in ('lease.json','maintenance-lease.json','MANIFEST.sha256.json'):return False
 rel=p.relative_to(delivery).parts
 # Intermediate synthetic runs are disposable; keep their check logs for audit only.
 if len(rel)>2 and rel[0]=='verification' and rel[1] in ('final','final2','release'):
  return len(rel)==3 and p.suffix=='.log'
 return True
files=sorted(p for p in delivery.rglob('*') if included(p))
save(delivery/'MANIFEST.sha256.json',{p.relative_to(delivery).as_posix():sha(p) for p in files})
files.append(delivery/'MANIFEST.sha256.json')
archive=delivery.parent/'workflow-testing-v6.1-delivery-20261019.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,'workflow-testing-v6.1/'+p.relative_to(delivery).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for ref,h in read(delivery/'MANIFEST.sha256.json').items():assert hashlib.sha256(z.read('workflow-testing-v6.1/'+ref)).hexdigest()==h,ref
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'version':'v6.1','date':'20261019',
 'files':len(files),'changed_existing':len(set(changed)|{'change-request.json'}),'new_files':len(added),'tests':208,
 'lease_released':True,'source_v6_unchanged':True}
save(archive.with_suffix('.receipt.json'),receipt)
print(json.dumps(receipt,ensure_ascii=False))
