"""Value-free diagnosis and explicitly bounded evidence projection. No execution."""
import json
import re

import http_runner as rt
import file_workflow as fw
import v5_common as c

TERMINAL = {'PASS', 'FAIL', 'ERROR'}
ACTIONS = {
    'TODO': 'refresh_prepare', 'PREPARED': 'review_then_refresh_execute',
    'UNKNOWN': 'reconcile_side_effects', 'INCOMPLETE': 'reconcile_side_effects',
    'PASS': 'continue_status', 'FAIL': 'inspect_failed_checks', 'ERROR': 'inspect_execution_error',
    'ABANDONED': 'review_explicit_retry', 'CANCELLED': 'review_explicit_retry',
}


def _bytes(value):
    return len(rt.canonical(value).encode('utf-8'))


def _output(root, args, value, budget):
    _, directory = c.project(root, args['project'])
    rt.need(directory in rt.workspace_path(root, args['out']).parents,
            'Diagnostic output must stay inside the project')
    rt.need(_bytes(value) <= budget, 'Narrow the query; output exceeds budget', 'QUERY_TOO_LARGE')
    # Budget applies to the actual pretty-printed file as well as its JSON content.
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n'
    rt.need(len(raw.encode('utf-8')) <= budget, 'Narrow the query; output exceeds budget', 'QUERY_TOO_LARGE')
    for ref, digest in (c.READS.get() or {}).items():
        rt.need(c.hash_file(root, ref) == digest, 'Evidence changed during inspection', 'STALE_INPUT')
    c.write(root, args['out'], value)
    return {'result': args['out'], 'bytes': len(raw.encode('utf-8')), 'network_executed': False}


def _load(root, args):
    p, directory = c.project(root, args['project'])
    cid = args['case_id']
    rt.need(cid in p['cases'], 'Unknown case_id')
    nums = fw.attempts(root, directory, cid)
    number = args.get('attempt', nums[-1] if nums else None)
    if number is None:
        return p, directory, None, {'status': 'TODO'}, None
    rt.need(number in nums, 'Attempt not found')
    ad = fw.attempt_dir(root, directory, cid, number)
    # Capture metadata/checksum/intent dependencies before consulting authoritative state.
    for name in ('meta.json', 'intent.json', 'resolution.json'):
        if (ad / name).is_file():
            c.read(root, c.relative(root, ad / name))
    meta = c.read(root, c.relative(root, ad / 'meta.json')) if (ad / 'meta.json').is_file() else None
    if meta:
        ref = 'runs/' + meta['run_id'] + '/results.json'
        for item in (ref, ref[:-5] + '.sha256'):
            if rt.workspace_path(root, item).is_file():
                c.remember(root, item)
    state = fw.evidence(root, directory, cid, number)
    return p, directory, ad, state, meta


def _source(root, args, artifact, loaded):
    _, _, ad, state, meta = loaded
    rt.need(ad is not None and meta is not None, 'No prepared evidence for this attempt', 'EVIDENCE_UNAVAILABLE')
    if artifact == 'results':
        rt.need(state['status'] in TERMINAL, 'Unsealed execution must be reconciled; no value query', 'EVIDENCE_UNAVAILABLE')
        ref = state['results']
    else:
        ref = c.relative(root, ad / (artifact + '.json'))
    value = c.read(root, ref)
    digest = c.hash_file(root, ref)
    if artifact == 'plan':
        rt.need(digest == meta['plan_hash'], 'Prepared plan changed', 'EVIDENCE_CHANGED')
    if artifact == 'preview':
        rt.need(value.get('fingerprint') == meta['fingerprint'], 'Preview identity changed', 'EVIDENCE_CHANGED')
    if artifact == 'results':
        checksum = c.relative(root, rt.workspace_path(root, ref).with_suffix('.sha256'))
        expected = rt.workspace_path(root, checksum, existing=True).read_text(encoding='ascii').strip()
        rt.need(digest == expected, 'Run evidence changed during read', 'EVIDENCE_CHANGED')
        rt.need(value.get('run_id') == meta['run_id'] and value.get('fingerprint') == meta['fingerprint'],
                'Run identity changed', 'EVIDENCE_CHANGED')
    return ref, digest, value


def diagnose(root, args):
    loaded = _load(root, args)
    _, directory, ad, state, meta = loaded
    status = state['status']
    result = {'diagnostic_version': '1.0', 'case_id': args['case_id'],
              'attempt': state.get('attempt'), 'status': status,
              'action': ACTIONS[status], 'automatic_retry': False,
              'network_executed': False, 'artifacts': {}, 'findings': [],
              'resume_request': c.relative(root, directory / 'requests/status.json')}
    if not meta:
        return _output(root, args, result, 8192)
    # Plan, unlike preview, has a checksum bound by preparation metadata.
    ref, digest, plan = _source(root, args, 'plan', loaded)
    result['artifacts']['plan'] = {'ref': ref, 'sha256': digest}
    steps = plan['cases'][0]['steps']
    result['prepared'] = {'steps': len(steps), 'checks': sum(len(s['checks']) for s in steps),
                          'details_pointer': '/cases/0/steps',
                          'first_steps': [{'step_id': s['id'], 'operation': s['operation'],
                                           'actor': s['actor'], 'checks': len(s['checks'])}
                                          for s in steps[:5]]}
    # Source drift is a finding, not an excuse to overwrite or re-prepare an existing attempt.
    changed = [ref for ref, old in meta['source_hashes'].items()
               if not rt.workspace_path(root, ref).is_file() or c.hash_file(root, ref) != old]
    if changed:
        result['findings'].append({'code': 'SOURCE_DRIFT', 'count': len(changed), 'refs': changed[:5]})
        if status == 'PREPARED':
            result['action'] = 'cancel_stale_preparation_then_review_retry'
    if status in TERMINAL:
        ref, digest, raw = _source(root, args, 'results', loaded)
        result['artifacts']['results'] = {'ref': ref, 'sha256': digest}
        cases = [(i, case) for i, case in enumerate(raw['cases']) if case['case_id'] == args['case_id']]
        rt.need(len(cases) == 1, 'Execution case identity mismatch', 'EVIDENCE_CHANGED')
        i, case = cases[0]
        failures = case.get('failures', [])
        result['execution'] = {'status': case['execution_status'], 'gate': case['gate'],
                               'failure_count': len(failures),
                               'unexecuted_step_count': len(case.get('unexecuted_steps', []))}
        result['failed_checks'] = [
            {'step_id': f['step_id'], 'check_id': f['check_id'], 'assertion_id': f.get('assertion_id'),
             'evidence_pointer': '/cases/%d/failures/%d' % (i, j)}
            for j, f in enumerate(failures[:5])]
        if len(failures) > 5:
            result['findings'].append({'code': 'MORE_FAILURES_ON_DISK', 'remaining': len(failures) - 5})
        if 'error' in case:
            # Exception messages may contain actual response values: never copy them here.
            result['execution']['error_code'] = case['error'].get('code', 'EXECUTION_ERROR')
            result['execution']['error_pointer'] = '/cases/%d/error' % i
    elif status in ('UNKNOWN', 'INCOMPLETE'):
        result['findings'].append({'code': 'UNSEALED_EXECUTION', 'instruction': 'Inspect side effects and confirm old writer stopped before reconciliation.'})
    return _output(root, args, result, 8192)


def _kind(value):
    if value is rt.MISSING:
        return 'missing'
    if value is None:
        return 'null'
    if type(value) is bool:
        return 'boolean'
    if isinstance(value, dict):
        return 'object'
    if isinstance(value, list):
        return 'array'
    if isinstance(value, str):
        return 'string'
    return 'number'


def query(root, args):
    spec = c.read(root, args['query'])
    rt.shape(spec, ['artifact', 'sha256', 'pointers'], ['mode', 'max_bytes'], label='evidence query')
    rt.need(spec['artifact'] in ('plan', 'preview', 'results'), 'Unknown evidence artifact')
    expected_hash = spec['sha256']
    if isinstance(expected_hash, dict):
        rt.shape(expected_hash, ['$file', 'pointer'], label='digest reference')
        rt.text(expected_hash['$file'], 'digest file')
        rt.need(isinstance(expected_hash['pointer'], str) and expected_hash['pointer'].startswith('/')
                and len(expected_hash['pointer']) <= 240 and not re.search(r'~(?![01])', expected_hash['pointer']),
                'Invalid digest pointer')
        expected_hash = rt.json_pointer(c.read(root, expected_hash['$file']), expected_hash['pointer'])
    rt.need(isinstance(expected_hash, str) and re.fullmatch('[a-f0-9]{64}', expected_hash), 'SHA-256 required')
    pointers = spec['pointers']
    rt.need(isinstance(pointers, list) and 1 <= len(pointers) <= 8, 'Use 1..8 pointers')
    rt.need(all(isinstance(p, str) and len(p) <= 240 and (p == '' or p.startswith('/'))
                and not re.search(r'~(?![01])', p) for p in pointers), 'Invalid JSON pointer')
    rt.need(len(set(pointers)) == len(pointers), 'Duplicate pointers')
    mode, budget = spec.get('mode', 'structure'), spec.get('max_bytes', 2048)
    rt.need(mode in ('structure', 'value'), 'Mode must be structure or value')
    rt.need(type(budget) is int and 512 <= budget <= 8192, 'max_bytes must be 512..8192')
    loaded = _load(root, args)
    ref, digest, document = _source(root, args, spec['artifact'], loaded)
    rt.need(digest == expected_hash, 'Evidence revision changed; diagnose again', 'EVIDENCE_CHANGED')
    rows = []
    for pointer in pointers:
        value = rt.json_pointer(document, pointer)
        kind = _kind(value)
        row = {'pointer': pointer, 'type': kind}
        if kind != 'missing':
            row['bytes'] = _bytes(value)
        if kind in ('array', 'object', 'string'):
            row['length'] = len(value)
        if mode == 'value' and kind != 'missing':
            rt.need(kind not in ('array', 'object'), 'Container values stay on disk; query scalar pointers', 'QUERY_TOO_LARGE')
            # Check the complete decoded path, including parent keys.
            if rt.SECRET_KEYS.search(pointer.replace('~1', '/').replace('~0', '~')):
                row['value'] = '[REDACTED]'
            else:
                rt.need(_bytes(value) <= budget, 'Scalar exceeds budget; use structure mode', 'QUERY_TOO_LARGE')
                row['value'] = value
        rows.append(row)
    value = {'query_version': '1.0', 'case_id': args['case_id'], 'attempt': loaded[3].get('attempt'),
             'artifact': spec['artifact'], 'source': {'ref': ref, 'sha256': digest},
             'mode': mode, 'rows': rows, 'network_executed': False}
    return _output(root, args, value, budget)


def control_response(response, response_file):
    """Allowlist projection, never truncate/summarize arbitrary payload text."""
    code = response['code']
    action = {
        'CONTEXT_STALE': 'refresh_context', 'CONTEXT_REQUIRED': 'refresh_context',
        'TEST_FAILED': 'diagnose_case', 'EXECUTION_ERROR': 'diagnose_case',
        'ATTEMPT_BLOCKED': 'diagnose_then_reconcile', 'EVIDENCE_CHANGED': 'inspect_integrity',
        'OUTPUT_EXISTS': 'choose_new_response_path_without_resending_uncertain_write',
        'QUERY_TOO_LARGE': 'narrow_query', 'EFFECT_DENIED': 'report_code_boundary_violation',
    }.get(code, 'inspect_contract_or_receipt' if code != 'OK' else 'inspect_references')
    data = response.get('data') or {}
    references = {}
    if isinstance(data, dict):
        for key in ('result', 'focus', 'context', 'refresh_request', 'next_request',
                    'resume_request', 'preview', 'execute_request', 'results', 'results_path','report','diagnosis','session_log'):
            value = data.get(key)
            if isinstance(value, str) and len(value.encode('utf-8')) <= 512:
                references[key] = value
    result = {'protocol_version': '1.0', 'tool': response['tool'][:80], 'ok': response['ok'],
              'code': code, 'action': action, 'automatic_retry': False,
              'response_file': response_file, 'refs': references}
    if len(json.dumps(result, ensure_ascii=False, allow_nan=False).encode('utf-8')) > 4096:
        result['refs'] = {}
    if len(json.dumps(result, ensure_ascii=False, allow_nan=False).encode('utf-8')) > 4096:
        result['response_file'] = None
    return result
