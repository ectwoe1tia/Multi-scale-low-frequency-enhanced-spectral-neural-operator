"""Reproducible local verification; all large inputs/outputs stay in files."""
import hashlib,json,shutil,subprocess,sys,time
from pathlib import Path
here=Path(__file__).resolve().parent;delivery=here.parent;skill=delivery/'workflow-testing'
out=here/(sys.argv[1] if len(sys.argv)>1 else 'final');out.mkdir(exist_ok=False)
sys.path.insert(0,str(skill/'scripts'))
import toolchain as tc
import semantic_tools as st
def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2)
def run(label,cmd,expected=0,cwd=skill):
 started=time.monotonic()
 p=subprocess.run(cmd,cwd=cwd,capture_output=True,encoding='utf-8',timeout=240)
 (out/(label+'.stdout.log')).write_text(p.stdout,encoding='utf-8');(out/(label+'.stderr.log')).write_text(p.stderr,encoding='utf-8')
 if p.returncode!=expected:raise RuntimeError('Verification failed: '+label)
 return {'command':cmd,'exit_code':p.returncode,'seconds':round(time.monotonic()-started,3),'stdout_bytes':len(p.stdout.encode('utf-8'))}
checks=[run('regression',[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-v']),
 run('boundaries',[sys.executable,'-X','utf8','scripts/check_boundaries.py']),
 run('skill',[sys.executable,'-X','utf8',r'C:\Users\jing\.codex\skills\.system\skill-creator\scripts\quick_validate.py',str(skill)])]
root=out/'demo';root.mkdir()
def put(ref,value):save(root/ref,value)
def call(tool,**args):return tc.dispatch(root,{'protocol_version':'1.0','tool':tool,'arguments':args})
def req(name,tool,**args):put('requests/'+name+'.json',{'protocol_version':'1.0','tool':tool,'arguments':args})
config={'fields':{str(i):{'name':'f'+str(i),'value':i,'description':'业务配置说明'*100} for i in range(600)},
 'conditions':[{'expression':'form.f'+str(i)+' > 100'} for i in range(60)],'flowId':'FLOW-DEMO-12345678','abnormal':'坏\ufffd值'}
har={'log':{'entries':[{'request':{'postData':{'text':json.dumps({'flowId':'FLOW-DEMO-12345678','configuration':config},ensure_ascii=False)}}}]}}
recorder={'title':'合成录制','steps':[{'type':'click','selectors':[['#step-'+str(i)]]} for i in range(80)]}
for ref,data in [('inputs/config.json',config),('inputs/network.har',har),('inputs/recorder.json',recorder)]:put(ref,data)
put('set-a.json',{'version':'1.0','files':[{'id':'config','path':'inputs/config.json','kind':'json'}]})
put('file-set.json',{'version':'1.0','includes':['set-a.json'],'files':[
 {'id':'network','path':'inputs/network.har','kind':'har'},{'id':'ui','path':'inputs/recorder.json','kind':'recorder'}]})
profile=json.loads((skill/'assets/semantic-profile.example.json').read_text(encoding='utf-8'))
put('profile.json',profile);put('compile.json',{'file_set':'file-set.json','profile':'profile.json'})
req('compile','semantic_compile',spec='compile.json',out='analysis/first')
req('cached','semantic_compile',spec='compile.json',out='analysis/cached')
tasks=[{'id':'index','request':'requests/compile.json','depends_on':[]},
       {'id':'reuse','request':'requests/cached.json','depends_on':['index']}]
for i in range(36):
 put('queries/q'+str(i)+'.json',{'kind':'dependencies','node':{'file':'config','pointer':'/conditions/'+str(i)+'/expression'},'max_bytes':4096})
 req('q'+str(i),'semantic_query',index='analysis/first/manifest.json',query='queries/q'+str(i)+'.json',out='answers/q'+str(i)+'.json')
 tasks.append({'id':'query-'+str(i).zfill(2),'request':'requests/q'+str(i)+'.json','depends_on':['reuse']})
put('query-set.json',{'version':'1.0','tasks':tasks[2:]})
put('batch.json',{'version':'1.0','includes':['query-set.json'],'tasks':tasks[:2],'max_tasks':10,'max_seconds':30,'parallel_queries':3})
shell=shutil.which('powershell') or shutil.which('pwsh');calls=[]
for i in range(4):
 cmd=[shell,'-NoProfile','-File',str(skill/'scripts/Invoke-WorkflowBatch.ps1'),'-Batch',str(root/'batch.json'),'-State','batch-state/demo']
 calls.append(run('batch-'+str(i+1),cmd))
state=json.loads((root/'batch-state/demo/state.json').read_text(encoding='utf-8'))
assert all(x['status']=='DONE' for x in state['tasks'].values())
cache=json.loads((root/'analysis/cached/summary.json').read_text(encoding='utf-8'));assert cache['cached_files']==3 and cache['parsed_files']==0
put('seeds.json',{'seeds':[{'file':'config','pointer':'/flowId'}]})
call('semantic_propose',index='analysis/first/manifest.json',spec='seeds.json',out='knowledge/candidates.json')
props=json.loads((root/'knowledge/candidates.json').read_text(encoding='utf-8'));assert len(props['candidates'])==2
put('synthetic-review.json',{'proposals_sha256':hashlib.sha256((root/'knowledge/candidates.json').read_bytes()).hexdigest(),
 'reviewer':'synthetic-demo-fixture-not-user-approval','decisions':[{'id':h['id'],'decision':'accept'} for h in props['candidates']]})
call('semantic_promote',index='analysis/first/manifest.json',proposals='knowledge/candidates.json',review='synthetic-review.json',out='knowledge/recipe-v1')
assert call('semantic_check',index='analysis/first/manifest.json',recipe='knowledge/recipe-v1/recipe.json',out='checks/first.json')['data']['status']=='PASS'
put('issues-query.json',{'kind':'issues','code':'REPLACEMENT_CHARACTER','limit':3})
call('semantic_query',index='analysis/first/manifest.json',query='issues-query.json',out='answers/issues.json')
metrics={'input_bytes':sum((root/p).stat().st_size for p in ('inputs/config.json','inputs/network.har','inputs/recorder.json')),
 'tasks':len(tasks),'batch_invocations':4,'batch_stdout_total_bytes':sum(x['stdout_bytes'] for x in calls),
 'batch_stdout_max_bytes':max(x['stdout_bytes'] for x in calls),'cached_files':cache['cached_files'],
 'reparse_files_on_identical_build':cache['parsed_files'],'query_bytes_max':max(p.stat().st_size for p in (root/'answers').glob('q*.json')),
 'index_counts':cache['counts'],'business_network_calls':0,'candidate_count':len(props['candidates']),
 'approval_is_synthetic_fixture':True,'elapsed_batch_seconds':round(sum(x['seconds'] for x in calls),3)}
save(out/'validation.json',{'checks':checks,'batch_calls':calls,'metrics':metrics})
print(json.dumps(metrics,ensure_ascii=False))
